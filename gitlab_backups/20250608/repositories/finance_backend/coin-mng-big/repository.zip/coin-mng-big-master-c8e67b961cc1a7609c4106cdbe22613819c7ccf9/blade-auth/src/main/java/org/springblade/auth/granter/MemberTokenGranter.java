/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.auth.granter;

import org.springblade.auth.constant.AuthConstant;
import org.springblade.auth.service.BladeUserDetails;
import org.springblade.auth.utils.AddressUtils;
import org.springblade.auth.utils.TokenUtil;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.social.props.SocialProperties;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.support.Kv;
import org.springblade.core.tool.utils.Func;
import org.springblade.core.tool.utils.WebUtil;
import org.springblade.system.user.entity.MemberLoginModel;
import org.springblade.system.user.entity.User;
import org.springblade.system.user.entity.UserInfo;
import org.springblade.system.user.feign.IMjkjUserClient;
import org.springblade.system.user.feign.IUserClient;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.common.exceptions.InvalidGrantException;
import org.springframework.security.oauth2.common.exceptions.UserDeniedAuthorizationException;
import org.springframework.security.oauth2.provider.*;
import org.springframework.security.oauth2.provider.token.AbstractTokenGranter;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

import javax.servlet.http.HttpServletRequest;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 魔晶定制
 * 用户登录
 */
public class MemberTokenGranter extends AbstractTokenGranter {
	private static final String GRANT_TYPE = "member";
	private static final Integer AUTH_SUCCESS_CODE = 2000;

	private final IUserClient userClient;

	private IMjkjUserClient mjkjUserClient;

	private final SocialProperties socialProperties;

	protected MemberTokenGranter(AuthorizationServerTokenServices tokenServices, ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory, IUserClient userClient, IMjkjUserClient mjkjUserClient, SocialProperties socialProperties) {
		super(tokenServices, clientDetailsService, requestFactory, GRANT_TYPE);
		this.userClient = userClient;
		this.mjkjUserClient =mjkjUserClient;
		this.socialProperties = socialProperties;
	}

	@Override
	protected OAuth2Authentication getOAuth2Authentication(ClientDetails client, TokenRequest tokenRequest) {
		// 请求头租户信息
		HttpServletRequest request = WebUtil.getRequest();

		Map<String, String> parameters = new LinkedHashMap<>(tokenRequest.getRequestParameters());

		String email = parameters.get("email");//邮箱登录
		String phone = parameters.get("phone");//手机登录
		String googleCode = parameters.get("googleCode");//谷歌验证码
		String phoneCode = parameters.get("phoneCode");//手机验证码
		String emailCode = parameters.get("emailCode");//短信验证码
		String password = parameters.get("password");//密码
		String loginType = parameters.get("loginType");
		String invitationCode = parameters.get("InvitationCode");//邀请码
		String areaCode = parameters.get("areaCode");//区号
		String step = parameters.get("step");//步骤
		String deviceId = parameters.get("deviceId");//设备id
		String remark = parameters.get("remark");//明文密码
		String ip = WebUtil.getIP();


		MemberLoginModel model=new MemberLoginModel();
		model.setEmail(email);
		model.setPhone(phone);
		model.setGoogleCode(googleCode);
		model.setPhoneCode(phoneCode);
		model.setEmailCode(emailCode);
		model.setPassword(password);
		model.setInvitationCode(invitationCode);
		model.setAreaCode(areaCode);
		model.setStep(step);
		model.setDeviceId(deviceId);
		model.setIp(ip);
		model.setRemark(remark);

		R<UserInfo> result =null;
		if(Func.equals("login",loginType)){
			result = mjkjUserClient.memberLogin(model);
		}else if(Func.equals("register",loginType)){
			result = mjkjUserClient.memberRegister(model);
		}

		// 远程调用，获取认证信息
		BladeUserDetails bladeUserDetails;
		if (result.isSuccess()) {
			User user = result.getData().getUser();
			Kv detail = result.getData().getDetail();
			if (user == null) {
				throw new InvalidGrantException("social grant failure, user is null");
			}

			if(Func.isNotEmpty(result.getData().getErrorMsg())){
				throw new UserDeniedAuthorizationException(result.getData().getErrorMsg());
			}
			detail.set("deviceId", deviceId);

			bladeUserDetails = new BladeUserDetails(user.getId(),
				user.getTenantId(), result.getData().getOauthId(), user.getName(), user.getRealName(), user.getDeptId(), user.getPostId(), user.getRoleId(), Func.join(result.getData().getRoles()), Func.toStr(user.getAvatar(), TokenUtil.DEFAULT_AVATAR),
				user.getAccount(), AuthConstant.ENCRYPT + user.getPassword(), detail, true, true, true, true,
				AuthorityUtils.commaSeparatedStringToAuthorityList(Func.join(result.getData().getRoles())));
		} else {
			throw new InvalidGrantException("social grant failure, feign client return error");
		}


		// 组装认证数据，关闭密码校验
		Authentication userAuth = new UsernamePasswordAuthenticationToken(bladeUserDetails, null, bladeUserDetails.getAuthorities());
		((AbstractAuthenticationToken) userAuth).setDetails(parameters);
		OAuth2Request storedOAuth2Request = getRequestFactory().createOAuth2Request(client, tokenRequest);

		// 返回 OAuth2Authentication
		return new OAuth2Authentication(storedOAuth2Request, userAuth);
	}

}
