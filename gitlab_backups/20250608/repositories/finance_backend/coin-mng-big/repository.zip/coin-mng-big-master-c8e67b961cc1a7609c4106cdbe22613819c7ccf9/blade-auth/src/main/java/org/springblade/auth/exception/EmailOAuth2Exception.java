package org.springblade.auth.exception;

import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;

public class EmailOAuth2Exception extends OAuth2Exception {
	public EmailOAuth2Exception(String msg, Throwable t) {
		super(msg, t);
	}

	public EmailOAuth2Exception(String msg) {
		super(msg);
	}
}
