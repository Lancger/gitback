package org.springblade.auth.granter;

import org.springblade.auth.utils.TokenUtil;
import org.springblade.third.cache.CacheNames;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.utils.StringUtil;
import org.springblade.core.tool.utils.WebUtil;
import org.springblade.feign.IMjkjWebClient;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.exceptions.InvalidGrantException;
import org.springframework.security.oauth2.common.exceptions.UserDeniedAuthorizationException;
import org.springframework.security.oauth2.provider.*;
import org.springframework.security.oauth2.provider.token.AbstractTokenGranter;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;

import javax.servlet.http.HttpServletRequest;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 验证码TokenGranter
 *
 * @author Chill
 */
public class CaptchaTokenGranter extends AbstractTokenGranter {

	private static final String GRANT_TYPE = "captcha";

	private final AuthenticationManager authenticationManager;

	private BladeRedis bladeRedis;

	private IMjkjWebClient webClient;

	public CaptchaTokenGranter(AuthenticationManager authenticationManager,
							   AuthorizationServerTokenServices tokenServices,
							   ClientDetailsService clientDetailsService,
							   OAuth2RequestFactory requestFactory,
							   BladeRedis bladeRedis,
							   IMjkjWebClient webClient) {
		this(authenticationManager, tokenServices, clientDetailsService, requestFactory, GRANT_TYPE);
		this.bladeRedis = bladeRedis;
		this.webClient = webClient;
	}

	protected CaptchaTokenGranter(AuthenticationManager authenticationManager, AuthorizationServerTokenServices tokenServices,
								  ClientDetailsService clientDetailsService, OAuth2RequestFactory requestFactory, String grantType) {
		super(tokenServices, clientDetailsService, requestFactory, grantType);
		this.authenticationManager = authenticationManager;
	}

	@Override
	protected OAuth2Authentication getOAuth2Authentication(ClientDetails client, TokenRequest tokenRequest) {
		HttpServletRequest request = WebUtil.getRequest();
		// 增加验证码判断
		String key = request.getHeader(TokenUtil.CAPTCHA_HEADER_KEY);
		String code = request.getHeader(TokenUtil.CAPTCHA_HEADER_CODE);
		// 获取验证码
		String redisCode = bladeRedis.get(CacheNames.CAPTCHA_KEY + key);
		// 判断验证码
		if (code == null || !StringUtil.equalsIgnoreCase(redisCode, code)) {
			throw new UserDeniedAuthorizationException(TokenUtil.CAPTCHA_NOT_CORRECT);
		}

		Map<String, String> parameters = new LinkedHashMap<String, String>(tokenRequest.getRequestParameters());
		String username = parameters.get("username");
		String password = parameters.get("password");
		// Protect from downstream leaks of password
		parameters.remove("password");

		Authentication userAuth = new UsernamePasswordAuthenticationToken(username, password);
		((AbstractAuthenticationToken) userAuth).setDetails(parameters);
		try {
			userAuth = authenticationManager.authenticate(userAuth);
		} catch (AccountStatusException | BadCredentialsException ase) {
			//covers expired, locked, disabled cases (mentioned in section 5.2, draft 31)
			throw new InvalidGrantException(ase.getMessage());
		}
		// If the username/password are wrong the spec says we should send 400/invalid grant

		if (userAuth == null || !userAuth.isAuthenticated()) {
			throw new InvalidGrantException("Could not authenticate user: " + username);
		}

		OAuth2Request storedOAuth2Request = getRequestFactory().createOAuth2Request(client, tokenRequest);

		//邮箱验证
//		Kv details = ((BladeUserDetails) userAuth.getPrincipal()).getDetail();
//		String email = details.getStr("email");
//
//		if (StringUtil.isBlank(email)) {
//			throw new UserDeniedAuthorizationException("当前账户未绑定邮箱，请联系管理员");
//		}
//
//		// 获取验证码
//		String emailCode = request.getHeader(TokenUtil.EMAIL_HEADER_CODE);
//		String emailRedisCode = bladeRedis.get(CacheNames.EMAIL_KEY + email);
//		boolean debug = MjjyConfig.isDebug();
//		if (StringUtil.isBlank(emailCode)) {
//			String varCode = !debug ? Func.random(6, RandomType.INT) : "123456";
//			SendEmailParam param = new SendEmailParam();
//			param.setEmail(email);
//			param.setTitle("验证码");
//			param.setContent(Collections.singletonList("您的邮箱验证码为: " + varCode + " ,有效期为5分钟"));
//			if (!debug) {
//				Boolean bl = webClient.sendEmail(param);
//				if (bl == null || !bl) {
//					throw new UnapprovedClientAuthenticationException("发送邮箱验证码失败, 请稍后重试!");
//				}
//			}
//			bladeRedis.setEx(CacheNames.EMAIL_KEY + email, varCode, Duration.ofMinutes(5));
//			throw new EmailOAuth2Exception(email.replaceAll("(\\w?)(\\w+)(\\w)(@\\w+\\.[a-z]+(\\.[a-z]+)?)", "$1****$3$4"));
//		}
//		if (!StringUtil.equalsIgnoreCase(emailCode, emailRedisCode)) {
//			throw new UserDeniedAuthorizationException(TokenUtil.EMAIL_NOT_CORRECT);
//		}

		return new OAuth2Authentication(storedOAuth2Request, userAuth);
	}
}
