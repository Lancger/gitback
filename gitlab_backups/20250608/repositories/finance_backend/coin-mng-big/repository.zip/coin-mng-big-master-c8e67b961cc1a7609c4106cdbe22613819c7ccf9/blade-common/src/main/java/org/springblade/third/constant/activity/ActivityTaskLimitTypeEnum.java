package org.springblade.third.constant.activity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ActivityTaskLimitTypeEnum {

	/**
	 * (抽奖)任务完成次数限制：0-无限制，1-用户限制，2-用户每天限制
	 */
	NONE("无限制", 0),
	USER("用户限制", 1),
	USER_DAY("用户每天限制", 2),
	;

	final String name;
	final int status;
}
