package org.springblade.third.utils;

import java.math.BigDecimal;

/**
 * @author Watson
 * @date 2024/2/28 17:44
 */
public class ValidatorUtil {


	public static boolean verifyBigDecimal(BigDecimal val) {
		BigDecimal minValue = new BigDecimal("-9999999999.99999999");
		BigDecimal maxValue = new BigDecimal("9999999999.99999999");
		// 检查 val 是否在合理范围内
		if (val.compareTo(minValue) >= 0 && val.compareTo(maxValue) <= 0) {
			return true;
		}
		return false;
	}




}
