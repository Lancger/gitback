package org.springblade.third.constant.activity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ActivityTypeEnum {

	/**
	 * 1-抽奖活动，2-兑换活动
	 */
	RAFFLE("抽奖活动", 1),
	REDEEM("兑换活动", 2),
	;

	final String name;
	final int status;
}
