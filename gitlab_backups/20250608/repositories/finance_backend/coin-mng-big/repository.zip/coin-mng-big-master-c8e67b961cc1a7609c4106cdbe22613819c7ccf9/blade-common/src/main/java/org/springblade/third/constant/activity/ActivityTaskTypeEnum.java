package org.springblade.third.constant.activity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ActivityTaskTypeEnum {

	/**
	 * 任务类型：1-积分挑战任务，2-积分日常任务，3-抽奖活动任务
	 */
	REDEEM("积分挑战任务", 1),
	REDEEM_DAY("积分日常任务", 2),
	RAFFLE("抽奖活动任务", 3),
	;

	final String name;
	final int status;

	public static boolean isRaffle(int type){
		return type == RAFFLE.getStatus();
	}

	public static boolean isRedeem(int type){
		return type == REDEEM.getStatus();
	}


	public static boolean isRedeemDay(int type){
		return type == REDEEM_DAY.getStatus();
	}
}
