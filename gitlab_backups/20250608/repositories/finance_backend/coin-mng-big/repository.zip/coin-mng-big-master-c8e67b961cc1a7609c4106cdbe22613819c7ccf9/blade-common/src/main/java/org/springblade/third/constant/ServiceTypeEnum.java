package org.springblade.third.constant;


import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ServiceTypeEnum {
	DEPOSIT("充值", "1"),
	BUY("买入", "2"),
	MARKET_PROFIT("市值发放收益", "3"),
	OTC_BUY("OTC买入", "4"),
	INVITE_REWARD("直推奖励", "5"),
	BROKERAGE("市值维护佣金", "6"),
	CONTRACT_BACK("返还保证金", "7"),
	FEE("手续费", "8"),
	GIFT_CARD("活动礼品卡", "100"),
	CASH_GIFT("活动现金红包", "101"),
	FEE_CASHBACK("活动礼品卡", "100"),
	FEE_OFFSET("活动现金红包", "101"),

	//返佣
	REBATE_SPOT_FEE("现货手续费返佣", "201"),
	REBATE_USDT_M_FEE("U本位合约手续费返佣", "202"),
	REBATE_COIN_M_FEE("B本位合约手续费返佣", "203"),


	SUPPORT_DEPOSIT("客服充值", "999"),
	;

	final String name;
	final String status;
}
