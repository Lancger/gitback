package org.springblade.web.cache;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.utils.Func;
import org.springblade.third.cache.CacheNames;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 用来缓存币信息
 */
@Component
public class CoinCoinCache {
	@Autowired
	private BladeRedis bladeRedis;

	@Autowired
	private IMjkjBaseSqlService baseSqlService;

	/**
	 * 一次存入全部币信息
	 */
	public void refPutAll(IMjkjBaseSqlService baseSqlService, BladeRedis bladeRedis){
		QueryWrapper<Object> queryWrapper = new QueryWrapper<>();
		queryWrapper.eq("is_deleted",0);
		List<Map<String, Object>> coinCoin = baseSqlService.getDataListByFieldParams("coin_coin", queryWrapper);
		if (!Func.isEmpty(coinCoin)) {
			coinCoin.forEach(coinMap -> {
				// 作为key存入缓存
				String coinNameKey = MjkjUtils.getMap2Str(coinMap, "symbol");
				String jsonMap = JSON.toJSONString(coinMap);
				bladeRedis.set(CacheNames.SYS_COIN_COIN+coinNameKey, jsonMap);
			});
		}
	}

	/**
	 * 根据名称获取
	 * @param coinName
	 * @return
	 */
	public Map<String, Object> getCoinByName(String coinName) {
		if (coinName == null) {
			return null;
		}
		// 这里的coinName就是币名称
		Object object = bladeRedis.get(CacheNames.SYS_COIN_COIN + coinName);
		if (Func.isEmpty(object)) {
			QueryWrapper<Object> queryWrapper = new QueryWrapper<>();
			queryWrapper.eq("name", coinName);
			List<Map<String, Object>> coinCoin = baseSqlService.getDataListByFieldParams("coin_coin", queryWrapper);
			if (!Func.isEmpty(coinCoin)) {
				return coinCoin.get(0);
			}
			return null;
		}
		Map<String, Object> map = JSON.parseObject(object.toString(), Map.class);
		return map;
	}
}
