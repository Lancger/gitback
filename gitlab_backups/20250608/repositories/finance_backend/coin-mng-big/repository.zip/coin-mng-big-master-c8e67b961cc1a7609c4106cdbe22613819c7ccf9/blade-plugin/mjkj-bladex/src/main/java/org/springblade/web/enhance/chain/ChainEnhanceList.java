package org.springblade.web.enhance.chain;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.constant.WalletTypeEnum;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.feign.IMjkjWalletClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 *
 */
@Service("chainEnhanceList")
@AllArgsConstructor
public class ChainEnhanceList implements CgformEnhanceJavaListInter {

	private final IMjkjBaseSqlService sqlService;

	@Autowired
	private IMjkjWalletClient mjkjWalletClient;



	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);

		QueryWrapper<Object> wrapper = new QueryWrapper<>();
		wrapper.eq("is_deleted", 0);
		IPage<Map<String, Object>> pages = sqlService.getDataIPageByFieldParams("coin_chain_list", page, wrapper);
		if (Func.isEmpty(pages)) {
			MjkjUtils.setPageResult(params, pages);
			return;
		}
		List<Map<String, Object>> dataMapList = pages.getRecords();
		if (Func.isEmpty(dataMapList)) {
			MjkjUtils.setPageResult(params, pages);
			return;
		}
		for (Map<String, Object> dataMap : dataMapList) {
			String walletType = MjkjUtils.getMap2Str(dataMap, "wallet_type");
			if (WalletTypeEnum.Owner.toString().equalsIgnoreCase(walletType)) {
				try {
					String chainType = MjkjUtils.getMap2Str(dataMap, "chain_type");
					String coinSymbol = MjkjUtils.getMap2Str(dataMap, "coin_symbol");
					//校验
					QueryWrapper<Object> chainWrapper = new QueryWrapper<>();
					chainWrapper.eq("type", "1");//转出
					chainWrapper.eq("chain_type", chainType);//转出
					Map<String, Object> systemWalletMap = sqlService.getDataOneByFieldParams("coin_system_wallet", chainWrapper);//已弄111
					if (Func.isEmpty(systemWalletMap)) {
						throw new BusinessException("获取系统转出钱包失败");
					}
					//系统钱包地址
					String systemWalletAddress = MjkjUtils.getMap2Str(systemWalletMap, "wallet_address");
					systemWalletAddress = MjkjUtils.getDbJieMi(systemWalletAddress);//解密

					R<BigDecimal> chainBalanceR = mjkjWalletClient.getChainBalance(chainType, systemWalletAddress, coinSymbol);
					if (chainBalanceR.isSuccess()) {
						BigDecimal balance = chainBalanceR.getData();
						dataMap.put("txqbye", balance + " " + coinSymbol);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		MjkjUtils.setPageResult(params, pages);
	}
}
