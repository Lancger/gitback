package org.springblade.web.enhance.cwgl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.common.utils.UserRoleUtil;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.mapper.CwglMapper;
import org.springblade.web.service.IHtMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 财务管理-充值记录
 */
@Component("cwglCzjlEnhanceList")
public class CzjlEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private CwglMapper cwglMapper;
	@Autowired
	private IMjkjBaseSqlService sqlService;
	@Autowired
	private IHtMongoService mongoService;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		String userRole = AuthUtil.getUserRole();
		QueryWrapper<Object> queryWrapper = null;
		if (!userRole.contains("administrator")) {
			queryWrapper = new QueryWrapper<>();
			queryWrapper = UserRoleUtil.UserRole(queryWrapper, "deposit");
		}
		Page pages = cwglMapper.getCzjlPage(page, params,queryWrapper);
		List<Map<String, Object>> records = pages.getRecords();
		if (Func.isEmpty(records)) {
			HashMap<String, Object> hashMap = new HashMap<>();
			hashMap.put("sum", 0);
			params.put("dataOther", hashMap);
			return;
		}
		for (Map<String, Object> dataMap : records) {
			String amount = MjkjUtils.getMap2BigD(dataMap, "amount").stripTrailingZeros().toPlainString();
			String coinSymbol = MjkjUtils.getMap2Str(dataMap, "coin_symbol");
			dataMap.put("amount", amount + coinSymbol);
		}
		Page<Map<String, Object>> czjlPage = cwglMapper.getCzjlPage(new Page<>(1, -521), params,queryWrapper);
		List<Map<String, Object>> listMap = czjlPage.getRecords();
		BigDecimal reduce = listMap.parallelStream().map(m -> MjkjUtils.getMap2Str(m, "coin_symbol").equalsIgnoreCase("usdt") ?
				MjkjUtils.getMap2BigD(m, "amount") : MjkjUtils.getMap2BigD(m, "amount")
				.multiply(mongoService.getPriceBySymbol("xh", MjkjUtils.getMap2Str(m, "coin_symbol" + "/USDT"))))
			.reduce(BigDecimal.ZERO, BigDecimal::add);
		HashMap<String, Object> hashMap = new HashMap<>();
		hashMap.put("sum", reduce.toPlainString());
		MjkjUtils.setPageResult(params, pages, hashMap);
	}
}
