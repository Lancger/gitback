package org.springblade.web.enhance.file;

import com.alibaba.fastjson.JSONObject;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.model.file.FileLogModel;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.web.event.FileLogEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 文件列表-新增
 * 表明：mjkj_file_list
 */
@Component("fileListEnhanceEdit")
public class FileListEnhanceEdit implements CgformEnhanceJavaInter {

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private IMjkjBaseSqlService mjkjBaseSqlService;

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		Long id = jsonobject.getLong("id");
		Map<String, Object> pfileMap = mjkjBaseSqlService.getTableByIdL("mjkj_file_list", id);
		String  file_url= MjkjUtils.getMap2Str(pfileMap,"file_url");
		String  file_pwd=MjkjUtils.getMap2Str(pfileMap,"file_pwd");
		String  file_salt=MjkjUtils.getMap2Str(pfileMap,"file_salt");
		String  download_num=MjkjUtils.getMap2Str(pfileMap,"download_num");
		String  view_num=MjkjUtils.getMap2Str(pfileMap,"view_num");
		String  file_size=MjkjUtils.getMap2Str(pfileMap,"file_size");
		jsonobject.put("file_url",file_url);
		jsonobject.put("file_salt",file_salt);
		jsonobject.put("file_pwd",file_pwd);
		jsonobject.put("download_num",download_num);
		jsonobject.put("view_num",view_num);
		jsonobject.put("file_size",file_size);

		//写入预览记录
		FileLogModel logModel=new FileLogModel();
		logModel.setFile_id(id);
		logModel.setFile_title(MjkjUtils.getMap2Str(pfileMap,"title"));
		logModel.setOperate_user_id(AuthUtil.getUserId());
		logModel.setOperate_user_name(AuthUtil.getNickName());
		logModel.setTenant_id(AuthUtil.getTenantId());
		logModel.setRemark(AuthUtil.getNickName()+" 修改");
		logModel.setType("修改");
		applicationContext.publishEvent(new FileLogEvent(logModel));
		return 1;
	}


}
