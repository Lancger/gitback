package org.springblade.web.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.service.IMemberService;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;
import java.util.Map;

/**
 * Author: @Wai
 * Date: 2022-7-16
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("coin/agent")
@Api(value = "代理商管理", tags = "代理商管理")
public class MemberController {
	private final IMemberService memberService;

	@ApiOperationSupport(order = 1)
	@GetMapping("/statistics/all")
	@ApiOperation(value = "总统计", notes = "总统计")
	public R statistics() {
		Map<String, Object> statistics = memberService.allStatistics();
		return R.data(statistics);
	}

	@ApiOperationSupport(order = 1)
	@GetMapping("/statistics/member")
	@ApiOperation(value = "会员统计", notes = "会员统计")
	public R statisticsByDept(@ApiParam("开始时间") @RequestParam(required = false) String startTime,
							  @ApiParam("结束时间") @RequestParam(required = false) String endTime) {
		Map<String, Object> statistics = memberService.memberStatistics(startTime, endTime);
		return R.data(statistics);
	}

	@ApiOperationSupport(order = 1)
	@GetMapping("/records")
	@ApiOperation(value = "聊天记录", notes = "聊天记录")
	@ApiImplicitParams({
		@ApiImplicitParam(paramType = "query", name = "member_id", value = "会员id", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "pid", value = "三级代理id", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "content_type", value = "内容类型", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "order", value = "排序", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "column", value = "排序字段", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "pageNo", value = "起始页", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "pageSize", value = "每页数", dataType = "String")
	})
	public R records(@ApiIgnore @RequestParam(required = false) Map<String, Object> params) {
		IPage records = memberService.getRecords(params);
		return R.data(records);
	}
}
