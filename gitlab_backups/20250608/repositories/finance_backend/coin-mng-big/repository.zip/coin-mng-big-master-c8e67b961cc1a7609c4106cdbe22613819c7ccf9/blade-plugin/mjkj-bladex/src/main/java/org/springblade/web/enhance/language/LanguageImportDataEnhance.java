package org.springblade.web.enhance.language;

import com.alibaba.fastjson.JSONObject;
import lombok.RequiredArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.jackson.JsonUtil;
import org.springblade.core.tool.utils.Func;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 处理导入数据
 */
@Component("languageImportDataEnhance")
@RequiredArgsConstructor
public class LanguageImportDataEnhance implements CgformEnhanceJavaInter {
	private final IMjkjBaseSqlService mjkjBaseSqlService;

	@Autowired
	private BladeRedis bladeRedis;

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		String languageId = jsonobject.getString("language_id");//数据id
		String zh_cn = jsonobject.getString("zh_cn");//中文
		String zh_tw = jsonobject.getString("zh_tw");//繁体
		String en = jsonobject.getString("en");//英文

		String ko = jsonobject.getString("ko");//韩语
		String ja = jsonobject.getString("ja");//日语
		String th = jsonobject.getString("th");//泰语
		String pt = jsonobject.getString("pt");//葡语
		String fr = jsonobject.getString("fr");//法语
		String es = jsonobject.getString("es");//西班牙语



		Map<String, Object> languageMap = mjkjBaseSqlService.getTableById("coin_language", languageId);
		if(Func.isEmpty(languageMap)){
			return -1;
		}
		String attrPage = MjkjUtils.getMap2Str(languageMap, "attr_page");

		LanguageModel model=new LanguageModel();
		model.setZh_cn(zh_cn);
		model.setZh_tw(zh_tw);
		model.setEn(en);

		model.setKo(ko);
		model.setJa(ja);
		model.setTh(th);
		model.setPt(pt);
		model.setFr(fr);
		model.setEs(es);

		String text= JsonUtil.toJson(model);
		if(!Func.equals(attrPage,"ht_config")){
			text="return "+text;
		}

		//更新
		Map<String,Object> updateMap=new HashMap<>();
		updateMap.put("text",text);
		mjkjBaseSqlService.baseUpdateData("coin_language",updateMap,languageId);

		//清空缓存
		String CGFORM_ID_REDIS_KEY = "cgform:id:";
		Long headId = head.getId();
		String redisKey=CGFORM_ID_REDIS_KEY+headId;
		if(bladeRedis.exists(redisKey)){
			bladeRedis.del(redisKey);
		}
		return -1;
	}
}
