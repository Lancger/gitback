package org.springblade.web.enhance.language;

import lombok.Data;

@Data
public class LanguageModel {
	String zh_cn="";
	String zh_tw="";
	String en="";

	String ko="";//韩语
	String ja="";//日语
	String th="";//泰语
	String pt="";//葡语
	String fr="";//法语
	String es="";//西班牙语

}
