package org.springblade.web.enhance.contract;

import com.alibaba.fastjson.JSONObject;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.config.exception.BusinessException;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * 自动减仓java增强
 * @author Watson
 * @date 2024/2/2 13:48
 */
@Component("automaticallyReducePositionEnhance")
public class AutomaticallyReducePositionEnhance implements CgformEnhanceJavaInter {
	BigDecimal ONE_HUNDRED = new BigDecimal("100");

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		BigDecimal amountOfIncome = jsonobject.getBigDecimal("amount_of_income");
		BigDecimal rateOfReturn = jsonobject.getBigDecimal("rate_of_return");
		BigDecimal reducePositions = jsonobject.getBigDecimal("reduce_positions");
		if (amountOfIncome.compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException("收益额必须大于0");
		}
		if (rateOfReturn.compareTo(BigDecimal.ZERO) <= 0) {
			throw new BusinessException("收益率必须大于0");
		}
		if (reducePositions.compareTo(BigDecimal.ZERO) <= 0
			|| reducePositions.compareTo(ONE_HUNDRED) > 0) {
			throw new BusinessException("减仓必须大于0，小于等于100");
		}

		return 1;
	}
}
