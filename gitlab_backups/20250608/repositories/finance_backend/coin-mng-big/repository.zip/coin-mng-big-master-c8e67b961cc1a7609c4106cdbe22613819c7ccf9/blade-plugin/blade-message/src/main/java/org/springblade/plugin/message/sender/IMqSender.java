package org.springblade.plugin.message.sender;

import net.dreamlu.iot.mqtt.codec.MqttQoS;

/**
 * mq发送消息接口
 * @author weikun
 */
public interface IMqSender {
	/**
	 * 发送socket消息
	 * @param topic
	 * @param content
	 */
	void sendSocketMsg(String topic,String content);

	void sendSocketMsg(String topic,String content, MqttQoS qos);
}
