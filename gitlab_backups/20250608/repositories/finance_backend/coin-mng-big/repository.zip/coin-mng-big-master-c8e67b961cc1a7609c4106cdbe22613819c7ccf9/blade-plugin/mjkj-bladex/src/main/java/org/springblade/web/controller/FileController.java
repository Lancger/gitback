/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.web.controller;

import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.cgform.controller.BaseController;
import org.springblade.cgform.model.file.*;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.constant.CoinhouseConfig;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.api.crypto.annotation.encrypt.ApiEncryptAes;
import org.springblade.core.oss.model.BladeFile;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.DesUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.event.FileLogEvent;
import org.springblade.web.service.IMjkjFileIndexService;
import org.springblade.web.service.IMjkjFileService;
import org.springblade.web.utils.resource.OssBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("mjkj/file")
@Api(value = "文件管理", tags = "文件管理接口")
public class FileController extends BaseController {

	@Autowired
	private IMjkjBaseSqlService mjkjBaseSqlService;

	@Autowired
	private IMjkjFileService fileService;

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private IMjkjFileIndexService fileIndexService;

	private final OssBuilder ossBuilder;

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "获取所有文件列表", notes = "获取所有文件列表")
	@GetMapping({"/folder/dataList"})
	public R getFolderDataListGet(FileCreateModel model) {
		if (model.getType() == 1) {
			//判断是否有创建私人空间
			String tenantId = AuthUtil.getTenantId();
			Long userId = AuthUtil.getUserId();
			String userName = AuthUtil.getUser().getNickName();
			//判断是否有创建个人空间
			boolean privateFlag = fileService.isExistPrivateFolder();
			if(!privateFlag){
				fileService.createFolder(IdWorker.getId(), "个人空间", 0L, "1", tenantId,userId,userName);
			}

			boolean publicFlag = fileService.isExistPublicFolder();
			if(!publicFlag){
				fileService.createFolder(IdWorker.getId(), "共享空间", 0L, "2", tenantId,userId,userName);
			}
			//判断当前用户是否已经建立空间
			boolean userFolder = fileService.isExistUserFolder();
			if(!userFolder){
				fileService.createFolder(IdWorker.getId(), "空间", 0L, "4", tenantId,userId,userName);
			}
			List<Map<String, Object>> myPtFile = fileService.getMyPtFile();//获取平台文件

			List<FileResultListModel> list = fileService.getFileList(myPtFile);
			return R.data(list);
		}
		return R.success("成功");
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "改名/删除/移动文件夹", notes = "改名/删除文件夹")
	@PostMapping({"/folder/dataList"})
	public R getFolderDataListPost(FileCreateModel model) throws Exception {
		try {
			//个人空间目录不允许操作
			Map<String, Object> grkjMap = mjkjBaseSqlService.getDataOneByField("mjkj_file_list", "file_type", "1");
			Map<String, Object> selectfileMap = mjkjBaseSqlService.getTableById("mjkj_file_list", Func.toStr(model.getSource()));
			String grkjId = MjkjUtils.getMap2Str(grkjMap, "id");
			String selectPid = MjkjUtils.getMap2Str(selectfileMap, "pid");
			if (Func.equals(grkjId, selectPid)) {
				return R.fail("无操作该文件权限！");
			}

			Map<String, Object> pfileMap = mjkjBaseSqlService.getTableById("mjkj_file_list", Func.toStr(model.getSource()));
			String file_type = MjkjUtils.getMap2Str(pfileMap, "file_type");
			if (Func.equals("0", file_type) || Func.equals("1", file_type) || Func.equals("2", file_type) || Func.equals("3", file_type)) {//平台文件
				System.out.println(AuthUtil.isAdmin());
				if (!(AuthUtil.isAdmin() || AuthUtil.isAdministrator())) {
					return R.fail("无操作该文件权限！");
				}
				if (Func.equals("0", file_type) ||Func.equals("1", file_type) || Func.equals("2", file_type)) {
					return R.fail("不允许移动");
				}
			}
			if (Func.equals("4", file_type)) {//私人文件
				Long create_user = MjkjUtils.getMap2Long(pfileMap, "create_user");
				if (create_user.longValue() != AuthUtil.getUserId()) {
					return R.fail("暂无操作该文件权限！");
				}
			}

			if (Func.equals(model.getAction(), "rename")) {//修改名字
				fileService.renameFolder(Func.toLong(model.getSource()), model.getTarget());
			} else if (Func.equals(model.getAction(), "remove")) {//删除
				fileService.removeFolder(Func.toLong(model.getSource()));
			} else if (Func.equals(model.getAction(), "move")) {//移动
				long pid = Func.toLong(model.getTarget());
				Map<String, Object> pmap = mjkjBaseSqlService.getTableById("mjkj_file_list", Func.toStr(pid));
				String ptype = MjkjUtils.getMap2Str(pmap, "file_type");
				if (!Func.equals(ptype, "4") && Func.equals("4", file_type)) {
					return R.fail("私人文件不允许移动到公共文件夹！");
				}

				fileService.moveFolder(Func.toLong(model.getSource()), pid);
			}
		} catch (Exception e) {
			return R.fail(e.getMessage());
		}
		return R.success("成功");
	}

	@ApiOperation(value = "创建文件夹", notes = "创建文件夹")
	@PostMapping("/create")
	@ApiOperationSupport(order = 2)
	public R create(FileCreateModel model) {
		if (Func.equals(model.getAction(), "create")) {//新增
			long fileId = IdWorker.getId();
			Long userId = AuthUtil.getUserId();
			long pid = Func.toLong(model.getTarget());
			Map<String, Object> pfileMap = mjkjBaseSqlService.getTableById("mjkj_file_list", Func.toStr(pid));
			String file_type = MjkjUtils.getMap2Str(pfileMap, "file_type");
			if (pid == 0) {
				file_type = "3";//平台
			}

			FileCreateResultModel data = fileService.createFolder(fileId, model.getSource(), Func.toLong(model.getTarget()), file_type, AuthUtil.getTenantId(), userId, AuthUtil.getNickName());
			data.setFileId(fileId);
			data.setId(model.getId());
			return R.data(data);
		}
		return R.success("成功");
	}

	@ApiOperation(value = "上传文件", notes = "上传文件")
	@PostMapping("/uploadFile")
	@ApiOperationSupport(order = 3)
	public R uploadFile(@RequestParam MultipartFile upload, FileCreateModel model) {
		if (Func.equals(model.getAction(), "upload")) {//新增
			try{
				BladeFile bladeFile = ossBuilder.template().putFile(upload.getOriginalFilename(), upload.getInputStream());
				bladeFile.setLink(CoinhouseConfig.getStaticUrl() + bladeFile.getName());
				FileCreateResultModel data = fileService.uploadFile(bladeFile, model.getUpload_fullpath(), Func.toLong( model.getTarget()),upload.getOriginalFilename(),upload.getSize());
				return R.data(data);
			}catch (Exception e){
				return R.fail(e.getMessage());
			}

		}
		return R.success("成功");
	}


	//----------------------------------------------------------------


	@ApiEncryptAes
	@ApiOperation(value = "查看文件", notes = "查看文件")
	@PostMapping("/view/{id}")
	@ApiOperationSupport(order = 1)
	public R viewFile(@PathVariable("id") Long id, String pwd, HttpServletRequest request) {
		Map<String, Object> fileMap = fileService.fileListById(id);
		boolean flag=true;
		if(Func.isNotEmpty(fileMap)){
			String fileType = MjkjUtils.getMap2Str(fileMap, "file_type");
			if(Func.isNotEmpty(fileType) && Func.equals(fileType,"0")){
				flag=false;
			}
		}

		if(flag){
			try {
				BladeUser user = AuthUtil.getUser();
				this.checkFile(id, pwd, user);
			} catch (Exception e) {
				return R.fail(e.getMessage());
			}
		}
		//------------------校验完成------------------------------------
		Long view_num = MjkjUtils.getMap2Long(fileMap, "view_num");
		if (Func.isEmpty(view_num)) {
			view_num = 0L;
		}
		view_num++;

		//更新阅读次数
		Map<String, Object> updateData = new HashMap<>();
		updateData.put("view_num", view_num);
		mjkjBaseSqlService.baseUpdateDataTenantIgnore("mjkj_file_list", updateData,Func.toStr(id));


		//写入预览记录
		FileLogModel logModel = new FileLogModel();
		logModel.setFile_id(id);
		logModel.setFile_title(MjkjUtils.getMap2Str(fileMap, "title"));
		logModel.setOperate_user_id(AuthUtil.getUserId());
		logModel.setOperate_user_name(AuthUtil.getNickName());
		logModel.setTenant_id(AuthUtil.getTenantId());
		logModel.setRemark(AuthUtil.getNickName() + " 预览");
		logModel.setType("预览");
		applicationContext.publishEvent(new FileLogEvent(logModel));

		String fileUrl = MjkjUtils.getMap2Str(fileMap, "file_url");
		String fileSalt = MjkjUtils.getMap2Str(fileMap, "file_salt");
		fileUrl = DesUtil.decryptFormHex(fileUrl, fileSalt);

		Map<String, String> resultMap = new HashMap<>();
		resultMap.put("fileUrl", fileUrl);
		resultMap.put("fileName", MjkjUtils.getMap2Str(fileMap, "title"));
		return R.data(resultMap);
	}



	@ApiEncryptAes
	@ApiOperation(value = "文件下载url-ok", notes = "文件下载url")
	@PostMapping("/downloadurl/{id}")
	@ApiOperationSupport(order = 2)
	public R downloadFileUrl(@PathVariable("id") Long id, String pwd) throws Exception {
		Map<String, Object> fileMap = fileService.fileListById(id);
		boolean flag=true;
		if(Func.isNotEmpty(fileMap)){
			String fileType = MjkjUtils.getMap2Str(fileMap, "file_type");
			if(Func.isNotEmpty(fileType) && Func.equals(fileType,"0")){
				flag=false;
			}
		}
		if(flag){
			try {
				this.checkFile(id, pwd, AuthUtil.getUser());
			} catch (Exception e) {
				return R.fail(e.getMessage());
			}
		}

		//------------------校验完成------------------------------------

		Long download_num = MjkjUtils.getMap2Long(fileMap, "download_num");
		if (Func.isEmpty(download_num)) {
			download_num = 0L;
		}
		download_num++;

		//更新阅读次数
		Map<String, Object> updateData = new HashMap<>();
		updateData.put("download_num", download_num);
		mjkjBaseSqlService.baseUpdateDataTenantIgnore("mjkj_file_list", updateData,Func.toStr(id));


		//写入预览记录
		FileLogModel logModel = new FileLogModel();
		logModel.setFile_id(id);
		logModel.setFile_title(MjkjUtils.getMap2Str(fileMap, "title"));
		logModel.setOperate_user_id(AuthUtil.getUserId());
		logModel.setOperate_user_name(AuthUtil.getNickName());
		logModel.setTenant_id(AuthUtil.getTenantId());
		logModel.setRemark(AuthUtil.getNickName() + " 下载文件");
		logModel.setType("下载");
		applicationContext.publishEvent(new FileLogEvent(logModel));

		String fileUrl = MjkjUtils.getMap2Str(fileMap, "file_url");
		String fileSalt = MjkjUtils.getMap2Str(fileMap, "file_salt");
		fileUrl = DesUtil.decryptFormHex(fileUrl, fileSalt);
		String title = MjkjUtils.getMap2Str(fileMap, "title");
		Map<String, String> resultMap = new HashMap<>();
		resultMap.put("fileUrl", fileUrl);
		resultMap.put("title", title);
		return R.data(resultMap);
	}



	@ApiOperationSupport(order = 4)
	@ApiOperation(value = "给文件设置权限", notes = "给文件设置权限")
	@PostMapping({"/file/role"})
	public R fileRole(@RequestBody FileRoleModel model) throws Exception {
		for (Long fileId : model.getFileIdList()) {
			Map<String, Object> pfileMap = mjkjBaseSqlService.getTableById("mjkj_file_list", fileId+"");
			String file_type = MjkjUtils.getMap2Str(pfileMap, "file_type");
			if (Func.equals("0", file_type)){// 超级管理员才可以编辑
				if (!AuthUtil.isAdministrator()) {
					return R.fail("只允许超级管理员操作此文件");
				}
			}
			if (Func.equals("1", file_type) || Func.equals("2", file_type) || Func.equals("3", file_type)) {//平台文件，所有人可见
				if (!(AuthUtil.isAdmin() || AuthUtil.isAdministrator())) {
					return R.fail("只允许管理员操作此文件");
				}
				if (Func.equals("1", file_type) || Func.equals("2", file_type)) {
					return R.fail("不允许操作");
				}
			}

			Long create_user = MjkjUtils.getMap2Long(pfileMap, "create_user");
			if (create_user.longValue() != AuthUtil.getUserId()) {
				return R.fail("暂无操作该文件权限");
			}
		}

		fileService.addFileRole(model);
		return R.success("成功");
	}

	@ApiOperationSupport(order = 5)
	@ApiOperation(value = "获取文件夹所有授权列表", notes = "获取文件夹所有授权列表")
	@PostMapping({"/file/getRoleInfo/{fileId}"})
	public R fileGetRoleInfo(@PathVariable("fileId") Long fileId) throws Exception {
		List<Long> userIdList = fileService.getMyRoleFileIdListUserId(fileId);
		List<String> userNameList = new ArrayList<>();
		if (Func.isNotEmpty(userIdList)) {
			Map<String, Map<String, Object>> userMap = mjkjBaseSqlService.getData2Map("blade_user", "id",false);
			for (Long id : userIdList) {
				Map<String, Object> map = userMap.get(Func.toStr(id));
				String name = MjkjUtils.getMap2Str(map, "name");
				userNameList.add(name);
			}
		}

		Set<Long> deptIdList = fileService.getMyRoleFileIdListDeptId(fileId);
		List<String> deptNameList = new ArrayList<>();
		if (Func.isNotEmpty(deptIdList)) {
			Map<String, Map<String, Object>> userMap = mjkjBaseSqlService.getData2Map("blade_dept", "id",false);
			for (Long id : deptIdList) {
				Map<String, Object> map = userMap.get(Func.toStr(id));
				String name = MjkjUtils.getMap2Str(map, "dept_name");
				deptNameList.add(name);
			}
		}

		List<Long> roleIdList = fileService.getMyRoleFileIdListRoleId(fileId);
		List<String> roleNameList = new ArrayList<>();
		if (Func.isNotEmpty(roleIdList)) {
			Map<String, Map<String, Object>> userMap = mjkjBaseSqlService.getData2Map("blade_role", "id",false);
			for (Long id : roleIdList) {
				Map<String, Object> map = userMap.get(Func.toStr(id));
				String name = MjkjUtils.getMap2Str(map, "role_name");
				roleNameList.add(name);
			}
		}

		Map<String, Collection> resultMap = new HashMap<>();
		resultMap.put("userIdList", userIdList);
		resultMap.put("userNameList", userNameList);

		resultMap.put("deptIdList", deptIdList);
		resultMap.put("deptNameList", deptNameList);

		resultMap.put("roleIdList", roleIdList);
		resultMap.put("roleNameList", roleNameList);
		return R.data(resultMap);
	}


	@ApiOperationSupport(order = 6)
	@ApiOperation(value = "获取该文件是否可以修改删除等操作-ok", notes = "获取该文件是否可以修改删除等操作")
	@PostMapping({"/file/role/{fileId}"})
	public R fileRole(@PathVariable("fileId") Long fileId, FileCreateModel model) throws Exception {
		Map<String, Object> fileMap = fileService.fileListById(fileId);
		if(Func.isNotEmpty(fileMap)){
			String fileType = MjkjUtils.getMap2Str(fileMap, "file_type");
			if(Func.isNotEmpty(fileType) && Func.equals(fileType,"0")){
				if (!AuthUtil.isAdministrator()) {
					return R.data(false);
				}
			}
		}

		if (AuthUtil.isAdmin() || AuthUtil.isAdministrator()) {
			return R.data(true);
		}
		//个人空间目录不允许操作
		Map<String, Object> pfileMap = mjkjBaseSqlService.getTableById("mjkj_file_list", fileId+"");

		String file_type = MjkjUtils.getMap2Str(pfileMap, "file_type");
		if (Func.equals("0", file_type) || Func.equals("1", file_type) || Func.equals("2", file_type) || Func.equals("3", file_type)) {//平台文件，所有人可见
			if (AuthUtil.isAdmin() || AuthUtil.isAdministrator()) {
				return R.data(true);
			}
			if (Func.equals("1", file_type) || Func.equals("2", file_type)) {
				return R.data(false, "不允许操作！");
			}
		}
		Long create_user = MjkjUtils.getMap2Long(pfileMap, "create_user");
		if (create_user.longValue() != AuthUtil.getUserId()) {
			return R.data(false);
		}
		if (Func.equals(model.getAction(), "move")) {//移动
			long pid = Func.toLong(model.getTarget());
			Map<String, Object> pmap = mjkjBaseSqlService.getTableById("mjkj_file_list", pid+"");
			String ptype = MjkjUtils.getMap2Str(pmap, "file_type");
			if (!Func.equals(ptype, "4") && Func.equals("4", file_type)) {
				return R.data(false, "私人文件不允许移动到公共文件夹！");
			}
		}
		return R.data(true);
	}

	@ApiOperationSupport(order = 7)
	@ApiOperation(value = "获取首页统计-顶部统计", notes = "获取首页统计-顶部统计")
	@GetMapping({"/indexDat"})
	public R<Map> indexData(Integer type, String paramStartTime, String paramEndTime) {
		Map<String, Object> map = null;
		if (type == 1) {//头部
			map = fileIndexService.tjTop();
		} else if (type == 2) {//下载量
			map = fileIndexService.xzlList();
		} else if (type == 3) {//上传量
			map = fileIndexService.sclList();
		} else if (type == 4) {//上传列表
			map = fileIndexService.uploadList(paramStartTime, paramEndTime);
		} else if (type == 5) {//下载列表
			map = fileIndexService.downloadList(paramStartTime, paramEndTime);
		} else if (type == 6) {//阅读列表
			map = fileIndexService.viewList();
		}
		return R.data(map);
	}

	private void checkFile(Long id, String pwd, BladeUser user) throws BusinessException {
		Map<String, Object> map = mjkjBaseSqlService.getTableById("mjkj_file_list", Func.toStr(id));

		if (Func.isEmpty(map)) {
			throw new BusinessException("文件不存在");
		}
		if (AuthUtil.isAdministrator() || AuthUtil.isAdmin()) {
			return;
		}
		String file_type = MjkjUtils.getMap2Str(map, "file_type");
		if (Func.equals("1", file_type) || Func.equals("2", file_type) || Func.equals("3", file_type)) {//平台文件，所有人可见
			return;
		}

		//私人文件
		//判断权限 用户权限 部门权限 角色权限
		Long userId = user.getUserId();
		Long create_user = MjkjUtils.getMap2Long(map, "create_user");
		boolean flag = userId.longValue() == create_user;
		if (!flag) {//该文件是否授权给我
			flag = fileService.getFileRoleUserId(id, userId);
		}

		if (!flag) {///该文件是否授权给我的部门
			String deptIds = user.getDeptId();
			List<Long> deptList = Func.toLongList(deptIds);
			List<Long> allDeptList=new ArrayList<>();
			allDeptList.addAll(deptList);//本身
			for (Long deptId : deptList) {
				String allParentId = fileService.getDeptParentId(deptId);
				if(Func.isNotEmpty(allParentId)){
					List<Long> list = Func.toLongList(allParentId);
					allDeptList.addAll(list);//父级
				}
			}

			for (Long deptId : allDeptList) {
				flag = fileService.getFileRoleDeptId(id, deptId);
				if (flag) {
					break;//跳出当前循环
				}
			}
		}

		if (!flag) {//角色
			String userRoles = user.getRoleId();
			List<Long> roleList = Func.toLongList(userRoles);
			for (Long roleId : roleList) {
				flag = fileService.getFileRoleRoleId(id, roleId);
				if (flag) {
					break;//跳出当前循环
				}
			}
		}

		if (!flag) {
			throw new BusinessException("暂无权限");
		}


		//------------------校验完成------------------------------------
	}

}
