package org.springblade.web.enhance.contract;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.config.exception.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 自动减仓白名单java增强
 *
 * @author Watson
 * @date 2024/2/2 14:05
 */
@Component("automaticallyReducePositionWhitelistEnhance")
public class AutomaticallyReducePositionWhitelistEnhance implements CgformEnhanceJavaInter {

	@Autowired
	private IMjkjBaseSqlService mjkjBaseSqlService;

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		String memberId = jsonobject.getString("member_id");
		QueryWrapper<Object> wrapper = new QueryWrapper<>();
		wrapper.eq("status", 0);
		wrapper.eq("is_deleted", 0);
		wrapper.eq("id", memberId);
		if (mjkjBaseSqlService.countByWrapper("coin_member", wrapper) == 0) {
			throw new BusinessException("此用户不存在");
		}
		wrapper = new QueryWrapper<>();
		wrapper.eq("status", 0);
		wrapper.eq("is_deleted", 0);
		wrapper.eq("member_id", memberId);
		if (mjkjBaseSqlService.countByWrapper("contract_automatically_reduce_positions_whitelist", wrapper) > 0) {
			throw new BusinessException("该用户已在白名单");
		}
		return 1;

	}
}
