package org.springblade.web.enhance.appeal;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.web.mapper.OrderAppealMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component("orderAppealEnhanceList")
@AllArgsConstructor
public class OrderAppealEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private OrderAppealMapper orderAppealMapper;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		Page<Map<String, Object>> pages = orderAppealMapper.getOrderAppealList(page, params);
		MjkjUtils.setPageResult(params, pages);
	}
}
