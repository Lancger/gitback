package org.springblade.web.enhance.cwgl.xtqb;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.service.IHtMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 系统钱包，系统提现记录
 */
@Component("xtqbxttxjlEnhanceList")
public class XtqbxttxjlEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private IMjkjBaseSqlService sqlService;
	@Autowired
	private IHtMongoService mongoService;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);

		QueryWrapper<Object> wrapper=new QueryWrapper<>();
		wrapper.eq("is_deleted",0);

		String fromWalletAddress = MjkjUtils.getMap2Str(params, "from_wallet_address");
		String toWalletAddress = MjkjUtils.getMap2Str(params, "to_wallet_address");
		String tradeHash = MjkjUtils.getMap2Str(params, "hash");
		String startTime = MjkjUtils.getMap2Str(params, "time_begin");
		String endTime = MjkjUtils.getMap2Str(params, "time_end");

		wrapper.eq(Func.isNotEmpty(fromWalletAddress),"from_wallet_address",fromWalletAddress);
		wrapper.eq(Func.isNotEmpty(toWalletAddress),"to_wallet_address",toWalletAddress);
		wrapper.eq(Func.isNotEmpty(tradeHash),"hash",tradeHash);
		wrapper.ge(Func.isNotEmpty(startTime),"create_time",startTime);
		wrapper.le(Func.isNotEmpty(endTime),"create_time",endTime);
		wrapper.select("*, create_time time");


		wrapper.orderByDesc("(id+0)");
		IPage<Map<String, Object>> pages = sqlService.getDataIPageByFieldParams("coin_system_withdraw", page, wrapper);
		List<Map<String, Object>> dataList = pages.getRecords();
		if(Func.isNotEmpty(dataList)){
			for(Map<String, Object> dataMap:dataList){
				String coinName = MjkjUtils.getMap2Str(dataMap, "symbol");
				BigDecimal amount = MjkjUtils.getMap2BigD(dataMap, "amount");
				String str=amount.stripTrailingZeros().toPlainString()+" "+coinName;
				dataMap.put("amount",str);

				BigDecimal feeAmount = MjkjUtils.getMap2BigD(dataMap, "fee_amount");
				if(feeAmount.compareTo(BigDecimal.ZERO)==1){
					dataMap.put("fee_amount",feeAmount.stripTrailingZeros().toPlainString());
				}else{
					dataMap.put("fee_amount","-");
				}

				Map<String, Object> memberWallet = sqlService.getDataOneByFieldParams("coin_log_withdrawal", Wrappers
					.query()
					.eq("is_deleted", 0)
					.in("id", MjkjUtils.getMap2Str(dataMap, "task_id")));
				Map<String, Object> member = sqlService.getTableById("coin_member", MjkjUtils.getMap2Str(memberWallet, "member_id"));
				dataMap.put("uid", MjkjUtils.getMap2Str(member, "uid"));
				dataMap.put("name", MjkjUtils.getMap2Str(member, "name"));
				dataMap.put("phone", MjkjUtils.getMap2Str(member, "phone"));
				dataMap.put("email", MjkjUtils.getMap2Str(member, "email"));
			}
		}

		IPage<Map<String, Object>> noPages = sqlService.getDataIPageByFieldParams("coin_system_withdraw", new Page(1, -521), wrapper);
		BigDecimal reduce = noPages.getRecords().parallelStream().map(m -> MjkjUtils.getMap2Str(m, "symbol").equalsIgnoreCase("usdt") ?
				MjkjUtils.getMap2BigD(m, "amount") : MjkjUtils.getMap2BigD(m, "amount")
				.multiply(mongoService.getPriceBySymbol("xh", MjkjUtils.getMap2Str(m, "symbol" + "/USDT"))))
			.reduce(BigDecimal.ZERO, BigDecimal::add);
		HashMap<String, Object> hashMap = new HashMap<>();
		hashMap.put("sum", reduce.toPlainString());

		MjkjUtils.setPageResult(params,pages, hashMap);

	}
}
