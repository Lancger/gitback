package org.springblade.plugin.message.feign;

import lombok.AllArgsConstructor;
import org.springblade.core.tenant.annotation.NonDS;
import org.springblade.core.tool.api.R;
import org.springblade.plugin.message.model.IndexHqModel;
import org.springblade.plugin.message.model.SocketMsgModel;
import org.springblade.plugin.message.sender.IMqSender;
import org.springblade.plugin.message.utils.MessageUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author weikun
 */
@NonDS
@RestController
@AllArgsConstructor
public class MessageClient implements IMessageClient {

	@Autowired
	private IMqSender mqSender;

	@Override
	@PostMapping(SEND_SOCKET_MSG)
	public R<Boolean> sendSocketMsg(@RequestBody SocketMsgModel model){
		mqSender.sendSocketMsg(model.getTopic(),model.getContent());
		return R.data(true);
		/*boolean flag=true;
		if (MessageUtils.webSocketFlag) {
			return R.data(flag);
		}
		try {
			MessageUtils.webSocketFlag = true;
			for (int i = 0; i < 20; i++) {
				mqSender.sendSocketMsg(model.getTopic(),model.getContent());
				Thread.sleep(1000);
			}
		}catch (Exception  e){
			MessageUtils.webSocketFlag = false;
		}finally {
			MessageUtils.webSocketFlag = false;
		}
		return R.data(flag);*/
	}



}
