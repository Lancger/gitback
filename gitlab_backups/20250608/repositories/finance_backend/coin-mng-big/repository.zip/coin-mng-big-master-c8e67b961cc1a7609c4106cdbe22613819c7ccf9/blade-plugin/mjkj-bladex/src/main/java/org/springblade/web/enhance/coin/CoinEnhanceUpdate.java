package org.springblade.web.enhance.coin;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.RequiredArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.utils.Func;
import org.springblade.third.cache.CacheNames;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Author: @Wai
 * Date: 2022-6-25
 */
@Component("coinEnhanceUpdate")
@RequiredArgsConstructor
public class CoinEnhanceUpdate implements CgformEnhanceJavaInter {
	private final IMjkjBaseSqlService baseSqlService;
	private final BladeRedis bladeRedis;

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		String symbol = MjkjUtils.getMap2Str(jsonobject, "symbol");
		Map<String, Object> cheackMap = baseSqlService.getDataOneByField("coin_coin", "symbol", symbol);
		if (Func.isNotEmpty(cheackMap) && !Func.equals(MjkjUtils.getMap2Str(cheackMap, "id"), MjkjUtils.getMap2Str(jsonobject, "id")))
			throw new BusinessException("修改失败！该币种已存在！");
//		Map<String, Object> coin = baseSqlService.getTableById("coin_coin", MjkjUtils.getMap2Str(jsonobject, "id"));
//		if (!Func.equals(MjkjUtils.getMap2Str(coin, "symbol"), MjkjUtils.getMap2Str(jsonobject, "symbol"))) {
//			List<Map<String, Object>> coinExchange = baseSqlService.getDataListByField("coin_fiat_quick", "from_symbol or to_symbol", MjkjUtils.getMap2Str(jsonobject, "symbol"));
//			if (Func.isEmpty(coinExchange)) {
//				List<Map<String, Object>> countries = baseSqlService.getDataByTable("coin_country", Collections.singletonList("distinct local_currency"));
//				if (Func.isNotEmpty(countries)) {
//					countries.parallelStream().forEach(m -> {
//						HashMap<String, Object> buy = new HashMap<>();
//						HashMap<String, Object> sell = new HashMap<>();
//						buy.put("to_symbol", MjkjUtils.getMap2Str(jsonobject, "symbol"));
//						buy.put("is_from_unit", "1");
//						sell.put("from_symbol", MjkjUtils.getMap2Str(jsonobject, "symbol"));
//						String currency = MjkjUtils.getMap2Str(m, "local_currency");
//						buy.put("from_symbol", currency);
//						sell.put("to_symbol", currency);
//						if (Func.equals(buy.get("from_symbol"),buy.get("to_symbol")))
//							return;
//						baseSqlService.baseInsertData("coin_fiat_quick", buy);
//						baseSqlService.baseInsertData("coin_fiat_quick", sell);
//					});
//					return 2;
//				}
//			}
//			coinExchange.parallelStream().forEach(map -> {
//				HashMap<String, Object> updateMap = new HashMap<>();
//				updateMap.put(Func.equals(MjkjUtils.getMap2Str(map, "form_symbol"), MjkjUtils.getMap2Str(coin, "symbol")) ? "form_symbol" : "to_symbol", MjkjUtils.getMap2Str(jsonobject, "symbol"));
//				baseSqlService.baseUpdateData("coin_fiat_quick", updateMap, MjkjUtils.getMap2Str(map, "id"));
//			});
//		}
		Map<String, Object> map = new HashMap<>();
		jsonobject.forEach((k, v) -> {
			if (!k.startsWith("$")){
				map.put(k, v);
			}
		});
		// 加入redis缓存
		bladeRedis.set(CacheNames.SYS_COIN_COIN +symbol, JSON.toJSONString(map));
		return 2;
	}
}
