package org.springblade.web.enhance.lcgl.cbhq;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.AllArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 活期存币计划新增处理
 */
@Component("lcglCbhqEnhanceUpdate")
@AllArgsConstructor
public class LcglCbhqEnhanceUpadte implements CgformEnhanceJavaInter {
	private final IMjkjBaseSqlService mjkjBaseSqlService;


	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		// 存储的上架状态
		String onlineStatus = MjkjUtils.getMap2Str(jsonobject, "online_status");
		String idStr = MjkjUtils.getMap2Str(jsonobject, "id");
		String coinId = MjkjUtils.getMap2Str(jsonobject, "coin_id");
		// 修改上下架时判断除自己以外是否还存在
		if (onlineStatus.equals("0")){
			// 上架，将同类型的进行下架处理
			List<Map<String, Object>> hqGoods = mjkjBaseSqlService.getDataListByFieldParams("coin_wealth_current", Wrappers
				.query()
				.eq("is_deleted", 0)
				.eq("online_status", 0)
				.eq("coin_id", coinId));
			List<Map<String, Object>> filterMap = hqGoods.stream().filter(map -> !map.get("id").equals(idStr)).collect(Collectors.toList());
			for (Map<String, Object> stringObjectMap : filterMap) {
				stringObjectMap.put("online_status", 1);
				mjkjBaseSqlService.baseUpdateData("coin_wealth_current", stringObjectMap,MjkjUtils.getMap2Str(stringObjectMap, "id"));
			}
		}else {
			// 下架
			// 判断是否有用户出于存币状态
			boolean isPass = checkHasUserBuy(coinId);
			if (isPass){
				throw new BusinessException("该存币计划有订单数据，无法下架");
			}
			// 运行修改
			return 2;
		}
		return -1;
	}

	// 判断是否还有用户存活期
	public boolean checkHasUserBuy(String coinId){
		List<Map<String, Object>> allMember = mjkjBaseSqlService.getDataListByFieldParams("coin_wealth_current_history", Wrappers
			.query()
			.eq("coin_id", coinId)
		);
		// 根据用户id进行分组
		Map<String, List<Map<String, Object>>> recordsByUserId = allMember.stream()
			.collect(Collectors.groupingBy(record -> (String) record.get("member_id")));
		boolean userHasUnmatchedBuy = recordsByUserId.values().stream()
			.anyMatch(records -> {
				BigDecimal buyAmount = BigDecimal.ZERO;
				BigDecimal sellAmount = BigDecimal.ZERO;

				for (Map<String, Object> record : records) {
					int type = (int) record.get("type"); // 0 买, 1 卖
					BigDecimal amount = (BigDecimal) record.get("amount");

					if (type == 0) {
						buyAmount = buyAmount.add(amount);
					} else if (type == 1) {
						sellAmount = sellAmount.add(amount);
					}
				}

				return buyAmount.compareTo(sellAmount) > 0;
			});
		return userHasUnmatchedBuy;
	}
}
