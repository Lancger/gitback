package org.springblade.web.enhance.file;

import com.alibaba.fastjson.JSONObject;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.model.file.FileLogModel;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.event.FileLogEvent;
import org.springblade.web.mapper.MjkjFileMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 资源审核-删除
 * 表明：mjkj_file_list
 */
@Component("fileViewEnhanceDel")
public class FileViewEnhanceDel implements CgformEnhanceJavaInter {

	@Autowired
	private IMjkjBaseSqlService mjkjBaseSqlService;

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private MjkjFileMapper mjkjFileMapper;

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		Long id = jsonobject.getLong("id");
		Map<String, Object> pfileMap = mjkjBaseSqlService.getTableByIdL("mjkj_file_list", id);
		if(Func.isEmpty(pfileMap)){
			throw new BusinessException("文件不存在");
		}
		if(AuthUtil.isAdministrator()){
			throw new BusinessException("您不是超级管理员");
		}

		//个人空间目录不允许操作
		Map<String, Object> grkjMap = mjkjBaseSqlService.getDataOneByField("mjkj_file_list", "file_type", "1");
		Map<String, Object> myfileMap = mjkjBaseSqlService.getTableByIdL("mjkj_file_list", id);
		String grkjId = MjkjUtils.getMap2Str(grkjMap, "id");
		String selectPid = MjkjUtils.getMap2Str(myfileMap, "pid");
		if(Func.equals(grkjId,selectPid)){
			throw new BusinessException("该文件不允许删除");
		}

		//获取所有子节点
		List<Map<String, Object>> subDataList = mjkjBaseSqlService.getDataListByLike("mjkj_file_list", "pstr", ","+id,null);
		if(Func.isNotEmpty(subDataList)){
			for (Map<String, Object> subData:subDataList) {
				Long subId = MjkjUtils.getMap2Long(subData, "id");
				mjkjBaseSqlService.baseDeleteSql("mjkj_file_list",subId);

				//删除权限
				mjkjFileMapper.removeUserIdByFileId(subId);
				mjkjFileMapper.removeRoleIdByFileId(subId);
				mjkjFileMapper.removeDeptIdByFileId(subId);

				//写入预览记录
				FileLogModel logModel=new FileLogModel();
				logModel.setFile_id(subId);
				logModel.setFile_title(MjkjUtils.getMap2Str(pfileMap,"title"));
				logModel.setOperate_user_id(AuthUtil.getUserId());
				logModel.setOperate_user_name(AuthUtil.getNickName());
				logModel.setTenant_id(AuthUtil.getTenantId());
				logModel.setRemark(AuthUtil.getNickName()+" 删除文件夹");
				logModel.setType("删除");
				applicationContext.publishEvent(new FileLogEvent(logModel));
			}
		}

		mjkjBaseSqlService.baseDeleteSql("mjkj_file_list",id);
		//删除权限
		mjkjFileMapper.removeUserIdByFileId(id);
		mjkjFileMapper.removeRoleIdByFileId(id);
		mjkjFileMapper.removeDeptIdByFileId(id);

		//写入预览记录
		FileLogModel logModel=new FileLogModel();
		logModel.setFile_id(id);
		logModel.setFile_title(MjkjUtils.getMap2Str(pfileMap,"title"));
		logModel.setOperate_user_id(AuthUtil.getUserId());
		logModel.setOperate_user_name(AuthUtil.getNickName());
		logModel.setTenant_id(AuthUtil.getTenantId());
		logModel.setRemark(AuthUtil.getNickName()+" 删除");
		logModel.setType("删除");
		applicationContext.publishEvent(new FileLogEvent(logModel));
		return -1;
	}


}
