/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.web.controller;


import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.config.constant.CoinhouseConfig;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.core.tool.utils.RandomType;
import org.springblade.entity.SendEmailParam;
import org.springblade.entity.SendPhoneParam;
import org.springblade.feign.IMjkjWebClient;
import org.springblade.web.service.IResouceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;


@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("coin/open")
@Api(value = "公共开放接口", tags = "公共开放接口")
public class OpenController {

	@Autowired
	private IResouceService resouceService;

	@Autowired
	private BladeRedis bladeRedis;

	@Autowired
	private IMjkjBaseSqlService baseSqlService;

	@Autowired
	private IMjkjWebClient mjkjWebClient;



	@ApiOperationSupport(order = 2)
	@GetMapping({"/send/sms"})
	@ApiOperation(value = "发送短信", notes = "发送短信")
	public R sendSms(String type) {
		try {
			if(Func.equals(type,"99") || Func.equals(type,"100")){//后台发送
				String random = Func.random(6, RandomType.INT);
				String message = "";
				if(Func.equals(type,"99")){
					message = "【必屋】重要信息!管理员正在申请修改系统钱包，本次验证码为：" + random+",有效期为5分钟";
				}else if(Func.equals(type,"100")){
					message = "【必屋】重要信息!管理员正在人工充值，本次验证码为：" + random+",有效期为5分钟";
				}

				String phone=CoinhouseConfig.getAdministratorPhoneCode()+CoinhouseConfig.getAdministratorPhone();
				phone=phone.replaceAll(" ","").trim();
				phone=phone.replace("+","");

				SendPhoneParam param=new SendPhoneParam();
				param.setPhone(phone);
				param.setContent(message);
				param.setAreaCode(CoinhouseConfig.getAdministratorPhoneCode());
				Boolean flag = mjkjWebClient.sendPhone(param);
				if(Func.isNotEmpty(flag) && flag){
					if(Func.equals(type,"99")){
						String key="systemWallet:administrator_phone:"+CoinhouseConfig.getAdministratorPhone();
						bladeRedis.setEx(key, random, 300L);
					}else if(Func.equals(type,"100")){//人工充值
						String key="wallet_rgcz:administrator_phone:"+CoinhouseConfig.getAdministratorPhone();
						bladeRedis.setEx(key, random, 300L);
					}
				}else{
					return R.fail("发送失败");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return R.fail("发送失败");
		}
		return R.success("成功");
	}


	@ApiOperationSupport(order = 3)
	@GetMapping({"/send/email"})
	@ApiOperation(value = "发送邮箱", notes = "发送邮箱")
	public R sendEmail(String type) {
		try {
			if(Func.equals(type,"99") || Func.equals(type,"100")){//后台发送
				String random = Func.random(6, RandomType.INT);
				SendEmailParam param=new SendEmailParam();
				param.setEmail(CoinhouseConfig.getAdministratorEmail());
				if(Func.equals(type,"99")){
					param.setTitle("修改系统钱包");
					param.setContent(Func.toStrList("重要通知!管理员正在申请修改系统钱包，本次验证码为：" + random+",有效期为5分钟"));
				}else if(Func.equals(type,"100")){
					param.setTitle("人工充值");
					param.setContent(Func.toStrList("重要通知!管理员正在人工充值，本次验证码为：" + random+",有效期为5分钟"));
				}

				Boolean flag = mjkjWebClient.sendEmail(param);
				if(Func.isNotEmpty(flag) && flag){
					if(Func.equals(type,"99")){
						String key="systemWallet:administrator_email:"+CoinhouseConfig.getAdministratorEmail();
						bladeRedis.setEx(key, random, 300L);
					}else if(Func.equals(type,"100")){
						String key="wallet_rgcz:administrator_email:"+CoinhouseConfig.getAdministratorEmail();
						bladeRedis.setEx(key, random, 300L);
					}

				}else{
					return R.fail("发送失败");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			return R.fail("发送失败");
		}
		return R.success("成功");
	}

	@ApiOperationSupport(order = 4)
	@GetMapping({"/getSysInfo"})
	@ApiOperation(value = "获取对外参数", notes = "获取对外参数")
	public R getSysInfo() {
		Map<String,Object> resultMap=new HashMap<>();
		resultMap.put("admin_areaCode",CoinhouseConfig.getAdministratorPhoneCode());//区号
		resultMap.put("admin_phone",CoinhouseConfig.getAdministratorPhone()); //手机
		resultMap.put("admin_email",CoinhouseConfig.getAdministratorEmail());//邮箱
		return R.data(resultMap);
	}



}

