package org.springblade.web.enhance.article;

import com.alibaba.fastjson.JSONObject;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springframework.stereotype.Component;

import java.util.Base64;

@Slf4j
@AllArgsConstructor
@Component("articleEnhanceAdd")
public class ArticleEnhanceAdd implements CgformEnhanceJavaInter {

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {

		String articleContent = MjkjUtils.getMap2Str(jsonobject, "article_content");
		try {
			// 对数据进行解码
			byte[] decodedBytes = Base64.getDecoder().decode(articleContent);
			String decodedData = new String(decodedBytes);
			log.info("ArticleEnhanceAdd articleContent:{},decodedData:{}",
				articleContent,decodedData);
			jsonobject.put("article_content",decodedData);
		}catch (Exception e){
			log.error("ArticleEnhanceAdd error,articleContent:{}",articleContent,e);
		}
		return 1;
	}
}
