package org.springblade.web.enhance.contract;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.RequiredArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.utils.Func;
import org.springblade.third.cache.CacheNames;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 检查交易对是否已存在
 * Author: @Wai
 * Date: 2022-6-9
 */
@Component("swapEnhanceAdd")
@RequiredArgsConstructor
public class SwapEnhanceAdd implements CgformEnhanceJavaInter {
	private final IMjkjBaseSqlService mjkjBaseSqlService;
	private final BladeRedis bladeRedis;

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		String whereFiledAndName = "base_coin_id = " + MjkjUtils.getMap2Long(jsonobject, "base_coin_id") + " and coin_coin_id";
		String symbolName = jsonobject.getString("symbol_name");
		Map<String, Object> check = mjkjBaseSqlService
			.getDataOneByField("coin_coin_contract",
				 whereFiledAndName , MjkjUtils.getMap2Long(jsonobject, "coin_coin_id"),
				Collections.singletonList("id"));
		if (Func.isNotEmpty(check) && !Func.equals(MjkjUtils.getMap2Long(check,"id"),MjkjUtils.getMap2Long(jsonobject,"id")))
			throw new BusinessException("交易对已存在！");
		// 缓存处理
		Map<String, Object> map = new HashMap<>();
		jsonobject.forEach((k, v) -> {
			if (!k.startsWith("$")){
				map.put(k, v);
			}
		});
		bladeRedis.set(CacheNames.SYS_COIN_CONTRACT+symbolName, JSON.toJSONString(map));
		return 1;
	}
}
