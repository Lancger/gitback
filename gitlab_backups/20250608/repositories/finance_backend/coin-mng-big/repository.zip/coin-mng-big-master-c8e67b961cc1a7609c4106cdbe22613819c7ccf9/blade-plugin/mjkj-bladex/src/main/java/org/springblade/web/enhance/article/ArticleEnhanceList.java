package org.springblade.web.enhance.article;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.AllArgsConstructor;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.utils.Func;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@AllArgsConstructor
@Component("articleEnhanceList")
public class ArticleEnhanceList implements CgformEnhanceJavaListInter {
	private final IMjkjBaseSqlService sqlService;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		String articleType = MjkjUtils.getMap2Str(params, "article_type");
		String articleTitle = MjkjUtils.getMap2Str(params, "article_title");
		String articleCode = MjkjUtils.getMap2Str(params, "article_code");
		List<String> orderColumnList = MjkjUtils.<String>getMapAll2List(params, "column");

		List<String> idList = new ArrayList<>();
		if (Func.isNotEmpty(articleType)) {
			idList.add(articleType);
			getChildren(idList, articleType);
		}
		IPage<Map<String, Object>> page = sqlService.getDataIPageByFieldParams("coin_article",
			MjkjUtils.getPage(params), Wrappers
				.query()
				.eq(Func.isNotEmpty(articleTitle), "article_title", articleTitle)
				.eq(Func.isNotEmpty(articleCode), "article_code", articleCode)
				.in(Func.isNotEmpty(articleType), "article_type", idList)
				.orderBy(Func.isNotEmpty(orderColumnList), MjkjUtils.getMap2Str(params, "order").equals("asc"), orderColumnList));
		MjkjUtils.setPageResult(params, page);
	}

	private void getChildren(List<String> idList, String article) {
		List<Map<String, Object>> mapList = sqlService.getDataListByField("coin_article_section", "pid", article);
		if (Func.isEmpty(mapList))
			return;
		for (int i = 0; i < mapList.size(); i++) {
			Map<String, Object> map = mapList.get(i);
			String id = MjkjUtils.getMap2Str(map, "id");
			if (idList.contains(id))
				continue;
			idList.add(id);
			if (MjkjUtils.getMap2Integer(map, "haschildren") == 1) {
				getChildren(idList, id);
			}
		}
	}
}
