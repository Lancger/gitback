package org.springblade.plugin.message.service.impl;

import net.dreamlu.iot.mqtt.codec.MqttQoS;
import org.springblade.plugin.message.sender.IMqSender;
import org.springblade.plugin.message.service.IMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * 合约
 */
@Service
public class MessageServiceImpl implements IMessageService {

	@Autowired
	private IMqSender mqSender;

	@Async("messagePoolTaskExecutor")
	@Override
	public void sendMessage(String topic,String content){
		try{
			mqSender.sendSocketMsg(topic,content);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	@Async("messagePoolTaskExecutor")
	@Override
	public void sendMessage(String topic,String content, MqttQoS qos){
		try{
			mqSender.sendSocketMsg(topic,content, qos);
		}catch (Exception e){
			e.printStackTrace();
		}
	}
}
