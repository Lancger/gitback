package org.springblade.web.enhance.cwgl.xtqb;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.utils.Func;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 系统钱包，归集记录
 */
@Component("xtqbxtgjjlEnhanceList")
public class XtqbxtgjjlEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private IMjkjBaseSqlService sqlService;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);

		QueryWrapper<Object> wrapper=new QueryWrapper<>();
		wrapper.eq("is_deleted",0);

		String fromWalletAddress = MjkjUtils.getMap2Str(params, "from_address");
		String toWalletAddress = MjkjUtils.getMap2Str(params, "to_address");
		String tradeHash = MjkjUtils.getMap2Str(params, "hash");

		String startTime = MjkjUtils.getMap2Str(params, "time_begin");
		String endTime = MjkjUtils.getMap2Str(params, "time_end");
		String collectStatus = MjkjUtils.getMap2Str(params, "collect_status");

		wrapper.ge(Func.isNotEmpty(startTime),"create_time",startTime);
		wrapper.le(Func.isNotEmpty(endTime),"create_time",endTime);
		wrapper.eq(Func.isNotEmpty(fromWalletAddress),"from_address",fromWalletAddress);
		wrapper.eq(Func.isNotEmpty(toWalletAddress),"to_address",toWalletAddress);
		wrapper.eq(Func.isNotEmpty(tradeHash),"hash",tradeHash);
		wrapper.eq(Func.isNotEmpty(collectStatus),"collect_status",collectStatus);
		wrapper.select("*, create_time time");


		wrapper.orderByDesc("(id+0)");
		IPage<Map<String, Object>> pages = sqlService.getDataIPageByFieldParams("coin_system_collect", page, wrapper);
		List<Map<String, Object>> dataList = pages.getRecords();
		if(Func.isNotEmpty(dataList)){
			for(Map<String, Object> dataMap:dataList){
				String systemChargeId = MjkjUtils.getMap2Str(dataMap, "system_charge_id");

				String coinName ="";
				if(Func.isNotEmpty(systemChargeId)){
					Map<String, Object> changeMap = sqlService.getTableById("coin_system_change", systemChargeId);
					coinName = MjkjUtils.getMap2Str(changeMap, "coin_name");
				}

				BigDecimal amount = MjkjUtils.getMap2BigD(dataMap, "amount");
				String str=amount.stripTrailingZeros().toPlainString()+" "+coinName;
				dataMap.put("amount",str);

				BigDecimal feeAmount = MjkjUtils.getMap2BigD(dataMap, "fee_amount");
				if(feeAmount.compareTo(BigDecimal.ZERO)==1){
					dataMap.put("fee_amount",feeAmount.stripTrailingZeros().toPlainString());
				}else{
					dataMap.put("fee_amount","-");
				}

				String chainType = MjkjUtils.getMap2Str(dataMap, "chain_type");
				String address = MjkjUtils.getMap2Str(dataMap, "from_address");
				String addressEncryption = MjkjUtils.getDbJiaMi(address);
				Map<String, Object> memberWallet = sqlService.getDataOneByFieldParams("coin_chain_wallet", Wrappers
					.query()
					.eq("is_deleted", 0)
					.eq("chain_type", chainType)
					.in("address", addressEncryption, address));
				Map<String, Object> member = sqlService.getTableById("coin_member", MjkjUtils.getMap2Str(memberWallet, "member_id"));
				dataMap.put("uid", MjkjUtils.getMap2Str(member, "uid"));
				dataMap.put("name", MjkjUtils.getMap2Str(member, "name"));
				dataMap.put("phone", MjkjUtils.getMap2Str(member, "phone"));
				dataMap.put("email", MjkjUtils.getMap2Str(member, "email"));
			}
		}

		MjkjUtils.setPageResult(params,pages);

	}
}
