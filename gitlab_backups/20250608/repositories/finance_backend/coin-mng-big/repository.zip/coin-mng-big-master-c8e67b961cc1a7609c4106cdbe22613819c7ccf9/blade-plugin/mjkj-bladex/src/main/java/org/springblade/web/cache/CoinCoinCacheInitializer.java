package org.springblade.web.cache;

import org.springblade.cgform.service.impl.MjkjBaseSqlServiceImpl;
import org.springblade.core.redis.cache.BladeRedis;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

/**
 * 启动时缓存操作
 */
@Component
public class CoinCoinCacheInitializer implements ApplicationListener<ApplicationReadyEvent> {

    @Autowired
    private CoinCoinCache coinCoinCache;

	@Autowired
	private CoinCoinContractCache coinCoinContractCache;

	@Autowired
	private MjkjBaseSqlServiceImpl mjkjBaseSqlService;

	@Autowired
	private BladeRedis bladeRedis;

    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
		// 缓存全部coin币信息
        coinCoinCache.refPutAll(mjkjBaseSqlService,bladeRedis);
		// 缓存全部合约交易对信息
		coinCoinContractCache.refPutAll(mjkjBaseSqlService,bladeRedis);
    }
}
