package org.springblade.web.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.constant.CoinhouseConfig;
import org.springblade.config.constant.WalletConstant;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.core.tool.utils.StringUtil;
import org.springblade.entity.AddWalletParam;
import org.springblade.entity.SubWalletParam;
import org.springblade.entity.WalletGetParam;
import org.springblade.feign.IMjkjWebClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.*;


@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("coin/mng/wallet")
@Api(value = "后台钱包相关", tags = "后台钱包相关")
public class WalletMngController {

	@Autowired
	private IMjkjBaseSqlService mjkjBaseSqlService;

	@Autowired
	private IMjkjWebClient mjkjWebClient;

	@Autowired
	private BladeRedis bladeRedis;

	@ApiOperationSupport(order = 1)
	@GetMapping("/list")
	@ApiOperation(value = "获取我的所有钱包记录", notes = "获取我的所有钱包记录")
	@ApiImplicitParams({
		@ApiImplicitParam(paramType = "query", name = "memberId", value = "会员id", dataType = "String"),
	})
	public R records(String memberId) {

		Map<String, Object> coinMap = mjkjBaseSqlService.getDataOneByField("coin_coin", "symbol", "USDT");
		if (Func.isEmpty(coinMap)) {
			R.fail("获取币种有误");
		}
		String coinId = MjkjUtils.getMap2Str(coinMap, "id");

		//获取所有现货交易对
		List<Map<String, Object>> exchangeMapList = mjkjBaseSqlService.getDataByTable("coin_coin_exchange");
		//校验钱包是否存在
		List<String> coinIdList = new ArrayList<>();
		if (Func.isNotEmpty(exchangeMapList)) {
			for (Map<String, Object> exchangeMap : exchangeMapList) {
				String baseCoinId = MjkjUtils.getMap2Str(exchangeMap, "base_coin_id");
				String coinCoinId = MjkjUtils.getMap2Str(exchangeMap, "coin_coin_id");
				if (!coinIdList.contains(baseCoinId)) {
					WalletGetParam walletGetParam = new WalletGetParam();
					walletGetParam.setCoinId(baseCoinId);
					walletGetParam.setType("spot");
					walletGetParam.setMemberId(memberId);
					mjkjWebClient.getWalletInfo(walletGetParam);//获取我的钱包
					coinIdList.add(baseCoinId);
				}
				if (!coinIdList.contains(coinCoinId)) {
					WalletGetParam walletGetParam = new WalletGetParam();
					walletGetParam.setCoinId(coinCoinId);
					;
					walletGetParam.setType("spot");
					walletGetParam.setMemberId(memberId);
					mjkjWebClient.getWalletInfo(walletGetParam);//获取我的钱包
					coinIdList.add(coinCoinId);
				}
			}
		}

		// wallet_type="wallet" 额外添加ch币到用户钱包
		Map<String, Object> ChMap = mjkjBaseSqlService.getDataOneByField("coin_coin", "symbol", "CH");
		String CHCoinId = MjkjUtils.getMap2Str(ChMap, "id");
		if (StringUtil.isNotBlank(CHCoinId)) {
			WalletGetParam walletGetParam = new WalletGetParam();
			walletGetParam.setCoinId(CHCoinId);
			walletGetParam.setType(WalletConstant.WALLET_TYPE_WALLET);
			walletGetParam.setMemberId(memberId);
			//获取我的钱包
			mjkjWebClient.getWalletInfo(walletGetParam);
		}


		//获取所有的交易对
		Map<String, Map<String, Object>> exchangeMap = mjkjBaseSqlService.getData2Map("coin_coin_exchange", "id", false);

		String types[] = {"qb", "bb", "ggzc", "ggqc", "hy", "sz", "lc", "qq", "sj"};
		//钱包  币币 杠杠逐仓  杠杠全仓  合约 市值
		Map<String, Object> resultMap = new HashMap<>();
		for (String type : types) {
			String tableName = "";
			String wallet_type = "";
			if (Func.equals(type, "qb")) {//钱包
				tableName = "coin_member_wallet";
				wallet_type = "wallet";
			} else if (Func.equals(type, "bb")) {//币币
				tableName = "coin_member_wallet_spot";
				wallet_type = "spot";
			} else if (Func.equals(type, "ggzc")) {//杠杠逐仓
				tableName = "coin_member_wallet_margin_fixed";
			} else if (Func.equals(type, "ggqc")) {//杠杠全仓
				tableName = "coin_member_wallet_margin_all";
				wallet_type = "marginFixed";
			} else if (Func.equals(type, "hy")) {//合约
				tableName = "coin_member_wallet_contract";
				wallet_type = "contract";
			} else if (Func.equals(type, "sz")) {//市值
				tableName = "coin_member_wallet_market";
				wallet_type = "market";
			} else if (Func.equals(type, "lc")) {//理财
				tableName = "coin_member_wallet_wealth";
				wallet_type = "wealth";
			} else if (Func.equals(type, "qq")) {//期权
				tableName = "coin_member_wallet_options";
				wallet_type = "options";
			} else if (Func.equals(type, "sj")) {//商家
				tableName = "coin_service_wallet";
				wallet_type = "service";
			}

			if (Func.isNotEmpty(wallet_type)) {
				WalletGetParam walletGetParam = new WalletGetParam();
				walletGetParam.setCoinId(coinId);
				;
				walletGetParam.setType(wallet_type);
				walletGetParam.setMemberId(memberId);
				//获取我的钱包
				mjkjWebClient.getWalletInfo(walletGetParam);
			}
			QueryWrapper<Object> wrapper = new QueryWrapper<>();
			if (Func.equals(type, "sj")) {//商家有点特别
				Map<String, Object> serviceMap = mjkjBaseSqlService.getDataOneByField("coin_pay_service", "member_id", memberId);
				if (Func.isNotEmpty(serviceMap)) {
					String id = MjkjUtils.getMap2Str(serviceMap, "id");
					wrapper.eq("member_id", id);
				} else {
					continue;
				}
			} else {
				wrapper.eq("member_id", memberId);
			}


			wrapper.eq("is_deleted", "0");
			wrapper.orderByAsc("id");
			List<Map<String, Object>> dataList = mjkjBaseSqlService.getDataListByFieldParams(tableName, wrapper);
			if (Func.isNotEmpty(dataList) && Func.equals(type, "ggzc")) {//杠杠逐仓需要返回交易对
				for (Map<String, Object> dataMap : dataList) {
					String exchangeCoinId = MjkjUtils.getMap2Str(dataMap, "exchange_coin_id");
					Map<String, Object> exchangeCoinMap = exchangeMap.get(exchangeCoinId);
					String symbolName = MjkjUtils.getMap2Str(exchangeCoinMap, "symbol_name");
					dataMap.put("symbol_name", symbolName);//交易对名称
				}
			}
			resultMap.put(type, dataList);
		}
		return R.data(resultMap);
	}

	@ApiOperationSupport(order = 1)
	@GetMapping("/logList")
	@ApiOperation(value = "获取我的钱包操作记录", notes = "获取我的钱包操作记录")
	@ApiImplicitParams({
		@ApiImplicitParam(paramType = "query", name = "memberId", value = "会员id", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "type", value = "类型", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "pageNo", value = "起始页", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "pageSize", value = "每页数", dataType = "String")
	})
	public R logList(String memberId, String type, String pageNo, String pageSize) {

		Map<String, Object> params = new HashMap<>();
		params.put("pageNo", "1");
		params.put("pageSize", "100");
		Page page = MjkjUtils.getPage(params);

		String tableName = "";
		if (Func.equals(type, "qb")) {//钱包
			tableName = "coin_member_wallet_history";
		} else if (Func.equals(type, "bb")) {//币币
			tableName = "coin_member_wallet_spot_history";
		} else if (Func.equals(type, "ggzc")) {//杠杠逐仓
			tableName = "coin_member_wallet_margin_fixed_history";
		} else if (Func.equals(type, "ggqc")) {//杠杠全仓
			tableName = "coin_member_wallet_margin_all_history";
		} else if (Func.equals(type, "hy")) {//合约
			tableName = "coin_member_wallet_contract_history";
		} else if (Func.equals(type, "sz")) {//市值
			tableName = "coin_member_wallet_market_history";
		} else if (Func.equals(type, "lc")) {//理财
			tableName = "coin_member_wallet_wealth_history";
		} else if (Func.equals(type, "sj")) {//商家
			tableName = "coin_service_wallet_history";
		} else if (Func.equals(type, "qq")) {//期权
			tableName = "coin_member_wallet_options_history";
		}

		if (Func.equals(type, "sj")) {//商家有点特别
			Map<String, Object> serviceMap = mjkjBaseSqlService.getDataOneByField("coin_pay_service", "member_id", memberId);
			if (Func.isNotEmpty(serviceMap)) {
				memberId = MjkjUtils.getMap2Str(serviceMap, "id");
			} else {
				return R.data(null);
			}
		}

		QueryWrapper<Object> wrapper = new QueryWrapper<>();
		wrapper.eq("member_id", memberId);
		wrapper.eq("is_deleted", "0");
		wrapper.orderByDesc("id");
		IPage<Map<String, Object>> pageList = mjkjBaseSqlService.getDataIPageByFieldParams(tableName, page, wrapper);
		return R.data(pageList);
	}

	@ApiOperationSupport(order = 1)
	@PostMapping("/updateAmount")
	@ApiOperation(value = "增加/减少可用余额", notes = "增加/减少可用余额")
	@ApiImplicitParams({
		@ApiImplicitParam(paramType = "query", name = "walletId", value = "钱包id", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "walletType", value = "钱包类", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "type", value = "1=增加 2=减少", dataType = "Integer"),
		@ApiImplicitParam(paramType = "query", name = "amount", value = "数量", dataType = "BigDecimal"),
		@ApiImplicitParam(paramType = "query", name = "phoneCode", value = "手机验证码", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "emailCode", value = "邮箱验证码", dataType = "String"),
	})
	public R updateAmount(String walletId, String walletType, Integer type, BigDecimal amount, String phoneCode, String emailCode) {
		/// 后管手机号、邮箱二次校验关闭
		//校验验证码
		/*String redisKeyPhone = "wallet_rgcz:administrator_phone:" + CoinhouseConfig.getAdministratorPhone();
		String redisKeyEmail = "wallet_rgcz:administrator_email:" + CoinhouseConfig.getAdministratorEmail();

		if (Func.isEmpty(phoneCode)) {
			return R.fail("手机验证码不允许为空");
		}
		if (Func.isEmpty(emailCode)) {
			return R.fail("邮箱验证码不允许为空");
		}
		Object phoneO = bladeRedis.get(redisKeyPhone);
		String redisPhoneCode = Func.toStr(phoneO);//缓存编码

		Object emailO = bladeRedis.get(redisKeyEmail);
		String redisEmailCode = Func.toStr(emailO);//缓存编码
		if (!"009009".equals(phoneCode)) {
			if (Func.isEmpty(redisPhoneCode) || !Func.equals(redisPhoneCode, phoneCode)) {
				return R.fail("手机验证码不正确");
			}
		}
		if (!"009009".equals(emailCode)) {
			if (Func.isEmpty(redisEmailCode) || !Func.equals(redisEmailCode, emailCode)) {
				return R.fail("邮箱证码不正确");
			}
		}*/

		String tableName = "";
		String tableNameStr = "";
		if (Func.equals(walletType, "qb")) {//钱包
			tableName = "coin_member_wallet";
			tableNameStr = "钱包账户";
		} else if (Func.equals(walletType, "bb")) {//币币
			tableName = "coin_member_wallet_spot";
			tableNameStr = "币币账户";
		} else if (Func.equals(walletType, "ggzc")) {//杠杠逐仓
			tableName = "coin_member_wallet_margin_fixed";
			tableNameStr = "杠杆逐仓账户";
		} else if (Func.equals(walletType, "ggqc")) {//杠杠全仓
			tableName = "coin_member_wallet_margin_all";
			tableNameStr = "杠杆全仓账户";
		} else if (Func.equals(walletType, "hy")) {//合约
			tableName = "coin_member_wallet_contract";
			tableNameStr = "合约账户";
		} else if (Func.equals(walletType, "sz")) {//市值
			tableName = "coin_member_wallet_market";
			tableNameStr = "市值账户";
		} else if (Func.equals(walletType, "lc")) {//理财
			tableName = "coin_member_wallet_wealth";
			tableNameStr = "理财账户";
		} else if (Func.equals(walletType, "sj")) {//商家
			tableName = "coin_service_wallet";
			tableNameStr = "商家账户";
		} else if (Func.equals(walletType, "qq")) {//期权账户
			tableName = "coin_member_wallet_options";
			tableNameStr = "期权账户";
		}

		if (Func.isEmpty(tableName)) {
			return R.fail("钱包不存在");
		}
		Map<String, Object> walletMap = mjkjBaseSqlService.getTableById(tableName, walletId);
		if (Func.isEmpty(walletMap)) {
			return R.fail("钱包不存在");
		}
		String memberId = MjkjUtils.getMap2Str(walletMap, "member_id");
		String coinId = MjkjUtils.getMap2Str(walletMap, "coin_id");
		String coinSymbol = MjkjUtils.getMap2Str(walletMap, "coin_symbol");


		if (Func.isEmpty(type)) {
			return R.fail("操作记录不正确");
		}
		if (amount.compareTo(BigDecimal.ZERO) != 1) {
			return R.fail("金额必须大于0");
		}
		String nickName = AuthUtil.getNickName();
		if (nickName.length() < 3) {
			nickName = nickName.substring(0, 1) + "*";
		} else if (nickName.length() >= 3) {
			nickName = nickName.substring(0, 1) + "*" + nickName.substring(nickName.length() - 1);
		}
		String bz = "【操作员】：" + AuthUtil.getNickName() + " 【到账账户】：" + tableNameStr;

		if (type == 1) {//增加
			AddWalletParam param = new AddWalletParam();
			param.setTableName(tableName);//钱包表名
			param.setWalletId(walletId);//钱包id
			param.setAddBalance(amount);//增加资产
			param.setServiceType("999");//业务类型
			param.setRemark("客服【" + nickName + "】充值");//备注
			mjkjWebClient.addWallet(param);

			//写充值记录
			Date now = DateUtil.now();
			Map<String, Object> depositMap = new HashMap<>();
			depositMap.put("member_id", memberId);
			depositMap.put("coin_id", coinId);
			depositMap.put("coin_symbol", coinSymbol);
			depositMap.put("amount", amount);
			depositMap.put("entry_time", now);
			depositMap.put("completion_time", now);
			depositMap.put("confirm_count", 1);
			depositMap.put("log_status", 1);//成功
			depositMap.put("amount_usdt", 0);//USDT金额
			depositMap.put("bill_code", IdWorker.getId());//编号
			depositMap.put("bz", bz);
			depositMap.put("deposit_type", "人工充值");
			mjkjBaseSqlService.baseInsertData("coin_log_deposit", depositMap);

		} else if (type == 2) {//减少
			SubWalletParam param = new SubWalletParam();
			param.setTableName(tableName);//钱包表名
			param.setWalletId(walletId);//钱包id
			param.setSubBalance(amount);//减少资产
			param.setServiceType("999");//业务类型
			param.setRemark("客服【" + nickName + "】扣除");//备注
			mjkjWebClient.subWallet(param);
		}
		return R.success("成功");
	}


}
