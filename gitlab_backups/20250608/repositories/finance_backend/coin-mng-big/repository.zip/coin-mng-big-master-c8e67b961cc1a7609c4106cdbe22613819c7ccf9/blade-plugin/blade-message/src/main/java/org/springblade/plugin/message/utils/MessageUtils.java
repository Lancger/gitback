package org.springblade.plugin.message.utils;

public class MessageUtils {
	public static Boolean webSocketFlag=false;
}
