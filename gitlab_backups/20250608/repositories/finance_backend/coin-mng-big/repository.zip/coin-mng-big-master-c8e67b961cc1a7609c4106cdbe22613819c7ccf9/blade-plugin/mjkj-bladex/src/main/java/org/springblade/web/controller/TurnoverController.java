package org.springblade.web.controller;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.service.IFinancialService;
import org.springblade.web.service.ITurnoverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Author: @Wai
 * Date: 2022-7-16
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("coin/agent/turnover")
@Api(value = "代理商管理", tags = "代理商管理")
public class TurnoverController {
	private final ITurnoverService turnoverService;
	private final IMjkjBaseSqlService sqlService;
	@Autowired
	private IFinancialService financialService;

	@ApiOperationSupport(order = 1)
	@GetMapping("/statistics/all")
	@ApiOperation(value = "otc和币币统计", notes = "otc和币币统计")
	public R<Map<String, Object>> allStatisticsGraph() {
		Map<String, Object> statistics = turnoverService.allStatistics();
		return R.data(statistics);
	}

	@ApiOperationSupport(order = 1)
	@GetMapping("/statistics/graph")
	@ApiOperation(value = "法币现货统计图", notes = "法币现货统计图")
	public R<Map<String, Object>> allStatisticsGraph(Integer type,
													 @RequestParam(required = false) String startTime,
													 @RequestParam(required = false) String endTime) {
		if (null==type)
			return R.fail("error");
		Date startDate;
		if (Func.isEmpty(startTime))
			startDate = null;
		else
			startDate = DateUtil.parse(startTime, "yyyy-MM-dd");
		Date endDate = endTime == null ? null : DateUtil.parse(endTime, "yyyy-MM-dd");
		Map<String, Object> statistics = turnoverService.allStatisticsGraph(type, startDate, endDate);
		return R.data(statistics);
	}

	@ApiOperationSupport(order = 1)
	@GetMapping("/statistics/detail")
	@ApiOperation(value = "流水统计", notes = "流水统计")
	public R<Map<String, Object>> statistics(@ApiParam("账单类型(1:充值 2:提币 3:交易)") @RequestParam Integer type,
											 @ApiParam("id") @RequestParam(required = false) Long id) {
		Map<String, Object> statistics = turnoverService.statistics(type, id);
		return R.data(statistics);
	}


	@ApiOperationSupport(order = 1)
	@PostMapping("/financial/statistical/reset")
	@ApiOperation(value = "财务统计", notes = "财务统计")
	public R financialReset( Map<String, Object> map) {
		if (!AuthUtil.isAdministrator()) {
			return R.fail("仅超级管理员可操作");
		}
		String startDateStr = MjkjUtils.getMap2Str(map, "startDate");
		Date date = DateUtil.parse(Func.isEmpty(startDateStr) ? "2022-07-07" : startDateStr, "yyyy-MM-dd");
		List<DateTime> list = cn.hutool.core.date.DateUtil.rangeToList(date, new Date(), DateField.DAY_OF_YEAR);
		list.forEach(l -> {
			financialService.otc(l);
			financialService.coin(l);
			financialService.contract(l);
			financialService.wealth(l);
			financialService.margin(l);
			financialService.market(l);
			financialService.memberWithdrawal(l);
			financialService.systemAssets(l);
		});
		return R.success("成功");
	}
}
