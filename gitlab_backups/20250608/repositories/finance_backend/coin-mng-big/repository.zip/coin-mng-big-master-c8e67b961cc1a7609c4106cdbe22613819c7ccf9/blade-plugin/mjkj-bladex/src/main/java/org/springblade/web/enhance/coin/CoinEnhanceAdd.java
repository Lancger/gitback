package org.springblade.web.enhance.coin;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.RequiredArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.utils.Func;
import org.springblade.third.cache.CacheNames;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 检查币种是否已存在
 * Author: @Wai
 * Date: 2022-6-9
 */
@Component("coinEnhanceAdd")
@RequiredArgsConstructor
public class CoinEnhanceAdd implements CgformEnhanceJavaInter {
	private final IMjkjBaseSqlService mjkjBaseSqlService;
	private final BladeRedis bladeRedis;


	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		String symbol = MjkjUtils.getMap2Str(jsonobject, "symbol");
		Map<String, Object> check = mjkjBaseSqlService.getDataOneByField("coin_coin", "symbol", symbol, Collections.singletonList("id"));
		if (Func.isNotEmpty(check) && !Func.equals(MjkjUtils.getMap2Long(check, "id"), MjkjUtils.getMap2Long(jsonobject, "id")))
			throw new BusinessException("币种已存在，不可重复添加！");
//		List<Map<String, Object>> countries = mjkjBaseSqlService.getDataByTable("coin_country",Collections.singletonList("distinct local_currency"));
//		if (Func.isNotEmpty(countries)) {
//			countries.parallelStream().forEach(m -> {
//				HashMap<String, Object> buy = new HashMap<>();
//				HashMap<String, Object> sell = new HashMap<>();
//				buy.put("to_symbol", MjkjUtils.getMap2Str(jsonobject, "symbol"));
//				buy.put("is_from_unit", "1");
//				sell.put("from_symbol", MjkjUtils.getMap2Str(jsonobject, "symbol"));
//				String currency = MjkjUtils.getMap2Str(m, "local_currency");
//				buy.put("from_symbol", currency);
//				sell.put("to_symbol", currency);
//				if (Func.equals(buy.get("from_symbol"),buy.get("to_symbol")))
//					return;
//				mjkjBaseSqlService.baseInsertData("coin_fiat_quick", buy);
//				mjkjBaseSqlService.baseInsertData("coin_fiat_quick", sell);
//			});
//		}
		// 加入redis缓存
		Map<String, Object> map = new HashMap<>();
		jsonobject.forEach((k, v) -> {
			if (!k.startsWith("$")){
				map.put(k, v);
			}
		});
		// 加入redis缓存
		bladeRedis.set(CacheNames.SYS_COIN_COIN +symbol,JSON.toJSONString(map));
		return 1;
	}
}
