package org.springblade.web.enhance.lang;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.AllArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.utils.Func;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Author: @Wai
 * Date: 2022-9-15
 */
@Component("languageEnhanceAdd")
@AllArgsConstructor
public class LanguageEnhanceAdd implements CgformEnhanceJavaInter {
	private final IMjkjBaseSqlService sqlService;
	private final BladeRedis bladeRedis;
	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		String code = MjkjUtils.getMap2Str(jsonobject, "code");
		String attrPage = MjkjUtils.getMap2Str(jsonobject, "attr_page");
		Map<String, Object> langMap = sqlService.getDataOneByFieldParams("coin_language", Wrappers.query()
			.eq("is_deleted", 0)
			.eq("code", code)
			.eq("attr_page", attrPage));
		if (Func.isNotEmpty(langMap))
			throw new BusinessException("编号及所属页面已存在!");

		// 删除缓存
		bladeRedis.del("coin_language");
		return 1;
	}
}
