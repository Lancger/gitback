package org.springblade.web.enhance.chat;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.web.mapper.ProxyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Author: @Wai
 * Date: 2022-7-19
 * 总代、一级、二级代理都有权限查看自己下级的聊天记录；
 * 聊天记录页是根据会员分类的
 */
@Component("chatEnhanceList")
@AllArgsConstructor
public class ChatEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private ProxyMapper proxyMapper;


	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);

		if(!AuthUtil.isAdministrator()){//不是超级管理员
			Long userId = AuthUtil.getUserId();
			params.put("pid",userId);
		}

		IPage pages = proxyMapper.getChatHistoryList(page, params);
		MjkjUtils.setPageResult(params, pages);
	}
}
