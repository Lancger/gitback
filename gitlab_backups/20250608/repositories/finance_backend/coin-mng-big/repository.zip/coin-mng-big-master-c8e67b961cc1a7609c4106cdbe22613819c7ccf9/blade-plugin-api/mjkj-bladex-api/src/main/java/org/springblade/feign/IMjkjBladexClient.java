package org.springblade.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Date;

/**
 * 水务相关
 */
@FeignClient(
	value = "mjkj-bladex"
)
public interface IMjkjBladexClient {

	String API_PREFIX = "/client";
	String FINANCIAL_STATISTICAL = API_PREFIX + "/financial/statistical";
	String FINANCIAL_CONTRACT_MONITOR = API_PREFIX + "/financial/contract/monitor";
	String WITHDRAW_AUTOAMOUNT = API_PREFIX + "/withdraw/autoAmount";//提现自动放币
	String BA_BALANCE_REMIND = API_PREFIX + "/ba/balance/remind";//提现自动放币

	String Get_FUNDING_RATE = API_PREFIX + "/funding/rate"; // 获取第三方资金费率

	/**
	 * 财务统计
	 */
	@GetMapping(FINANCIAL_STATISTICAL)
	void financialStatistical();

	@PostMapping(FINANCIAL_CONTRACT_MONITOR)
	void financialContractMonitor();

	/**
	 * 提现自动放币
	 */
	@PostMapping(WITHDRAW_AUTOAMOUNT)
	void withdrawAutoAmount();

	/**
	 * binance余额提醒
	 */
	@PostMapping(BA_BALANCE_REMIND)
	void baBalanceRemind();

	@PostMapping(Get_FUNDING_RATE)
	void getFundingRate();
}
