package org.springblade.model;

public enum RequestMethod {
	POST, GET
}
