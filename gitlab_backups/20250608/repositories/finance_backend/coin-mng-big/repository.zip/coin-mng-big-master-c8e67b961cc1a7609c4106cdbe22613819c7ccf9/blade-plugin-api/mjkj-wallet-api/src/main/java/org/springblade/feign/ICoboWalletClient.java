package org.springblade.feign;

import org.springblade.core.tool.api.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

@FeignClient(
	value = "mjkj-wallet"
)
public interface ICoboWalletClient {
	String API_PREFIX = "/cobo-wallet";
	String GET_ADDRESS = API_PREFIX + "/get-address";//创建钱包地址
	String TRANSFER = API_PREFIX + "/transfer";//转账
	String CHECK_ADDRESS = API_PREFIX + "/check-address";//校验地址
	/**
	 * 获取钱包
	 *
	 * @return
	 */
	@PostMapping(GET_ADDRESS)
	R<String> getAddress(@RequestParam("coboSymbol") String coboSymbol, @RequestParam("nativeSegwit") boolean nativeSegwit);


	/**
	 * 转账
	 *
	 * @param chainType       ERC20 TRC20 BTC
	 * @param taskId          任务id
	 * @param toAddress       到账地址
	 * @param amount          转账金额
	 * @param contractAddress 合约地址
	 * @param decimal         币种decimal
	 * @return
	 * @throws Exception
	 */
	@PostMapping(TRANSFER)
	void transfer(@RequestParam("chainType") String chainType, @RequestParam("taskId") String taskId, @RequestParam("coboSymol") String coboSymbol,
				  @RequestParam("toAddress") String toAddress, @RequestParam("amount") BigDecimal amount,
				  @RequestParam("contractAddress") String contractAddress, @RequestParam("decimal") int decimal);

	/**
	 * 校验地址
	 * @param coin
	 * @param address
	 * @return
	 */
	@PostMapping(CHECK_ADDRESS)
	R<Boolean> checkAddress(@RequestParam("coin") String coin, @RequestParam("address") String address);


}
