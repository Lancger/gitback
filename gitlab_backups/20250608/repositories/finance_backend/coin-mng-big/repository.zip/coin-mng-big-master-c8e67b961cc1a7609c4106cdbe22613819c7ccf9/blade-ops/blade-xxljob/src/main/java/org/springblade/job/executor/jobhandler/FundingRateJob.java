package org.springblade.job.executor.jobhandler;

import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.springblade.feign.IMjkjBladexClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;


@Component
public class FundingRateJob {

	@Lazy
	@Autowired
	private IMjkjBladexClient bladexClient;

	/**
	 * 获取资金费率
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("getFundingRate")
	public ReturnT<String> getFundingRate(String param) throws Exception {
		bladexClient.getFundingRate();
		return ReturnT.SUCCESS;
	}
}
