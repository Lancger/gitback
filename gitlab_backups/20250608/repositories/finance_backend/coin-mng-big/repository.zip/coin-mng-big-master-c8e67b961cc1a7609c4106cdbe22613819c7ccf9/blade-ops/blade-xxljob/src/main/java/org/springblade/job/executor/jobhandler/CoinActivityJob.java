package org.springblade.job.executor.jobhandler;

import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.springblade.feign.IMjkjWebClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component
public class CoinActivityJob {

	@Lazy
	@Autowired
	private IMjkjWebClient webClient;
	/**
	 * 定时处理活动以及奖品、任务状态
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("activityStatusDeal")
	public ReturnT<String> activityStatusDeal(String param) throws Exception {
		webClient.dealActivityAndTaskStatus();
		return ReturnT.SUCCESS;
	}




	/**
	 * 定时处理用户活动统计数据 发放奖励
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("activityUserStatsDeal")
	public ReturnT<String> activityUserStatsDeal(String param) throws Exception {
		webClient.dealUserTaskDetail();
		return ReturnT.SUCCESS;
	}



	/**
	 * 定时处理用户活动奖励过期
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("activityUserRewardStatusDeal")
	public ReturnT<String> activityUserRewardStatusDeal(String param) throws Exception {
		webClient.dealUserRewardStatus();
		return ReturnT.SUCCESS;
	}




	/**
	 * 定时处理用户日常活动统计数据 重置数据
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("activityUserStatsDayDeal")
	public ReturnT<String> activityUserStatsDayDeal(String param) throws Exception {
		webClient.dealUserDayTaskStatus();
		return ReturnT.SUCCESS;
	}


	/**
	 * 定时处理用户增金仓位，自动平仓
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("activityCouponPositionDeal")
	public ReturnT<String> activityCouponPositionDeal(String param) throws Exception {
		webClient.handleContractRgCoupon();
		return ReturnT.SUCCESS;
	}


}
