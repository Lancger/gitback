package com.cool.core.leaf.segment.mapper;

import com.cool.core.leaf.segment.entity.LeafAllocEntity;
import com.mybatisflex.core.BaseMapper;

public interface LeafAllocMapper extends BaseMapper<LeafAllocEntity> {
}
