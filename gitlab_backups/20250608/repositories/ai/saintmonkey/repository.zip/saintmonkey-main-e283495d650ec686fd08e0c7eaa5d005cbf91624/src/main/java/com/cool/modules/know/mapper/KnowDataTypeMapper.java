package com.cool.modules.know.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.know.entity.KnowDataTypeEntity;

/**
 * 知识信息类型
 */
public interface KnowDataTypeMapper extends BaseMapper<KnowDataTypeEntity> {
}
