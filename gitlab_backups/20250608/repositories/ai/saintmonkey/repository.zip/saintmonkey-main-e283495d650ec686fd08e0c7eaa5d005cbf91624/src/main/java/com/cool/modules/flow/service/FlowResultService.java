package com.cool.modules.flow.service;

import com.cool.core.base.BaseService;
import com.cool.modules.flow.entity.FlowResultEntity;

/**
 * 流程结果
 */
public interface FlowResultService extends BaseService<FlowResultEntity> {
}
