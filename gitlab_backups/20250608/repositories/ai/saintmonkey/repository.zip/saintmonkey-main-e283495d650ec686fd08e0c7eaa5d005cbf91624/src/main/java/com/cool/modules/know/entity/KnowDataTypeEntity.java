package com.cool.modules.know.entity;

import com.cool.core.base.BaseEntity;
import com.mybatisflex.annotation.Column;
import com.mybatisflex.annotation.Table;
import com.mybatisflex.core.handler.Fastjson2TypeHandler;
import com.tangzc.mybatisflex.autotable.annotation.ColumnDefine;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 * 知识信息类型
 */
@Getter
@Setter
@Table(value = "know_data_type")
public class KnowDataTypeEntity extends BaseEntity<KnowDataTypeEntity> {

    @ColumnDefine(comment = "名称", notNull = true)
    private String name;

    @ColumnDefine(comment = "图标")
    private String icon;

    @ColumnDefine(comment = "描述")
    private String description;

    @ColumnDefine(comment = "embedding配置ID", notNull = true)
    private Long embedConfigId;

    @ColumnDefine(comment = "embedding配置")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private Map<String, Object> embedOptions;

    @ColumnDefine(comment = "是否开启rerank 0-否 1-是", defaultValue = "0", notNull = true)
    private Integer enableRerank;

    @ColumnDefine(comment = "rerank配置ID")
    private Long rerankConfigId;

    @ColumnDefine(comment = "rerank配置")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private Object rerankOptions;

    @ColumnDefine(comment = "链接更新频率(天)")
    private Integer updateFrequency;

    @ColumnDefine(comment = "状态 0-禁用 1-启用", defaultValue = "1", notNull = true)
    private Integer enable;
}
