package com.cool.modules.task.service;

import com.cool.core.base.BaseService;
import com.cool.modules.task.entity.TaskLogEntity;

/**
 * 任务日志
 */
public interface TaskInfoLogService extends BaseService<TaskLogEntity> {
}
