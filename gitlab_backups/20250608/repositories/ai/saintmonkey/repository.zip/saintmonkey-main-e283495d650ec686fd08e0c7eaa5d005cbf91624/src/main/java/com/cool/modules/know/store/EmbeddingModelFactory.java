package com.cool.modules.know.store;

import cn.hutool.core.util.StrUtil;
import com.cool.core.exception.CoolPreconditions;
import com.cool.modules.flow.nodes.llm.ModelTypeEnum;
import dev.langchain4j.community.model.dashscope.QwenEmbeddingModel;
import dev.langchain4j.community.model.qianfan.QianfanEmbeddingModel;
import dev.langchain4j.community.model.zhipu.ZhipuAiEmbeddingModel;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.ollama.OllamaEmbeddingModel;
import dev.langchain4j.model.openai.OpenAiEmbeddingModel;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class EmbeddingModelFactory {
    private final static Map<String, EmbeddingModel> embeddingMap = new ConcurrentHashMap<>();
    public static EmbeddingModel create(ModelTypeEnum modelTypeEnum, Map<String, Object> options) {
        CoolPreconditions.checkEmpty(modelTypeEnum, "未知类型模型");
        String apiKey = StrUtil.toStringOrNull(options.get("apiKey"));
        String model = StrUtil.toStringOrNull(options.get("model"));
        String key = modelTypeEnum.name() + model;
        if (embeddingMap.containsKey(key)) {
            return embeddingMap.get(key);
        }
        EmbeddingModel embeddingModel = switch (modelTypeEnum) {
            case openai ->
                    OpenAiEmbeddingModel.builder()
                            .apiKey(apiKey)
                            .modelName(model)
                            .build();
            case deepseek ->
                    OpenAiEmbeddingModel.builder()
                            .apiKey(apiKey)
                            .baseUrl(String.valueOf(options.get("baseUrl")))
                            .modelName(model)
                            .build();
            case zhipu ->
                    ZhipuAiEmbeddingModel.builder()
                            .apiKey(apiKey)
                            .model(model)
                            .callTimeout(Duration.ofSeconds(60))
                            .connectTimeout(Duration.ofSeconds(60))
                            .writeTimeout(Duration.ofSeconds(60))
                            .readTimeout(Duration.ofSeconds(60))
                            .logRequests(true)
                            .logResponses(true)
                            .build();
            case ollama ->
                    OllamaEmbeddingModel.builder()
                            .modelName(model)
                            .baseUrl(StrUtil.toStringOrNull(options.get("baseUrl")))
                            .maxRetries(3)
                            .build();
            case qwen ->
                    QwenEmbeddingModel.builder()
                            .apiKey(apiKey)
                            .modelName(model)
                            .build();
            case qianfan ->
                    QianfanEmbeddingModel.builder()
                            .apiKey(apiKey)
                            .secretKey(StrUtil.toStringOrNull(options.get("secretKey")))
                            .modelName(model)
                            .maxRetries(3)
                            .build();
        };
        embeddingMap.put(key, embeddingModel);
        return embeddingModel;
    }
}