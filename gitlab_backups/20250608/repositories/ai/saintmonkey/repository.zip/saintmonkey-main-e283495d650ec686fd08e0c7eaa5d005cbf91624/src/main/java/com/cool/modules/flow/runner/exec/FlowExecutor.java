package com.cool.modules.flow.runner.exec;

import static org.bsc.langgraph4j.StateGraph.END;
import static org.bsc.langgraph4j.StateGraph.START;
import static org.bsc.langgraph4j.action.AsyncEdgeAction.edge_async;
import static org.bsc.langgraph4j.action.AsyncNodeAction.node_async;

import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.StrUtil;
import com.cool.core.exception.CoolPreconditions;
import com.cool.modules.flow.runner.context.FlowContext;
import com.cool.modules.flow.runner.context.LineInfo;
import com.cool.modules.flow.runner.context.NodeInfo;
import com.cool.modules.flow.runner.context.SimpleNodeInfo;
import com.cool.modules.flow.runner.node.FlowNode;
import com.cool.modules.flow.runner.result.FlowResult;
import java.util.*;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.bsc.langgraph4j.GraphStateException;
import org.bsc.langgraph4j.StateGraph;
import org.bsc.langgraph4j.prebuilt.MessagesState;
import org.bsc.langgraph4j.state.AgentState;
import org.bsc.langgraph4j.utils.EdgeMappings;
import org.springframework.stereotype.Component;

/**
 * 执行器
 */
@Getter
@Setter
@Component
@Slf4j
public class FlowExecutor {

    public FlowResult run(String nodeId, FlowContext context) {
        NodeInfo oneNode = oneNode(nodeId, context);
        context.setStartTime(System.currentTimeMillis());
        sendFlow(FlowCallbackData.builder().status("start").build(), context);
        StateGraph<MessagesState<AgentState>> graph = new StateGraph<>(MessagesState::new);
        try {
            // 添加节点
            addNode(context, graph, oneNode);
            // 添加边
            addEdge(context, graph, oneNode);
            var workflow = graph.compile();
            workflow.invoke(new HashMap<>());
            sendFlow(FlowCallbackData.builder()
                    .status("end")
                    .reason("success")
                    .result(context.getFlowResult())
                    .count(context.getCount())
                    .duration(System.currentTimeMillis() - context.getStartTime()).build(), context);
        } catch (Exception e) {
            log.error("执行失败", e);
            context.setFlowResult(FlowResult.builder().success(false).error(e.getMessage()).build());
            sendFlow(FlowCallbackData.builder()
                    .status("end")
                    .reason(e.getMessage())
                    .count(context.getCount())
                    .result(context.getFlowResult())
                    .duration(System.currentTimeMillis() - context.getStartTime()).build(), context);
        }
        return context.getFlowResult();
    }

    private void addEdge(final FlowContext context, StateGraph<MessagesState<AgentState>> graph, NodeInfo oneNode) throws GraphStateException {
        if (ObjUtil.isNotNull(oneNode)) {
            String graphNodeId = getGraphNodeId(oneNode);
            graph.addEdge(START, graphNodeId);
            graph.addEdge(graphNodeId, END);
            return;
        }
        List<NodeInfo> nodes = context.getFlowGraph().getNodes();
        NodeInfo startNode = nodes.stream().filter(node -> ObjUtil.equal(node.getType(), "start")).findFirst().orElse(null);
        CoolPreconditions.checkEmpty(startNode, "开始节点不存在");
        graph.addEdge(START, getGraphNodeId(startNode));
        // 找出条件节点
        List<NodeInfo> conditionNodes = nodes.stream().filter(node -> ObjUtil.equal(node.getType(), "judge") || ObjUtil.equal(node.getType(), "classify")).toList();
        List<LineInfo> edges = context.getFlowGraph().getEdges();
        List<FlowNode> flowNodes = context.getFlowNodes();
        for (NodeInfo judgeNode : conditionNodes) {
            // 找出所有该条件节点的目标节点
            List<LineInfo> targetNodes = edges.stream().filter(
                    edge ->
                            ObjUtil.equal(edge.getSource(), judgeNode.getId()) &&
                                    (ObjUtil.equal(edge.getSourceType(), "judge") || ObjUtil.equal(edge.getSourceType(), "classify"))).toList();
            EdgeMappings.Builder builder = EdgeMappings.builder();
            targetNodes.forEach(targetNode -> builder.to(getGraphNodeId(targetNode.getTargetType(), targetNode.getTarget())));
            graph.addConditionalEdges(getGraphNodeId(judgeNode), edge_async(state -> {
                sendNodeRunning(judgeNode.getId(), judgeNode.getType(), context);
                FlowNode flowNode = flowNodes.stream().filter(node -> ObjUtil.equal(node.getId(), judgeNode.getId())).findFirst().orElse(null);
                CoolPreconditions.checkEmpty(flowNode, "未找到节点");
                FlowResult result = flowNode.invoke(context);
                context.set(flowNode.getId(), result, "result");
                FlowContext.NodeRunInfo nodeRunInfo = context.getNodeRunInfo(judgeNode.getId());
                if (!result.isSuccess()) {
                    sendNodeDone(judgeNode.getId(), judgeNode.getType(), nodeRunInfo, context);
                    return "";
                }
                sendNodeDone(judgeNode.getId(), judgeNode.getType(), nodeRunInfo, context);
                SimpleNodeInfo next = result.getNext();
                return getGraphNodeId(next.getType(), next.getId());
            }), builder.build());
        }
        // 过滤掉judge和classify节点
        List<LineInfo> commonEdges = edges.stream().filter(edge ->
                ObjUtil.notEqual(edge.getSourceType(), "judge") && ObjUtil.notEqual(edge.getSourceType(), "classify")).toList();
        for (LineInfo edge : commonEdges) {
            graph.addEdge(getGraphNodeId(edge.getSourceType(), edge.getSource()),
                    getGraphNodeId(edge.getTargetType(), edge.getTarget()));
        }
        // 找出所有的结束节点
        List<NodeInfo> endNodes = nodes.stream().filter(edge ->
                ObjUtil.equal(edge.getType(), "end")).toList();
        for (NodeInfo endNode : endNodes) {
            graph.addEdge(getGraphNodeId(endNode), END);
        }
    }

    private void sendNodeRunning(String nodeId, String nodeType, FlowContext context) {
        if (!context.isDebug()) {
            return;
        }
        sendCallback("node", FlowCallbackData.builder()
                .status("running")
                .nodeId(nodeId)
                .nodeType(nodeType)
                .build(), context.getCallback());
    }


    private void sendFlow(FlowCallbackData data, FlowContext context) {
        if (!context.isDebug()) {
            return;
        }
        sendCallback("flow", data, context.getCallback());
    }

    private void sendNodeDone(String nodeId, String nodeType, FlowContext.NodeRunInfo nodeRunInfo, FlowContext context) {
        if (!context.isDebug()) {
            return;
        }
        sendCallback("node", FlowCallbackData.builder()
                .status("done")
                .nodeId(nodeId)
                .nodeType(nodeType)
                .duration(nodeRunInfo.getDuration())
                .result(nodeRunInfo.getResult())
                .nextNodeIds(ObjUtil.isNotNull(nodeRunInfo) && ObjUtil.isNotNull(nodeRunInfo.getResult())
                        && ObjUtil.isNotNull(nodeRunInfo.getResult().getNext()) ? Collections.singletonList(nodeRunInfo.getResult().getNext().getId()) : null)
                .build(), context.getCallback());
    }

    public void sendLlmStream(String nodeId, String content, boolean isEnd, boolean isThinking, FlowContext context) {
        sendCallback("llmStream", FlowCallbackData.builder()
                .isEnd(isEnd)
                .content(content)
                .isThinking(isThinking)
                .nodeId(nodeId)
                .build(), context.getCallback());
    }

    private String getGraphNodeId(NodeInfo oneNode) {
        return getGraphNodeId(oneNode.getType(), oneNode.getId());
    }
    private String getGraphNodeId(String type, String id) {
        return String.format("%s-%s", type, id);
    }

    private void addNode(final FlowContext context, StateGraph<MessagesState<AgentState>> graph, NodeInfo oneNode) throws GraphStateException {
        if (ObjUtil.isNotNull(oneNode)) {
            graph.addNode(String.format("%s-%s", oneNode.getType(), oneNode.getId()), node_async(state -> {
                FlowResult result = context.getFlowNodes().get(0).invoke(context);
                context.set(oneNode.getId(), result, "result");
                return null;
            }));
            return;
        }
        List<FlowNode> flowNodes = context.getFlowNodes();
        // 去除judge和classify节点以及没有任何连线的节点
        for (FlowNode node : flowNodes) {
            // 检查节点是否有连线（作为源节点或目标节点）
            long count = context.getFlowGraph().getEdges().stream()
                    .filter(edge -> ObjUtil.equal(edge.getSource(), node.getId()) || ObjUtil.equal(edge.getTarget(), node.getId()))
                    .count();
            // 跳过没有连线的节点
            if (count == 0) {
                continue;
            }
            graph.addNode(String.format("%s-%s", node.getType(), node.getId()), node_async(state -> {
                if (ObjUtil.equal(node.getType(), "judge") || ObjUtil.equal(node.getType(), "classify")) {
                    return Map.of();
                }
                sendNodeRunning(node.getId(), node.getType(), context);
                FlowResult result = node.invoke(context);
                context.set(node.getId(), result, "result");
                FlowContext.NodeRunInfo nodeRunInfo = context.getNodeRunInfo(node.getId());
                if (!result.isSuccess()) {
                    sendNodeDone(node.getId(), node.getType(), nodeRunInfo, context);
                    CoolPreconditions.alwaysThrow(result.getError());
                }
                CoolPreconditions.check(!result.isSuccess(), "报错中断");
                sendNodeDone(node.getId(), node.getType(), nodeRunInfo, context);
                return Map.of();
            }));
        }
    }

    /**
     * 发送回调消息
     */
    private void sendCallback(String msgType, FlowCallbackData data, FlowCallback callback) {
        if (ObjUtil.isNull(callback)) {
            return;
        }
        callback.execute(FlowCallbackResult.builder()
                .msgType(msgType)
                .data(data)
                .build());
    }
    /**
     * 执行一个节点
     */
    private NodeInfo oneNode(String nodeId, FlowContext context) {
        // 如果未提供节点ID，直接返回
        if (StrUtil.isBlank(nodeId)) {
            return null;
        }
        context.setDebugOne(true);
        // 查找指定的节点
        NodeInfo targetNode = context.getFlowGraph().getNodes().stream().filter(node -> ObjUtil.equal(node.getId(), nodeId)).findFirst().orElse(null);
        CoolPreconditions.checkEmpty(targetNode, "指定的节点不存在");
        context.getFlowGraph().setNodes(Collections.singletonList(targetNode));
        context.setFlowNodes(Collections.singletonList(context.getFlowNodes().stream().filter(node -> ObjUtil.equal(node.getId(), nodeId)).findFirst().orElse(null)));
        return targetNode;
    }

    @FunctionalInterface
    public interface FlowCallback {
        void execute(FlowCallbackResult result);
    }

    @Builder
    @Getter
    @Setter
    public static class FlowCallbackData {
        private FlowResult result;
        private String status;
        private String reason;
        private String nodeType;
        private String nodeId;
        private Long duration;
        private List<String> nextNodeIds;
        private Object count;
        private Boolean isEnd;
        private String content;
        private Boolean isThinking;
    }

    @Builder
    @Getter
    @Setter
    public static class FlowCallbackResult {
        private String msgType;

        private FlowCallbackData data;
    }
}