package com.cool.modules.know.enums;

import com.cool.modules.know.store.KnowStoreBase;
import com.cool.modules.know.store.impl.KnowChromaStore;
import com.cool.modules.know.store.impl.KnowMemoryStore;
import com.cool.modules.know.store.impl.KnowMilvusStore;
import java.util.Arrays;
import lombok.Getter;

public enum StoreType {
    // 内存存储
    MEMORY("memory", KnowMemoryStore.class),
    // Chroma 存储， 云端存储， 需要安装 Chroma 服务
    CHROMA("chroma", KnowChromaStore.class),
    // Milvus 存储， 云端存储， 需要安装 Milvus 服务
    MILVUS("milvus",KnowMilvusStore .class),

    ;
    @Getter
    private String name;
    @Getter
    private final Class<? extends KnowStoreBase> storeClass;

    StoreType(String name, Class<? extends KnowStoreBase> storeClass) {
        this.name = name;
        this.storeClass = storeClass;
    }

    public static StoreType findEnumByName(String name) {
        return Arrays.stream(values())
                .filter(type -> type.name().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }
}