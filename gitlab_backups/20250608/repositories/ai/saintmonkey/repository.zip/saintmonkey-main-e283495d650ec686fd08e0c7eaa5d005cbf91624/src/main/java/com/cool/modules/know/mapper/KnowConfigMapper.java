package com.cool.modules.know.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.know.entity.KnowConfigEntity;

/**
 * 知识库配置
 */
public interface KnowConfigMapper extends BaseMapper<KnowConfigEntity> {
}
