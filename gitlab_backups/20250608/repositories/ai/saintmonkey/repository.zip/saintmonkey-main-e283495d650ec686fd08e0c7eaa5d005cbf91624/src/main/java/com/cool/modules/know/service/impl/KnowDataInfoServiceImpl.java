package com.cool.modules.know.service.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONArray;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.cool.core.base.BaseServiceImpl;
import com.cool.core.base.ModifyEnum;
import com.cool.modules.know.entity.KnowDataInfoEntity;
import com.cool.modules.know.mapper.KnowDataInfoMapper;
import com.cool.modules.know.service.KnowDataInfoService;
import com.cool.modules.know.store.KnowStore;
import com.cool.modules.know.store.KnowStoreBase;
import com.google.common.collect.Lists;
import com.mybatisflex.core.query.QueryWrapper;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 知识信息
 */
@Service
@RequiredArgsConstructor
public class KnowDataInfoServiceImpl extends BaseServiceImpl<KnowDataInfoMapper, KnowDataInfoEntity> implements KnowDataInfoService {
    private final KnowStore knowStore;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Object addBatch(JSONObject requestParams, List<KnowDataInfoEntity> entitys) {
        return super.addBatch(requestParams, entitys);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean update(JSONObject requestParams, KnowDataInfoEntity entity) {
        return super.update(requestParams, entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean delete(JSONObject requestParams, Long... ids) {
        return super.delete(requestParams, ids);
    }

    @Override
    public void modifyBefore(JSONObject requestParams, KnowDataInfoEntity paramEntity, ModifyEnum type) {
        if (ModifyEnum.DELETE.equals(type)) {
            List ids = requestParams.get("ids", List.class);
            if (ObjectUtil.isNotEmpty(ids)) {
                List<KnowDataInfoEntity> list = list(
                    QueryWrapper.create().in(KnowDataInfoEntity::getId, ids));
                List<String> contentIds = list.stream().filter(o -> o.getContent().containsKey("id"))
                    .map(o -> o.getContent().get("id")).toList();
                requestParams.set("contentIds", contentIds);
                requestParams.set("typeId", list.get(0).getTypeId());
            }
        }
    }

    @Override
    public void modifyAfter(JSONObject requestParams, KnowDataInfoEntity paramEntity, ModifyEnum type) {
        List<KnowDataInfoEntity> entities = Lists.newArrayList();
        int status = 1;
        String body = requestParams.getStr("body");
        if (JSONUtil.isTypeJSONArray(body)) {
            JSONArray array = JSONUtil.parseArray(body);
            List<KnowDataInfoEntity> params = array.toList(KnowDataInfoEntity.class);
            if (ModifyEnum.ADD.equals(type)) {
                KnowStoreBase store = knowStore.getKnowStoreBase(params.get(0).getTypeId());
                store.upsert(params.get(0).getTypeId(), params);
                entities.addAll(params);
            }
        } else {
            if (ModifyEnum.ADD.equals(type) && paramEntity.getEnable() == 1) {
                KnowStoreBase store = knowStore.getKnowStoreBase(paramEntity.getTypeId());
                store.upsert(paramEntity.getTypeId(), List.of(paramEntity));
                entities.add(paramEntity);
            } else if (ModifyEnum.UPDATE.equals(type)) {
                KnowDataInfoEntity info = this.getById(paramEntity.getId());
                KnowStoreBase store = knowStore.getKnowStoreBase(info.getTypeId());
                mergeData(info, paramEntity);
                if (info.getEnable() == 0) {
                    status = 0;
                }
                store.upsert(info.getTypeId(), List.of(info));
                entities.add(info);
            } else if (ModifyEnum.DELETE.equals(type)) {
                List contentIds = requestParams.get("contentIds", List.class);
                if (ObjectUtil.isNotEmpty(contentIds)) {
                    Long typeId = requestParams.get("typeId", Long.class);
                    KnowStoreBase store = knowStore.getKnowStoreBase(typeId);
                    store.remove(typeId, contentIds);
                }
            }
        }
        if (ObjectUtil.isNotEmpty(entities)) {
            int finalStatus = status;
            entities.forEach(o -> o.setStatus(finalStatus));
            this.updateBatch(entities);
        }
    }

    private KnowDataInfoEntity mergeData(KnowDataInfoEntity existing, KnowDataInfoEntity updated) {
        // 合并数据的逻辑
        existing.setContent(updated.getContent());
        existing.setEnable(updated.getEnable());
        existing.setTitle(updated.getTitle());
        // 继续合并其他字段
        return existing;
    }
}