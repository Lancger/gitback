package com.cool.modules.know.controller.admin.data;


import static com.cool.modules.know.entity.table.KnowDataInfoEntityTableDef.KNOW_DATA_INFO_ENTITY;

import cn.hutool.json.JSONObject;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.base.BaseController;
import com.cool.modules.know.entity.KnowDataInfoEntity;
import com.cool.modules.know.service.KnowDataInfoService;
import com.mybatisflex.core.query.QueryWrapper;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;

/**
 * 知识信息
 */
@Tag(name = "知识信息", description = "知识信息")
@CoolRestController(api = {"add", "delete", "update", "page", "list", "info"})
public class AdminKnowDataInfoController extends BaseController<KnowDataInfoService, KnowDataInfoEntity> {
    @Override
    protected void init(HttpServletRequest request, JSONObject requestParams) {
        Integer from = requestParams.get("from", Integer.class);
        Long typeId = requestParams.get("typeId", Long.class);
        setPageOption(createOp().keyWordLikeFields(KNOW_DATA_INFO_ENTITY.TITLE, KNOW_DATA_INFO_ENTITY.CONTENT)
            .queryWrapper(QueryWrapper.create().where(KNOW_DATA_INFO_ENTITY.SOURCE.eq(from)
                .and(KNOW_DATA_INFO_ENTITY.TYPE_ID.eq(typeId)))));
    }
}