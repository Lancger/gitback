package com.cool.modules.know.entity;
import com.cool.core.base.BaseEntity;
import com.mybatisflex.annotation.Column;
import com.mybatisflex.annotation.Table;
import com.mybatisflex.core.handler.Fastjson2TypeHandler;
import com.tangzc.mybatisflex.autotable.annotation.ColumnDefine;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.dromara.autotable.annotation.Ignore;
import org.dromara.autotable.annotation.Index;

/**
 * 知识信息
 */
@Getter
@Setter
@Table(value = "know_data_info")
public class KnowDataInfoEntity extends BaseEntity<KnowDataInfoEntity> {

    @Index
    @ColumnDefine(comment = "类型ID", notNull = true)
    private Long typeId;

    @ColumnDefine(comment = "标题")
    private String title;

    // 为了兼容postgre
    @ColumnDefine(comment = "内容", notNull = true, type = "json")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private Map<String, String> content;

    @ColumnDefine(comment = "来源 0-自定义 1-文件 2-链接", defaultValue = "0", notNull = true)
    private int source;

    @ColumnDefine(comment = "元数据", type = "json")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private Map<String, Object> metadata;

    @ColumnDefine(comment = "状态 0-准备中 1-已就绪", defaultValue = "0", notNull = true)
    private int status;

    @ColumnDefine(comment = "启用 0-禁用 1-启用", defaultValue = "1", notNull = true)
    private int enable;

    public Map<String, String> getContent() {
        if (content == null) {
            content = new HashMap<>();
        }
        return content;
    }

    /******node版本使用的是from字段，该字段为关键字，
     * 在postgresql中 autotable 创建字段 没加 双引号 会导致报错；顾该字段使用 source 替换 落库
     * 返回前端还是使用 from
     * *******/
    @Ignore
    @Column(ignore = true)
    private int from;

    public void setFrom(int from) {
        this.source = from;
        this.from = from;
    }

    public void setSource(int source) {
        this.source = source;
        this.from = source;
    }
}
