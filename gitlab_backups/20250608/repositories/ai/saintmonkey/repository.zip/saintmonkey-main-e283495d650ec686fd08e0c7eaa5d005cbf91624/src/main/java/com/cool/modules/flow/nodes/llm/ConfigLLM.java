package com.cool.modules.flow.nodes.llm;
import java.util.List;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "configllm")
public class ConfigLLM {

    private Map<String, LLMConfig> config;

    public static class LLMConfig {
        private Map<String, String> comm;
        private List<Option> options;

        // Getters and Setters
        public Map<String, String> getComm() {
            return comm;
        }

        public void setComm(Map<String, String> comm) {
            this.comm = comm;
        }

        public List<Option> getOptions() {
            return options;
        }

        public void setOptions(List<Option> options) {
            this.options = options;
        }
    }

    public static class Option {
        private String field;
        private String title;
        private List<String> select;
        private String defaultValue;
        private String type;
        private double max;
        private double min;
        private boolean enable;
        private String tips;
        private List<String> supports;

        // Getters and Setters
        // ...

        public String getField() {
            return field;
        }

        public void setField(String field) {
            this.field = field;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public List<String> getSelect() {
            return select;
        }

        public void setSelect(List<String> select) {
            this.select = select;
        }

        public String getDefaultValue() {
            return defaultValue;
        }

        public void setDefaultValue(String defaultValue) {
            this.defaultValue = defaultValue;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public double getMax() {
            return max;
        }

        public void setMax(double max) {
            this.max = max;
        }

        public double getMin() {
            return min;
        }

        public void setMin(double min) {
            this.min = min;
        }

        public boolean isEnable() {
            return enable;
        }

        public void setEnable(boolean enable) {
            this.enable = enable;
        }

        public String getTips() {
            return tips;
        }

        public void setTips(String tips) {
            this.tips = tips;
        }

        public List<String> getSupports() {
            return supports;
        }

        public void setSupports(List<String> supports) {
            this.supports = supports;
        }
    }

    public Map<String, LLMConfig> getConfig() {
        return config;
    }

    public void setConfig(Map<String, LLMConfig> config) {
        this.config = config;
    }
}
