package com.cool.modules.know.enums;

import com.google.common.collect.Lists;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;

@Getter
public enum ConfigType {
    EMBED("embed", "向量化模型"),
    RERANK("rerank", "重排模型Rerank")
    ;

    private final String type;
    private final String title;

    ConfigType(String type, String title) {
        this.type = type;
        this.title = title;
    }

    public static ConfigType findEnumByName(String name) {
        return Arrays.stream(values())
                .filter(type -> type.name().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }

    // 将枚举转换为list的方法
    public static List<Map<String, String>> toList() {
        List<Map<String, String>> list = Lists.newArrayList();
        for (ConfigType config : values()) {
            Map<String, String> map = new HashMap<>();
            map.put("title", config.title);
            map.put("type", config.type);
            list.add(map);
        }
        return list;
    }
}