package com.cool.modules.flow.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.flow.entity.FlowConfigEntity;

/**
 * 流程配置
 */
public interface FlowConfigMapper extends BaseMapper<FlowConfigEntity> {
}
