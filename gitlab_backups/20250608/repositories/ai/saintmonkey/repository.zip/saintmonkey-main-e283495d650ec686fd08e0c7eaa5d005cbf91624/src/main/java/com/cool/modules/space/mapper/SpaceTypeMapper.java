package com.cool.modules.space.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.space.entity.SpaceTypeEntity;

/**
 * 文件空间信息
 */
public interface SpaceTypeMapper extends BaseMapper<SpaceTypeEntity> {
}
