package com.cool.modules.flow.nodes.llm;

import static com.cool.modules.flow.constant.Consts.UN_KNOW_MESSAGE;
import static com.cool.modules.flow.nodes.enums.NodeTypeEnum.know;

import cn.hutool.core.lang.Pair;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.thread.ThreadUtil;
import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.alibaba.fastjson2.JSONObject;
import com.cool.core.exception.CoolException;
import com.cool.core.exception.CoolPreconditions;
import com.cool.modules.flow.nodes.llm.memory.PersistentChatMemoryStore;
import com.cool.modules.flow.rag.DefaultRetrievalAugmentor;
import com.cool.modules.flow.runner.context.FlowContext;
import com.cool.modules.flow.runner.context.SimpleNodeInfo;
import com.cool.modules.flow.runner.exec.FlowExecutor;
import com.cool.modules.flow.runner.node.FlowNode;
import com.cool.modules.flow.runner.result.FlowResult;
import com.cool.modules.flow.service.FlowConfigService;
import dev.langchain4j.data.message.*;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.chat.StreamingChatLanguageModel;
import dev.langchain4j.model.chat.response.ChatResponse;
import dev.langchain4j.model.chat.response.StreamingChatResponseHandler;
import dev.langchain4j.model.input.structured.StructuredPrompt;
import dev.langchain4j.model.input.structured.StructuredPromptProcessor;
import dev.langchain4j.model.output.Response;
import dev.langchain4j.rag.content.aggregator.ContentAggregator;
import dev.langchain4j.rag.query.router.QueryRouter;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.service.TokenStream;
import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import java.util.concurrent.CountDownLatch;
@Slf4j
public class NodeLLM extends FlowNode {
    @Override
    public FlowResult run(FlowContext context) {
        Map<String, Object> options = this.getConfig().getOptions();
        Map model = Optional.ofNullable(options.get("model"))
                .map(Map.class::cast)
                .orElseThrow(() -> new IllegalArgumentException("Missing 'model' in options"));
        Long configId = Optional.ofNullable(model.get("configId"))
                .map(Object::toString)
                .map(NumberUtil::parseLong)
                .orElseThrow(() -> new IllegalArgumentException("Invalid 'configId' in model"));
        List messages = Optional.ofNullable(options.get("messages"))
                .map(List.class::cast)
                .orElse(Collections.emptyList());
        int history = Optional.ofNullable(options.get("history"))
                .map(Integer.class::cast)
                .orElse(0);
        String objectId = context.getSessionId();

        FlowConfigService flowConfigService = SpringUtil.getBean(FlowConfigService.class);
        Map<String, Object> config = flowConfigService.getOptions(configId);

        Map<String, Object> params = this.getInputParams();
        List<ChatMessage> list = getChatMessages(messages, objectId, params, history);

        CoolPreconditions.check(list.isEmpty() || list.stream().noneMatch(o -> ChatMessageType.USER.equals(o.type())), "LLM节点USER消息不能为空");

        if (context.isStream()) {
            return new FlowResult(true, handleStreamMode(context, model, config, objectId, history, list));
        } else {
            return new FlowResult(true, handleNonStreamMode(context, model, config, objectId, history, list));
        }
    }

    private static Map<ChatMessageType, String> getMessageTypeListMap(List<ChatMessage> list) {
        // 使用 Collectors.toMap 进行收集，并处理可能的键冲突
        return list.stream()
                .collect(Collectors.toMap(
                        ChatMessage::type, // 键：消息类型
                        ChatMessage::text, // 值：消息内容
                        (existing, replacement) -> existing // 处理键冲突：保留原有值
                ));
    }

    private Map<String, Object> handleStreamMode(FlowContext context, Map<String, Object> model, Map<String, Object> config, String objectId, int history, List<ChatMessage> list) {
        Map<String, Object> result = new HashMap<>();
        CountDownLatch latch = new CountDownLatch(1);
        StringBuilder res = new StringBuilder();
        final FlowExecutor flowExecutor = SpringUtil.getBean(FlowExecutor.class);
        try {
            // 多模态，无法使用assistant
            Map<String, String> imageParams = this.getImageParams();
            if (MapUtil.isNotEmpty(imageParams)) {
                StreamingChatLanguageModel streamingModel = getStreamingModel((String) model.get("supplier"), mergeMaps(model.get("params"), config.get("comm")));
                streamingModel.chat(list, new StreamingChatResponseHandler() {
                    @Override
                    public void onPartialResponse(String content) {
                        res.append(content);
                        writeSafe(flowExecutor, content, false, context);
                    }
                    @Override
                    public void onCompleteResponse(ChatResponse response) {
                        closeSafe(latch, flowExecutor, response, context);
                    }
                    @Override
                    public void onError(Throwable throwable) {
                        handleError(latch, flowExecutor, throwable, context);
                    }
                });
            } else {
                Map<ChatMessageType, String> map = getMessageTypeListMap(list);
                String prompt = toString(map.get(ChatMessageType.USER));
                TokenStream tokenStream;
                if (isMemory(objectId, history)) {
                    IChatMemoryAssistant chatAssistant = getChatMemoryAssistant(true, context, model, config, objectId, history);
                    tokenStream = chatAssistant.chatStream(objectId, toString(map.get(ChatMessageType.SYSTEM)), prompt);
                } else {
                    IChatAssistant chatAssistant = getChatAssistant(true, context, model, config);
                    tokenStream = chatAssistant.chatStream(toString(map.get(ChatMessageType.SYSTEM)), prompt);
                }
                tokenStream.onPartialResponse(content -> {
                            res.append(content);
                            writeSafe(flowExecutor, content, false, context);
                        })
                        .onCompleteResponse(response -> closeSafe(latch, flowExecutor, response, context))
                        .onError(throwable -> handleError(latch, flowExecutor, throwable, context))
                        .start();
            }
        } catch (CoolException e) {
            ThreadUtil.execAsync(() -> writeAndCloseSafe(latch, flowExecutor, UN_KNOW_MESSAGE, context));
        }
        try {
            latch.await();
        } catch (InterruptedException ignore) {}
        result.put("text", res.toString());
        context.set(this.getPrefix() + ".text", res.toString(), "output");
        return result;
    }

    private boolean isMemory(String objectId, int history) {
        return StrUtil.isNotBlank(objectId) && history > 0;
    }

    private Map<String, Object> handleNonStreamMode(FlowContext context, Map<String, Object> model, Map<String, Object> config, String objectId, int history, List<ChatMessage> list) {
        Map<String, Object> result = new HashMap<>();
        try {
            // 多模态，无法使用assistant
            Map<String, String> imageParams = this.getImageParams();
            if (MapUtil.isNotEmpty(imageParams)) {
                ChatLanguageModel chatLanguageModel = getModel((String) model.get("supplier"), mergeMaps(model.get("params"), config.get("comm")));
                ChatResponse response = chatLanguageModel.chat(list);
                if (ObjUtil.isNotNull(response)) {
                    context.set(this.getPrefix() + ".text", response.aiMessage().text(), "output");
                    context.updateCount("tokenUsage", response.tokenUsage() != null
                            && response.tokenUsage().totalTokenCount() != null ? response.tokenUsage().totalTokenCount() : 0);
                    result.put("text", response.aiMessage().text());
                    return result;
                }
            } else {
                Map<ChatMessageType, String> map = getMessageTypeListMap(list);
                String prompt = toString(map.get(ChatMessageType.USER));
                Response<AiMessage> response;
                if (isMemory(objectId, history)) {
                    IChatMemoryAssistant chatAssistant = getChatMemoryAssistant(false, context, model, config, objectId, history);
                    response = chatAssistant.chat(objectId, toString(map.get(ChatMessageType.SYSTEM)), prompt);
                } else {
                    IChatAssistant chatAssistant = getChatAssistant(false, context, model, config);
                    response = chatAssistant.chat(toString(map.get(ChatMessageType.SYSTEM)), prompt);
                }
                if (ObjUtil.isNotNull(response)) {
                    context.set(this.getPrefix() + ".text", response.content().text(), "output");
                    context.updateCount("tokenUsage", response.tokenUsage() != null
                            && response.tokenUsage().totalTokenCount() != null ? response.tokenUsage().totalTokenCount() : 0);                    result.put("text", response.content().text());
                    return result;
                }
            }
        } catch (CoolException ignored) {}
        context.set(this.getPrefix() + ".text", UN_KNOW_MESSAGE, "output");
        result.put("text", UN_KNOW_MESSAGE);
        return result;
    }

    private void writeSafe(FlowExecutor flowExecutor, String content, boolean isThinking, FlowContext context) {
        flowExecutor.sendLlmStream(NodeLLM.super.getId(), content, false, isThinking, context);
    }

    private void closeSafe(CountDownLatch latch, FlowExecutor flowExecutor, ChatResponse response, FlowContext context) {
        flowExecutor.sendLlmStream(NodeLLM.super.getId(), null, true, false, context);
        context.updateCount("tokenUsage", response.tokenUsage() != null
                && response.tokenUsage().totalTokenCount() != null ? response.tokenUsage().totalTokenCount() : 0);
        latch.countDown();
    }

    private void handleError(CountDownLatch latch, FlowExecutor flowExecutor, Throwable throwable, FlowContext context) {
        flowExecutor.sendLlmStream(NodeLLM.super.getId(), throwable.getMessage(), false, false, context);
        latch.countDown();
    }

    private void writeAndCloseSafe(CountDownLatch latch, FlowExecutor flowExecutor, String content, FlowContext context) {
        flowExecutor.sendLlmStream(NodeLLM.super.getId(), content, false, false, context);
        latch.countDown();
    }

    private String toString(Object arg) {
        if (arg.getClass().isArray()) {
            return arrayToString(arg);
        } else if (arg.getClass().isAnnotationPresent(StructuredPrompt.class)) {
            return StructuredPromptProcessor.toPrompt(arg).text();
        } else {
            return arg.toString();
        }
    }

    private String arrayToString(Object arg) {
        StringBuilder sb = new StringBuilder();
        int length = Array.getLength(arg);
        for (int i = 0; i < length; i++) {
            sb.append(toString(Array.get(arg, i)));
            if (i < length - 1) {
                sb.append(", ");
            }
        }
        return sb.toString();
    }
    private IChatAssistant getChatAssistant(boolean stream, FlowContext context, Map<String, Object> model, Map<String, Object> config) {
        AiServices<IChatAssistant> builder = AiServices.builder(IChatAssistant.class);
        builderRAG(stream, context, model, config, builder);
        return builder.build();
    }

    private IChatMemoryAssistant getChatMemoryAssistant(boolean stream, FlowContext context, Map<String, Object> model, Map<String, Object> config, String objectId, int history) {
        AiServices<IChatMemoryAssistant> builder = AiServices.builder(IChatMemoryAssistant.class);
        builderRAG(stream, context, model, config, builder);
        builder.chatMemoryProvider(memoryId -> MessageWindowChatMemory.builder()
                .maxMessages(history + 2)
                .id(objectId)
                .chatMemoryStore(SpringUtil.getBean(PersistentChatMemoryStore.class))
                .build());
        return builder.build();
    }

    private void builderRAG(boolean stream, FlowContext context, Map<String, Object> model, Map<String, Object> config, AiServices builder) {
        List<SimpleNodeInfo> nextNodes = getPrevNodes(context.getFlowGraph());
        SimpleNodeInfo nodeInfo = nextNodes.stream().filter(o -> ObjUtil.equals(o.getType(), know.name())).findFirst().orElse(null);
        if (stream) {
            builder.streamingChatLanguageModel(getStreamingModel((String) model.get("supplier"), mergeMaps(model.get("params"), config.get("comm"))));
        } else {
            builder.chatLanguageModel(getModel((String) model.get("supplier"), mergeMaps(model.get("params"), config.get("comm"))));
        }
        if (ObjUtil.isNotNull(nodeInfo) && ObjUtil.equals(nodeInfo.getType(), know.name())) {
            // 前一节点为知识库，进行rag大模型增强
            Pair<QueryRouter, Boolean> pair = getQueryRouter(context, nodeInfo);
            if (ObjUtil.isNotNull(pair.getKey())) {
                builder.retrievalAugmentor(DefaultRetrievalAugmentor.builder()
                        .queryRouter(pair.getKey())
                        .contentAggregator(getContentAggregator(context, nodeInfo))
                        .breakIfSearchMissed(pair.getValue())
                        .build());
            }
        }
    }

    private Pair<QueryRouter, Boolean> getQueryRouter(FlowContext context, SimpleNodeInfo nodeInfo) {
        Map<String, Object> data = context.getData("input");
        Object queryRouterObj = data.get(String.format("%s.%s.queryRouter", nodeInfo.getType(), nodeInfo.getId()));
        Object breakIfSearchMissedObj = data.get(String.format("%s.%s.breakIfSearchMissed", nodeInfo.getType(), nodeInfo.getId()));
        return Pair.of((QueryRouter) queryRouterObj, ObjUtil.equals(breakIfSearchMissedObj, true));
    }

    private ContentAggregator getContentAggregator(FlowContext context, SimpleNodeInfo nodeInfo) {
        Map<String, Object> data = context.getData("input");
        return (ContentAggregator) data.get(String.format("%s.%s.contentAggregator", nodeInfo.getType(), nodeInfo.getId()));
    }

    public List<ChatMessage> getChatMessages(List<JSONObject> messages, String objectId, Map<String, Object> params, int history) {
        Map<String, String> imageParams = this.getImageParams();
        List<ChatMessage> // 转换格式
                messageList = messages.stream()
                .filter(item -> ObjUtil.isNotEmpty(item.get("content")))
                .map(item -> {
                    if ("system".equals(item.get("role"))) {
                        return new SystemMessage(replace(item.get("content").toString(), params));
                    } else if ("user".equals(item.get("role"))) {
                        if (MapUtil.isNotEmpty(imageParams)) {
                            List<Content> contents = new ArrayList<>();
                            contents.add(TextContent.from(replace(item.get("content").toString(), params)));
                            for (String value : imageParams.values()) {
                                contents.add(ImageContent.from(value));
                            }
                            return UserMessage.from(contents);
                        }
                        return new UserMessage(replace(item.get("content").toString(), params));
                    }
                    return new AiMessage(replace(item.get("content").toString(), params));
                }).collect(Collectors.toList());
        if (history > 0) {
            CoolPreconditions.checkEmpty(objectId, "需要保存历史信息，请求参数必须包含objectId (请添加objectId字段的入参，标记为会话Id)");
        }
        return messageList;
    }

    private String replace(String content, Map<String, Object> params) {
        if (params == null) {
            return content;
        }
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            if (entry.getValue() == null) {
                continue;
            }
            content = content.replace("{" + entry.getKey() + "}", entry.getValue().toString());
        }
        return content;
    }
}