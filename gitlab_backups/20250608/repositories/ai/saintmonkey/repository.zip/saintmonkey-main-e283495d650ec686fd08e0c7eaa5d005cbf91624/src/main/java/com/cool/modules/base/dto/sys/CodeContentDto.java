package com.cool.modules.base.dto.sys;

import lombok.Data;

@Data
public class CodeContentDto {
    private String path;
    private String content;
}
