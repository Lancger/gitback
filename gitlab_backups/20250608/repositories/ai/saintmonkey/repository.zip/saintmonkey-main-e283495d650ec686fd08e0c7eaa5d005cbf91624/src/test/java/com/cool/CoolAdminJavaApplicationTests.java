package com.cool;

import cn.hutool.core.util.ReflectUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.cool.core.cache.CoolCache;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.Map;

@SpringBootTest
class CoolAdminJavaApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    public void test() {
        Map<String, Object> params = new HashMap<>();
        params.put("inObjectId","111");
        params.put("inLabelId","4");
        Object obj = SpringUtil.getBean(CoolCache.class);
        String rediskey = "dialogueCount:"+params.get("inLabelId")+":"+params.get("inObjectId");
        Integer num = 0;
        Object version = ReflectUtil.invoke(obj, "get", rediskey);
        if(null == version){
            ReflectUtil.invoke(obj, "set", rediskey,num);
        }else{
            num = (Integer)version+1;
            ReflectUtil.invoke(obj, "set", rediskey,num);
        }
        params.put("outDialogueCount",String.valueOf(num));
    }

}
