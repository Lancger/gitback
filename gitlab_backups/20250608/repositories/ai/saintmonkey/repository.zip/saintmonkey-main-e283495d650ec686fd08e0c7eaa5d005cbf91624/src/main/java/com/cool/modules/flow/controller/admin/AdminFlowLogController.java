package com.cool.modules.flow.controller.admin;

import static com.cool.modules.flow.entity.table.FlowInfoEntityTableDef.FLOW_INFO_ENTITY;
import static com.cool.modules.flow.entity.table.FlowLogEntityTableDef.FLOW_LOG_ENTITY;

import cn.hutool.json.JSONObject;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.base.BaseController;
import com.cool.modules.flow.entity.FlowLogEntity;
import com.cool.modules.flow.service.FlowLogService;
import com.mybatisflex.core.query.QueryWrapper;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;

/**
 * 流程信息
 */
@Tag(name = "流程信息", description = "流程信息")
@CoolRestController(api = {"add", "delete", "update", "page", "list", "info"})
public class AdminFlowLogController extends BaseController<FlowLogService, FlowLogEntity> {
    @Override
    protected void init(HttpServletRequest request, JSONObject requestParams) {
        setPageOption(createOp().select(FLOW_LOG_ENTITY.ALL_COLUMNS,FLOW_INFO_ENTITY.NAME.as("flowName"), FLOW_INFO_ENTITY.LABEL.as("flowLabel"))
            .fieldEq(FLOW_LOG_ENTITY.FLOW_ID, FLOW_LOG_ENTITY.TYPE)
            .queryWrapper(QueryWrapper.create().from(FLOW_LOG_ENTITY)
                .join(FLOW_INFO_ENTITY).on(FLOW_LOG_ENTITY.FLOW_ID.eq(FLOW_INFO_ENTITY.ID))));
    }
}