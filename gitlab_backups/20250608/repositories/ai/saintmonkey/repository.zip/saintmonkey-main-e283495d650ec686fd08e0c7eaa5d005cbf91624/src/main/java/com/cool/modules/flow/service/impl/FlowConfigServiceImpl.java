package com.cool.modules.flow.service.impl;

import static com.cool.modules.flow.entity.table.FlowConfigEntityTableDef.FLOW_CONFIG_ENTITY;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.resource.ResourceUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.cool.core.base.BaseServiceImpl;
import com.cool.core.exception.CoolPreconditions;
import com.cool.core.util.Consts;
import com.cool.modules.flow.entity.FlowConfigEntity;
import com.cool.modules.flow.enums.LLMConfigEnum;
import com.cool.modules.flow.mapper.FlowConfigMapper;
import com.cool.modules.flow.service.FlowConfigService;
import com.cool.modules.know.service.KnowDataTypeService;
import com.mybatisflex.core.query.QueryWrapper;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * 流程配置
 */
@Service
@RequiredArgsConstructor
public class FlowConfigServiceImpl extends BaseServiceImpl<FlowConfigMapper, FlowConfigEntity> implements FlowConfigService {

    private final KnowDataTypeService knowDataTypeService;

    @Override
    public Object all() {
        return LLMConfigEnum.toList();
    }

    @Override
    public Object config(JSONObject requestParams) {
        String node = requestParams.get("node", String.class);
        String type = requestParams.get("type", String.class);
        return getConfig(node, type);
    }

    private Object getConfig(String node, String type) {
        if (ObjectUtil.equal(node, "know")) {
            return Map.of("knows", knowDataTypeService.getKnows());
        }
        String json = ResourceUtil.readUtf8Str(String.format(Consts.FLOW_CONFIG, node));
        CoolPreconditions.checkEmpty(json, "llm config file is empty");
        Map map = JSONUtil.toBean(json, Map.class);
        if (ObjectUtil.isNotEmpty(type)) {
            return map.get(type);
        }
        return map;
    }

    @Override
    public Object getByNode(String node, String type) {
        return this.list(QueryWrapper.create()
            .and(FLOW_CONFIG_ENTITY.TYPE.eq(type))
            .and(FLOW_CONFIG_ENTITY.NODE.eq(node))).stream().map(o -> {
            Map<String, Object> stringObjectMap = BeanUtil.beanToMap(o);
            if (ObjectUtil.isNotEmpty(o.getOptions())) {
                stringObjectMap.put("options", JSONUtil.toBean(o.getOptions(), Map.class));
            }
            return stringObjectMap;
        }).collect(Collectors.toList());
    }

    @Override
    public Map<String, Object> getOptions(Long configId) {
        FlowConfigEntity flowConfigEntity = this.getById(configId);
        return ObjectUtil.isNotEmpty(flowConfigEntity) &&
            ObjectUtil.isNotEmpty(flowConfigEntity.getOptions())
            ? JSONUtil.toBean(flowConfigEntity.getOptions(), Map.class) : Map.of();
    }
}