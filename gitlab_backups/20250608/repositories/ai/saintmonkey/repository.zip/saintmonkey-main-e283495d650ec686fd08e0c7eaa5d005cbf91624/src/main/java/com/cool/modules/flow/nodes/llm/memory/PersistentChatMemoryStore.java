package com.cool.modules.flow.nodes.llm.memory;

import com.cool.core.cache.CoolCache;
import dev.langchain4j.data.message.ChatMessage;
import dev.langchain4j.store.memory.chat.ChatMemoryStore;
import lombok.RequiredArgsConstructor;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import static dev.langchain4j.data.message.ChatMessageDeserializer.messagesFromJson;
import static dev.langchain4j.data.message.ChatMessageSerializer.messagesToJson;

import java.util.List;

/**
 * 会话记录存储器
 */
@Component
@RequiredArgsConstructor
public class PersistentChatMemoryStore implements ChatMemoryStore {

    private final CoolCache coolCache;

    @Value("${llm.memory.ttl:86400}")
    private Long ttl;

    @Override
    public List<ChatMessage> getMessages(Object memoryId) {
        String json = coolCache.get(getString(memoryId), String.class);
        return messagesFromJson(json);
    }

    @Override
    public void updateMessages(Object memoryId, List<ChatMessage> messages) {
        String json = messagesToJson(messages);
        // 默认存储1天
        coolCache.set(getString(memoryId), json, ttl);
    }

    @Override
    public void deleteMessages(Object memoryId) {
        coolCache.del(getString(memoryId));
    }

    @NotNull
    private static String getString(Object memoryId) {
        return "chat:memory:" + memoryId;
    }
}