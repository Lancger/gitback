package com.cool.modules.know.enums;

import java.util.Arrays;

public enum RerankScoringType {
    Cohere("cohere", "cohere");

    private final String type;
    private final String title;

    RerankScoringType(String type, String title) {
        this.type = type;
        this.title = title;
    }

    public static RerankScoringType findEnumByType(String name) {
        return Arrays.stream(values())
                .filter(type -> type.name().equalsIgnoreCase(name))
                .findFirst().orElse(null);
    }
}