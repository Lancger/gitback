package com.cool.modules.flow.controller.admin;

import cn.hutool.json.JSONObject;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.base.BaseController;
import com.cool.core.request.R;
import com.cool.modules.flow.entity.FlowConfigEntity;
import com.cool.modules.flow.entity.table.FlowConfigEntityTableDef;
import com.cool.modules.flow.service.FlowConfigService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;

/**
 * 流程配置
 */
@Tag(name = "流程配置", description = "流程配置")
@CoolRestController(api = {"add", "delete", "update", "page", "list", "info"})
@RequiredArgsConstructor
public class AdminFlowConfigController extends BaseController<FlowConfigService, FlowConfigEntity> {

    private final FlowConfigService flowConfigService;

    @Override
    protected void init(HttpServletRequest request, JSONObject requestParams) {
        setPageOption(createOp().fieldEq(FlowConfigEntityTableDef.FLOW_CONFIG_ENTITY.NODE));
    }

    @Operation(summary = "获取所有配置", description = "获取所有配置")
    @GetMapping("/all")
    public R all() {
        return R.ok(flowConfigService.all());
    }

    @Operation(summary = "获取节点配置", description = "获取节点配置")
    @PostMapping("/config")
    protected R config(@RequestAttribute() JSONObject requestParams) {
        return R.ok(flowConfigService.config(requestParams));
    }

    @Operation(summary = "通过名称获取配置", description = "通过名称获取配置")
    @GetMapping("/getByNode")
    protected R getByNode(String node, String type) {
        return R.ok(flowConfigService.getByNode(node, type));
    }
}