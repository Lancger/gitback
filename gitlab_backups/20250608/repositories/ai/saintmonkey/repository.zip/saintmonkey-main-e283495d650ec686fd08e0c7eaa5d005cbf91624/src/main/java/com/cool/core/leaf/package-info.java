/**
 * 全局唯一id生成
 * 来源美团：https://github.com/Meituan-Dianping/Leaf
 */
package com.cool.core.leaf;
