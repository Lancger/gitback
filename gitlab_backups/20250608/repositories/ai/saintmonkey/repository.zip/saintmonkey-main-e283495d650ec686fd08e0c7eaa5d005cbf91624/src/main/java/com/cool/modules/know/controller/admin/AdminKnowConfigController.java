package com.cool.modules.know.controller.admin;

import static com.cool.modules.know.entity.table.KnowConfigEntityTableDef.KNOW_CONFIG_ENTITY;

import cn.hutool.json.JSONObject;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.base.BaseController;
import com.cool.core.request.R;
import com.cool.modules.know.entity.KnowConfigEntity;
import com.cool.modules.know.service.KnowConfigService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;

/**
 * 知识库配置
 */
@Tag(name = "知识库配置", description = "知识库配置")
@CoolRestController(api = {"add", "delete", "update", "page", "list", "info"})
@RequiredArgsConstructor
public class AdminKnowConfigController extends BaseController<KnowConfigService, KnowConfigEntity> {
    private final KnowConfigService knowConfigService;
    @Override
    protected void init(HttpServletRequest request, JSONObject requestParams) {
        setPageOption(createOp().fieldEq(KNOW_CONFIG_ENTITY.FUNC));
    }

    @Operation(summary = "获取所有配置", description = "获取所有配置")
    @GetMapping("/all")
    public R all() {
        return R.ok(knowConfigService.all());
    }

    @Operation(summary = "获取节点配置", description = "获取节点配置")
    @PostMapping("/config")
    protected R config(@RequestAttribute() JSONObject requestParams) {
        String func = requestParams.get("func", String.class);
        String type = requestParams.get("type", String.class);
        return R.ok(knowConfigService.config(func, type));
    }

    @Operation(summary = "通过名称获取配置", description = "通过名称获取配置")
    @GetMapping("/getByFunc")
    protected R getByFunc(@RequestAttribute() JSONObject requestParams) {
        String func = requestParams.get("func", String.class);
        String type = requestParams.get("type", String.class);
        return R.ok(knowConfigService.getByFunc(func, type));
    }
}