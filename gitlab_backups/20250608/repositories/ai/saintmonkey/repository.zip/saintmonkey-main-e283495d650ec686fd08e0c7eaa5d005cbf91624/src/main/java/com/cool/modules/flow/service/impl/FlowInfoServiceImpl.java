package com.cool.modules.flow.service.impl;

import static com.cool.modules.flow.entity.table.FlowInfoEntityTableDef.FLOW_INFO_ENTITY;

import cn.hutool.core.lang.Pair;
import cn.hutool.core.util.ObjUtil;
import com.cool.core.base.BaseServiceImpl;
import com.cool.core.exception.CoolPreconditions;
import com.cool.modules.flow.entity.FlowInfoEntity;
import com.cool.modules.flow.mapper.FlowInfoMapper;
import com.cool.modules.flow.nodes.NodeFactory;
import com.cool.modules.flow.runner.context.LineInfo;
import com.cool.modules.flow.runner.context.NodeInfo;
import com.cool.modules.flow.runner.node.FlowNode;
import com.cool.modules.flow.runner.node.NodeConfig;
import com.cool.modules.flow.service.FlowInfoService;
import com.mybatisflex.core.query.QueryWrapper;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * 流程信息
 */
@Service
public class FlowInfoServiceImpl extends BaseServiceImpl<FlowInfoMapper, FlowInfoEntity> implements FlowInfoService {

    @Override
    public Boolean release(Long flowId) {
        FlowInfoEntity flowInfoEntity = this.getById(flowId);
        CoolPreconditions.checkEmpty(flowInfoEntity, "流程不存在");

        flowInfoEntity.setVersion(flowInfoEntity.getVersion() + 1);
        flowInfoEntity.setData(flowInfoEntity.getDraft());
        flowInfoEntity.setReleaseTime(new Date());
        return this.updateById(flowInfoEntity);
    }

    @Override
    public Pair<FlowInfoEntity, List<FlowNode>> getNodes(String label, boolean isDraft) {
        FlowInfoEntity flowInfoEntity = this.getOne(QueryWrapper.create().and(FLOW_INFO_ENTITY.LABEL.eq(label))
                .and(FLOW_INFO_ENTITY.STATUS.eq(1)));
        CoolPreconditions.checkEmpty(flowInfoEntity, "流程不存在或被禁用");

        var data = isDraft ? flowInfoEntity.getDraft() : flowInfoEntity.getData();
        CoolPreconditions.checkEmpty(data, "流程未发布，请先发布后调用");
        List<FlowNode> nodes = new ArrayList<>();

        // 构建所有节点
        for (NodeInfo item : data.getNodes()) {
            FlowNode node = NodeFactory.getNode(item.getType());
            node.setId(item.getId());
            node.setFlowId(flowInfoEntity.getId());
            node.setLabel(item.getLabel());
            node.setType(item.getType());
            node.setConfig(new NodeConfig(
                    item.getData().getInputParams(),
                    item.getData().getOutputParams(),
                    item.getData().getOptions()
            ));
            nodes.add(node);
        }
        for (LineInfo item : data.getEdges()) {
            var sourceNode = nodes.stream().filter(node -> ObjUtil.equal(node.getId(), item.getSource())).findFirst().orElse(null);
            if (ObjUtil.isNotNull(sourceNode)) {
                item.setSourceType(sourceNode.getType());
            }
            var targetNode = nodes.stream().filter(node -> ObjUtil.equal(node.getId(), item.getTarget())).findFirst().orElse(null);
            if (ObjUtil.isNotNull(targetNode)) {
                item.setTargetType(targetNode.getType());
            }
        }
        return new Pair<>(flowInfoEntity, nodes);
    }

    @Override
    public FlowInfoEntity getByLable(String label) {
        return this.getOne(QueryWrapper.create().and(FLOW_INFO_ENTITY.LABEL.eq(label)));
    }
}