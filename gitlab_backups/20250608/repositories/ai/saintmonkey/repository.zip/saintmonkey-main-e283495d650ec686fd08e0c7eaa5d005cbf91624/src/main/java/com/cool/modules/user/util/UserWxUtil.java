package com.cool.modules.user.util;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * UserWxUtil - 用户微信工具类
 */
@Component
@RequiredArgsConstructor
public class UserWxUtil {
}
