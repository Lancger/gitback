package com.cool.modules.know.service;

import cn.hutool.core.lang.Pair;
import cn.hutool.json.JSONObject;
import com.cool.core.base.BaseService;
import com.cool.modules.know.entity.KnowConfigEntity;
import java.util.List;
import java.util.Map;

/**
 * 知识库配置
 */
public interface KnowConfigService extends BaseService<KnowConfigEntity> {

    List<Map<String, String>> all();

    Object config(String config, String type);

    Object getByFunc(String func, String type);

    Pair<String, JSONObject> getOptions(Long id);
}