package com.cool.modules.user.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.user.entity.UserWxEntity;

/**
 * 微信用户
 */
public interface UserWxMapper extends BaseMapper<UserWxEntity> {
}
