package com.cool.modules.know.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.resource.ResourceUtil;
import cn.hutool.core.lang.Pair;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.cool.core.base.BaseServiceImpl;
import com.cool.core.base.ModifyEnum;
import com.cool.core.cache.CoolCache;
import com.cool.core.exception.CoolPreconditions;
import com.cool.core.util.Consts;
import com.cool.modules.know.entity.KnowConfigEntity;
import com.cool.modules.know.enums.ConfigType;
import com.cool.modules.know.mapper.KnowConfigMapper;
import com.cool.modules.know.service.KnowConfigService;
import com.mybatisflex.core.query.QueryWrapper;
import java.io.Serializable;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * 知识库配置
 */
@Service
@RequiredArgsConstructor
public class KnowConfigServiceImpl extends BaseServiceImpl<KnowConfigMapper, KnowConfigEntity> implements KnowConfigService {
    private final CoolCache coolCache;
    @Override
    public List<Map<String, String>> all() {
        return ConfigType.toList();
    }

    @Override
    public Object config(String config, String type) {
        String json = null;
        if (config.equals(ConfigType.EMBED.getType())) {
            json = ResourceUtil.readUtf8Str(Consts.KNOW_CONFIG);
        } else {
            json = ResourceUtil.readUtf8Str(Consts.RERANK_CONFIG);
        }
        Map map = JSONUtil.toBean(json, Map.class);
        if (ObjectUtil.isNotEmpty(type)) {
            return map.get(type);
        }
        return map;
    }

    @Override
    public Object getByFunc(String func, String type) {

        return this.list(QueryWrapper.create().eq(KnowConfigEntity::getType, type, ObjectUtil.isNotEmpty(type))
                        .eq(KnowConfigEntity::getFunc, func, ObjectUtil.isNotEmpty(func))).stream()
                .map(o -> {
                    Map<String, Object> stringObjectMap = BeanUtil.beanToMap(o);
                    if (ObjectUtil.isNotEmpty(o.getOptions())) {
                        stringObjectMap.put("options", JSONUtil.toBean(o.getOptions(), Map.class));
                    }
                    return stringObjectMap;
                }).collect(Collectors.toList());
    }

    @Override
    public Pair<String, JSONObject> getOptions(Long id) {
        KnowConfigEntity entity = getById(id);
        CoolPreconditions.checkEmpty(entity);
        return Pair.of(entity.getType(), JSONUtil.parseObj(entity.getOptions()));
    }

    @Override
    public KnowConfigEntity getById(Serializable id) {
        return (KnowConfigEntity) coolCache.get(getRedisKey(id), Duration.ofHours(2), () -> super.getById(id));
    }

    private String getRedisKey(Serializable id) {
        return "KnowConfigEntity_" + id;
    }

    @Override
    public void modifyAfter(JSONObject requestParams, KnowConfigEntity t, ModifyEnum type) {
        if (ObjUtil.isNotNull(t) && ObjUtil.isNotNull(t.getId())) {
            coolCache.del(getRedisKey(t.getId()));
        }
    }
}