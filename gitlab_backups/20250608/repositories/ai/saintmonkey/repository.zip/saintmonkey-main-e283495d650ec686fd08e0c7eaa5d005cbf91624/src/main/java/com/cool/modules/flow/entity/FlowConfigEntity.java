package com.cool.modules.flow.entity;

import com.cool.core.base.BaseEntity;
import com.mybatisflex.annotation.Table;
import com.tangzc.mybatisflex.autotable.annotation.ColumnDefine;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Table(value = "flow_config", comment = "流程配置")
public class FlowConfigEntity extends BaseEntity<FlowConfigEntity> {

    @ColumnDefine(comment = "名称", notNull = true)
    private String name;

    @ColumnDefine(comment = "描述")
    private String description;

    @ColumnDefine(comment = "类型", notNull = true)
    private String type;

    @ColumnDefine(comment = "节点", notNull = true)
    private String node;

    @ColumnDefine(comment = "配置", type = "text", notNull = true)
    private String options;
}
