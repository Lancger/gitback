package com.cool.modules.flow.entity;

import com.cool.modules.flow.runner.context.SimpleNodeInfo;
import com.cool.modules.flow.runner.result.FlowResult;
import com.mybatisflex.annotation.Column;
import com.mybatisflex.annotation.Table;
import com.mybatisflex.core.handler.Fastjson2TypeHandler;
import com.tangzc.mybatisflex.autotable.annotation.ColumnDefine;
import lombok.*;
import org.dromara.autotable.annotation.Index;
import com.cool.core.base.BaseEntity;

import java.util.Map;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(value = "flow_result", comment = "流程结果")
public class FlowResultEntity extends BaseEntity<FlowResultEntity> {

    @ColumnDefine(comment = "请求ID", notNull = true)
    @Index
    private String requestId;

    @ColumnDefine(comment = "节点信息", type = "json")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private SimpleNodeInfo node;

    @ColumnDefine(comment = "节点类型")
    private String nodeType;

    @ColumnDefine(comment = "输入", type = "json")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private Map<String, Object> input;

    @ColumnDefine(comment = "输出", type = "json")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private FlowResult output;

    @ColumnDefine(comment = "持续时间(毫秒)", defaultValue = "0")
    private Long duration;
}