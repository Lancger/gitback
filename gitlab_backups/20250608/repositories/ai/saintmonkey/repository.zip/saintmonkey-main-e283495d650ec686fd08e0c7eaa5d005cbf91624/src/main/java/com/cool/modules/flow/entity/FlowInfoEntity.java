package com.cool.modules.flow.entity;

import com.cool.core.base.BaseEntity;
import com.cool.modules.flow.runner.context.FlowGraph;
import com.mybatisflex.annotation.Column;
import com.mybatisflex.annotation.Table;
import com.mybatisflex.core.handler.Fastjson2TypeHandler;
import com.tangzc.mybatisflex.autotable.annotation.ColumnDefine;
import com.tangzc.mybatisflex.autotable.annotation.UniIndex;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import org.dromara.autotable.annotation.Index;

@Getter
@Setter
@Table(value = "flow_info", comment = "流程信息")
public class FlowInfoEntity extends BaseEntity<FlowInfoEntity> {

    @Index
    @ColumnDefine(comment = "名称", notNull = true)
    private String name;

    @UniIndex
    @ColumnDefine(comment = "标签（可以根据标签调用）")
    private String label;

    @ColumnDefine(comment = "描述")
    private String description;

    @ColumnDefine(comment = "状态 0-禁用 1-启用", defaultValue = "1")
    private Integer status;

    @ColumnDefine(comment = "版本", defaultValue = "1")
    private Integer version;

    @ColumnDefine(comment = "草稿", type = "json")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private FlowGraph draft;

    @ColumnDefine(comment = "数据", type = "json")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private FlowGraph data;

    @ColumnDefine(comment = "发布时间")
    private Date releaseTime;
}
