package com.cool.modules.space.service;

import com.cool.core.base.BaseService;
import com.cool.modules.space.entity.SpaceInfoEntity;

/**
 * 文件空间信息
 */
public interface SpaceInfoService extends BaseService<SpaceInfoEntity> {
}
