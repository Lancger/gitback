package com.cool.modules.flow.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.flow.entity.FlowLogEntity;

/**
 * 流程信息
 */
public interface FlowLogMapper extends BaseMapper<FlowLogEntity> {
}
