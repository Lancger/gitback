package com.cool.modules.know.service.impl;

import static com.cool.modules.know.entity.table.KnowDataInfoEntityTableDef.KNOW_DATA_INFO_ENTITY;
import static com.cool.modules.know.entity.table.KnowDataTypeEntityTableDef.KNOW_DATA_TYPE_ENTITY;

import cn.hutool.core.lang.Pair;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.cool.core.base.BaseServiceImpl;
import com.cool.core.base.ModifyEnum;
import com.cool.core.cache.CoolCache;
import com.cool.modules.flow.nodes.llm.ModelTypeEnum;
import com.cool.modules.know.entity.KnowConfigEntity;
import com.cool.modules.know.entity.KnowDataInfoEntity;
import com.cool.modules.know.entity.KnowDataTypeEntity;
import com.cool.modules.know.enums.CollectionType;
import com.cool.modules.know.mapper.KnowDataTypeMapper;
import com.cool.modules.know.service.KnowConfigService;
import com.cool.modules.know.service.KnowDataInfoService;
import com.cool.modules.know.service.KnowDataTypeService;
import com.cool.modules.know.store.EmbeddingModelFactory;
import com.cool.modules.know.store.KnowStore;
import com.cool.modules.know.store.KnowStoreBase;
import com.mybatisflex.core.query.QueryWrapper;
import com.mybatisflex.core.update.UpdateChain;
import dev.langchain4j.model.embedding.EmbeddingModel;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * 知识信息类型
 */
@Service
@RequiredArgsConstructor
public class KnowDataTypeServiceImpl extends BaseServiceImpl<KnowDataTypeMapper, KnowDataTypeEntity> implements KnowDataTypeService {
    private final KnowDataInfoService knowDataInfoService;

    private final KnowConfigService knowConfigService;

    private final KnowStore knowStore;

    private final CoolCache coolCache;

    @Override
    public List<KnowDataTypeEntity> getKnows() {
        return this.list(QueryWrapper.create().and(KNOW_DATA_TYPE_ENTITY.ENABLE.eq(1)));
    }

    @Override
    public void rebuild(Long typeId) {
        UpdateChain.of(KnowDataInfoEntity.class)
                .set(KnowDataInfoEntity::getStatus, 0)
                .eq(KnowDataInfoEntity::getTypeId, typeId).update();
        KnowStoreBase knowStoreBase = knowStore.getKnowStoreBase(typeId);
        knowStoreBase.collection(typeId, CollectionType.DELETE);
        knowStoreBase.collection(typeId, CollectionType.CREATE);
        List<KnowDataInfoEntity> list = knowDataInfoService.list(
                QueryWrapper.create().and(KNOW_DATA_INFO_ENTITY.ENABLE.eq(1))
                        .and(KNOW_DATA_INFO_ENTITY.TYPE_ID.eq(typeId)));
        knowStoreBase.upsert(typeId, list);
        list.forEach(o -> o.setStatus(1));
        knowDataInfoService.updateBatch(list);
    }

    @Override
    public KnowDataTypeEntity getKnowDataType(Long knowId) {
        return (KnowDataTypeEntity) coolCache.get(getRedisKey(knowId), Duration.ofHours(2), () -> this.getById(knowId));
    }

    private String getRedisKey(Long id) {
        return "KnowDataTypeEntity_" + id;
    }

    @Override
    public void modifyAfter(JSONObject requestParams, KnowDataTypeEntity knowDataTypeEntity, ModifyEnum type) {
        if (ObjUtil.isNotNull(knowDataTypeEntity) && ObjUtil.isNotNull(knowDataTypeEntity.getId())) {
            coolCache.del(getRedisKey(knowDataTypeEntity.getId()));
        }
    }

    @Override
    public Pair<EmbeddingModel, JSONObject> getEmbedding(Long knowId) {
        KnowDataTypeEntity knowDataTypeEntity = getKnowDataType(knowId);
        Long embedConfigId = knowDataTypeEntity.getEmbedConfigId();
        Pair<String, JSONObject> pair = knowConfigService.getOptions(embedConfigId);
        return Pair.of(EmbeddingModelFactory.create(
                ModelTypeEnum.findEnumByName(pair.getKey()),
                mergeJSONObject(pair.getValue().get("comm", Map.class), knowDataTypeEntity.getEmbedOptions())), pair.getValue());
    }

    @Override
    public Pair<String, JSONObject> getRerankOptions(Long knowId) {
        KnowDataTypeEntity knowDataTypeEntity = getKnowDataType(knowId);
        if (ObjUtil.equal(0, knowDataTypeEntity.getEnableRerank())) {
            return null;
        }
        Pair<String, JSONObject> pair = knowConfigService.getOptions(knowDataTypeEntity.getRerankConfigId());
        return Pair.of(pair.getKey(),
                mergeJSONObject(pair.getValue().get("comm", Map.class), knowDataTypeEntity.getRerankOptions()));
    }

    protected JSONObject mergeJSONObject(Object... maps) {
        JSONObject mergedMap = new JSONObject();
        for (Object map : maps) {
            if (map instanceof Map) {
                mergedMap.putAll((Map<String, Object>) map);
            }
        }
        return mergedMap;
    }
}