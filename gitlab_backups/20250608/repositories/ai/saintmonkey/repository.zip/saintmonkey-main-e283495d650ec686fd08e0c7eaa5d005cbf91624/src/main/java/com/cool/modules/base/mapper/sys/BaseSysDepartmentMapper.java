package com.cool.modules.base.mapper.sys;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.base.entity.sys.BaseSysDepartmentEntity;

/**
 * 系统部门
 */
public interface BaseSysDepartmentMapper extends BaseMapper<BaseSysDepartmentEntity> {
}
