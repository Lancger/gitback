package com.cool.modules.know.service;

import com.cool.core.base.BaseService;
import com.cool.modules.know.entity.KnowDataInfoEntity;

/**
 * 知识信息
 */
public interface KnowDataInfoService extends BaseService<KnowDataInfoEntity> {
}
