package com.cool.modules.know.enums;
/**
 * 操作集合的类型
 */
public enum CollectionType {
    CREATE,
    DELETE,
    GET
}