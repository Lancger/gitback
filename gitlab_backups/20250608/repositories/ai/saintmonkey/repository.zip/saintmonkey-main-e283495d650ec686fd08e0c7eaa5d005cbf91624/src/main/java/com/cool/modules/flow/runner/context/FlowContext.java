package com.cool.modules.flow.runner.context;

import com.cool.modules.flow.runner.exec.FlowExecutor;
import com.cool.modules.flow.runner.node.FlowNode;
import com.cool.modules.flow.runner.result.FlowResult;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * 上下文
 */
public class FlowContext {
    /** 请求ID */
    @Setter
    @Getter
    private String requestId;
    /** 会话ID */
    @Setter
    @Getter
    private String sessionId;
    /** 是否调试 */
    @Setter
    @Getter
    private boolean debug = false;
    /** 是否内部调用 */
    @Setter
    @Getter
    private boolean internal = false;
    // 调试单个节点
    @Setter
    @Getter
    private boolean debugOne = false;

    /** 节点 */
    @Setter
    @Getter
    private List<FlowNode> flowNodes;

    /** 开始时间 */
    @Setter
    @Getter
    private long startTime;
    /** 流程结果 */
    @Setter
    @Getter
    private FlowResult flowResult;

    // 存储输入输出数据
    private FlowContextData data = new FlowContextData();
    /** 运行情况 */
    private Map<String, NodeRunInfo> nodeRunInfoMap = new HashMap<>();
    /**
     *  获得请求参数
     */
    @Getter
    @Setter
    private Map<String, Object> requestParams = new HashMap<>();

    // 统计
    @Getter
    private Map<String, Integer> count = new HashMap<>();

    /**
     *  获取流程图
     */
    @Getter
    @Setter
    private FlowGraph flowGraph;

    // 是否流式调用
    @Setter
    @Getter
    private boolean stream = false;

    @Setter
    @Getter
    private FlowExecutor.FlowCallback callback;
    /**
     * 更新统计
     * @param key
     * @param increment
     */
    public void updateCount(String key, int increment) {
        count.put(key, count.getOrDefault(key, 0) + increment);
    }

    /**
     * 设置数据
     * @param key 键
     * @param value 值
     * @param type 类型
     */
    public void set(String key, Object value, String type) {
        if ("input".equals(type)) {
            data.getInput().put(key, value);
        } else if ("output".equals(type)) {
            data.getOutput().put(key, value);
        } else if ("result".equals(type)) {
            data.getResult().put(key, value);
        }
    }

    /**
     * 获取数据
     * @param key
     * @param type
     * @return
     */
    public Object get(String key, String type) {
        return "input".equals(type) ? data.getInput().get(key) : data.getOutput().get(key);
    }

    /**
     * 获取所有输入数据或输出数据
     * @param type
     * @return
     */
    public Map<String, Object> getData(String type) {
        return "input".equals(type) ? data.getInput() : data.getOutput();
    }
    public void setNodeRunInfo(String key, NodeRunInfo nodeRunInfo) {
        this.nodeRunInfoMap.put(key, nodeRunInfo);
    }
    public NodeRunInfo getNodeRunInfo(String key) {
        return this.nodeRunInfoMap.get(key);
    }
    @Builder
    @Data
    public static class NodeRunInfo {
        // 耗时
        private long duration;
        // 是否成功
        private boolean success;
        // 结果
        private FlowResult result;
    }
}