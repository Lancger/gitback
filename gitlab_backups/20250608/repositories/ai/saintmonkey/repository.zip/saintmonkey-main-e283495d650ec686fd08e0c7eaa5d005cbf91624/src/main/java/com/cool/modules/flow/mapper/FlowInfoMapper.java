package com.cool.modules.flow.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.flow.entity.FlowInfoEntity;

/**
 * 流程信息
 */
public interface FlowInfoMapper extends BaseMapper<FlowInfoEntity> {
}
