package com.cool.modules.space.service;

import com.cool.core.base.BaseService;
import com.cool.modules.space.entity.SpaceTypeEntity;

/**
 * 文件空间信息
 */
public interface SpaceTypeService extends BaseService<SpaceTypeEntity> {
}
