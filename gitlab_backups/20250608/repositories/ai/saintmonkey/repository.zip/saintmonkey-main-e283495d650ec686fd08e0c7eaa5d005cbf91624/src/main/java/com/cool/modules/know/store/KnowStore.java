package com.cool.modules.know.store;

import cn.hutool.core.lang.Pair;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.extra.spring.SpringUtil;
import cn.hutool.json.JSONObject;
import com.cool.core.exception.CoolPreconditions;
import com.cool.modules.know.enums.StoreType;
import com.cool.modules.know.service.KnowDataTypeService;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.store.embedding.EmbeddingStore;
import org.springframework.stereotype.Component;

@Component
public class KnowStore {

    /**
     * 获得存储器
     * @return
     */
    public KnowStoreBase getKnowStoreBase(Long knowId) {
        Pair<EmbeddingModel, JSONObject> pair = SpringUtil.getBean(KnowDataTypeService.class).getEmbedding(knowId);
        return getKnowStoreBase(pair.getValue());
    }

    private static KnowStoreBase getKnowStoreBase(JSONObject jsonObject) {
        jsonObject = jsonObject.get("store", JSONObject.class);
        if (ObjUtil.isNull(jsonObject)) {
            jsonObject = new JSONObject();
        }
        String storeType = jsonObject.getStr("type", StoreType.MEMORY.getName());
        StoreType storeTypeEnum = StoreType.findEnumByName(storeType);
        CoolPreconditions.checkEmpty(storeTypeEnum, "暂不支持该存储器 {}", storeType);
        return SpringUtil.getBean(storeTypeEnum.getStoreClass());
    }

    public EmbeddingStore getEmbeddingStore(Long knowId, JSONObject jsonObject) {
        KnowStoreBase knowStoreBase = getKnowStoreBase(jsonObject);
        return knowStoreBase.getStore(knowId);
    }
}