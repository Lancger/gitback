package com.cool.modules.flow.service;

import cn.hutool.core.lang.Pair;
import cn.hutool.core.util.IdUtil;
import com.cool.modules.flow.entity.FlowInfoEntity;
import com.cool.modules.flow.entity.FlowLogEntity;
import com.cool.modules.flow.mongo.FlowMongoLogEntity;
import com.cool.modules.flow.runner.context.FlowContext;
import com.cool.modules.flow.runner.exec.FlowExecutor;
import com.cool.modules.flow.runner.node.FlowNode;
import com.cool.modules.flow.runner.result.FlowResult;
import dev.langchain4j.community.model.xinference.client.utils.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class FlowRunService {

    private final FlowExecutor flowExecutor;

    private final FlowInfoService flowInfoService;

    private final FlowLogService flowLogService;

    private final MongoTemplate mongoTemplate;
    /**
     * 调试
     * @param label 标签
     * @param nodeId 节点ID
     */
    public FlowResult debug(FlowContext context, String label, String nodeId)
            throws IOException {
        // 预初始化
        preInit(label, context);
        // 执行流程
        return flowExecutor.run(nodeId, context);
    }

    private FlowInfoEntity preInit(String label, FlowContext context) {
        // 获得所有节点
        Pair<FlowInfoEntity, List<FlowNode>> pair = flowInfoService.getNodes(label, context.isDebug());
        var info = pair.getKey();
        var nodes = pair.getValue();
        // 设置流程图
        context.setFlowGraph(context.isDebug() ? info.getDraft() :info.getData());
        // 设置流程节点
        context.setFlowNodes(nodes);
        return info;
    }

    public FlowResult invoke(String label, Map<String, Object> params) {
        FlowContext context = new FlowContext();
        context.setInternal(true);
        context.setRequestParams(params);
        context.setRequestId(IdUtil.randomUUID());
        return invoke(label, context);
    }

    /**
     * 调用
     * @param label 标签
     * @returns
     */
    public FlowResult invoke(String label, FlowContext context) {
        // 预初始化
        FlowInfoEntity flowInfo = preInit(label, context);
        // 执行流程
        FlowResult flowResult = flowExecutor.run(null, context);
        FlowLogEntity flowLogEntity = new FlowLogEntity();
        flowLogEntity.setFlowId(flowInfo.getId());
        flowLogEntity.setType(flowResult.isSuccess() ? 1 : 0);
        flowLogEntity.setInputParams(context.getRequestParams());
        flowLogEntity.setResult(flowResult);
        // 保存日志
        flowLogService.save(flowLogEntity);
        FlowMongoLogEntity flowMongoLogEntity = new FlowMongoLogEntity();
        BeanUtils.copyProperties(flowLogEntity,flowMongoLogEntity);
        flowMongoLogEntity.setNodeInfo(JsonUtil.toJson(context.getFlowNodes()));
        flowMongoLogEntity.setResult(JsonUtil.toJson(flowResult));
        flowMongoLogEntity.setCreateTime(new Date());
        flowMongoLogEntity.setUpdateTime(new Date());
        flowMongoLogEntity.setUserId((String)context.getRequestParams().get("userId"));
        mongoTemplate.save(flowMongoLogEntity);
        return flowResult;
    }

    /**
     * 保存日志
     * @param success 是否成功 true | false
     * @param label 标签
     * @param inputParams 输入参数
     * @param result 结果
     * @param error 错误信息
     * @param nodeInfo 节点信息
     */
    private void saveLog(boolean success, String label, Map<String, Object> inputParams, Object result, String error, List<Map<String, Object>> nodeInfo) {
        try {
            FlowInfoEntity flowInfoEntity = flowInfoService.getByLable(label);
            if (flowInfoEntity != null) {

            }
        } catch (Exception e) {
            log.error("保存日志错误", e);
        }
    }
}