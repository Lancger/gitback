package com.cool.modules.flow.runner.node;


import lombok.Data;

@Data
public class BaseFlowNode {

    /**对话次数*/
    private Long dialogueCount = 0L;

    private Long userId =0L;

    public void setDialogueCount(){
        this.dialogueCount+=1;
    }


}
