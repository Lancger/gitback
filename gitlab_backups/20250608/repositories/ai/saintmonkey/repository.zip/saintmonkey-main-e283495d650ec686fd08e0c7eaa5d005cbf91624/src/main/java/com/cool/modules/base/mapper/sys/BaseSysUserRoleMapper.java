package com.cool.modules.base.mapper.sys;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.base.entity.sys.BaseSysUserRoleEntity;

/**
 * 系统用户角色
 */
public interface BaseSysUserRoleMapper extends BaseMapper<BaseSysUserRoleEntity> {
}
