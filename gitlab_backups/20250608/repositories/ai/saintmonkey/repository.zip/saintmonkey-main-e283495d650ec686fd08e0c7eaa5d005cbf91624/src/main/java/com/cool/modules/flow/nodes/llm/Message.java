package com.cool.modules.flow.nodes.llm;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Message {
    // 'system' | 'user' | 'assistant'
    private String role;
    private Object content;

    public Message(String role, Object content) {
        this.role = role;
        this.content = content;
    }

    public Message() {
    }
}
