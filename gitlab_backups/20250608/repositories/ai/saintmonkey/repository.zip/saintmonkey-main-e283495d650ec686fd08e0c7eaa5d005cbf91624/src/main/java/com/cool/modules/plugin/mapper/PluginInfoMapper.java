package com.cool.modules.plugin.mapper;

import com.cool.modules.plugin.entity.PluginInfoEntity;
import com.mybatisflex.core.BaseMapper;

public interface PluginInfoMapper extends BaseMapper<PluginInfoEntity> {

}
