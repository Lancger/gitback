package com.cool.modules.flow.nodes.llm;

import java.util.Arrays;

public enum ModelTypeEnum {
    // 智谱
    zhipu,
    // open ai
    openai,
    // ollama
    ollama,
    // 通义千问
    qwen,
    // 千帆
    qianfan,
    // 深度求索
    deepseek,
    ;

    public static ModelTypeEnum findEnumByName(String name) {
        return Arrays.stream(values())
            .filter(type -> type.name().equalsIgnoreCase(name))
            .findFirst().orElse(null);
    }

}
