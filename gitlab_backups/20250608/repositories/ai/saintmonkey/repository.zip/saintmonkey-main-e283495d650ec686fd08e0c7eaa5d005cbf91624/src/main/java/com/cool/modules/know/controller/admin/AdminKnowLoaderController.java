package com.cool.modules.know.controller.admin;

import cn.hutool.core.io.FileUtil;
import cn.hutool.json.JSONObject;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.request.R;
import com.cool.modules.know.loader.KnowLoaderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

/**
 * 知识库加载器
 */
@CoolRestController
@RequiredArgsConstructor
public class AdminKnowLoaderController {

    private final KnowLoaderService knowLoaderService;

    @Operation(summary = "加载文件，支持多个文件", description = "加载文件，支持多个文件")
    @PostMapping("/file")
    public R file(@RequestPart(value = "files0", required = false) @Parameter(description = "文件") MultipartFile[] files)
        throws IOException {
        List<Object> list = new ArrayList<>();
        for (MultipartFile multipartFile : files) {
            String userDir = System.getProperty("user.dir");
            String filePath = userDir + File.separator + multipartFile.getOriginalFilename();
            multipartFile.transferTo(new File(filePath));
            list.add(List.of(knowLoaderService.loadFile(filePath)));
            FileUtil.del(filePath);
        }
        return R.ok(list);
    }

    @Operation(summary = "加载链接", description = "加载链接")
    @PostMapping("/link")
    public R link(@RequestAttribute JSONObject requestParams) {
        return R.ok(List.of(knowLoaderService.loadLink(requestParams.get("link", String.class))));
    }
}
