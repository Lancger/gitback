package com.cool.modules.know.store.impl;


import static dev.langchain4j.model.openai.OpenAiChatModelName.GPT_3_5_TURBO;

import cn.hutool.core.lang.Pair;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.json.JSONObject;
import com.cool.core.exception.CoolPreconditions;
import com.cool.modules.flow.constant.Consts;
import com.cool.modules.know.entity.KnowDataInfoEntity;
import com.cool.modules.know.enums.CollectionType;
import com.cool.modules.know.service.KnowDataTypeService;
import com.cool.modules.know.store.KnowStoreBase;
import com.google.common.collect.Maps;
import dev.langchain4j.data.document.DefaultDocument;
import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.document.DocumentSplitter;
import dev.langchain4j.data.document.Metadata;
import dev.langchain4j.data.document.splitter.DocumentSplitters;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.openai.OpenAiTokenizer;
import dev.langchain4j.store.embedding.EmbeddingStoreIngestor;
import dev.langchain4j.store.embedding.chroma.ChromaEmbeddingStore;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import tech.amikos.chromadb.Client;
import tech.amikos.chromadb.Collection;
import tech.amikos.chromadb.handler.ApiException;

@Slf4j
@Component
@RequiredArgsConstructor
public class KnowChromaStore extends KnowStoreBase {
    private final KnowDataTypeService knowDataTypeService;

    private final Map<Long, ChromaEmbeddingStore> embeddingStoreMap = Maps.newHashMap();
    private final Map<Long, Client> clientMap = Maps.newHashMap();

    @Override
    public ChromaEmbeddingStore getStore(Long typeId) {
        if (!embeddingStoreMap.containsKey(typeId)) {
            String chromaUrl = getChromaUrl(typeId);
            embeddingStoreMap.put(typeId, ChromaEmbeddingStore.builder()
                .baseUrl(chromaUrl)
                .collectionName(prefix + typeId)
                .build());
        }
        return embeddingStoreMap.get(typeId);
    }

    private Client getClient(Long typeId) {
        if (!clientMap.containsKey(typeId)) {
            String chromaUrl = getChromaUrl(typeId);
            clientMap.put(typeId, new Client(chromaUrl));
        }
        return clientMap.get(typeId);
    }

    private String getChromaUrl(Long typeId) {
        JSONObject storeConfig = getStoreConfig(knowDataTypeService, typeId);
        return storeConfig.getStr("url", "http://127.0.0.1:8000");
    }

    @Override
    public ChromaEmbeddingStore collection(Long typeId, CollectionType type) {
        try {
            if (type == CollectionType.DELETE) {
                String collectionName = prefix + typeId;
                List<Collection> collections = getClient(typeId).listCollections();
                long count = collections.stream().filter(o -> o.getName().equals(collectionName))
                    .count();
                if (count > 0) {
                    getClient(typeId).deleteCollection(collectionName);
                }
                // 重新构建
                embeddingStoreMap.remove(typeId);
                clientMap.remove(typeId);
                return null;
            } else {
                return getStore(typeId);
            }
        } catch (Exception e) {
            log.error("collectionErr", e);
        }
        return null;
    }

    @Override
    public void upsert(Long typeId, List<KnowDataInfoEntity> datas) {
        ChromaEmbeddingStore embeddingStore = getStore(typeId);
        Pair<EmbeddingModel, JSONObject> pair = knowDataTypeService.getEmbedding(typeId);
        EmbeddingModel embeddingModel = pair.getKey();
        JSONObject jsonObject = pair.getValue();
        DocumentSplitter documentSplitter =
            DocumentSplitters.recursive(
                jsonObject.getInt("maxSegmentSizeInTokens", Consts.RAG_MAX_SEGMENT_SIZE_IN_TOKENS),
                jsonObject.getInt("maxOverlapSizeInTokens", 0),
                new OpenAiTokenizer(GPT_3_5_TURBO));
        EmbeddingStoreIngestor embeddingStoreIngestor = EmbeddingStoreIngestor.builder()
            .documentSplitter(documentSplitter)
            .embeddingModel(embeddingModel)
            .embeddingStore(embeddingStore)
            .build();
        datas.forEach(
            o -> {
                if (ObjUtil.isNotEmpty(o.getContent()) && o.getContent().containsKey("data")) {
                    String data = o.getContent().get("data");
                    String documentId = o.getContent().get("id");
                    if (ObjUtil.isNotEmpty(documentId)) {
                        embeddingStore.remove(documentId);
                    }
                    Document document = new DefaultDocument(data, Metadata.metadata("id", String.valueOf(o.getId()))
                        .put("title", o.getTitle()).put("enable", String.valueOf(o.getEnable())));
                    List<String> ids = embeddingStoreIngestor.ingest(document).ids();
                    o.getContent().put("id", ids.get(0));
                }
            });
    }

    @Override
    public void remove(Long typeId, List<String> ids) {
        try{
            String collectionName = prefix + typeId;
            List<Collection> collections = getClient(typeId).listCollections();
            Collection collection = collections.stream().filter(o -> o.getName().equals(collectionName))
                .findFirst().orElse(null);
            if (collection != null && ObjUtil.isNotEmpty(ids)) {
                collection.deleteWithIds(ids);
            }
        } catch (ApiException e) {
            log.error("removeErr", e);
            CoolPreconditions.alwaysThrow(e.getMessage());
        }
    }
}