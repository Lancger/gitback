package com.cool.modules.base.service.sys;

import com.cool.core.base.BaseService;
import com.cool.modules.base.entity.sys.BaseSysRoleEntity;

/**
 * 系统角色
 */
public interface BaseSysRoleService extends BaseService<BaseSysRoleEntity> {
}
