package com.cool.modules.dict.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.dict.entity.DictInfoEntity;

/**
 * 字典信息
 */
public interface DictInfoMapper extends BaseMapper<DictInfoEntity> {
}
