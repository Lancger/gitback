package com.cool.modules.flow.controller.admin;

import cn.hutool.json.JSONObject;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.base.BaseController;
import com.cool.modules.flow.entity.FlowResultEntity;
import com.cool.modules.flow.service.FlowResultService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;

import static com.cool.modules.flow.entity.table.FlowResultEntityTableDef.FLOW_RESULT_ENTITY;

/**
 * 流程结果
 */
@Tag(name = "流程结果", description = "流程结果")
@CoolRestController(api = {"list"})
public class AdminFlowResultController extends BaseController<FlowResultService, FlowResultEntity> {
    @Override
    protected void init(HttpServletRequest request, JSONObject requestParams) {
        setListOption(createOp().fieldEq(FLOW_RESULT_ENTITY.REQUEST_ID, FLOW_RESULT_ENTITY.NODE_TYPE));
    }
}