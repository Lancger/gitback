package com.cool.modules.recycle.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.recycle.entity.RecycleDataEntity;

public interface RecycleDataMapper extends BaseMapper<RecycleDataEntity> {
}
