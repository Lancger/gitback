package com.cool.modules.flow.enums;

import com.google.common.collect.Lists;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;

@Getter
public enum LLMConfigEnum {
    LLM("大模型LLM", "llm"),
    TOOL("工具TOOL", "tool"),
    MCP("功能MCP", "mcp"),

    ;

    private final String title;
    private final String type;

    LLMConfigEnum(String title, String type) {
        this.title = title;
        this.type = type;
    }

    // 将枚举转换为list的方法
    public static List<Map<String, String>> toList() {
        List<Map<String, String>> list = Lists.newArrayList();
        for (LLMConfigEnum config : values()) {
            Map<String, String> map = new HashMap<>();
            map.put("title", config.getTitle());
            map.put("type", config.getType());
            list.add(map);
        }
        return list;
    }
}
