package com.cool.modules.flow.nodes.llm;

import dev.langchain4j.data.message.AiMessage;
import dev.langchain4j.model.output.Response;
import dev.langchain4j.service.*;

public interface IChatMemoryAssistant {

    @SystemMessage("{{sm}}")
    TokenStream chatStream(@MemoryId String memoryId, @V("sm") String systemMessage, @UserMessage String userMessage);

    @SystemMessage("{{sm}}")
    Response<AiMessage> chat(@MemoryId String memoryId, @V("sm") String systemMessage, @UserMessage String userMessage);
}