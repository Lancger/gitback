package com.cool.modules.flow.nodes.end;
import com.cool.modules.flow.runner.context.FlowContext;
import com.cool.modules.flow.runner.node.FlowNode;
import com.cool.modules.flow.runner.node.NodeConfig.OutputParam;
import com.cool.modules.flow.runner.result.FlowResult;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 结束节点
 */
public class NodeEnd extends FlowNode {

    /**
     * 执行方法
     *
     * @param context 流程上下文
     * @return 执行结果
     */
    @Override
    public FlowResult run(FlowContext context) {
        Map<String, Object> datas = context.getData("output");
        Map<String, Object> result = new HashMap<>();
        List<OutputParam> outputParams = this.getConfig().getOutputParams();
        for (OutputParam param : outputParams) {
            String key = getParamPrefix(param) + "." + param.getName();
            result.put(param.getField(), datas.get(key));
        }
        return new FlowResult(true, result);
    }
}
