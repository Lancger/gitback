package com.cool.modules.flow.nodes.judge;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * 配置
 */
@Setter
@Getter
public class Options {
    /** IF条件 */
    private List<Condition> IF;
    /** ELSE条件 */
    private List<Condition> ELSE;
}
