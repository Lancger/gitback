package com.cool.modules.flow.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.flow.entity.FlowDataEntity;

/**
 * 流程数据
 */
public interface FlowDataMapper extends BaseMapper<FlowDataEntity> {
}
