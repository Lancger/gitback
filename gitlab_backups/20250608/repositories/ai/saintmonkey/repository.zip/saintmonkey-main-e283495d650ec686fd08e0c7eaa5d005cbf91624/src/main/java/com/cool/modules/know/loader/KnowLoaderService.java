package com.cool.modules.know.loader;

import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.document.loader.FileSystemDocumentLoader;
import dev.langchain4j.data.document.loader.UrlDocumentLoader;
import dev.langchain4j.data.document.parser.apache.tika.ApacheTikaDocumentParser;
import java.util.Map;
import org.springframework.stereotype.Component;

/**
 * 链接加载器
 */
@Component
public class KnowLoaderService {
    /**
     * 加载链接
     * @param link 链接
     * @return 文档
     */
    public Object loadLink(String link) {
        Document document = UrlDocumentLoader.load(link, new ApacheTikaDocumentParser());
        return Map.of("metadata", Map.of("source", link),
            "pageContent", document.text());
    }

    /**
     * 加载文档
     * @param filePath 文件路径
     * @return 文档
     */
    public Object loadFile(String filePath) {
        Document document = FileSystemDocumentLoader.loadDocument(filePath);
        return Map.of("pageContent", document.text());
    }
}