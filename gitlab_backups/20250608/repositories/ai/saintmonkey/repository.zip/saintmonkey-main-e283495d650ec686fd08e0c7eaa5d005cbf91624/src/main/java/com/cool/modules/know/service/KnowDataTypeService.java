package com.cool.modules.know.service;

import cn.hutool.core.lang.Pair;
import cn.hutool.json.JSONObject;
import com.cool.core.base.BaseService;
import com.cool.modules.know.entity.KnowDataTypeEntity;
import dev.langchain4j.model.embedding.EmbeddingModel;
import java.util.List;

/**
 * 知识信息类型
 */
public interface KnowDataTypeService extends BaseService<KnowDataTypeEntity> {

    List<KnowDataTypeEntity> getKnows();

    void rebuild(Long typeId);

    KnowDataTypeEntity getKnowDataType(Long knowId);

    Pair<EmbeddingModel, JSONObject> getEmbedding(Long knowId);

    Pair<String, JSONObject> getRerankOptions(Long knowId);
}