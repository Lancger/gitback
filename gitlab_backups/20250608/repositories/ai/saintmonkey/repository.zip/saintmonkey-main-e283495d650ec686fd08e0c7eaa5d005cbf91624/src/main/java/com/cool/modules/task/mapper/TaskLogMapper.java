package com.cool.modules.task.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.task.entity.TaskLogEntity;

public interface TaskLogMapper extends BaseMapper<TaskLogEntity> {

}
