package com.cool.modules.flow.nodes.parse;

import cn.hutool.core.util.NumberUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.cool.modules.flow.runner.context.FlowContext;
import com.cool.modules.flow.runner.node.FlowNode;
import com.cool.modules.flow.runner.node.NodeConfig.OutputParam;
import com.cool.modules.flow.runner.result.FlowResult;
import com.cool.modules.flow.service.FlowConfigService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import dev.langchain4j.data.message.AiMessage;
import dev.langchain4j.data.message.UserMessage;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.input.Prompt;
import dev.langchain4j.model.input.PromptTemplate;
import dev.langchain4j.model.output.Response;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class NodeParse extends FlowNode {


    public FlowResult run(FlowContext context) {
        List<OutputParam> outputParams = this.getConfig().getOutputParams();
        Map<String, Object> model = (Map<String, Object>) this.getConfig().getOptions().get("model");

        // 获得输入参数
        Map<String, Object> params = this.getInputParams();

        // 获取流程配置
        Map<String, Object> config = SpringUtil.getBean(FlowConfigService.class).getOptions(NumberUtil.parseLong(model.get("configId").toString()));

        // 获取模型
        ChatLanguageModel llm = getModel((String) model.get("supplier"), mergeMaps(model.get("params"), config.get("comm")));
        PromptTemplate userPromptTemplate = PromptTemplate.from("input: {{inputData}} format: {{format}}");
        Map<String, Object> map = Map.of("inputData", params.get("text"),
                "format", getFormat(outputParams));
        Prompt userPrompt = userPromptTemplate.apply(map);
        PromptTemplate sysPromptTemplate = new PromptTemplate("您现在正在充当信息提取工具。当你收到任何输入时，你需要从中提取相关信息，并以请求的JSON格式输出提取的信息，而不回复任何其他无关的内容。");
        Prompt sysPrompt = sysPromptTemplate.apply(Map.of());

        Response<AiMessage> res = llm.generate(sysPrompt.toSystemMessage(), new UserMessage("user", userPrompt.text()));

        // 获取执行结果
        Map<String, Object> extractResult = extractJSON(res.content().text());

        for (OutputParam param : outputParams) {
            if ("result".equals(param.getField())) {
                context.set(getPrefix() + "." + param.getField(), extractResult, "output");
            } else {
                context.set(getPrefix() + "." + param.getField(), extractResult.get(param.getField()), "output");
            }
        }

        // 更新计数器
        context.updateCount("tokenUsage", res.tokenUsage().totalTokenCount());

        return new FlowResult(true, extractResult);
    }


    private String getFormat(List<OutputParam> list) {
        if (list == null || list.isEmpty()) {
            return "";
        }
        return list.stream()
                .filter(param -> !"result".equals(param.getField())) // 过滤掉 field 为 "result" 的项
                .map(param -> String.format("\"%s\": \"%s\"", param.getField(), param.getType())) // 转换格式
                .collect(Collectors.joining(",")); // 以逗号拼接
    }

    private Map<String, Object> extractJSON(String str) {
        // 使用正则表达式匹配JSON字符串
        Pattern jsonRegex = Pattern.compile("\\{(?:[^{}]|(?:\\{[^{}]*\\}))*\\}");
        Matcher matcher = jsonRegex.matcher(str);
        if (matcher.find()) {
            String jsonString = matcher.group();
            ObjectMapper objectMapper = new ObjectMapper();
            try {
                return objectMapper.readValue(jsonString, new TypeReference<Map<String, Object>>() {});
            } catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        }
        return null;
    }
}