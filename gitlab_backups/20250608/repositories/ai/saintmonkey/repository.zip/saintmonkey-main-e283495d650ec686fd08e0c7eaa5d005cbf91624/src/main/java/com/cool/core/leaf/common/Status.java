package com.cool.core.leaf.common;

public enum  Status {
    SUCCESS,
    EXCEPTION
}
