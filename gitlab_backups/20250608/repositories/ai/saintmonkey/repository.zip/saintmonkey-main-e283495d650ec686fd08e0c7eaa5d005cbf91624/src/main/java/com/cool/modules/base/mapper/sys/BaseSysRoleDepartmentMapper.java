package com.cool.modules.base.mapper.sys;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.base.entity.sys.BaseSysRoleDepartmentEntity;

/**
 * 系统角色部门
 */
public interface BaseSysRoleDepartmentMapper extends BaseMapper<BaseSysRoleDepartmentEntity> {
}
