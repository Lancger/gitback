package com.cool.modules.flow.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.flow.entity.FlowResultEntity;

/**
 * 流程结果
 */
public interface FlowResultMapper extends BaseMapper<FlowResultEntity> {
}
