package com.cool.modules.base.mapper.sys;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.base.entity.sys.BaseSysRoleEntity;

/**
 * 系统角色
 */
public interface BaseSysRoleMapper extends BaseMapper<BaseSysRoleEntity> {
}
