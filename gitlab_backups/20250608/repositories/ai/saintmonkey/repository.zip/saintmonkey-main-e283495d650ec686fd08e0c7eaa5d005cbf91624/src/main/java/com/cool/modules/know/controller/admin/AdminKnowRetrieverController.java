package com.cool.modules.know.controller.admin;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONObject;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.request.R;
import com.cool.modules.know.service.KnowRetrieverService;
import dev.langchain4j.data.document.Metadata;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.store.embedding.EmbeddingMatch;
import io.swagger.v3.oas.annotations.Operation;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;

/**
 * 检索器
 */
@CoolRestController
@RequiredArgsConstructor
public class AdminKnowRetrieverController {
    private final KnowRetrieverService knowRetrieverService;

    @Operation(summary = "调用", description = "调用")
    @PostMapping("/invoke")
    protected R invoke(
        @RequestAttribute() JSONObject requestParams) {
        Long knowId = requestParams.get("knowId", Long.class);
        String text = requestParams.get("text", String.class);
        Integer size = requestParams.get("options", JSONObject.class).get("size", Integer.class);
        size = ObjectUtil.isEmpty(size) ? 10 : size;
        List<EmbeddingMatch<TextSegment>> matchList = knowRetrieverService.invoke(
            knowId,
            text,
            size,
            0.7
        );
        List<Object> list = new ArrayList<>();
        matchList.forEach(o -> {
            Metadata metadata = o.embedded().metadata();
            list.add(List.of(Map.of("metadata", metadata.toMap(), "pageContent", o.embedded().text()), o.score()));
        });
        return R.ok(list);
    }
}
