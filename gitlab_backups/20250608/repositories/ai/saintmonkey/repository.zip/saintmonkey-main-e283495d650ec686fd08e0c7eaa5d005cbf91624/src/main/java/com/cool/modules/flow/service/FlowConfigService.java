package com.cool.modules.flow.service;

import cn.hutool.json.JSONObject;
import com.cool.core.base.BaseService;
import com.cool.modules.flow.entity.FlowConfigEntity;
import java.util.Map;

/**
 * 流程配置
 */
public interface FlowConfigService extends BaseService<FlowConfigEntity> {

    Object all();

    Object config(JSONObject requestParams);

    Object getByNode(String node, String type);

    Map<String, Object> getOptions(Long configId);
}
