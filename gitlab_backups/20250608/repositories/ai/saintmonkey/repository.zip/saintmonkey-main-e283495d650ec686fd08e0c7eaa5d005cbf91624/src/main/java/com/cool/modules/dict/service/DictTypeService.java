package com.cool.modules.dict.service;

import com.cool.core.base.BaseService;
import com.cool.modules.dict.entity.DictTypeEntity;

/**
 * 字典类型
 */
public interface DictTypeService extends BaseService<DictTypeEntity> {
}
