package com.cool.modules.flow.nodes.llm;

import dev.langchain4j.data.message.AiMessage;
import dev.langchain4j.model.output.Response;
import dev.langchain4j.service.*;

public interface IChatAssistant {

    @SystemMessage("{{sm}}")
    TokenStream chatStream(@V("sm") String systemMessage, @UserMessage String userMessage);

    @SystemMessage("{{sm}}")
    Response<AiMessage> chat(@V("sm") String systemMessage, @UserMessage String userMessage);
}