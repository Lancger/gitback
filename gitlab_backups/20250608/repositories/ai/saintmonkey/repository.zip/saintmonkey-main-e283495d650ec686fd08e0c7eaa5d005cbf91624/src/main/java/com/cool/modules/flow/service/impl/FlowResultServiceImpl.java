package com.cool.modules.flow.service.impl;

import com.cool.core.base.BaseServiceImpl;
import com.cool.modules.flow.entity.FlowResultEntity;
import com.cool.modules.flow.mapper.FlowResultMapper;
import com.cool.modules.flow.service.FlowResultService;
import org.springframework.stereotype.Service;

/**
 * 流程结果
 */
@Service
public class FlowResultServiceImpl extends BaseServiceImpl<FlowResultMapper, FlowResultEntity> implements FlowResultService {
}