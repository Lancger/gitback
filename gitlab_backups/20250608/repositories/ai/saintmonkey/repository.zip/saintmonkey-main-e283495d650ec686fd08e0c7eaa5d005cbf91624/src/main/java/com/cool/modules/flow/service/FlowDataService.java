package com.cool.modules.flow.service;

import com.cool.core.base.BaseService;
import com.cool.modules.flow.entity.FlowDataEntity;
import com.cool.modules.flow.nodes.llm.Message;
import java.util.List;

/**
 * 流程数据
 */
public interface FlowDataService extends BaseService<FlowDataEntity> {

    List<Message> get(Long flowId, String objectId);

    void update(Long flowId, String objectId, List<Message> newMessages);
}
