package com.cool.modules.flow.entity;

import com.cool.core.base.BaseEntity;
import com.cool.modules.flow.nodes.llm.Message;
import com.mybatisflex.annotation.Column;
import com.mybatisflex.annotation.Table;
import com.mybatisflex.core.handler.Fastjson2TypeHandler;
import com.tangzc.mybatisflex.autotable.annotation.ColumnDefine;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.dromara.autotable.annotation.Index;

@Getter
@Setter
@Table(value = "flow_data", comment = "流程数据")
public class FlowDataEntity extends BaseEntity<FlowDataEntity> {

    @Index
    @ColumnDefine(comment = "流程ID", notNull = true)
    private Long flowId;

    @Index
    @ColumnDefine(comment = "对象ID", notNull = true)
    private String objectId;

    @ColumnDefine(comment = "数据", type = "json", notNull = true)
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private List<Message> data;
}
