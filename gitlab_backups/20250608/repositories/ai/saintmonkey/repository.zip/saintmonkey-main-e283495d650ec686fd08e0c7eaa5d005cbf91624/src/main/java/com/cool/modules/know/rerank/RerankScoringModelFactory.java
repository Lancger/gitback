package com.cool.modules.know.rerank;

import cn.hutool.json.JSONObject;
import com.cool.modules.know.enums.RerankScoringType;
import dev.langchain4j.model.cohere.CohereScoringModel;
import dev.langchain4j.model.scoring.ScoringModel;

import java.util.HashMap;
import java.util.Map;

public class RerankScoringModelFactory {

    private static final Map<String, ScoringModel> ScoringModelMap = new HashMap<>();
    public static ScoringModel getScoringModel(String type, JSONObject options) {
        String model = options.getStr("model");
        String key = type + ":" + model;
        if (ScoringModelMap.containsKey(key)) {
            return ScoringModelMap.get(key);
        }
        RerankScoringType rerankScoringType = RerankScoringType.findEnumByType(type);
        switch (rerankScoringType) {
            case Cohere ->
                    ScoringModelMap.put(key, CohereScoringModel.builder()
                            .apiKey(options.getStr("apiKey"))
                            .modelName(model)
                            .build());
            // 扩展其他的重排序模型
        }
        return ScoringModelMap.get(key);
    }
}