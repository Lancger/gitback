package com.cool.modules.flow.runner.context;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SimpleNodeInfo {
    /** 节点id */
    private String id;
    /** 节点类型 */
    private String type;
    /** 节点label */
    private String label;
    /** 节点描述 */
    private String desc;
}