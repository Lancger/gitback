package com.cool.core.base;

/**
 * 修改枚举
 */
public enum ModifyEnum {
    // 新增
    ADD,
    // 修改
    UPDATE,
    // 删除
    DELETE
}
