package com.cool.modules.know.store;

import cn.hutool.json.JSONObject;
import com.cool.modules.know.entity.KnowDataInfoEntity;
import com.cool.modules.know.enums.CollectionType;
import com.cool.modules.know.service.KnowDataTypeService;
import dev.langchain4j.store.embedding.EmbeddingStore;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;

public abstract class KnowStoreBase {
    @Value("${module.know.prefix:COOL_}")
    protected String prefix;
    /**
     * 获得存储器
     * @return 存储器
     */
    public abstract EmbeddingStore getStore(Long type);

    /**
     * 操作集合
     * @param type 操作类型
     */
    public abstract EmbeddingStore collection(Long typeId, CollectionType type);

    /**
     * 更新数据
     * @param datas 数据列表
     */
    public abstract void upsert(Long typeId, List<KnowDataInfoEntity> datas);

    /**
     * 移除数据
     * @param ids 数据ID列表
     */
    public abstract void remove(Long typeId, List<String> ids);

    public JSONObject getStoreConfig(KnowDataTypeService knowDataTypeService, Long typeId) {
        JSONObject jsonObject = knowDataTypeService.getEmbedding(typeId).getValue();
        return jsonObject.get("store", JSONObject.class);
    }
}