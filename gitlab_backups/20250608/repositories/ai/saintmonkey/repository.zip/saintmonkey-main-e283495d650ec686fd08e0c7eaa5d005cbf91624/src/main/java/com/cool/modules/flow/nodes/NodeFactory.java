package com.cool.modules.flow.nodes;

import com.cool.core.exception.CoolPreconditions;
import com.cool.modules.flow.nodes.classify.NodeClassify;
import com.cool.modules.flow.nodes.code.NodeCode;
import com.cool.modules.flow.nodes.end.NodeEnd;
import com.cool.modules.flow.nodes.enums.NodeTypeEnum;
import com.cool.modules.flow.nodes.flow.NodeFlow;
import com.cool.modules.flow.nodes.judge.NodeJudge;
import com.cool.modules.flow.nodes.know.NodeKnow;
import com.cool.modules.flow.nodes.llm.NodeLLM;
import com.cool.modules.flow.nodes.parse.NodeParse;
import com.cool.modules.flow.nodes.start.NodeStart;
import com.cool.modules.flow.nodes.variable.NodeVariable;
import com.cool.modules.flow.runner.node.FlowNode;

/**
 * 节点工厂类，负责创建和管理节点实例
 */
public class NodeFactory {

    /**
     * 根据节点类型获取节点实例
     * @param type 节点类型
     * @return 节点实例
     */
    public static FlowNode getNode(String type) {
        NodeTypeEnum typeEnum = NodeTypeEnum.findEnumByName(type);
        CoolPreconditions.checkEmpty(typeEnum, "暂不支持该节点 {}", type);
        return switch (typeEnum) {
            case start -> new NodeStart();
            case llm -> new NodeLLM();
            case code -> new NodeCode();
            case judge -> new NodeJudge();
            case classify -> new NodeClassify();
            case know -> new NodeKnow();
            case flow -> new NodeFlow();
            case parse -> new NodeParse();
            case variable -> new NodeVariable();
            case end -> new NodeEnd();
        };
    }
}
