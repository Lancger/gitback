package com.cool.modules.know.controller.admin.data;

import static com.cool.modules.know.entity.table.KnowDataTypeEntityTableDef.KNOW_DATA_TYPE_ENTITY;

import cn.hutool.json.JSONObject;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.base.BaseController;
import com.cool.core.request.R;
import com.cool.modules.know.entity.KnowDataTypeEntity;
import com.cool.modules.know.service.KnowDataTypeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;

/**
 * 知识信息类型
 */
@Tag(name = "知识信息类型", description = "知识信息类型")
@CoolRestController(api = {"add", "delete", "update", "page", "list", "info"})
@RequiredArgsConstructor
public class AdminKnowDataTypeController extends BaseController<KnowDataTypeService, KnowDataTypeEntity> {
    private final KnowDataTypeService knowDataTypeService;
    @Override
    protected void init(HttpServletRequest request, JSONObject requestParams) {
        setPageOption(createOp().keyWordLikeFields(KNOW_DATA_TYPE_ENTITY.NAME));
    }

    @Operation(summary = "重建")
    @PostMapping("/rebuild")
    public R rebuild(HttpServletResponse response,
        @RequestAttribute() JSONObject requestParams) {
        Long typeId = requestParams.get("typeId", Long.class);
        knowDataTypeService.rebuild(typeId);
        return R.ok();
    }
}