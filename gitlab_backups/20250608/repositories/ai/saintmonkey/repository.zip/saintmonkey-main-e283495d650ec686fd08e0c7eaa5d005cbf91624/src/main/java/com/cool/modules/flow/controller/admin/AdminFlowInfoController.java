package com.cool.modules.flow.controller.admin;

import static com.cool.modules.flow.entity.table.FlowInfoEntityTableDef.FLOW_INFO_ENTITY;

import cn.hutool.core.util.BooleanUtil;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.json.JSONObject;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.base.BaseController;
import com.cool.core.request.R;
import com.cool.modules.flow.entity.FlowInfoEntity;
import com.cool.modules.flow.service.FlowInfoService;
import com.mybatisflex.core.query.QueryWrapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;

/**
 * 流程信息
 */
@Tag(name = "流程信息", description = "流程信息")
@CoolRestController(api = {"add", "delete", "update", "page", "list", "info"})
@RequiredArgsConstructor
public class AdminFlowInfoController extends BaseController<FlowInfoService, FlowInfoEntity> {

    private final FlowInfoService flowInfoService;

    @Override
    protected void init(HttpServletRequest request, JSONObject requestParams) {
        Long flowId = requestParams.get("flowId", Long.class);
        Boolean isRelease = requestParams.get("isRelease", Boolean.class);
        setPageOption(createOp().keyWordLikeFields(FLOW_INFO_ENTITY.NAME, FLOW_INFO_ENTITY.LABEL)
            .queryWrapper(QueryWrapper.create().ne(FLOW_INFO_ENTITY.ID.getName(), flowId,
                    ObjectUtil.isNotEmpty(flowId))
                .isNotNull(FLOW_INFO_ENTITY.RELEASE_TIME.getName(), BooleanUtil.isTrue(isRelease))));
    }

    @Operation(summary = "发布流程")
    @PostMapping("/release")
    protected R release(@RequestAttribute() JSONObject requestParams) {
        Long flowId = requestParams.get("flowId", Long.class);
        return R.ok(flowInfoService.release(flowId));
    }
}