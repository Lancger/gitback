package com.cool.modules.flow.runner.context;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * 节点执行信息
 */
@Getter
@Setter
public class FlowNodeExec {

    // 当前节点
    private String current;

    // 上一个节点
    private String prev;

    // 下一个节点
    private String next;

    // 下一个节点列表
    private List<String> nextList;
}

