package com.cool.modules.flow.runner.node;
import cn.hutool.core.util.ObjUtil;
import cn.hutool.core.util.StrUtil;
import com.cool.modules.flow.entity.FlowResultEntity;
import com.cool.modules.flow.nodes.llm.ModelFactory;
import com.cool.modules.flow.nodes.llm.ModelTypeEnum;
import com.cool.modules.flow.runner.context.FlowContext;
import com.cool.modules.flow.runner.context.FlowGraph;
import com.cool.modules.flow.runner.context.LineInfo;
import com.cool.modules.flow.runner.context.SimpleNodeInfo;
import com.cool.modules.flow.runner.result.FlowResult;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.chat.StreamingChatLanguageModel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 * 节点
 */
@Getter
@Setter
public abstract class FlowNode {
    /** 节点id */
    private String id;
    /** 流程id */
    private Long flowId;
    /** 节点label */
    private String label;
    /** 节点类型 */
    private String type;
    /** 节点描述 */
    private String desc;
    /** 节点配置 */
    private NodeConfig config;
    /** 输入参数 */
    private Map<String, Object> inputParams;
    /** 输入图片参数 */
    private Map<String, String> imageParams;
    /** 上下文 */
    private FlowContext context;

    /**
     * 调用
     * @param context
     */
    public FlowResult invoke(FlowContext context) {
        long start = System.currentTimeMillis();
        try {
            this.inputParams = this.getInputParams(context);
            FlowResult flowResult = this.run(context);
            context.setNodeRunInfo(this.id, FlowContext.NodeRunInfo.builder()
                    .duration(System.currentTimeMillis() - start)
                    .success(flowResult.isSuccess())
                    .result(flowResult).build());
            if (ObjUtil.equal(this.getType(), "end")) {
                context.setFlowResult(flowResult);
            }
            FlowResultEntity entity = FlowResultEntity.builder()
                    .requestId(context.getRequestId())
                    .node(SimpleNodeInfo.builder()
                            .id(this.id).type(this.type).label(this.label).desc(this.desc).build())
                    .nodeType(this.type)
                    .input(this.inputParams)
                    .output(flowResult)
                    .duration(System.currentTimeMillis() - start)
                    .build();
            entity.save();
            return flowResult;
        } catch (Exception e) {
            FlowResult flowResult = FlowResult.builder().success(false).error(e.getMessage()).build();
            context.setNodeRunInfo(this.id, FlowContext.NodeRunInfo.builder()
                    .duration(System.currentTimeMillis() - start)
                    .success(flowResult.isSuccess())
                    .result(flowResult).build());
            return flowResult;
        }
    }

    /**
     * 下一个节点集合
     * @param flowGraph
     * @returns
     */
    public List<SimpleNodeInfo> getNextNodes(FlowGraph flowGraph) {
        // 找到所有的线
        List<LineInfo> edges = flowGraph.getEdges().stream()
                .filter(edge -> edge.getSource().equals(this.getId()))
                .toList();
        return edges.stream().map(o -> SimpleNodeInfo.builder().id(o.getTarget())
                .type(o.getTargetType()).build()).toList();
    }
    /**
     * 上一个节点集合
     * @param flowGraph
     * @returns
     */
    public List<SimpleNodeInfo> getPrevNodes(FlowGraph flowGraph) {
        // 找到所有的线
        List<LineInfo> edges = flowGraph.getEdges().stream()
                .filter(edge -> edge.getTarget().equals(this.getId()))
                .toList();
        return edges.stream().map(o -> SimpleNodeInfo.builder().id(o.getSource())
                .type(o.getSourceType()).build()).toList();
    }
    /**
     * 获得前缀
     * @returns
     */
    public String getPrefix() {
        return String.format("%s.%s", this.type, this.id);
    }

    /**
     * 获得参数前缀
     * @param param
     * @returns
     */
    public String getParamPrefix(NodeConfig.InputParam param) {
        return String.format("%s.%s", param.getNodeType(), param.getNodeId());
    }
    /**
     * 获得参数前缀
     * @param param
     * @returns
     */
    public String getParamPrefix(NodeConfig.OutputParam param) {
        return String.format("%s.%s", param.getNodeType(), param.getNodeId());
    }

    /**
     * 获取输入参数
     * @param context
     */
    private Map<String, Object> getInputParams(FlowContext context) {
        if (context.isDebugOne() || "start".equals(this.type)) {
            return context.getRequestParams();
        }
        List<NodeConfig.InputParam> inputParams = this.config.getInputParams();
        Map<String, Object> datas = context.getData("output");
        Map<String, Object> params = new HashMap<>();
        Map<String, String> imageParams = new HashMap<>();

        if (inputParams == null || inputParams.isEmpty()) {
            return params;
        }
        for (NodeConfig.InputParam param : inputParams) {
            if (param.getField() != null) {
                if (ObjUtil.equal(param.getType(), "image")) {
                    String imageUrl = StrUtil.toStringOrNull(datas.get(String.format("%s.%s", this.getParamPrefix(param), param.getName())));
                    if (StrUtil.isNotBlank(imageUrl)) {
                        imageParams.put(param.getField(), imageUrl);
                    }
                } else {
                    params.put(param.getField(), datas.get(String.format("%s.%s", this.getParamPrefix(param), param.getName())));
                }
            }
        }
        this.inputParams = params;
        this.imageParams = imageParams;
        return params;
    }

    /**
     * 执行
     *
     * @param context
     */
    public abstract FlowResult run(FlowContext context);

    protected ChatLanguageModel getModel(String name, Map<String, Object> options) {
        return ModelFactory.create(ModelTypeEnum.findEnumByName(name), options);
    }

    protected StreamingChatLanguageModel getStreamingModel(String name, Map<String, Object> options) {
        return ModelFactory.createStreaming(ModelTypeEnum.findEnumByName(name), options);
    }

    protected Map<String, Object> mergeMaps(Object... maps) {
        Map<String, Object> mergedMap = new HashMap<>();
        for (Object map : maps) {
            if (map instanceof Map) {
                mergedMap.putAll((Map<String, Object>) map);
            }
        }
        return mergedMap;
    }
}