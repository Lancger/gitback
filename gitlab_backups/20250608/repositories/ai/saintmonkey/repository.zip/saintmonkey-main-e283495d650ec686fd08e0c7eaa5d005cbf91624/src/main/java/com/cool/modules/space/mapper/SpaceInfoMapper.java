package com.cool.modules.space.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.space.entity.SpaceInfoEntity;

/**
 * 文件空间信息
 */
public interface SpaceInfoMapper extends BaseMapper<SpaceInfoEntity> {
}
