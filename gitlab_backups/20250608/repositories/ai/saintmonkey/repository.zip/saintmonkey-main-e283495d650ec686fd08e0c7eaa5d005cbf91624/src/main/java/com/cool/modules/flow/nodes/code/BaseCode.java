package com.cool.modules.flow.nodes.code;
import cn.hutool.core.util.ClassUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.cool.core.base.service.MapperProviderService;
import com.cool.core.util.CoolPluginInvokers;
import com.mybatisflex.core.BaseMapper;
import com.mybatisflex.core.row.Db;
import com.mybatisflex.core.row.Row;
import java.util.List;

/**
 * 代码执行基类
 */
public class BaseCode {
    /**
     * 主函数
     */
    public void main(Object params) {
        // 主函数逻辑
    }

    /**
     * 执行SQL
     * @param sql SQL语句
     * @param params 参数
     * @return 执行结果
     */
    public List<Row> execSql(String sql, Object[] params) {
        return Db.selectListBySql(sql, params);
    }

    /**
     * 获取BaseMapper
     * @param entityName 实体名称
     * @return Repository
     */
    public BaseMapper getBaseMapper(String entityName) {
        Class<?> entityClass = ClassUtil.loadClass(entityName);
        return SpringUtil.getBean(MapperProviderService.class).getMapperByEntityClass(entityClass);
    }

    /**
     * 调用Service
     * @param service 服务名称
     * @param method 方法名称
     * @param args 参数
     * @return 调用结果
     */
    public Object invokeService(String service, String method, Object... args) {
        Object serviceInstance = SpringUtil.getBean(service);
        return ReflectUtil.invoke(serviceInstance, method, args);
    }

    /**
     * 调用插件
     * @param key 插件键
     * @param args 参数
     * @return 调用结果
     */
    public Object invokePlugin(String key, String... args) {
        return CoolPluginInvokers.invokePlugin(key, args);
    }
}
