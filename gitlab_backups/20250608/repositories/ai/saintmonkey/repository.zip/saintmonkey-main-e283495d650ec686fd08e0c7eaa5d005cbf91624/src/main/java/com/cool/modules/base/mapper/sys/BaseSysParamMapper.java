package com.cool.modules.base.mapper.sys;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.base.entity.sys.BaseSysParamEntity;

/**
 * 系统参数配置
 */
public interface BaseSysParamMapper extends BaseMapper<BaseSysParamEntity> {
}
