package com.cool.modules.base.mapper.sys;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.base.entity.sys.BaseSysUserEntity;

/**
 * 系统用户
 */
public interface BaseSysUserMapper extends BaseMapper<BaseSysUserEntity> {

}
