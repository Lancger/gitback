package com.cool.modules.flow.nodes.llm;

import cn.hutool.core.util.NumberUtil;
import cn.hutool.core.util.StrUtil;
import com.cool.core.exception.CoolPreconditions;
import dev.langchain4j.community.model.dashscope.QwenChatModel;
import dev.langchain4j.community.model.dashscope.QwenStreamingChatModel;
import dev.langchain4j.community.model.qianfan.QianfanChatModel;
import dev.langchain4j.community.model.qianfan.QianfanStreamingChatModel;
import dev.langchain4j.community.model.zhipu.ZhipuAiChatModel;
import dev.langchain4j.community.model.zhipu.ZhipuAiStreamingChatModel;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.chat.StreamingChatLanguageModel;
import dev.langchain4j.model.ollama.OllamaChatModel;
import dev.langchain4j.model.ollama.OllamaStreamingChatModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.model.openai.OpenAiStreamingChatModel;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 模型工厂
 */
public class ModelFactory {

    private final static Map<String, ChatLanguageModel> chatMap = new ConcurrentHashMap<>();
    private final static Map<String, StreamingChatLanguageModel> streamingChatMap = new ConcurrentHashMap<>();
    public static ChatLanguageModel create(ModelTypeEnum modelTypeEnum, Map<String, Object> options) {
        CoolPreconditions.checkEmpty(modelTypeEnum, "未知类型模型");
        String apiKey = StrUtil.toStringOrNull(options.get("apiKey"));
        String model = StrUtil.toStringOrNull(options.get("model"));
        double temperature = NumberUtil.parseDouble(String.valueOf(options.get("temperature")));
        String key = modelTypeEnum.name() + model + temperature;
        if (chatMap.containsKey(key)) {
            return chatMap.get(key);
        }
        ChatLanguageModel chatLanguageModel = switch (modelTypeEnum) {
            case openai, deepseek ->
                    OpenAiChatModel.builder()
                            .apiKey(apiKey)
                            .baseUrl(StrUtil.toStringOrNull(options.get("baseUrl")))
                            .modelName(model)
                            .temperature(temperature)
                            .build();
            case zhipu ->
                    ZhipuAiChatModel.builder()
                            .apiKey(apiKey)
                            .model(model)
                            .temperature(temperature)
                            .callTimeout(Duration.ofSeconds(60))
                            .connectTimeout(Duration.ofSeconds(60))
                            .writeTimeout(Duration.ofSeconds(60))
                            .readTimeout(Duration.ofSeconds(60))
                            .logRequests(true)
                            .logResponses(true)
                            .build();
            case ollama ->
                    OllamaChatModel.builder()
                            .modelName(model)
                            .temperature(temperature)
                            .baseUrl(StrUtil.toStringOrNull(options.get("baseUrl")))
                            .maxRetries(3)
                            .build();
            case qwen ->
                    QwenChatModel.builder()
                            .apiKey(apiKey)
                            .modelName(model)
                            .temperature((float)temperature)
                            .build();
            case qianfan ->
                    QianfanChatModel.builder()
                            .apiKey(apiKey)
                            .secretKey(StrUtil.toStringOrNull(options.get("secretKey")))
                            .modelName(model)
                            .temperature(temperature)
                            .maxRetries(3)
                            .build();
        };
        chatMap.put(key, chatLanguageModel);
        return chatLanguageModel;
    }

    public static StreamingChatLanguageModel createStreaming(ModelTypeEnum modelTypeEnum, Map<String, Object> options) {
        CoolPreconditions.checkEmpty(modelTypeEnum, "未知类型模型");
        String apiKey = StrUtil.toStringOrNull(options.get("apiKey"));
        String model = StrUtil.toStringOrNull(options.get("model"));
        double temperature = NumberUtil.parseDouble(String.valueOf(options.get("temperature")));
        String key = modelTypeEnum.name() + model + temperature;
        if (streamingChatMap.containsKey(key)) {
            return streamingChatMap.get(key);
        }
        StreamingChatLanguageModel streamingChatLanguageModel = switch (modelTypeEnum) {
            case openai, deepseek ->
                    OpenAiStreamingChatModel.builder()
                            .apiKey(apiKey)
                            .baseUrl(StrUtil.toStringOrNull(options.get("baseUrl")))
                            .modelName(model)
                            .temperature(temperature)
                            .build();
            case zhipu ->
                    ZhipuAiStreamingChatModel.builder()
                            .apiKey(apiKey)
                            .model(model)
                            .temperature(temperature)
                            .callTimeout(Duration.ofSeconds(60))
                            .connectTimeout(Duration.ofSeconds(60))
                            .writeTimeout(Duration.ofSeconds(60))
                            .readTimeout(Duration.ofSeconds(60))
                            .logRequests(true)
                            .logResponses(true)
                            .build();
            case ollama ->
                    OllamaStreamingChatModel.builder()
                            .modelName(model)
                            .temperature(temperature)
                            .baseUrl(StrUtil.toStringOrNull(options.get("baseUrl"))).build();
            case qwen ->
                    QwenStreamingChatModel.builder()
                            .apiKey(apiKey)
                            .modelName(model)
                            .temperature((float)temperature)
                            .build();
            case qianfan ->
                    QianfanStreamingChatModel.builder()
                            .apiKey(apiKey)
                            .secretKey(StrUtil.toStringOrNull(options.get("secretKey")))
                            .modelName(model)
                            .temperature(temperature)
                            .build();
        };
        streamingChatMap.put(key, streamingChatLanguageModel);
        return streamingChatLanguageModel;
    }
}