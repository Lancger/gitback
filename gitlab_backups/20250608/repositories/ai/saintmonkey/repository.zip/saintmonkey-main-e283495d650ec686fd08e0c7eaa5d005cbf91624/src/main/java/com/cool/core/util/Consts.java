package com.cool.core.util;

public interface Consts {

    /**
     * flow 配置文件
     */
    String FLOW_CONFIG = "classpath:cool/data/flow/%s_config.json";

    /**
     * know 配置文件
     */
    String KNOW_CONFIG = "classpath:cool/data/know/know_config.json";

    /**
     * rerank 配置文件
     */
    String RERANK_CONFIG = "classpath:cool/data/know/rerank_config.json";
}
