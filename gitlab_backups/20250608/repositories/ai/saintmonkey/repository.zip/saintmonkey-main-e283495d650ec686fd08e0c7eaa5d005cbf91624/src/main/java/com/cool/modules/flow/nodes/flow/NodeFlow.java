package com.cool.modules.flow.nodes.flow;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.cool.core.exception.CoolPreconditions;
import com.cool.modules.flow.entity.FlowInfoEntity;
import com.cool.modules.flow.runner.context.FlowContext;
import com.cool.modules.flow.runner.node.FlowNode;
import com.cool.modules.flow.runner.node.NodeConfig.OutputParam;
import com.cool.modules.flow.runner.result.FlowResult;
import com.cool.modules.flow.service.FlowInfoService;
import com.cool.modules.flow.service.FlowRunService;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import org.springframework.util.Assert;

/**
 * 流程节点
 */
public class NodeFlow extends FlowNode {

    /**
     * 执行方法
     *
     * @param context 流程上下文
     * @return 执行结果
     */
    @Override
    public FlowResult run(FlowContext context) {
        Map<String, Object> params = this.getInputParams();
        Object result;

        // 获取流程label
        FlowInfoEntity flowInfo = SpringUtil.getBean(FlowInfoService.class).getById(
                (Serializable) this.getConfig().getOptions().get("flowId"));
        Assert.notNull(flowInfo, "流程不存在");
        CoolPreconditions.checkEmpty(flowInfo, "流程不存在");

        // 执行流程
        result = SpringUtil.getBean(FlowRunService.class).invoke(flowInfo.getLabel(), params).getResult();
        List<OutputParam> outputParams = this.getConfig().getOutputParams();
        // 设置输出参数
        for (OutputParam param : outputParams) {
            if (result instanceof Map) {
                context.set(getPrefix() + "." + param.getField(),
                        ((Map) result).get(param.getField()), "output");
            } else {
                context.set(getPrefix() + "." + param.getField(),
                        ReflectUtil.getFieldValue(result, param.getField()), "output");
            }
        }
        return new FlowResult(true, result);
    }
}