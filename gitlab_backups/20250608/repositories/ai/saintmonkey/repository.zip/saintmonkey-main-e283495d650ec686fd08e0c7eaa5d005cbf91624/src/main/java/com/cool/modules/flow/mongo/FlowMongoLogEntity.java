package com.cool.modules.flow.mongo;
import com.mybatisflex.annotation.Id;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import java.io.Serializable;
import java.util.Date;

/**
 * 流程日志
 */
@Getter
@Setter
@Document(collection = "flow_dialogue_log")
public class FlowMongoLogEntity  implements Serializable {

    @Field("flow_id")
    public Long flowId;

    @Field("type")
    public Integer type;

    @Field("input_params")
    public Object inputParams;

    @Field("result")
    public Object result;

    @Field("flow_label")
    public String flowLabel;

    @Field("flow_name")
    public String flowName;

    @Field("node_info")
    public Object nodeInfo;

    @Id
    public Long id;

    @Field("create_time")
    public Date createTime;

    @Field("update_time")
    public Date updateTime;

    @Field("user_id")
    public String userId;
}
