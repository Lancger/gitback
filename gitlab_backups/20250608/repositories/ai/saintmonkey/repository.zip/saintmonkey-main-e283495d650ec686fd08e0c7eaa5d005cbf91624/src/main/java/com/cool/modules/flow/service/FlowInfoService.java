package com.cool.modules.flow.service;

import cn.hutool.core.lang.Pair;
import com.cool.core.base.BaseService;
import com.cool.modules.flow.entity.FlowInfoEntity;
import com.cool.modules.flow.runner.node.FlowNode;
import java.util.List;

/**
 * 流程信息
 */
public interface FlowInfoService extends BaseService<FlowInfoEntity> {

    Boolean release(Long flowId);

    Pair<FlowInfoEntity, List<FlowNode>> getNodes(String label, boolean b);

    FlowInfoEntity getByLable(String label);
}
