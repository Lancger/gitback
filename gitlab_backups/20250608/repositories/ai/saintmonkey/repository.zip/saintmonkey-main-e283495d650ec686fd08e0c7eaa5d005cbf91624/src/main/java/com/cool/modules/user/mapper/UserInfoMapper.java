package com.cool.modules.user.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.user.entity.UserInfoEntity;

public interface UserInfoMapper extends BaseMapper<UserInfoEntity> {
}
