package com.cool.modules.flow.nodes.judge;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Condition {
    /** 条件 */
    private String condition;

    /** 节点ID */
    private String nodeId;

    /** 节点类型 */
    private String nodeType;

    /** 字段 */
    private String field;

    /** 操作符 */
    private String operator;

    /** 值 */
    private String value;
}