package com.cool.modules.base.mapper.sys;

import com.cool.modules.base.entity.sys.BaseSysConfEntity;
import com.mybatisflex.core.BaseMapper;

/**
 * 系统配置
 */
public interface BaseSysConfMapper extends BaseMapper<BaseSysConfEntity> {

}
