package com.cool.modules.flow.nodes.judge;
import cn.hutool.json.JSONUtil;
import com.cool.core.exception.CoolPreconditions;
import com.cool.modules.flow.runner.context.FlowContext;
import com.cool.modules.flow.runner.context.FlowGraph;
import com.cool.modules.flow.runner.context.LineInfo;
import com.cool.modules.flow.runner.context.SimpleNodeInfo;
import com.cool.modules.flow.runner.node.FlowNode;
import com.cool.modules.flow.runner.result.FlowResult;
import java.util.*;
import java.util.function.BiPredicate;

/**
 * 判断器
 */
public class NodeJudge extends FlowNode {

    /**
     * 执行
     *
     * @param context
     */
    public FlowResult run(FlowContext context){
        Options options = JSONUtil.toBean(JSONUtil.toJsonStr(this.getConfig().getOptions()), Options.class);
        List<Condition> conditions = options.getIF();
        Map<String, Object> datas = context.getData("output");
        List<EqResult> eqResults = new ArrayList<>();

        for (Condition item : conditions) {
            String paramValue = (String) datas.get(item.getNodeType() + "." + item.getNodeId() + "." + item.getField());
            String value = item.getValue();
            boolean result = eq(paramValue, value, item.getCondition());
            eqResults.add(new EqResult(result, item.getOperator()));
        }

        boolean finalResult = result(eqResults);
        context.set(getPrefix() + ".result", finalResult, "output");
        SimpleNodeInfo nextNode = nextNode(context.getFlowGraph(), finalResult);
        return new FlowResult(true, finalResult, nextNode);
    }

    /**
     * 下一个节点ID
     * @param flowGraph
     * @param result
     * @returns
     */
    private SimpleNodeInfo nextNode(FlowGraph flowGraph, boolean result) {
        // 找到所有的线
        List<LineInfo> edges = flowGraph.getEdges().stream()
                .filter(edge -> edge.getSource().equals(this.getId()))
                .toList();

        // 找到线中sourceHandle为 source-if 或 source-else 的线
        LineInfo edge = edges.stream()
                .filter(e -> e.getSourceHandle().equals(result ? "source-if" : "source-else"))
                .findFirst()
                .orElse(null);

        SimpleNodeInfo nextNode = edge != null ?
                SimpleNodeInfo.builder().id(edge.getTarget())
                        .type(edge.getTargetType()).build() : null;
        CoolPreconditions.checkEmpty(nextNode, "未找到下一节点");
        return nextNode;
    }

    /**
     * 结果
     * @param eqResults
     */
    private boolean result(List<EqResult> eqResults) {
        Boolean finalResult = null;
        String operator = null;
        for (EqResult item : eqResults) {
            if (finalResult == null) {
                finalResult = item.isResult();
                // 获取第一次操作符
                operator = item.getOperator();
                continue;
            }
            if ("AND".equals(operator)) {
                finalResult = finalResult && item.isResult();
            } else {
                finalResult = finalResult || item.isResult();
            }
            // 获取下一个操作符
            operator = item.getOperator();
        }
        return finalResult != null && finalResult;
    }

    /**
     * 对比
     * @param paramValue
     * @param value
     * @param condition
     * @returns
     */
    private boolean eq(String paramValue, String value, String condition)  {
        BiPredicate<String, String> method = conditonMethod(condition);
        CoolPreconditions.checkEmpty(method, "比较方式未配置");
        return method.test(paramValue, value);
    }

    /**
     * 将条件转为具体方法
     * @param condition
     */
    private BiPredicate<String, String> conditonMethod(String condition) {
        return ConditionMethods.getMethod(condition);
    }
}