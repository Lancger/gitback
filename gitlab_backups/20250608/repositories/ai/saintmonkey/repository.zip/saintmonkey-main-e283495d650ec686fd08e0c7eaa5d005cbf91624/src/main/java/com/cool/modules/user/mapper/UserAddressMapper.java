package com.cool.modules.user.mapper;

import com.cool.modules.user.entity.UserAddressEntity;
import com.mybatisflex.core.BaseMapper;

/**
 * 用户模块-收货地址
 */
public interface UserAddressMapper extends BaseMapper<UserAddressEntity> {
}
