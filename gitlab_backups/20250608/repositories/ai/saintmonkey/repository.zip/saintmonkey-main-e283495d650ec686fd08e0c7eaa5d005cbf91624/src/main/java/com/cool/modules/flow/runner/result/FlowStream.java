package com.cool.modules.flow.runner.result;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Getter;
import lombok.Setter;

/**
 * 自定义管道流
 */
@Setter
@Getter
//@JsonSerialize(using = FlowStreamSerializer.class)
// 忽略指定字段的序列化/反序列化
@JsonIgnoreProperties(value = {"pipedInputStream", "pipedOutputStream"})
public class FlowStream implements Serializable {
    @JsonIgnore
    private PipedInputStream pipedInputStream;
    @JsonIgnore
    private PipedOutputStream pipedOutputStream;

    private StringBuffer content;

    public FlowStream() {
    }

    public FlowStream(PipedInputStream pipedInputStream, PipedOutputStream pipedOutputStream,StringBuffer content) {
        this.pipedInputStream = pipedInputStream;
        this.pipedOutputStream = pipedOutputStream;
        this.content = content;
    }
}
