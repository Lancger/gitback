package com.cool.modules.base.mapper.sys;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.base.entity.sys.BaseSysLogEntity;

/**
 * 系统日志
 */
public interface BaseSysLogMapper extends BaseMapper<BaseSysLogEntity> {
}
