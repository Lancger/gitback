package com.cool.modules.flow.service.impl;

import static com.cool.modules.flow.entity.table.FlowDataEntityTableDef.FLOW_DATA_ENTITY;

import cn.hutool.core.util.ObjectUtil;
import com.cool.core.base.BaseServiceImpl;
import com.cool.modules.flow.entity.FlowDataEntity;
import com.cool.modules.flow.mapper.FlowDataMapper;
import com.cool.modules.flow.nodes.llm.Message;
import com.cool.modules.flow.service.FlowDataService;
import com.google.common.collect.Lists;
import com.mybatisflex.core.query.QueryWrapper;
import com.mybatisflex.core.update.UpdateChain;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 * 流程数据
 */
@Service
public class FlowDataServiceImpl extends BaseServiceImpl<FlowDataMapper, FlowDataEntity> implements FlowDataService {

    @Override
    public List<Message> get(Long flowId, String objectId) {
        FlowDataEntity flowDataEntity = this.getOne(
            QueryWrapper.create().and(FLOW_DATA_ENTITY.FLOW_ID.eq(flowId))
                .and(FLOW_DATA_ENTITY.OBJECT_ID.eq(objectId)));
        if (ObjectUtil.isNotNull(flowDataEntity)) {
            return flowDataEntity.getData();
        }
        return Lists.newArrayList();
    }

    @Override
    public void update(Long flowId, String objectId, List<Message> newMessages) {
        if (ObjectUtil.isEmpty(newMessages)) {
            return;
        }
        FlowDataEntity flowDataEntity = getOne(
            QueryWrapper.create().eq(FlowDataEntity::getFlowId, flowId)
                .eq(FlowDataEntity::getObjectId, objectId));
        if (ObjectUtil.isNotNull(flowDataEntity)) {
            UpdateChain.of(FlowDataEntity.class)
                .set(FlowDataEntity::getData, newMessages)
                .eq(FlowDataEntity::getId, flowDataEntity.getId())
                .update();
        } else {
            flowDataEntity = new FlowDataEntity();
            flowDataEntity.setData(newMessages);
            flowDataEntity.setFlowId(flowId);
            flowDataEntity.setObjectId(objectId);
            flowDataEntity.save();
        }
    }
}