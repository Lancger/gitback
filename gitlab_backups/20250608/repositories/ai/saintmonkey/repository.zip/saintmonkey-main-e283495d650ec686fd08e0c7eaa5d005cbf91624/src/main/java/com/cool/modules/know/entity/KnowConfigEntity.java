package com.cool.modules.know.entity;

import com.cool.core.base.BaseEntity;
import com.mybatisflex.annotation.Table;
import com.tangzc.mybatisflex.autotable.annotation.ColumnDefine;
import lombok.Getter;
import lombok.Setter;

/**
 * 知识库配置
 */
@Getter
@Setter
@Table(value = "know_config")
public class KnowConfigEntity extends BaseEntity<KnowConfigEntity> {

    @ColumnDefine(comment = "名称", notNull = true)
    private String name;

    @ColumnDefine(comment = "描述")
    private String description;

    @ColumnDefine(comment = "类型", notNull = true)
    private String type;

    @ColumnDefine(comment = "功能", notNull = true)
    private String func;

    @ColumnDefine(comment = "配置", notNull = true, type = "text")
    private String options;
}
