package com.cool.modules.dict.mapper;

import com.mybatisflex.core.BaseMapper;
import com.cool.modules.dict.entity.DictTypeEntity;

/**
 * 字典类型
 */
public interface DictTypeMapper extends BaseMapper<DictTypeEntity> {
}
