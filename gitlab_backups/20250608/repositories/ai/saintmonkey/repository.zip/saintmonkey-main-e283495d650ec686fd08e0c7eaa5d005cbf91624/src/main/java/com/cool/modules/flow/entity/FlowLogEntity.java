package com.cool.modules.flow.entity;

import com.cool.core.base.BaseEntity;
import com.mybatisflex.annotation.Column;
import com.mybatisflex.annotation.Table;
import com.mybatisflex.core.handler.Fastjson2TypeHandler;
import com.tangzc.mybatisflex.autotable.annotation.ColumnDefine;
import lombok.Getter;
import lombok.Setter;
import org.dromara.autotable.annotation.Ignore;

/**
 * 流程日志
 */
@Getter
@Setter
@Table(value = "flow_log", comment = "流程日志")
public class FlowLogEntity extends BaseEntity<FlowLogEntity> {

    @ColumnDefine(comment = "流程ID", notNull = true)
    private Long flowId;

    @ColumnDefine(comment = "类型 0-失败 1-成功 2-未知", defaultValue = "0")
    private Integer type;

    @ColumnDefine(comment = "传入参数", type = "json")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private Object inputParams;

    @ColumnDefine(comment = "结果", type = "json")
    @Column(typeHandler = Fastjson2TypeHandler.class)
    private Object result;

    /**
     * 流程标签
     */
    @Ignore
    @Column(ignore = true)
    private String flowLabel;

    /**
     * 流程名称
     */
    @Ignore
    @Column(ignore = true)
    private String flowName;
}