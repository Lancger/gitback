package com.cool.modules.flow.runner.context;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * 流程图
 */
@Getter
@Setter
public class FlowGraph {

    // 流程图中的节点列表
    private List<NodeInfo> nodes;

    // 流程图中的边（连接线）列表
    private List<LineInfo> edges;
}