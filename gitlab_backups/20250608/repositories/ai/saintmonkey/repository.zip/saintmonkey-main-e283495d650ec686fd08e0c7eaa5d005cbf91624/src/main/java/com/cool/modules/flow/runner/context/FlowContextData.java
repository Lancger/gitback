package com.cool.modules.flow.runner.context;

import cn.hutool.core.map.MapUtil;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 * 上下文数据
 */
@Getter
@Setter
public class FlowContextData {
    // 输入
    private Map<String, Object> input;
    // 输出
    private Map<String, Object> output;
    // 结果
    private Map<String, Object> result;

    public FlowContextData() {
        input = MapUtil.newHashMap();
        output = MapUtil.newHashMap();
        result = MapUtil.newHashMap();
    }
}