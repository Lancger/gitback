package com.cool.modules.flow.controller.admin;

import cn.hutool.core.util.IdUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.cool.core.annotation.CoolRestController;
import com.cool.core.annotation.TokenIgnore;
import com.cool.core.exception.CoolPreconditions;
import com.cool.core.request.R;
import com.cool.modules.flow.runner.context.FlowContext;
import com.cool.modules.flow.service.FlowRunService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicReference;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

@Slf4j
@Tag(name = "流程运行", description = "流程运行")
@CoolRestController
@RequiredArgsConstructor
public class AdminFlowRunController {
    private final FlowRunService flowRunService;
    private final ExecutorService executorService = Executors.newCachedThreadPool();

    @TokenIgnore
    @Operation(summary = "调试")
    @PostMapping("/debug")
    protected SseEmitter debug(@RequestAttribute JSONObject requestParams) throws IOException {
        // 提取请求参数
        String label = requestParams.getStr("label");
        CoolPreconditions.checkEmpty(label);
        Map params = requestParams.get("params", Map.class);
        Boolean stream = requestParams.getBool("stream");
        // 上下文
        FlowContext context = new FlowContext();
        context.setRequestParams(params);
        context.setRequestId(requestParams.getStr("requestId", IdUtil.randomUUID()));
        context.setSessionId(requestParams.getStr("sessionId"));
        context.setStream(stream);
        // 创建一个 SseEmitter 对象
        SseEmitter emitter = getSseEmitter(context);
        context.setDebug(true);
        String nodeId = requestParams.getStr("nodeId");
        executorService.execute(() -> {
            try {
                flowRunService.debug(context, label, nodeId);
            } catch (IOException e) {
                CoolPreconditions.alwaysThrow("流程执行异常", e);
            } finally{
                // 完成SSE会话
                emitter.complete();
            }
        });
        return emitter;
    }

    @NotNull
    private static SseEmitter getSseEmitter(FlowContext context) {
        SseEmitter emitter = new SseEmitter(300000L);
        AtomicReference<Boolean> isCompletion = new AtomicReference<>(false);
        emitter.onCompletion(() -> isCompletion.set(true));
        context.setCallback(data -> {
            try {
                if (!isCompletion.get()) {
                    emitter.send(SseEmitter.event().data(JSONUtil.toJsonStr(data)));
                }
            } catch (IOException e) {
                log.error("SSE send error", e);
                emitter.completeWithError(e);
            }
        });
        return emitter;
    }

    @TokenIgnore
    @Operation(summary = "调用流程")
    @PostMapping("/invoke")
    protected Object invoke(HttpServletResponse response, @RequestAttribute JSONObject requestParams) {
        // 提取请求参数
        String label = requestParams.getStr("label");
        CoolPreconditions.checkEmpty(label);
        Map params = requestParams.get("params", Map.class);
        Boolean stream = requestParams.getBool("stream");
        // 上下文
        FlowContext context = new FlowContext();
        context.setRequestParams(params);
        context.setRequestId(requestParams.getStr("requestId", IdUtil.randomUUID()));
        context.setSessionId(requestParams.getStr("sessionId"));
        context.setStream(stream);
        if (stream) {
            // 创建一个 SseEmitter 对象
            SseEmitter emitter = getSseEmitter(context);
            executorService.execute(() -> {
                try {
                    flowRunService.invoke(label, context);
                } catch (Exception e) {
                    CoolPreconditions.alwaysThrow("流程执行异常", e);
                } finally{
                    // 完成SSE会话
                    emitter.complete();
                }
            });
            return emitter;
        }
        return R.ok(flowRunService.invoke(label, context));
    }
}