package com.cool.modules.flow.service.impl;

import com.cool.core.base.BaseServiceImpl;
import com.cool.modules.flow.entity.FlowLogEntity;
import com.cool.modules.flow.mapper.FlowLogMapper;
import com.cool.modules.flow.service.FlowLogService;
import org.springframework.stereotype.Service;

/**
 * 流程信息
 */
@Service
public class FlowLogServiceImpl extends BaseServiceImpl<FlowLogMapper, FlowLogEntity> implements FlowLogService {
}