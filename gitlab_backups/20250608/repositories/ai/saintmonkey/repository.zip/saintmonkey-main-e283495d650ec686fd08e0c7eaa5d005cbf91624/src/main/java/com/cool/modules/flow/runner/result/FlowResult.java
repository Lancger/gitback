package com.cool.modules.flow.runner.result;
import java.util.List;
import java.util.Map;
import com.cool.modules.flow.runner.context.SimpleNodeInfo;
import lombok.*;

/**
 * 结果
 */
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class FlowResult {
    /**
     * 是否成功
     */
    private boolean success;

    /**
     * 异常信息(如果有则返回)
     */
    private String error;

    /**
     * 返回结果
     */
    private Object result;

    /**
     * 所有已经执行的节点信息
     */
    private List<Map<String, Object>> nodesResult;

    /**
     * 下个节点，如果有多个下个节点，当前节点需要做出判断选择一个节点执行
     */
    private SimpleNodeInfo next;

    public FlowResult(String error) {
        this.error = error;
    }

    public FlowResult(boolean success, String error) {
        this.success = success;
        this.error = error;
    }

    public FlowResult(boolean success, Object result) {
        this.success = success;
        this.result = result;
    }

    public FlowResult(boolean success, Object result, SimpleNodeInfo next) {
        this.success = success;
        this.result = result;
        this.next = next;
    }
}