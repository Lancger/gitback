package com.cool.modules.flow.service;

import com.cool.core.base.BaseService;
import com.cool.modules.flow.entity.FlowLogEntity;

/**
 * 流程信息
 */
public interface FlowLogService extends BaseService<FlowLogEntity> {
}
