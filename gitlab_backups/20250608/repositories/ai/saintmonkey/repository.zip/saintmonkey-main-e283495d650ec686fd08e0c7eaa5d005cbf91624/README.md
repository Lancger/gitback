
<p align="center">
  <a href="https://midwayjs.org/" target="blank"><img src="https://cool-show.oss-cn-shanghai.aliyuncs.com/admin/logo.png" width="200" alt="Midway Logo" /></a>
</p>
<p align="center">cool-admin(java版)后台权限管理系统，开源免费，Ai编码、流程编排、模块化、插件化，用于快速构建后台应用程序，详情可到<a href="https://cool-admin.com" target="_blank">官网</a> 进一步了解。
<p align="center">
    <a href="https://github.com/cool-team-official/cool-admin-midway/blob/master/LICENSE" target="_blank"><img src="https://img.shields.io/badge/license-MIT-green?style=flat-square" alt="GitHub license" />
    <a href=""><img src="https://img.shields.io/github/package-json/v/cool-team-official/cool-admin-midway?style=flat-square" alt="GitHub tag"></a>
    <img src="https://img.shields.io/github/last-commit/cool-team-official/cool-admin-midway?style=flat-square" alt="GitHub tag"></a>
</p>

# Ai流程编排+知识库
本项目是在开源版本的基础上新增了【Ai流程编排】和【知识库】模块   
开源部分这边就不过多介绍[请移步](https://github.com/cool-team-official/cool-admin-java)

## 介绍
🔥Ai 开发必备神器！！！未来趋势！！！


随着 Ai 的火热，很多应用希望接入 Ai 的能力，但是每次都是用代码手搓，容易把我们累死。这样不仅需要耗费大量的时间，而且做出来

的代码相对固定，不灵活，需要调整有得写代码。


有了 Ai 流程编排之后，关于 Ai 相关的开发就可以通过拖动的方式实现，原本几天的开发量，现在 10 分钟就搞定了，

真是一个 Ai 应用开发的神器，而且跟 cool-admin 后台管理系统深度结合，可以让你的 Ai 应用更加融入整个系统，同时它还支持自定义节点，可以满足你各种各样的业务需求。


因此如果你需要开发 Ai 相关应用，这个可能会给你的编码带来巨大的帮助。

## 结构

```
.
main
├─ java
│  ├─ com.cool
│  ├─ core             核心包
│  │  ├─ annotation
│  │  └─ ...
│  ├─ modules          模块包
│  │  ├─ flow              流程编排
│  │  │  ├─ controller
│  │  │  ├─ entity
│  │  │  ├─ mapper
│  │  │  └─ service
│  │  ├─ know              知识库
│  └─ CoolApplication
└─ resources           资源文件
   ├─ cool
   │  └─ data
   │     ├─ flow           流程编排相关配置json文件
   │     └─ know           知识库相关配置json文件         
   └─ mapper           mapper xml 文件
```

## 特点

深度与后台管理结合，可以调用后台管理的能力，如调用 cool-admin 后台的插件、操作数据库、操作 service、缓存等等，相比其他它更适合做为一个 Ai 应用的后台管理。

更加灵活可配置，可自定义节点以满足业务需求。

## 功能
1、 知识库：支持自定义、链接、文件等方式导入；

2、节点：
- 开始节点，流程的开始。
- 知识库，通过向量检索的方式，从向量数据库匹配相应的文本。
- LLM，大模型，对内容进行分析，执行相应的回复或动作。
- 执行代码，可以动态执行代码，调用框架的 service、操作数据库、调用插件、缓存等。
- 分类器，通过 LLM 分析，将内容分类，执行不同的行为。
- 智能解析，可以从一段文本中智能解析出你想要的内容，比如用户的收货地址。
- 条件判断，满足或不满足条件执行不同的动作。
- 流程，流程中也可以调用其它流程。
- 结束，结束流程，输出信息。
- ...
  3、流程支持流式和非流式两种方式调用。

节点可以自定义，以结合实际业务扩展更多功能。

## 前置准备
1、安装Chroma向量数据库
- 知识库检索使用到了向量数据库[Chroma](https://docs.trychroma.com/getting-started)
- 这边推荐使用docker方式进行安装，在 docker-compose.yml 中运行 chroma
  ![](doc/images/run_chroma.png)

2、大模型LLM相关apiKey获取

- 这边以[智谱AI 开放平台](https://maas.aminer.cn/usercenter/apikeys)为例，可麻烦使用；先注册，注册后如下图从中复制对应的apiKey并保存起来，接下来将会使用到
  ![](doc/images/zhipu_apikey.png)

### 后台使用
1、在流程模块添加配置
![](doc/images/add_llm_1.png)
![](doc/images/add_llm_2.png)

2、添加流程
![](doc/images/flow_1.png)

3、流程编排
![](doc/images/flow_2.png)

4、流程编排-分类器
分离器按输入的内容智能去调用LLM进行智能分类选择，在根据选择结果走到对应的分支        
可以选择不同的模型调试匹配出最合适自己场景的模型
![](doc/images/flow_classify_detail.png)
![](doc/images/flow_classify.png)

4、流程编排-LLM
调用大语言模型回答问题,其中消息类型有如下:

SYSTEM: 可以根据你的描述让大模型定位角色；比如示例中 他是一个售货员

USER: 使用斜杠/input 即你输入的内容

ASSISTANT: 表示模型对user发送信息的应答
- 助手角色是系统设计的虚拟角色，代表系统提供的智能对话服务。
- 助手会根据用户的输入进行理解和回复，提供信息、建议或者执行任务。
- 助手的作用是帮助用户解决问题、获取信息，提供支持和指导。

![](doc/images/flow_llm.png)
这个例子是文本输出，也可以使用对话的方式通过流式输出结果, 即在结束节点选择 stream

在输入那边得勾选上对话
![](doc/images/flow_llm_stream.png)

5、流程编排-知识库
从知识库中检索出相关的内容
- 知识库向量化模型配置
  ![](doc/images/know_1.png)

向量化模型如果是使用ollama，需要运行以下命令,拉取模型

```
ollama pull nomic-embed-text
```
否则会报错
```
status code: 404; body: {"error":"model \"nomic-embed-text\" not found, try pulling it first"}
```

ollama
![](doc/images/flow_llm_ollama.png)
模型配置在 resources/cool/data/flow/llm_config.json 配置文件中，可以自行添加，比如

我这边就在 ollama下新增了 llama3.1:8b 模型，同时需要在命令行拉取模型

```
ollama run llama3.1:8b
```

- 添加知识库分组
  ![](doc/images/know_2.png)

- 添加知识库
  ![](doc/images/know_3.png)

以下是知识库应用案例
![](doc/images/flow_know.png)

6、流程编排-流程节点
可以引用其他流程作为当前流程的子流程来执行

7、流程编排-智能解析
通过输入的文本，可以让大模型提取相应的内容信息

如：年龄、姓名
![](doc/images/flow_parse.png)

7、流程编排-执行代码
支持在流程中自定义代码，可以在代码中执行你需要的逻辑，动态编译执行

如：年龄、姓名
![](doc/images/flow_parse.png)

同时代码支持获取spring 容器中的bean如：
```java
import cn.hutool.core.util.ReflectUtil;
import cn.hutool.extra.spring.SpringUtil;
import com.cool.core.cache.CoolCache;
import java.util.Map;
/**
 * 代码执行
 */
public class DynamicClass {
  /**
   * 主函数
   */
  public Map<String, Object> main(Map<String, Object> params) {
    Object obj = SpringUtil.getBean(CoolCache.class);
    Object version = ReflectUtil.invoke(obj, "get", "admin:passwordVersion:1");
    String name = (String) params.get("arg1");
    name += "是个帅小伙_" + version;
    params.put("name", name);
    params.put("ageEq18", "我18岁");
    params.put("ageNotEq18", "不是18岁");
    return params;
  }
}
```
使用 Janino一个开源的轻量级Java编译器,它可以执行Java代码片段、类、方法等,无需通过javac编译

8、流程编排-条件判断
![](doc/images/flow_judge.png)

## 如何调用流程
```
SpringUtil.getBean(FlowRunService.class).invoke(params, flowInfo.getLabel(), false);
```
参考以下这两个类调用:
com.cool.modules.flow.controller.admin.AdminFlowRunController    
com.cool.modules.flow.nodes.flow.NodeFlow

## 241222 完善知识库RAG能力
- RAG增强大模型生成问答
- 文档召回最低分数可设置
- 未匹配到知识库不进行大模型生成
- 切块时内容重叠数量可设置

### RAG增强大模型生成问答
知识库配合大模型检索, 可以增强模型的知识能力。
![](doc/images/flow_rag_1.png)
此时我们在智谱知识库中添加 MyBatis-Flex 相关作者信息
![](doc/images/flow_rag_2.png)
然后在进行询问, 可以看出模型会根据输入内容检索出知识库内容进行RAG增强生成答案
![](doc/images/flow_rag_3.png)
关闭严格模式，未检索到知识库内容时，模型会生成答案
![](doc/images/flow_rag_4.png)
开启严格模式，未检索到知识库内容时，无法回答
![](doc/images/flow_rag_5.png)

### 知识库切块时内容重叠数量可设置
向量化模型新增两个配置参数   
- maxOverlapSizeInTokens 文档切割时重叠数量(按token算)
- maxSegmentSizeInTokens 每块文档长度（按token算）
![](doc/images/know_4.png)
```
参数解释
1. maxSegmentSizeInTokens
  含义：指定生成的每个文本片段（TextSegment）的最大大小，以“tokens”（标记）为单位。
  作用：文本被拆分成多个段时，每个段的长度不能超过这个值。
如果某个文本段过长（如一段话、一个句子），会进一步拆分为更小的单位（如句子、单词甚至字符）直到满足这个长度限制。
  场景：防止生成的文本片段过长，超过模型或存储的限制。确保每个文本片段可以适应后续的处理，比如发送给语言模型进行处理。

2. maxOverlapSizeInTokens
  含义：指定文本段与相邻段之间的最大重叠部分的大小，以“tokens”为单位。
  作用：在分段时，允许某些句子或部分重复出现在两个相邻段之间，增强上下文连贯性。
仅完整的句子会被纳入重叠部分（如代码注释中提到的：Only full sentences are considered for the overlap）。
  场景：避免因为硬性分段导致上下文缺失。提高模型回答的准确性，因为它可以参考更多上下文。
```

## 250305 升级
- 升级LangChain4j版本到1.0.0-beta1
- 新增deepseek对接
- 知识库支持向量库类型可配置
- 新增内存/Milvus向量库支持，其他类型向量库可自己扩展实现
- 支持 rerank 重排
- 优化聊天记忆

#### 安装Milvus
- 知识库检索使用到了向量数据库[Milvus](https://milvus.io/docs/quickstart.md)
- 这边推荐使用docker方式进行安装，在 docker-compose.yml 中运行 milvus
![](doc/images/run_milvus.png)

#### 知识库支持向量库类型可配置
![](doc/images/know_5.png)
Milvus配置
```json
{
"store": {
      "type": "milvus",
      "host": "127.0.0.1",
      "port": 19530,
      "dimension": 768
    }
}
```
Chroma配置
```json
{
  "store": {
    "type": "chroma",
    "url": "http://127.0.0.1:8000"
  }
}
```
内存配置
```json
{
  "store": {
    "type": "memory"
  }
}
```
注意：没配置默认为内存(memory)，如修改了store配置，需在对应的知识库里点击左上角的【重建】按钮，才会生效新的配置

![](doc/images/know_3.png)
目前就支持这两种向量库，如需其他向量库，可自己扩展实现

1、[引入对应的依赖](https://docs.langchain4j.dev/category/embedding-stores)

2、实现com.cool.modules.know.store.KnowStoreBase，在com.cool.modules.know.service.KnowServiceImpl中新增对应的store

3、新增对应的store枚举值：com.cool.modules.know.enums.StoreType

4、在配置中添加对应的配置信息

#### 可能会出现的问题
1、使用Milvus时插入知识点可能会报错
```
io.milvus.exception.ParamException: Incorrect dimension for field 'vector': the no.0 vector's dimension: 1024 is not equal to field's dimension: 768
```
原因：
- 字段维度：在 Milvus 中创建集合时，你需要定义一个 schema，其中包含一个向量字段，并指定该向量的维度（在你的例子中，字段的维度是 768）。
- 插入的向量维度：你尝试插入的向量维度是 1024，这与集合中定义的维度 768 不一致。
解决：确保字段维度与插入向量维度一致。调整插入向量维度，使其与字段维度一致。
```json
{
"store": {
      "type": "milvus",
      "host": "127.0.0.1",
      "port": 19530,
      "dimension": 1024
    }
}
```
注意：上面已经提到了修改配置一定一定要点击对应知识库左上角的【重建】按钮，才会生效新的配置

#### 支持 rerank 重排
1、注册[cohere](https://cohere.com/) 账号，并创建ak,不过免费的不太稳定 时不时403 Forbidden
![](doc/images/rerank_1.png)

2、配置重排模型
![](doc/images/rerank_2.png)

3、使用重排模型
![](doc/images/rerank_3.png)

使用效果测试:
比如 知识库配置了 mybatis plus作者是青苗，
你问他 mybatis flex作者是谁，在没有重排前 会回答是青苗， 使用后不会回答青苗会过滤掉这个知识

#### 优化聊天记忆
使用持久化聊天记录，默认1天，可自行配置，具体参考下面这个存储器
com.cool.modules.flow.nodes.llm.memory.PersistentChatMemoryStore

## LLM
[LangChain4j](https://github.com/langchain4j/langchain4j)
Java版本的LangChain，随着大模型的不断发展，如何在程序中更好的利用大模型的能力来提高编程效率是一种趋势，LangChain是这么自己介绍自己的：

LangChain gives developers a framework to construct LLM‑powered apps easily.

意思是：LangChain提供了一个开发框架，使得开发者可以很容易的用来构建具有LLM能力的应用程序。

LLM就是Large Language Model，也就是常说的大语言模型，简称大模型。

大模型时代，如何将大模型能力和传统应用相结合，使得传统应用更加智能，是人工智能时代的趋势。以前一个应用要获得智能，需要企业自己投入资源训练模型，而现在只需要接入大模型即可，这种便利性将使得大模型会应用得更为广泛，而如何将大模型能力和Java编程语言相结合，这就是LangChain4j所做的。

注意，大模型的能力远远不止聊天的能力，而LangChain4j就在帮助我们更好的利用大模型的能力，从而帮我们打造出更加智能的应用。

使用场景
LangChain4j 的使用场景广泛，覆盖了从基础的聊天机器人、问答系统到复杂的文档检索、知识管理、自动化工作流以及行业特定的AI解决方案等多个领域。以下是几个具体的使用场景：

客户服务自动化：企业可以利用LangChain4j构建智能客服系统，自动处理客户咨询、投诉和常见问题解答，提高服务效率和客户满意度。

内部知识管理：员工可以通过LangChain4j驱动的知识库搜索引擎快速获取公司政策、操作手册、技术文档等信息，提高工作效率。

内容创作与编辑：内容创作者和编辑团队可以利用LangChain4j辅助创作，例如自动生成文章概要、润色文本、甚至是基于现有素材生成新的创意内容。

个性化推荐系统：电商平台或媒体平台可以结合用户行为数据和LangChain4j的分析能力，提供更加个性化的商品或内容推荐。

智能分析报告：企业数据分析团队可以利用LangChain4j分析大数据集，自动生成易于理解的分析报告和业务洞察。

优势
高度模块化设计：允许开发者根据需要选择和组合模块，构建符合特定需求的解决方案，提高了灵活性和可扩展性。

强大的扩展性：支持对接多种语言模型和外部数据源，随着技术进步和新模型的出现，框架能快速适应和集成。

高效性能优化：针对Java环境进行了优化，确保模型运行高效，即使在处理大规模数据和高并发请求时也能保持良好性能。

易用性和可维护性：提供了简洁的API接口和详细的文档，降低了开发门槛，使得非AI背景的开发者也能快速上手。

丰富的社区支持和生态发展：活跃的开发者社区不断贡献新模块、案例和最佳实践，促进了框架的持续迭代和功能丰富。

企业级安全与合规：考虑到企业对数据安全和隐私的需求，LangChain4j设计时可能考虑了相应的安全措施和合规要求，确保模型的使用符合企业标准。
