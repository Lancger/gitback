docker stop cool-admin || true
docker rm -f cool-admin || true
docker rmi cool-admin || true
docker build -t cool-admin .
docker run -d -p 8001:8001  --name cool-admin cool-admin:latest