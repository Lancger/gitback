// 本地缓冲key

//token
export const TOKEN_KEY = 'token'
//账号
export const ACCOUNT_KEY = 'account'
//设置
export const SETTING_KEY = 'setting'
