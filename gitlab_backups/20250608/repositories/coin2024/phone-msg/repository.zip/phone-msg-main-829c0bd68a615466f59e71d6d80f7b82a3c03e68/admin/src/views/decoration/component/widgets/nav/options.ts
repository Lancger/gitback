export default () => ({
    title: '导航菜单',
    name: 'nav',
    content: {
        enabled: 1,
        data: [
            {
                image: '',
                name: '导航名称',
                link: {}
            }
        ]
    },
    styles: {}
})
