<script lang='ts' setup>
import { importPhoneList, importSave, importPage } from '@/api/mobilePhone/index'
import feedback from '@/utils/feedback'
const loading = ref(false)
const fileList: any = ref([])
const tableData = ref([])
const total = ref(0)
const queryParams = ref({
    pageNo: 1,
    pageSize: 10
})

const emit = defineEmits(['success', 'close']);
const props = defineProps({
    value: {
        type: Boolean,
        default: false
    },
    title: {
        type: String,
        default: ''
    },
    rowData: {
        type: Object,
        default: () => ({})
    }
})
const close = () => {
    queryParams.value.pageNo = 1
    tableData.value = []
    total.value = 0
    emit('close')
}

const handleCurrentChange = (val: number) => {
    queryParams.value.pageNo = val
    getLists()
}
const handleSizeChange = (val: number) => {
    queryParams.value.pageSize = val
    getLists()
}

const getLists = async () => {
    loading.value = true
    try {
        const res:any = await importPage(queryParams.value)
        console.log(res);
        tableData.value = res.records
        total.value = res.total
    } finally {
        loading.value = false
    }
}
const handleChange = (e: any) => {
    handleImport()
}

const handleRemove = () => {
    fileList.value = [];
}

const handleImport = async () => {
    loading.value = true;
    const file = fileList.value[0].raw;
    const time: any = Date.now()
    if (file) {
        const formData = new FormData();
        formData.append('files', file);
        formData.append('time', time);
        try {
            const res = await importPhoneList(formData);
            feedback.msgSuccess('上传成功');
            tableData.value = res.records
            total.value = res.total
        }
        finally {
            handleRemove()
            loading.value = false;
        }

    }
}

const handleSubmit = async (formName: string) => {
    await feedback.confirm('已重粉数据会被过滤后导入')
    try {
        loading.value = true
        await importSave()
        feedback.msgSuccess('提交成功')
        tableData.value = []
        emit('close')
        emit('success')
    } finally {
        loading.value = false
    }

}

onMounted(() => { })
</script>

<template>
    <el-dialog title="批量导入" :visible.sync="value" width="1000px" @close="close">
        <el-upload class="upload-demo" ref="upload" action="" :show-file-list="false" :on-change="handleChange"
            :limit="1" :on-remove="handleRemove" :file-list="fileList" :auto-upload="false">
            <el-button slot="trigger" size="" type="primary" :loading="loading">选择文件</el-button>
        </el-upload>
        <el-table class="mt-4" ref="tableRef" height="500px" size="large" v-loading="loading" :data="tableData" row-key="id">
            <el-table-column label="区号" prop="areaCode" min-width="150" show-overflow-tooltip>
                <template #default="{ row }">
                    {{ row.areaCode ? '+' + row.areaCode : '' }}
                </template>
            </el-table-column>
            <el-table-column label="电话号码" prop="phone" min-width="150" show-overflow-tooltip />
            <el-table-column label="是否重粉" prop="status" min-width="150" show-overflow-tooltip>
                <template #default="{ row }">
                    <span :class="row.status === 0 ? 'erro' : 'success'">{{ row.status === 0 ? '已重粉' : '未重粉' }}</span>
                </template>
            </el-table-column>
            <el-table-column label="创建时间" prop="createTime" min-width="180" />
        </el-table>
        <div class="flex justify-end mt-4">
            <el-pagination v-model:current-page="queryParams.pageNo" v-model:page-size="queryParams.pageSize"
                :page-sizes="[10, 20, 30, 40]" layout="total, sizes, prev, pager, next, jumper" :total="total"
                @size-change="handleSizeChange" @current-change="handleCurrentChange" />
        </div>
        <div slot="footer" class="mt-3 flex justify-end">
            <el-button :loading="loading" @click="close">取 消</el-button>
            <el-button :disabled="tableData.length == 0" type="primary" :loading="loading" @click="handleSubmit">提 交</el-button>
        </div>
    </el-dialog>
</template>

<style lang='scss' scoped>
.erro {
    color: #cc1717;
}

.success {
    color: #11c01a;
}
</style>
