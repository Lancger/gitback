<script lang='ts' setup>
import { phoneEdit } from '@/api/mobilePhone'
import type { FormInstance } from 'element-plus'
import feedback from '@/utils/feedback'
const formRef = shallowRef<FormInstance>()
const loading = ref(false)
let form = {
    phone: undefined,
    // name: undefined,
    areaCode: undefined
}
const rules = reactive({
    // name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
    phone: [{ required: true, message: '请输入电话号码', trigger: 'blur' }],
    // areaCode: [{ required: true, message: '请输入区号', trigger: 'blur' }]
})
const formData = ref({ ...form })
const emit = defineEmits(['success', 'close']);
const props = defineProps({
    value: {
        type: Boolean,
        default: false
    },
    title: {
        type: String,
        default: ''
    },
    rowData: {
        type: Object,
        default: () => ({})
    }
})
const close = () => {
    emit('close')
    formRef.value?.resetFields()
}
const open = () => {
    formData.value = { ...form }
    formData.value = Object.assign(formData.value, props.rowData)
}
const handleSubmit = async (formName: string) => {
    await formRef.value?.validate()
    await feedback.confirm('确定提交？')
    loading.value = true
    try {
        await phoneEdit(formData.value)
        feedback.msgSuccess('提交成功')
        loading.value = false
        emit('success')
        close()
    } finally {
        loading.value = false
    }

}

onMounted(() => { })
</script>

<template>
    <el-dialog title="编辑" :visible.sync="value" width="800px" @close="close" @open="open">
        <el-form ref="formRef" :rules="rules" :model="formData" label-width="120px">
            <!-- <el-form-item label="姓名：" prop="name">
                <el-input v-model="formData.name" clearable></el-input>
            </el-form-item> -->
            <el-form-item label="区号：" prop="areaCode">
                <el-input v-model="formData.areaCode" clearable></el-input>
            </el-form-item>
            <el-form-item label="电话号码：" prop="phone">
                <el-input v-model="formData.phone" clearable></el-input>
            </el-form-item>
        </el-form>
        <div slot="footer" class="mt-3 flex justify-end">
            <el-button :loading="loading" @click="close">取 消</el-button>
            <el-button type="primary" :loading="loading" @click="handleSubmit('formRef')">确 定</el-button>
        </div>
    </el-dialog>
</template>

<style lang='scss' scoped></style>
