import request from '@/utils/request'

// 手机号列表
export function getPhoneList(params: any) {
    return request.get({ url: '/phone/list', params })
}

export function getPhoneListNow(params: any) {
    return request.get({ url: '/phone/listNow', params })
}

// 手机号列表导出
export function exportPhoneList() {
    return request.get(
        { url: '/phone/export', responseType: 'blob' },
        {
            isTransformResponse: false
        }
    )
}

// 手机号模板下载
export function exportPhoneModle() {
    return request.get(
        { url: '/phone/exportTemplate', responseType: 'blob' },
        {
            isTransformResponse: false
        }
    )
}

// 手机号列表导入
export function importPhoneList(params?: any) {
    return request.post({ url: '/phone/import', params })
}

// 新增
export function phoneAdd(params: any) {
    return request.post({ url: '/phone/add', params })
}

// 删除
export function phoneDelete(params: any) {
    return request.post({ url: `/phone/del`, params })
}

// 修改
export function phoneEdit(params: any) {
    return request.post({ url: '/phone/edit', params })
}

// 详情
export function phoneDetail(params: any) {
    return request.post({ url: '/phone/detail', params })
}

//二次校验
export function verification(params: any) {
    return request.get({ url: '/phone/checkPwdAdmin', params })
}

//二次确认导入
export function importSave() {
    return request.post({ url: '/phone/importSave' })
}

//批量预览列表
export function importPage(params:any) {
    return request.post({ url: '/phone/importPage',params })
}

