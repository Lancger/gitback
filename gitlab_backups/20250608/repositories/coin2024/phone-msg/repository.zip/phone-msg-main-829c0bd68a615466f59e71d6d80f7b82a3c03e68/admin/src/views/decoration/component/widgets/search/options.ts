export default () => ({
    title: '搜索',
    name: 'search',
    disabled: 1,
    content: {},
    styles: {}
})
