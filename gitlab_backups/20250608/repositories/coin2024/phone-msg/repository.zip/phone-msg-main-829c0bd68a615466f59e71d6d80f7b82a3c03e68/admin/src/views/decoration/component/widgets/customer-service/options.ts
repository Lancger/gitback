export default () => ({
    title: '客服设置',
    name: 'customer-service',
    content: {
        title: '添加客服二维码',
        time: '',
        mobile: '',
        qrcode: ''
    },
    styles: {}
})
