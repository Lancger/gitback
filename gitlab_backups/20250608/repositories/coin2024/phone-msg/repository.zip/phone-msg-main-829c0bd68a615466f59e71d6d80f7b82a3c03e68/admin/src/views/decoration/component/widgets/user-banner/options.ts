export default () => ({
    title: '个人中心广告图',
    name: 'user-banner',
    content: {
        enabled: 1,
        data: [
            {
                image: '',
                name: '',
                link: {}
            }
        ]
    },
    styles: {}
})
