<template>
    <div class="dept-lists">
        <el-card class="!border-none" shadow="never">
            <el-form ref="formRef" class="mb-[-16px]" :model="queryParams" :inline="true">
                <!-- <el-form-item label="姓名" prop="name">
                    <el-input class="w-[280px]" v-model="queryParams.name" clearable @keyup.enter="getLists" />
                </el-form-item> -->
                <el-form-item label="操作员" prop="userName">
                    <el-input class="w-[280px]" v-model="queryParams.userName" clearable @keyup.enter="getLists" />
                </el-form-item>
                <el-form-item label="手机号" prop="phone">
                    <el-input class="w-[280px]" v-model="queryParams.phone" clearable @keyup.enter="getLists" />
                </el-form-item>
                <el-form-item label="操作时间" prop="createTime">
                    <el-date-picker class="w-[280px]" v-model="dataTime" type="daterange" range-separator="至" clearable
                        start-placeholder="开始时间" end-placeholder="结束时间" format="YYYY-MM-DD" value-format="YYYY-MM-DD" />
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" :loading="loading" @click="getLists">查询</el-button>
                    <el-button @click="resetParams">重置</el-button>
                </el-form-item>
            </el-form>
        </el-card>
        <el-card class="!border-none mt-4" shadow="never">
            <div>
                <!-- <el-button type="primary" v-perms="['phone:import']" :loading="loading" @click="handleOpen">
                    <template #icon>
                        <icon name="el-icon-Upload" />
                    </template>
导入
</el-button> -->
                <el-button v-perms="['phone:export']" type="primary" :loading="loading" @click="handlePassword">
                    <template #icon>
                        <icon name="el-icon-Download" />
                    </template>
                    导出
                </el-button>
                <!-- <el-button type="primary" v-perms="['phone:template']" :loading="loading" @click="handleModel">
                    下载模板
                </el-button> -->
                <!-- <input :key="keyflie" type="file" accept=".xls,.xlsx" ref="fileInput" @change="handleImport"
                    style="display: none;" /> -->
                <!-- <el-button type="primary" @click="handleAdd()">
                    <template #icon>
                        <icon name="el-icon-Plus" />
                    </template>
                    新增
                </el-button> -->
            </div>
            <div class="mt-4">
                <el-table ref="tableRef" size="large" v-loading="loading" :data="tableData" row-key="id">
                    <!-- <el-table-column label="姓名" prop="name" min-width="150" show-overflow-tooltip /> -->
                    <el-table-column label="区号" prop="areaCode" min-width="150" show-overflow-tooltip>
                        <template #default="{ row }">
                            {{ row.areaCode ? '+' + row.areaCode : '' }}
                        </template>
                    </el-table-column>
                    <el-table-column label="电话号码" prop="phone" min-width="150" show-overflow-tooltip />
                    <el-table-column label="操作员" prop="userName" min-width="150" show-overflow-tooltip />
                    <el-table-column label="更新时间" prop="updateTime" min-width="180" />
                    <el-table-column label="创建时间" prop="createTime" min-width="180" />
                    <el-table-column label="操作" width="160" fixed="right">
                        <template #default="{ row }">
                            <el-button v-perms="['phone:edit']" type="primary" link @click="handleEdit(row)">
                                编辑
                            </el-button>
                            <el-button v-perms="['phone:del']" type="danger" link
                                @click="handleDelete(row.id)">
                                删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div class="flex justify-end mt-4">
                    <el-pagination v-model:current-page="queryParams.pageNo" v-model:page-size="queryParams.pageSize"
                        :page-sizes="[10, 20, 30, 40]" layout="total, sizes, prev, pager, next, jumper" :total="total"
                        @size-change="handleSizeChange" @current-change="handleCurrentChange" />
                </div>
            </div>
        </el-card>
        <options-dialog v-model="showEdit" :rowData="rowData" @success="getLists" @close="showEdit = false" />
    </div>
</template>
<script lang="ts" setup name="department">
import { ElMessage, ElMessageBox } from 'element-plus'
import type { ElTable, FormInstance } from 'element-plus'
import feedback from '@/utils/feedback';
import { getPhoneList, exportPhoneList, importPhoneList, exportPhoneModle, phoneDelete, phoneEdit, phoneDetail, verification } from '@/api/mobilePhone/index'
import OptionsDialog from './optionsDialog.vue';
const formRef = shallowRef<FormInstance>()
const fileInput = ref<HTMLInputElement | null>(null)
const loading = ref(false)
const tableData = ref<any[]>([])
const rowData = ref({})
const total = ref(0)
const showEdit = ref(false)
const queryParams: any = reactive({
    pageNo: 1,
    pageSize: 10,
    phone: '',
    name: '',
    userName: '',
    startTime: '',
    endTime: '',
})
const dataTime = ref([]);
const getLists = async () => {
    loading.value = true
    try {
        queryParams.startTime = dataTime.value[0]
        queryParams.endTime = dataTime.value[1]
        const res = await getPhoneList(queryParams)
        tableData.value = res.lists
        total.value = res.count
    } finally {
        loading.value = false
    }
}
getLists()
const resetParams = () => {
    dataTime.value = []
    formRef.value?.resetFields()
}
const handleOpen = () => {
    fileInput.value?.click()
}

const keyflie = ref(0)
const handleImport = async (event: any) => {
    loading.value = true;
    const file = event.target.files[0];
    const time: any = Date.now()
    console.log(file);

    if (file) {
        const formData = new FormData();
        formData.append('files', file);
        formData.append('time', time);
        keyflie.value = time;
        try {
            await importPhoneList(formData);
            loading.value = false;
            feedback.msgSuccess('上传成功');
            getLists();
        } catch (error: any) {
            if (error) {
                ElMessage({
                    dangerouslyUseHTMLString: true,
                    showClose: true,
                    message: "错误原因<br/>" + error.join('<br/>'),
                    type: "error",
                    duration: 5000
                })
            }
        }
        finally {
            loading.value = false;
        }

    }
}

const handlePassword = () => {
    ElMessageBox.prompt('请输入二次校验密码', '提示', {
        confirmButtonText: '确认',
        cancelButtonText: '取消',
        inputErrorMessage: '密码不能为空',
    } as any)
        .then(({ value }) => {
            if (!value) return ElMessage({ type: 'error', message: '密码不能为空', });
            verification({ pwdAdmin: value }).then((res) => {
                if (res) {
                    handleExport();
                    ElMessage({
                        type: 'success',
                        message: '密码正确',
                    });
                }
            })
        })
}
const handleExport = () => {
    loading.value = true;
    exportPhoneList()
        .then((res) => {
            ElMessage({
                message: "导出成功",
                type: "success",
            })
            loading.value = false;
            let blob = new Blob([res], {
                type: "application/vnd.ms-excel",
            });
            let url = window.URL.createObjectURL(blob);
            var a = document.createElement("a");
            document.body.appendChild(a);
            a.style.display = 'none'
            a.href = url;
            a.download = "手机号列表.xlsx";
            a.click();
            document.body.removeChild(a) // 下载完成移除元素
            window.URL.revokeObjectURL(url);
        })
        .catch(() => {
            loading.value = false;
        });
}
const handleModel = () => {
    loading.value = true;
    exportPhoneModle()
        .then((res) => {
            ElMessage({
                message: "下载成功",
                type: "success",
            })
            loading.value = false;
            console.log(res);

            let blob = new Blob([res], {
                type: "application/vnd.ms-excel",
            });
            let url = window.URL.createObjectURL(blob);
            var a = document.createElement("a");
            document.body.appendChild(a);
            a.style.display = 'none'
            a.href = url;
            a.download = "模板.xlsx";
            a.click();
            document.body.removeChild(a) // 下载完成移除元素
            window.URL.revokeObjectURL(url);
        })
        .catch(() => {
            loading.value = false;
        });
}
const handleEdit = (row: any) => {
    showEdit.value = true
    rowData.value = row

}
const handleDelete = async (id: any) => {
    await feedback.confirm('此操作将永久删除该项, 是否继续?')
    try {
        await phoneDelete({ id: id })
        feedback.msgSuccess('删除成功')
        getLists()
    } catch {
        feedback.msgError('删除失败')
    }
}
const handleSizeChange = (val: number) => {
    queryParams.pageSize = val
    getLists()
}
const handleCurrentChange = (val: number) => {
    queryParams.pageNo = val
    getLists()
}

onMounted(() => { })
</script>
<style scoped lang="scss"></style>
