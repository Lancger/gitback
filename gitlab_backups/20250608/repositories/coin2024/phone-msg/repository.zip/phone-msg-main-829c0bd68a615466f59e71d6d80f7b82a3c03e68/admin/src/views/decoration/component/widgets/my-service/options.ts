export default () => ({
    title: '我的服务',
    name: 'my-service',
    content: {
        style: 1,
        title: '我的服务',
        data: [
            {
                image: '',
                name: '导航名称',
                link: {}
            }
        ]
    },
    styles: {}
})
