import attr from './attr.vue'
import content from './content.vue'
import options from './options'
export default {
    attr,
    content,
    options
}
