<template>
    <div class="dept-lists">
        <el-card class="!border-none" shadow="never">
            <el-form ref="formRef" class="mb-[-16px]" :model="formData" :inline="true">
                <el-form-item label="区号" prop="areaCode">
                    <el-input class="w-[200px]" :prefix-icon="Plus" v-model="formData.areaCode" clearable />
                </el-form-item>
                <el-form-item label="手机号" prop="phone">
                    <el-input class="w-[200px]" v-model="formData.phone" @keyup.enter="handleEnter" clearable />
                </el-form-item>
                <el-form-item>
                    <el-button v-perms="['phone:add']" type="primary" :loading="loading" @click="handleEnter">录入</el-button>
                    <el-button @click="resetForm">重置</el-button>
                    <div class="ml-20">
                        操作员：<span class="ml-2">{{ userStore.userInfo.username }}</span>
                    </div>
                </el-form-item>
                <el-form-item class="float-right">
                    <el-button v-perms="['phone:exportTemplate']" type="primary" :loading="loading" @click="getExportTemplate">下载模板</el-button>
                </el-form-item>
                <el-form-item class="float-right">
                    <el-button v-perms="['phone:allImport']" type="primary" :loading="loading" @click="openImportDialog">批量导入</el-button>
                </el-form-item>
            </el-form>
        </el-card>
        <el-card class="!border-none mt-4" shadow="never">
            <div class="mt-4">
                <el-table ref="tableRef" size="large" v-loading="loading" :data="tableData" row-key="id">
                    <el-table-column label="区号" prop="areaCode" min-width="150" show-overflow-tooltip>
                        <template #default="{ row }">
                            {{ row.areaCode ? '+' + row.areaCode : '' }}
                        </template>
                    </el-table-column>
                    <el-table-column label="电话号码" prop="phone" min-width="150" show-overflow-tooltip />
                    <el-table-column label="操作员" prop="userName" min-width="150" show-overflow-tooltip />
                    <el-table-column label="是否重复" prop="isRepeat" min-width="150" show-overflow-tooltip>
                        <template #default="{ row }">
                            <el-tag v-if="row.isRepeat" type="danger">是</el-tag>
                            <el-tag v-else type="info">否</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column label="创建时间" prop="createTime" min-width="180" />
                </el-table>
                <div class="flex justify-end mt-4">
                    <el-pagination
                        v-model:current-page="queryParams.pageNo"
                        v-model:page-size="queryParams.pageSize"
                        :page-sizes="[10, 20, 30, 40]"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="total"
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                    />
                </div>
            </div>
        </el-card>
        <import-options-dialog v-model="showAllImport" @success="getLists" @close="showAllImport = false" />
    </div>
</template>
<script lang="ts" setup name="department">
    import { ElMessage, ElMessageBox } from 'element-plus';
    import type { ElTable, FormInstance } from 'element-plus';
    import { Plus } from '@element-plus/icons-vue';
    import { exportPhoneModle, phoneAdd, getPhoneListNow } from '@/api/mobilePhone/index';
    import feedback from '@/utils/feedback';
    import useUserStore from '@/stores/modules/user';
    import importOptionsDialog from './importOptionsDialog.vue';

    const userStore = useUserStore();

    const tableData: any = ref([]);
    const total = ref(0);
    const queryParams = ref({
        pageNo: 1,
        pageSize: 10
    });
    const loading = ref(false);
    const showAllImport = ref(false);

    const formRef = shallowRef<FormInstance>();

    const formData: any = reactive({
        name: undefined,
        areaCode: undefined,
        phone: undefined
    });

    const openImportDialog = () => {
        console.log('openImportDialog');
        showAllImport.value = true;
    };
    const getLists = async () => {
        loading.value = true;
        try {
            const res = await getPhoneListNow(queryParams.value);
            tableData.value = res.lists;
            total.value = res.count;
        } finally {
            loading.value = false;
        }
    };
    getLists();

    const getExportTemplate = () => {
        loading.value = true;
        exportPhoneModle()
            .then((res) => {
                ElMessage({
                    message: '下载成功',
                    type: 'success'
                });
                loading.value = false;
                console.log(res);

                let blob = new Blob([res], {
                    type: 'application/vnd.ms-excel'
                });
                let url = window.URL.createObjectURL(blob);
                var a = document.createElement('a');
                document.body.appendChild(a);
                a.style.display = 'none';
                a.href = url;
                a.download = '模板.xls';
                a.click();
                document.body.removeChild(a); // 下载完成移除元素
                window.URL.revokeObjectURL(url);
            })
            .catch(() => {
                loading.value = false;
            });
    };

    const handleCurrentChange = (val: number) => {
        queryParams.value.pageNo = val;
        getLists();
    };
    const handleSizeChange = (val: number) => {
        queryParams.value.pageSize = val;
        getLists();
    };

    const handleEnter = async (event: any) => {
        event.target.blur();
        await ElMessageBox.confirm('你确定要导入该手机号吗？', '确认导入', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
        }).then(() => {
            handleAdd(formData);
        });
    };
    const handleAdd = async (formName: string) => {
        loading.value = true;
        try {
            await phoneAdd(formData);
            feedback.msgSuccess('提交成功');
            resetForm();
            getLists();
        } finally {
            loading.value = false;
        }
    };
    const resetForm = () => {
        formRef.value?.resetFields();
    };

    onMounted(() => {});
</script>
<style lang="scss" scoped>
    .dialog-m-title {
        display: flex;
        padding: 0px 0px 20px;
    }

    .m-title {
        padding: 0px 0px 10px;
        font-size: 16px;
        color: #333;
    }

    .m-export {
        border-radius: 20px;
        padding: 10px;
        width: 35%;
        margin-right: 5%;
        background: #f7f9fa;
    }

    .m-fen {
        position: relative;
        display: flex;
        justify-content: space-evenly;
        align-items: center;
    }

    .m-btn {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .m-bq {
        height: 50px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .w-title {
        width: 47%;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 0;
    }

    .upflied {
        display: flex;
        flex-direction: column;
    }

    .importBtn {
        display: flex;
        justify-content: flex-end;
        margin-right: 15%;
        position: relative;
        bottom: 54px;
    }

    ::v-deep .el-dialog__body {
        padding: 0 20px 15px;
    }

    // ::v-deep .el-upload-list {
    //     position: absolute;
    //     bottom: -30%;
    //     right: 0;
    // }

    // ::v-deep .el-upload-list__item {
    //     padding: 0 10px;
    //     background: #f7f9fa;
    // }

    // ::v-deep .el-upload__tip {
    //     text-align: center;
    // }

    // ::v-deep .el-upload {
    //     display: flex;
    //     flex-direction: column;
    // }

    // ::v-deep .el-upload-list__item .el-upload-list__item-info {
    //     width: 100%;
    //     margin-right: 10px;
    // }
</style>
