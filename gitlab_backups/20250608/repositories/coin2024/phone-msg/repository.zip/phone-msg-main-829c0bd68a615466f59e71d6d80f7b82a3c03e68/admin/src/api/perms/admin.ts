import request from '@/utils/request'

// 管理员列表
export function adminLists(params: any) {
    return request.get({ url: '/system/admin/list', params })
}

// 管理员添加
export function adminAdd(params: any) {
    return request.post({ url: '/system/admin/add', params })
}

// 管理员编辑
export function adminDetail(params: any) {
    return request.get({ url: '/system/admin/detail', params })
}

// 管理员编辑
export function adminEdit(params: any) {
    return request.post({ url: '/system/admin/edit', params })
}

// 管理员删除
export function adminDelete(params: any) {
    return request.post({ url: '/system/admin/del', params })
}

// 管理员删除
export function adminStatus(params: any) {
    return request.post({ url: '/system/admin/disable', params })
}

// 用户模板下载
export function exportPhoneModle() {
    return request.get(
        { url: '/system/admin/exportTemplate', responseType: 'blob' },
        {
            isTransformResponse: false
        }
    )
}

// 用户列表导入
export function importPhoneList(params?: any) {
    return request.post({ url: '/system/admin/import', params })
}

//批量预览列表
export function importPage(params:any) {
    return request.post({ url: '/system/admin/importPage',params })
}

//二次确认导入
export function importSave() {
    return request.post({ url: '/system/admin/importSave' })
}

