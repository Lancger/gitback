declare module 'vue3-video-play'

declare module 'css-color-function'

type PromiseFun = (...arg: any[]) => Promise<any>
