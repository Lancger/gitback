export default () => ({
    title: '资讯',
    name: 'news',
    disabled: 1,
    content: {},
    styles: {}
})
