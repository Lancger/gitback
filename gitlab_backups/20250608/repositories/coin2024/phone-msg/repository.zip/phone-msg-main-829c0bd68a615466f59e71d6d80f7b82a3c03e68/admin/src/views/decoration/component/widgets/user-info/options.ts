export default () => ({
    title: '用户信息',
    name: 'user-info',
    disabled: 1,
    content: {},
    styles: {}
})
