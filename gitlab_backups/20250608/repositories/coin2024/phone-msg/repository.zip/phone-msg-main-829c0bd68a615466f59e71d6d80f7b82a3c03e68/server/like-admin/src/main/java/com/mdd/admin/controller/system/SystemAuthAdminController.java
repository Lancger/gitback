package com.mdd.admin.controller.system;

import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mdd.admin.LikeAdminThreadLocal;
import com.mdd.admin.aop.Log;
import com.mdd.admin.controller.BaseController;
import com.mdd.admin.vo.system.*;
import com.mdd.common.aop.NotLogin;
import com.mdd.common.aop.NotPower;
import com.mdd.admin.service.ISystemAuthAdminService;
import com.mdd.admin.validate.commons.IdValidate;
import com.mdd.admin.validate.commons.PageValidate;
import com.mdd.admin.validate.system.SystemAdminCreateValidate;
import com.mdd.admin.validate.system.SystemAdminSearchValidate;
import com.mdd.admin.validate.system.SystemAdminUpInfoValidate;
import com.mdd.admin.validate.system.SystemAdminUpdateValidate;
import com.mdd.common.config.execlpoi.template.ExcelTemplate;
import com.mdd.common.core.AjaxResult;
import com.mdd.common.core.PageResult;
import com.mdd.common.entity.system.SystemAuthAdmin;
import com.mdd.common.enums.ErrorEnum;
import com.mdd.common.util.ExcelExportUtil;
import com.mdd.common.util.RedisUtils;
import com.mdd.common.util.StringUtils;
import com.mdd.common.validator.annotation.IDMust;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("api/system/admin")
@Api(tags = "系统用户管理")
public class SystemAuthAdminController extends BaseController {

    @Resource
    ISystemAuthAdminService iSystemAuthAdminService;

    @GetMapping("/list")
    @ApiOperation(value="管理员列表")
    public AjaxResult<PageResult<SystemAuthAdminListedVo>> list(@Validated PageValidate pageValidate,
                                                                @Validated SystemAdminSearchValidate searchValidate) {
        PageResult<SystemAuthAdminListedVo> list = iSystemAuthAdminService.list(pageValidate, searchValidate);
        return AjaxResult.success(list);
    }

    @NotPower
    @GetMapping("/self")
    @ApiOperation(value="管理员信息")
    public AjaxResult<SystemAuthAdminSelvesVo> self() {
        Integer adminId = LikeAdminThreadLocal.getAdminId();
        SystemAuthAdminSelvesVo vo = iSystemAuthAdminService.self(adminId);
        return AjaxResult.success(vo);
    }

    @GetMapping("/detail")
    @ApiOperation(value="管理员详情")
    public AjaxResult<SystemAuthAdminDetailVo> detail(@Validated @IDMust() @RequestParam("id") Integer id) {
        SystemAuthAdminDetailVo vo = iSystemAuthAdminService.detail(id);
        return AjaxResult.success(vo);
    }

    @Log(title = "管理员新增")
    @PostMapping("/add")
    @ApiOperation(value="管理员新增")
    public AjaxResult<Object> add(@Validated @RequestBody SystemAdminCreateValidate createValidate) {
        iSystemAuthAdminService.add(createValidate);
        return AjaxResult.success();
    }

    @Log(title = "管理员编辑")
    @PostMapping("/edit")
    @ApiOperation(value="管理员编辑")
    public AjaxResult<Object> edit(@Validated @RequestBody SystemAdminUpdateValidate updateValidate) {
        Integer adminId = LikeAdminThreadLocal.getAdminId();
        iSystemAuthAdminService.edit(updateValidate, adminId);
        return AjaxResult.success();
    }

    @NotPower
    @Log(title = "管理员更新")
    @PostMapping("/upInfo")
    @ApiOperation(value="当前管理员更新")
    public AjaxResult<Object> upInfo(@Validated @RequestBody SystemAdminUpInfoValidate upInfoValidate) {
        Integer adminId = LikeAdminThreadLocal.getAdminId();
        iSystemAuthAdminService.upInfo(upInfoValidate, adminId);
        return AjaxResult.success();
    }

    @Log(title = "管理员删除")
    @PostMapping("/del")
    @ApiOperation(value="管理员删除")
    public AjaxResult<Object> del(@Validated @RequestBody IdValidate idValidate) {
        Integer adminId = LikeAdminThreadLocal.getAdminId();
        iSystemAuthAdminService.del(idValidate.getId(), adminId);
        return AjaxResult.success();
    }

    @Log(title = "管理员状态")
    @PostMapping("/disable")
    @ApiOperation(value="管理员状态切换")
    public AjaxResult<Object> disable(@Validated @RequestBody IdValidate idValidate) {
        Integer adminId = LikeAdminThreadLocal.getAdminId();
        iSystemAuthAdminService.disable(idValidate.getId(), adminId);
        return AjaxResult.success();
    }


    @Log(title = "下载模板")
    @GetMapping("/exportTemplate")
    @ApiOperation(value="下载模板")
    public void exportTemplate(HttpServletRequest request, HttpServletResponse response) {
        Workbook workbook = ExcelExportUtil.exportExcelDropdown(ExcelTemplate.batchAdminTemplate(), new ArrayList<>());
        super.outpuExcel("导入手机号模板",workbook,request,response);
    }

    @Log(title = "批量新增代理和业务员")
    @PostMapping("/import")
    @ApiOperation(value="批量新增代理和业务员")
    public AjaxResult<Object> importExcel(MultipartFile files) {
        Page<SysAuthAdminVo> sysAuthAdminVoPage = new Page<>();
        try {
            // 保障账号唯一
            List<Map<String, Object>> excelList = ExcelExportUtil.importExcel(files.getInputStream(), ExcelTemplate.batchAdminTemplate());
            if (CollectionUtils.isEmpty(excelList)){
                return AjaxResult.failed("解析数据为空");
            }
            if (CollectionUtils.isEmpty(excelList)){
                return AjaxResult.failed("解析数据为空");
            }

            List<SystemAuthAdmin> allAdmin = iSystemAuthAdminService.AllAdmin();
            List<String> pCode = allAdmin.stream().map(SystemAuthAdmin::getPromotionCode).collect(Collectors.toList());
            List<String> usernames = allAdmin.stream().map(SystemAuthAdmin::getUsername).collect(Collectors.toList());

            List<SysAuthAdminVo> sysAuthAdminVos = new ArrayList<>();
            HashSet<String> check = new HashSet<>();
            for (Map<String, Object> tagMember : excelList) {
                List<String> errArr = new ArrayList<>();
                String username = (String) tagMember.get("username"); // 账号
                String nickname = (String) tagMember.get("nickname"); // 名字
                String invitationCode = (String) tagMember.get("invitation_code"); // 邀请码
                String password = (String) tagMember.get("password"); // 密码
                String type = (String) tagMember.get("type"); // 代理还是业务员0，代理，1业务员
                if (StringUtils.isEmpty(username)&&StringUtils.isEmpty(invitationCode)){
                    continue;
                }
                if (StringUtils.isEmpty(username)){
                    errArr.add("账号未填写");
                }
                if (StringUtils.isEmpty(type)){
                    errArr.add("账号类型未填写");
                }
                if (StringUtils.isEmpty(invitationCode)){
                    errArr.add("邀请码未填写");
                }
                // 判断账号存在
                if (usernames.contains(username)){
                    String errStr = username+"账号存在";
                    errArr.add(errStr);
                }
                // 邀请码不存在
                if (!pCode.contains(invitationCode)){
                    String errStr = invitationCode+"邀请码不存在";
                    errArr.add(errStr);
                }

                if (StringUtils.isNotEmpty(username)) {
                    boolean add = check.add(username);
                    if (!add){
                        // 记录不合理的手机号
                        String errStr = username+"同表单出现重复账号";
                        errArr.add(errStr);
                    }
                }

                SysAuthAdminVo tagObj = new SysAuthAdminVo();
                tagObj.setPlainPassword(password); // 设置密码
                tagObj.setType(type);
                tagObj.setErrArr(errArr);
                if("0".equals(type)){
                    tagObj.setRoleIds("3");
                }else if("1".equals(type)){
                    tagObj.setRoleIds("2");
                }else {
                    errArr.add("账号类型不正确");
                }
                 // 设置代理还是业务员，3代理，2业务员
                tagObj.setInvitationCode(invitationCode); // 邀请码
                tagObj.setNickname(StringUtils.isEmpty(nickname)?username:nickname); // 名字
                tagObj.setUsername(username); // 账号
                tagObj.setPassword(password); // 密码
                sysAuthAdminVos.add(tagObj);
            }
            RedisUtils.set("sys:admin:import", JSON.toJSONString(sysAuthAdminVos));
            sysAuthAdminVoPage = handlePageManual(sysAuthAdminVos, 1, 10);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return AjaxResult.success(sysAuthAdminVoPage);
    }

    public Page<SysAuthAdminVo> handlePageManual(List<SysAuthAdminVo> excelList, Integer pageNo, Integer pageSize){
        int totalRecords = 0;
        pageSize = pageSize==null||pageSize==0?10:pageSize;
        pageNo = pageNo==null||pageNo==0?1:pageNo;
        Page<SysAuthAdminVo> page = new Page<>(pageNo,pageSize);
        if (CollectionUtils.isEmpty(excelList)){
            return page;
        }
        totalRecords = excelList.size();
        int fromIndex = (pageNo - 1) * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, totalRecords); // 防止越界
        // 截取
        List<SysAuthAdminVo> pageData = excelList.subList(fromIndex, toIndex);
        page.setTotal(totalRecords);
        page.setRecords(pageData);
        return page;
    }

    @PostMapping("/importPage")
    @ApiOperation(value="上传的分页")
    public AjaxResult importPage(@RequestBody LvAdminListImportVo vo) {
        Object o = RedisUtils.get("sys:admin:import");
        if (o == null){
            return AjaxResult.success(new Page<>());
        }
        List<SysAuthAdminVo> list = JSON.parseArray(o.toString(), SysAuthAdminVo.class);
        Page<SysAuthAdminVo> lvPhoneImportVoPage = handlePageManual(list, vo.getPageNo(), vo.getPageSize());
        return AjaxResult.success(lvPhoneImportVoPage);
    }

    @Log(title = "导入存储")
    @PostMapping("/importSave")
    public AjaxResult importSave() {
        Object o = RedisUtils.get("sys:admin:import");
        if (o == null){
            return AjaxResult.failed("请先上传文件");
        }
        List<SysAuthAdminVo> list = JSON.parseArray(o.toString(), SysAuthAdminVo.class);
        if (CollectionUtils.isEmpty(list)){
            return AjaxResult.failed("请先上传文件");
        }
        for (SysAuthAdminVo sysAuthAdminVo : list) {
            if (!CollectionUtils.isEmpty(sysAuthAdminVo.getErrArr())){
                return AjaxResult.failedImport(sysAuthAdminVo.getErrArr());
            }
        }
        boolean isOK = iSystemAuthAdminService.saveBatchUser(list);
        if (!isOK){
            return AjaxResult.failed("导入失败");
        }
        RedisUtils.del("sys:admin:import");
        return AjaxResult.success();
    }

}
