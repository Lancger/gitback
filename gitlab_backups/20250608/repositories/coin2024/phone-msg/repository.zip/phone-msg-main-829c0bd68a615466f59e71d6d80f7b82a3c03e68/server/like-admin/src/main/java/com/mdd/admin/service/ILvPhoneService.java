package com.mdd.admin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mdd.admin.validate.commons.PageValidate;
import com.mdd.admin.validate.LvPhoneCreateValidate;
import com.mdd.admin.validate.LvPhoneUpdateValidate;
import com.mdd.admin.validate.LvPhoneSearchValidate;
import com.mdd.admin.vo.LvPhoneListedVo;
import com.mdd.admin.vo.LvPhoneDetailVo;
import com.mdd.admin.vo.StatisticsVo;
import com.mdd.common.core.AjaxResult;
import com.mdd.common.core.PageResult;
import com.mdd.common.entity.LvPhone;

/**
 * 【请填写功能名称】服务接口类
 * @author LikeAdmin
 */
public interface ILvPhoneService extends IService<LvPhone> {

    /**
     * 【请填写功能名称】列表
     *
     * @author LikeAdmin
     * @param pageValidate 分页参数
     * @param searchValidate 搜索参数
     * @return PageResult<LvPhoneListedVo>
     */
    PageResult<LvPhoneListedVo> list(PageValidate pageValidate, LvPhoneSearchValidate searchValidate);

    PageResult<LvPhoneListedVo> listNow(PageValidate pageValidate, LvPhoneSearchValidate searchValidate);

    /**
     * 【请填写功能名称】详情
     *
     * @author LikeAdmin
     * @param id 主键ID
     * @return LvPhoneDetailVo
     */
    LvPhoneDetailVo detail(Integer id);

    /**
     * 【请填写功能名称】新增
     *
     * @author LikeAdmin
     * @param createValidate 参数
     */
    void add(LvPhoneCreateValidate createValidate);

    /**
     * 【请填写功能名称】编辑
     *
     * @author LikeAdmin
     * @param updateValidate 参数
     */
    void edit(LvPhoneUpdateValidate updateValidate);

    /**
     * 【请填写功能名称】删除
     *
     * @author LikeAdmin
     * @param id 主键ID
     */
    void del(Integer id);

    LvPhoneListedVo exists(String phone,String areaCode);

    AjaxResult<StatisticsVo> getStatistics();
}
