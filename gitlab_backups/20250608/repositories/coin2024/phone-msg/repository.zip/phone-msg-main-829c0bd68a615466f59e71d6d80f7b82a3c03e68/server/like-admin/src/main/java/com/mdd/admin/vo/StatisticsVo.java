package com.mdd.admin.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
@ApiModel("统计VO")
@Data
@AllArgsConstructor
public class StatisticsVo {

    @ApiModelProperty(value = "今日录入数量")
    private Integer todayCount;

    @ApiModelProperty(value = "总录入数量")
    private Integer totalCount;
    @ApiModelProperty(value = "重复数量")
    private Integer numberOfRepeats;
}
