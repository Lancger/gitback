package com.mdd.admin.validate;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.Serializable;
import javax.validation.constraints.*;

@Data
@ApiModel("创建参数")
public class LvPhoneCreateValidate implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "phone参数缺失")
    @Pattern(regexp = "^[0-9]+$", message = "手机号必须是全数字")
    @ApiModelProperty(value = "手机号")
    private String phone;

    /*@NotNull(message = "区号参数缺失")
    @Pattern(regexp = "^[0-9]+$", message = "区号必须是全数字")*/
    @ApiModelProperty(value = "区号")
    private String areaCode;

    /*@NotNull(message = "名字参数缺失")*/
    @ApiModelProperty(value = "名字")
    private String name;
    @ApiModelProperty(value = "名字")
    private Boolean isRepeat;

}
