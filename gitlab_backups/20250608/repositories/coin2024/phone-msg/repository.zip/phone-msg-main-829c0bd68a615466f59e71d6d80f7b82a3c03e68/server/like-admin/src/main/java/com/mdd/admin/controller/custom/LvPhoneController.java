package com.mdd.admin.controller.custom;

import com.alibaba.fastjson2.JSON;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.query.MPJQueryWrapper;
import com.mdd.admin.LikeAdminThreadLocal;
import com.mdd.admin.aop.Log;
import com.mdd.admin.controller.BaseController;
import com.mdd.admin.service.ILvPhoneService;
import com.mdd.admin.service.ISystemAuthAdminService;
import com.mdd.admin.validate.commons.IdValidate;
import com.mdd.admin.validate.LvPhoneCreateValidate;
import com.mdd.admin.validate.LvPhoneUpdateValidate;
import com.mdd.admin.validate.LvPhoneSearchValidate;
import com.mdd.admin.validate.commons.PageValidate;
import com.mdd.admin.vo.LvPhoneImportVo;
import com.mdd.admin.vo.LvPhoneListImportVo;
import com.mdd.admin.vo.LvPhoneListedVo;
import com.mdd.admin.vo.LvPhoneDetailVo;
import com.mdd.admin.vo.StatisticsVo;
import com.mdd.admin.vo.system.SystemAuthAdminDetailVo;
import com.mdd.common.config.GlobalConfig;
import com.mdd.common.config.execlpoi.template.ExcelTemplate;
import com.mdd.common.core.AjaxResult;
import com.mdd.common.core.PageResult;
import com.mdd.common.entity.LvPhone;
import com.mdd.common.enums.ErrorEnum;
import com.mdd.common.util.*;
import com.mdd.common.validator.annotation.IDMust;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("api/phone")
@Api(tags = "手机号管理")
@Slf4j
public class LvPhoneController extends BaseController {

    @Resource
    ILvPhoneService iLvPhoneService;

    @Resource
    ISystemAuthAdminService iSystemAuthAdminService;
    //统计接口 今日录入 总录入 重复录入数量
    @GetMapping("/getStatistics")
    @ApiOperation(value = "统计")
    public AjaxResult<StatisticsVo> getStatistics() {
         return iLvPhoneService.getStatistics();
    }

    @GetMapping("/list")
    @ApiOperation(value = "列表")
    public AjaxResult<PageResult<LvPhoneListedVo>> list(@Validated PageValidate pageValidate, @Validated LvPhoneSearchValidate searchValidate) {
        PageResult<LvPhoneListedVo> list = iLvPhoneService.list(pageValidate, searchValidate);
        return AjaxResult.success(list);
    }

    @GetMapping("/listNow")
    @ApiOperation(value = "列表")
    public AjaxResult<PageResult<LvPhoneListedVo>> listNow(@Validated PageValidate pageValidate, @Validated LvPhoneSearchValidate searchValidate) {
        PageResult<LvPhoneListedVo> list = iLvPhoneService.listNow(pageValidate, searchValidate);
        return AjaxResult.success(list);
    }

    @GetMapping("/detail")
    @ApiOperation(value = "详情")
    public AjaxResult<LvPhoneDetailVo> detail(@Validated @IDMust() @RequestParam("id") Integer id) {
        LvPhoneDetailVo detail = iLvPhoneService.detail(id);
        return AjaxResult.success(detail);
    }

    @Log(title = "新增")
    @PostMapping("/add")
    @ApiOperation(value = "新增")
    public AjaxResult<Object> add(@Validated @RequestBody LvPhoneCreateValidate createValidate) {
        LvPhoneListedVo vo = iLvPhoneService.exists(createValidate.getPhone(), createValidate.getAreaCode());
        AjaxResult ajaxResult;
        if (vo != null) {
            createValidate.setIsRepeat(true);
            ajaxResult = AjaxResult.failed(vo.getPhone() + "已存在首位录入人：" + vo.getUserName());
        } else {
            ajaxResult = AjaxResult.success();
        }
        iLvPhoneService.add(createValidate);
        return ajaxResult;
    }

    @Log(title = "编辑")
    @PostMapping("/edit")
    @ApiOperation(value = "【请填写功能名称】编辑")
    public AjaxResult<Object> edit(@Validated @RequestBody LvPhoneUpdateValidate updateValidate) {
        iLvPhoneService.edit(updateValidate);
        return AjaxResult.success();
    }

    @Log(title = "删除")
    @PostMapping("/del")
    @ApiOperation(value = "删除")
    public AjaxResult<Object> del(@Validated @RequestBody IdValidate idValidate) {
        iLvPhoneService.del(idValidate.getId());
        return AjaxResult.success();
    }

    @GetMapping("/exportTemplate")
    @ApiOperation(value = "下载模板")
    public void download(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Workbook workbook = ExcelExportUtil.exportExcelDropdown(ExcelTemplate.batchPhoneTemplate(), new ArrayList<>());
        super.outpuExcel("导入手机号模板", workbook, request, response);
    }

    @PostMapping("/import")
    @ApiOperation(value = "上传")
    public AjaxResult<Object> upload(@RequestBody MultipartFile files) throws Exception {
        List<Map<String, Object>> excelList = ExcelExportUtil.importExcel(files.getInputStream(), ExcelTemplate.batchPhoneTemplate());
        if (CollectionUtils.isEmpty(excelList)) {
            return AjaxResult.failed("解析数据为空");
        }
        List<LvPhoneImportVo> lvPhones = new ArrayList<>();
        HashSet<String> setArr = new HashSet<>();

        // 获取全部数据
        List<LvPhone> list = iLvPhoneService.list();
        List<String> allPhone = list.stream().map(item -> {
            // 将手机号字符进行反转
            String reversePhone = StringUtils.reverse(item.getPhone());
            // 判断区号是否有值
            if (reversePhone.length() >= 8) {
                reversePhone = reversePhone.substring(0, 8);
            }
            return reversePhone;
        }).collect(Collectors.toList());

        for (Map<String, Object> tagMember : excelList) {
            List<String> errArr = new ArrayList<>();
            String phone = (String) tagMember.get("phone");
            String name = "";
            if (null != tagMember.get("name")) {
                name = (String) tagMember.get("name");
            }
            String areaCode = "";
            if (null != tagMember.get("area_code")) {
                areaCode = (String) tagMember.get("area_code");
            }
            if (StringUtils.isEmpty(phone)) {
                continue;
                /*errArr.add("手机号为空");*/
            }
            String phoneReverse = StringUtils.reverse(phone);
            if (phone.length() >= 8) {
                phoneReverse = phoneReverse.substring(0, 8);
            }
            Boolean isRepeat=false;
            // 判断手机号是否已经存在
            if (allPhone.contains(phoneReverse)) {
                String errStr = "区号：" + areaCode + " 手机号：" + phone + "重复";
                errArr.add(errStr);
                isRepeat=true;
            }
            // 处理区号
            /*areaCode = areaCode.replace("+","");*/
            List<String> strings = checkPhone(phone, areaCode);
            if (CollectionUtils.isNotEmpty(strings)) {
                errArr.addAll(strings);
            }
            LvPhoneImportVo tagObj = new LvPhoneImportVo(areaCode, phone, name, LikeAdminThreadLocal.getAdminId().toString(),isRepeat);
            tagObj.setCreateTime(new Date());
            tagObj.setUpdateTime(new Date());
            String key = areaCode + phone;
            boolean add = setArr.add(key);
            if (!add) {
                // 记录不合理的手机号
                String errStr = "区号：" + areaCode + " 手机号：" + phone + "重复";
                errArr.add(errStr);
            }
            tagObj.setErrArr(errArr);
            tagObj.setStatus(CollectionUtils.isEmpty(errArr) ? 1 : 0);
            lvPhones.add(tagObj);
        }
//        lvPhones = lvPhones.stream().sorted(Comparator.comparing(vo -> (CollectionUtils.isEmpty(vo.getErrArr()) ? 1 : 0))).collect(Collectors.toList());
        RedisUtils.set("sys:phone", JSON.toJSONString(lvPhones));
        // 分页处理
        Page<LvPhoneImportVo> lvPhoneListImportVoPage = new Page<>();
        if (CollectionUtils.isNotEmpty(lvPhones)) {
            // 分页处理
            lvPhoneListImportVoPage = handlePageManual(lvPhones, 1, 10);
        }
        return AjaxResult.success(lvPhoneListImportVoPage);
    }

    private List<String> checkPhone(String phone, String areaCode) {
        List<String> strings = new ArrayList<>();
        return strings;
    }

    @PostMapping("/importPage")
    @ApiOperation(value = "上传的分页")
    public AjaxResult importPage(@RequestBody LvPhoneListImportVo vo) {
        Object o = RedisUtils.get("sys:phone");
        if (o == null) {
            return AjaxResult.success(new Page<>());
        }
        List<LvPhoneImportVo> list = JSON.parseArray(o.toString(), LvPhoneImportVo.class);
        Page<LvPhoneImportVo> lvPhoneImportVoPage = handlePageManual(list, vo.getPageNo(), vo.getPageSize());
        return AjaxResult.success(lvPhoneImportVoPage);
    }

    public Page<LvPhoneImportVo> handlePageManual(List<LvPhoneImportVo> excelList, Integer pageNo, Integer pageSize) {
        int totalRecords = 0;
        pageSize = pageSize == null || pageSize == 0 ? 10 : pageSize;
        pageNo = pageNo == null || pageNo == 0 ? 1 : pageNo;
        Page<LvPhoneImportVo> page = new Page<>(pageNo, pageSize);
        if (CollectionUtils.isEmpty(excelList)) {
            return page;
        }
        totalRecords = excelList.size();
        int fromIndex = (pageNo - 1) * pageSize;
        int toIndex = Math.min(fromIndex + pageSize, totalRecords); // 防止越界
        // 截取
        List<LvPhoneImportVo> pageData = excelList.subList(fromIndex, toIndex);
        page.setTotal(totalRecords);
        page.setRecords(pageData);
        return page;
    }


    @PostMapping("/importSave")
    @ApiOperation(value = "导入存储")
    public AjaxResult importSave() {
        Object o = RedisUtils.get("sys:phone");
        if (StringUtils.isNull(o)) {
            return AjaxResult.failed("数据为空");
        }
        List<LvPhoneImportVo> list = JSON.parseArray(o.toString(), LvPhoneImportVo.class);
        List<LvPhone> lvPhones = new ArrayList<>();
        for (LvPhoneImportVo importVo : list) {
            Integer adminId = LikeAdminThreadLocal.getAdminId();
            LvPhone lvPhone = new LvPhone(importVo.getAreaCode(), importVo.getPhone(), importVo.getName(), adminId.toString(),importVo.getIsRepeat());
            lvPhone.setCreateTime(new Date());
            lvPhone.setUpdateTime(new Date());
            iLvPhoneService.exists(lvPhone.getPhone(), lvPhone.getAreaCode());
            lvPhones.add(lvPhone);
        }
        if (CollectionUtils.isEmpty(lvPhones)) {
            return AjaxResult.failed("可导数据为空");
        }
        try {
            boolean b = iLvPhoneService.saveBatch(lvPhones);
            if (!b) {
                return AjaxResult.failed("导入失败");
            }
        } catch (Exception e) {
            throw new RuntimeException("批量导入失败");
        }
        RedisUtils.del("sys:phone");
        return AjaxResult.success();
    }

    /**
     * 导出
     */
    @GetMapping("/export")
    @ApiOperation(value = "导出")
    public void export(HttpServletRequest request, HttpServletResponse response) {

        Integer pageNo = 1;
        Integer pageSize = 2000;

        MPJQueryWrapper<LvPhone> mpjQueryWrapper = new MPJQueryWrapper<LvPhone>().selectAll(LvPhone.class).select("sa.username,sa.nickname").leftJoin("?_system_auth_admin sa ON sa.id=t.user_id".replace("?_", GlobalConfig.tablePrefix)).orderByDesc("create_time");
        mpjQueryWrapper.eq("t.is_delete", 0);
        if (!LikeAdminThreadLocal.isAdmin()) {
            mpjQueryWrapper.apply("FIND_IN_SET({0}, sa.ancestors)", LikeAdminThreadLocal.getAdminId());
        }

        List<Map<String, Object>> listData = new ArrayList<>();
        Page page1 = new Page<>(pageNo, pageSize);
        while (true) {
            if (pageNo > 1) {
                page1 = new Page<>(pageNo, pageSize);
            }
            Page<Map<String, Object>> mapPage = iLvPhoneService.pageMaps(page1, mpjQueryWrapper);
            if (CollectionUtils.isEmpty(mapPage.getRecords())) {
                break;
            }
            List<Map<String, Object>> records = mapPage.getRecords();
            listData.addAll(records);
            pageNo++;
        }

        Map<String, Object> dc = ExcelTemplate.dc();
        // 参数：名称，表头，数据集合
        Workbook workbook = ExcelExportUtil.exportExcel("导出数据", dc, listData);

        super.outpuExcel("导出数据", workbook, request, response);
    }

    @Log(title = "二次密码校验")
    @GetMapping("/checkPwdAdmin")
    @ApiOperation(value = "二次密码校验")
    public AjaxResult<Object> check(@RequestParam("pwdAdmin") String pwdAdmin) {
        if (StringUtils.isEmpty(pwdAdmin)) {
            return AjaxResult.failed("请输入二次密码");
        }
        Integer adminId = LikeAdminThreadLocal.getAdminId();
        SystemAuthAdminDetailVo detail = iSystemAuthAdminService.detail(adminId);
        if (!pwdAdmin.equals(detail.getPwdAdmin())) {
            return AjaxResult.failed(ErrorEnum.FAILED.getCode(), "二次密码不正确", false);
        }
        return AjaxResult.success(true);
    }

}
