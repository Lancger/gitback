package com.mdd.admin.vo;

import lombok.Data;

@Data
public class LvPhoneListImportVo {
    private Integer pageNo;
    private Integer pageSize;
}
