package com.mdd.admin.controller.system;

import com.mdd.common.aop.NotLogin;
import com.mdd.common.aop.NotPower;
import com.mdd.admin.service.ISystemLoginService;
import com.mdd.admin.validate.system.SystemAdminLoginsValidate;
import com.mdd.admin.vo.system.SystemCaptchaVo;
import com.mdd.admin.vo.system.SystemLoginVo;
import com.mdd.common.core.AjaxResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("api/system")
@Api(tags = "系统登录管理")
public class SystemLoginController {

    @Resource
    ISystemLoginService iSystemLoginService;

    @NotLogin
    @GetMapping("/captcha")
    @ApiOperation(value="取验证码")
    public AjaxResult<SystemCaptchaVo> captcha() {
        SystemCaptchaVo vo = iSystemLoginService.captcha();
        return AjaxResult.success(vo);
    }

    @NotLogin
    @PostMapping("/login")
    @ApiOperation(value="登录系统")
    public AjaxResult<SystemLoginVo> login(@Validated() @RequestBody SystemAdminLoginsValidate loginsValidate) {
        SystemLoginVo vo = iSystemLoginService.login(loginsValidate);
        return AjaxResult.success(vo);
    }

    @NotPower
    @PostMapping("/logout")
    @ApiOperation(value="退出登录")
    public AjaxResult<Object> logout(HttpServletRequest request) {
        iSystemLoginService.logout(request.getHeader("token"));
        return AjaxResult.success();
    }

    /*@NotLogin
    @GetMapping("/key")
    public AjaxResult<Object> key() {
        GoogleAuthenticator gAuth = new GoogleAuthenticator();
        String secretKey = gAuth.createCredentials().getKey();
        return AjaxResult.success(secretKey);
    }*/

    @NotLogin
    @GetMapping("/check")
    public AjaxResult<Object> checkUserRole(@RequestParam String username) {
        return AjaxResult.success(iSystemLoginService.checkUserRole(username));
    }

    /*@NotLogin
    @GetMapping("/check/{key}/{code}")
    public AjaxResult<Object> check(@PathVariable("key") String key, @PathVariable("code") String code) {
        return AjaxResult.success(iSystemLoginService.validateLoginCode(code,key));
    }

    @NotLogin
    @GetMapping("/qrc/{key}")
    public AjaxResult<Object> qrc(@PathVariable("key") String key) {
        try {
            String base64 = QRCodeUtils.generateQRCode(key, null);
            return AjaxResult.success("data:image/png;base64,"+base64);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }*/


}
