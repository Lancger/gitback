package com.mdd.admin.bot;

import org.springframework.beans.factory.annotation.Value;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
public class MyTelegramBot extends TelegramLongPollingBot {

    @Value("${telegram.username}")
    private String botUsername;
    @Value("${telegram.token}")
    private String botToken;
    @Value("${telegram.chatId}")
    private  String chatId;
    @Override
    public String getBotUsername() {
        return botUsername;
    }

    @Override
    public String getBotToken() {
        return botToken;
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            String messageText = update.getMessage().getText();
            String chatId = update.getMessage().getChatId().toString();
            System.out.println("Received message: " + messageText);
        }
    }

    public void sendTextMessage(String text) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setText(text);

        try {
            // 调用 Telegram API 发送消息;
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

}
