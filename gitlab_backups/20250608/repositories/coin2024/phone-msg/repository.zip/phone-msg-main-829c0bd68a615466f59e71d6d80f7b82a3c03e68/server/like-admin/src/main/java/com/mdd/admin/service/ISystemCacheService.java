package com.mdd.admin.service;

/**
 * 系统缓存接口类
 */
public interface ISystemCacheService {

    /**
     * 清除系统缓存
     *
     */
    void clear();

}
