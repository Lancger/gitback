package com.mdd.admin.service.impl;

import com.alibaba.fastjson2.JSONObject;
import com.aliyun.oss.ServiceException;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.query.MPJQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.mdd.admin.LikeAdminThreadLocal;
import com.mdd.admin.bot.MyTelegramBot;
import com.mdd.admin.validate.commons.PageValidate;
import com.mdd.admin.service.ILvPhoneService;
import com.mdd.admin.validate.LvPhoneCreateValidate;
import com.mdd.admin.validate.LvPhoneUpdateValidate;
import com.mdd.admin.validate.LvPhoneSearchValidate;
import com.mdd.admin.vo.LvPhoneListedVo;
import com.mdd.admin.vo.LvPhoneDetailVo;
import com.mdd.admin.vo.StatisticsVo;
import com.mdd.admin.vo.system.SystemLogOperateVo;
import com.mdd.common.config.GlobalConfig;
import com.mdd.common.core.AjaxResult;
import com.mdd.common.core.PageResult;
import com.mdd.common.entity.LvPhone;
import com.mdd.common.entity.system.SystemLogOperate;
import com.mdd.common.mapper.LvPhoneMapper;
import com.mdd.common.util.*;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 【请填写功能名称】实现类
 *
 * @author LikeAdmin
 */
@Service
public class LvPhoneServiceImpl extends ServiceImpl<LvPhoneMapper, LvPhone> implements ILvPhoneService {

    @Resource
    LvPhoneMapper lvPhoneMapper;
    @Resource
    MyTelegramBot telegramBot;

    /**
     * 【请填写功能名称】列表
     *
     * @param pageValidate   分页参数
     * @param searchValidate 搜索参数
     * @return PageResult<LvPhoneListedVo>
     * @author LikeAdmin
     */
    @Override
    public PageResult<LvPhoneListedVo> list(PageValidate pageValidate, LvPhoneSearchValidate searchValidate) {
        Integer page = pageValidate.getPageNo();
        Integer limit = pageValidate.getPageSize();

        MPJQueryWrapper<LvPhone> mpjQueryWrapper = new MPJQueryWrapper<LvPhone>().selectAll(LvPhone.class).select("sa.username,sa.nickname").leftJoin("?_system_auth_admin sa ON sa.id=t.user_id".replace("?_", GlobalConfig.tablePrefix)).orderByDesc("create_time");

        mpjQueryWrapper.eq("t.is_delete", 0);
        if (!LikeAdminThreadLocal.isAdmin()) {
            mpjQueryWrapper.and((wrapper) -> {
                wrapper.apply("FIND_IN_SET({0}, sa.ancestors)", LikeAdminThreadLocal.getAdminId());
                wrapper.or().eq("t.user_id", LikeAdminThreadLocal.getAdminId());
            });
        }

        if (StringUtils.isNotEmpty(searchValidate.getStartTime())) {
            mpjQueryWrapper.ge("t.create_time", searchValidate.getStartTime());
        }

        if (StringUtils.isNotEmpty(searchValidate.getEndTime())) {
            mpjQueryWrapper.le("t.create_time", searchValidate.getEndTime());
        }

        lvPhoneMapper.setSearch(mpjQueryWrapper, searchValidate, new String[]{"=:name@name:str", "like:phone:str", "like:userName@sa.username:str"});

        IPage<LvPhoneListedVo> iPage = lvPhoneMapper.selectJoinPage(new Page<>(page, limit), LvPhoneListedVo.class, mpjQueryWrapper);

        return PageResult.iPageHandle(iPage);
    }

    @Override
    public PageResult<LvPhoneListedVo> listNow(PageValidate pageValidate, LvPhoneSearchValidate searchValidate) {
        Integer page = pageValidate.getPageNo();
        Integer limit = pageValidate.getPageSize();

        MPJQueryWrapper<LvPhone> mpjQueryWrapper = new MPJQueryWrapper<LvPhone>().selectAll(LvPhone.class).select("sa.username,sa.nickname").leftJoin("?_system_auth_admin sa ON sa.id=t.user_id".replace("?_", GlobalConfig.tablePrefix)).orderByDesc("create_time");

        mpjQueryWrapper.eq("t.is_delete", 0);
        if (!LikeAdminThreadLocal.isAdmin()) {
            mpjQueryWrapper.eq("t.user_id", LikeAdminThreadLocal.getAdminId());
        }

        if (StringUtils.isNotEmpty(searchValidate.getStartTime())) {
            mpjQueryWrapper.ge("t.create_time", searchValidate.getStartTime());
        }

        if (StringUtils.isNotEmpty(searchValidate.getEndTime())) {
            mpjQueryWrapper.le("t.create_time", searchValidate.getEndTime());
        }

        lvPhoneMapper.setSearch(mpjQueryWrapper, searchValidate, new String[]{"=:phone:str", "=:name@name:str", "like:userName@sa.username:str"});

        IPage<LvPhoneListedVo> iPage = lvPhoneMapper.selectJoinPage(new Page<>(page, limit), LvPhoneListedVo.class, mpjQueryWrapper);

        return PageResult.iPageHandle(iPage);
    }

    /**
     * 【请填写功能名称】详情
     *
     * @param id 主键参数
     * @return LvPhone
     * @author LikeAdmin
     */
    @Override
    public LvPhoneDetailVo detail(Integer id) {
        LvPhone model = lvPhoneMapper.selectOne(new QueryWrapper<LvPhone>().eq("id", id).eq("is_delete", 0).last("limit 1"));

        Assert.notNull(model, "数据不存在");

        LvPhoneDetailVo vo = new LvPhoneDetailVo();
        BeanUtils.copyProperties(model, vo);
        return vo;
    }

    /**
     * 【请填写功能名称】新增
     *
     * @param createValidate 参数
     * @author LikeAdmin
     */
    @Override
    public void add(LvPhoneCreateValidate createValidate) {
        LvPhone model = new LvPhone();
        model.setPhone(createValidate.getPhone());
        String areaCode = createValidate.getAreaCode();
        if (!StringUtils.isEmpty(areaCode)) {
            areaCode = areaCode.replaceAll("\\+", "");
            model.setAreaCode(areaCode);
        }
        model.setName(createValidate.getName());
        model.setPhone(createValidate.getPhone());
        model.setCreateTime(new Date());
        model.setIsRepeat(createValidate.getIsRepeat());
        model.setUpdateTime(new Date());
        model.setUserId(LikeAdminThreadLocal.getAdminId().toString());
        try {
            lvPhoneMapper.insert(model);
        } catch (Exception e) {
            throw new RuntimeException("新增失败");
        }
    }

    /**
     * 【请填写功能名称】编辑
     *
     * @param updateValidate 参数
     * @author LikeAdmin
     */
    @Override
    public void edit(LvPhoneUpdateValidate updateValidate) {
        LvPhone model = lvPhoneMapper.selectOne(new QueryWrapper<LvPhone>().eq("id", updateValidate.getId()).eq("is_delete", 0).last("limit 1"));
        Assert.notNull(model, "数据不存在!");

        // 校验手机号和区号是否已经存在
        String phone = updateValidate.getPhone();
        LvPhone model1 = lvPhoneMapper.selectOne(new QueryWrapper<LvPhone>().eq("phone", phone).eq("area_code", updateValidate.getAreaCode()).eq("is_delete", 0).last("limit 1"));

        if (model1 != null && !model.getPhone().equals(model1.getPhone())) {
            throw new RuntimeException("手机号和区号已存在!");
        }

        List<LvPhone> all = lvPhoneMapper.selectList(new QueryWrapper<LvPhone>().eq("is_delete", 0));
        if (CollectionUtils.isNotEmpty(all)) {
            List<String> collect = all.stream().map(item -> {
                String strPhone = StringUtils.reverse(item.getPhone());
                if (item.getPhone().length() >= 8) {
                    strPhone = strPhone.substring(0, 8);
                }
                return strPhone;
            }).collect(Collectors.toList());
            String reversePhone = StringUtils.reverse(phone);
            if (reversePhone.length() >= 8) {
                reversePhone = reversePhone.substring(0, 8);
            }
            if (collect.contains(reversePhone) && !model.getPhone().equals(phone)) {
                throw new RuntimeException("手机号已存在!");
            }
        }

        model.setId(updateValidate.getId());
        model.setPhone(phone);
        model.setUpdateTime(new Date());
        model.setName(updateValidate.getName());
        model.setAreaCode(updateValidate.getAreaCode());
        try {
            lvPhoneMapper.updateById(model);
        } catch (Exception e) {
            throw new RuntimeException("修改失败");
        }
    }

    /**
     * 【请填写功能名称】删除
     *
     * @param id 主键ID
     * @author LikeAdmin
     */
    @Override
    public void del(Integer id) {
        LvPhone model = lvPhoneMapper.selectOne(new QueryWrapper<LvPhone>().eq("id", id).eq("is_delete", 0).last("limit 1"));

        Assert.notNull(model, "数据不存在!");
        model.setIsDelete(1L);
        model.setPhone(model.getPhone() + ToolUtils.randomString(5));
        try {
            lvPhoneMapper.updateById(model);
        } catch (Exception e) {
            throw new RuntimeException("删除失败");
        }
    }

    @Override
    public AjaxResult<StatisticsVo> getStatistics() {
        return AjaxResult.success(new StatisticsVo(baseMapper.getSumCountByToDay(), baseMapper.getSumCount(), baseMapper.getRepeatCountByToDay()));
    }

    @Override
    public LvPhoneListedVo exists(String phone, String areaCode) {
        MPJQueryWrapper<LvPhone> mpjQueryWrapper = new MPJQueryWrapper<LvPhone>().selectAll(LvPhone.class).select("sa.username,sa.nickname").leftJoin("?_system_auth_admin sa ON sa.id=t.user_id".replace("?_", GlobalConfig.tablePrefix)).like("t.phone", "%" + phone.substring(phone.length() - 8) + "%").orderByAsc("create_time");
        mpjQueryWrapper.eq("t.is_delete", 0);

//        if (!StringUtils.isEmpty(areaCode)) {
//            mpjQueryWrapper.eq("area_code", areaCode);
//        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        List<LvPhoneListedVo> lvPhones = lvPhoneMapper.selectJoinList(LvPhoneListedVo.class, mpjQueryWrapper);
        if (lvPhones.size() >0) {
            StringBuffer sb = new StringBuffer();
            sb.append("\uD83D\uDEA8【有账号撞客啦】\uD83D\uDEA8 \n" + " 账号:" + phone + "\n" + " 录入用户: \n");
            for (int i = 0; i < lvPhones.size(); i++) {
                JSONObject object = JSONObject.parseObject(JSONObject.toJSONString(lvPhones.get(i)));
                if (i == 0) {
                    sb.append(i+1+". 首次录入员🙎：@" + object.get("nickname") + "  \t\t 录入时间⌚️" + object.getDate("createTime").toInstant()
                            .atZone(ZoneId.systemDefault())
                            .format(formatter) + " \n");
                } else {
                    sb.append(i+1+". 录入员🙎：@" + object.get("nickname") + "  \t\t 录入时间⌚️" + object.getDate("createTime").toInstant()
                            .atZone(ZoneId.systemDefault())
                            .format(formatter) + " \n");
                }
            }
            telegramBot.sendTextMessage(sb.toString());
            return lvPhones.get(0);
        }
        return null;
    }
}
