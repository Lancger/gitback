package com.mdd.admin.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.Date;

@Data
@ApiModel("【请填写功能名称】列表Vo")
public class LvPhoneListedVo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键")
    private Long id;

    @ApiModelProperty(value = "手机号")
    private String phone;

    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "区号")
    private String areaCode;

    @ApiModelProperty(value = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date updateTime;

    @ApiModelProperty(value = "业务员id")
    private String userId;

    @ApiModelProperty(value = "业务员账号")
    private String userName;

    @ApiModelProperty(value = "业务员昵称")
    private String nickname;

    @ApiModelProperty(value = "是否重复")
    private Boolean isRepeat;


}
