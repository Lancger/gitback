package com.mdd.admin.controller;


import com.mdd.common.util.BrowserUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;

@Slf4j
public class BaseController {

    protected void outpuExcel(String fileName, Workbook workbook, HttpServletRequest request, HttpServletResponse response) {
        ServletOutputStream servletOutputStream = null;

        try {
            response.setContentType("application/x-msdownload;charset=utf-8");
            String browse = BrowserUtils.checkBrowse(request);
            String name = fileName;
            if ("MSIE".equalsIgnoreCase(browse.substring(0, 4))) {
                response.setHeader("content-disposition", "attachment;filename=" + URLEncoder.encode(name, "UTF-8") + ".xls");
            } else {
                String filename = new String(name.getBytes("UTF-8"), "ISO8859-1");
                response.setHeader("content-disposition", "attachment;filename=" + filename + ".xls");
            }
            servletOutputStream = response.getOutputStream();
            workbook.write(servletOutputStream);
            response.flushBuffer();
        } catch (Exception e) {
            log.error("--通过流的方式获取文件异常--" + e.getMessage(), e);
        } finally {
            if (servletOutputStream != null) {
                try {
                    servletOutputStream.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }

        }
    }
}
