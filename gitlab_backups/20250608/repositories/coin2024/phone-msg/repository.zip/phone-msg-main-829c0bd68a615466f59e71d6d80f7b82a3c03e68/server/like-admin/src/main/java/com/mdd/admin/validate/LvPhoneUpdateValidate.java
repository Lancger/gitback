package com.mdd.admin.validate;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.Serializable;
import javax.validation.constraints.*;
import java.util.Date;
import java.util.Date;
import com.mdd.common.validator.annotation.IDMust;

/**
 * 【请填写功能名称】参数
 * @author LikeAdmin
 */
@Data
@ApiModel("更新参数")
public class LvPhoneUpdateValidate implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "主键")
    private Long id;

    @NotNull(message = "phone参数缺失")
    @Pattern(regexp = "^[0-9]+$", message = "手机号必须是全数字")
    @ApiModelProperty(value = "手机号")
    private String phone;

    /*@NotNull(message = "区号参数缺失")
    @Pattern(regexp = "^[0-9]+$", message = "区号必须是全数字")*/
    @ApiModelProperty(value = "区号")
    private String areaCode;

    /*@NotNull(message = "名字参数缺失")*/
    @ApiModelProperty(value = "名字")
    private String name;

}
