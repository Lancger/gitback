package com.mdd.admin.vo;

import com.mdd.common.entity.LvPhone;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
@ApiModel("导入列表Vo")
public class LvPhoneImportVo extends LvPhone implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<String> errArr;

    private Integer status;

    public LvPhoneImportVo(String areaCode, String phone, String name, String userId,Boolean isRepeat){
        super(areaCode, phone, name, userId,isRepeat);
    }

}
