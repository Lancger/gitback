<template>
  <view
    :class="[
      `app-tag--${type}`,
      `app-tag--${size}`,
      {
        'app-tag--border': border,
      },
      customClass,
    ]"
    class="app-tag"
  >
    <slot></slot>
  </view>
</template>

<script lang="ts" setup>
const props = defineProps({
  border: {
    type: Boolean,
    default: false,
  },
  type: {
    type: String,
    default: 'primary', // info primary error success
  },
  size: {
    type: String,
    default: 'medium', // small medium  large
  },
  customClass: {
    type: String,
    default: '',
  },
})
</script>

<style lang="scss" scoped>
.app-tag {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  width: max-content;
  border-radius: 5rpx;
  &--primary {
    color: var(--color-primary);
    background: #00a7ed1a;
  }
  &--success {
    color: var(--color-green);
    background: #07ba831a;
  }
  &--info {
    color: var(--text-primary);
    background: var(--background-gary-4);
  }
  &--error {
    color: var(--color-red);
    background: rgba(255, 78, 67, 0.1);
  }
  &--large {
    min-width: 140rpx;
    height: 60rpx;
    padding: 0 20rpx;
    font-size: 24rpx;
    font-weight: 500;
  }
  &--medium {
    height: 36rpx;
    padding: 0 10rpx;
    font-size: 24rpx;
    font-weight: 500;
  }
  &--small {
    height: 30rpx;
    padding: 0 10rpx;
    font-size: 22rpx;
    font-weight: 400;
  }
  &--border {
    border: 1px solid currentColor;
  }
}
</style>
