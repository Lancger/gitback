<script setup lang="ts">
import i18n, { t } from '@/locale'
import { useToast, useNotify, setNotifyDefaultOptions } from 'wot-design-uni'
import { useUserStore, useSystemStore } from '@/store'
import { onRouter, onHtmlToText } from './utils'
import { fetchSetLanguage } from '@/service/user'
import { onSubscribe } from '@/utils/subscribe'
import config from '@/config'

const toast = useToast()
const whiteList = ['pages/auth/sign-in', 'pages/auth/sign-up', 'pages/auth/forget-password']
let notifyData = null
const { showNotify, closeNotify } = useNotify()
// 全局 notify
setNotifyDefaultOptions({
  onClick: (event) => {
    closeNotify()
    if (notifyData.type === 'c2c') {
      onRouter(`/pages/home/ctwoc/paid/index?id=${notifyData.orderId}`)
      return
    }
    onRouter(`/pages/message/notify`)
  },
})

onLaunch(async (options) => {
  console.log('App Launch')

  const userStore = useUserStore()
  const { getSystemConfig } = useSystemStore()

  // 获取系统配置
  getSystemConfig()

  if (userStore.isLogined) {
    fetchSetLanguage(i18n.global.locale === 'zh-Hant' ? 'zh_tw' : i18n.global.locale)
    await userStore.getUserInfo()
    config.c2cChat && onSubscribe(`refresh_${userStore.userInfo?.blade_user_id}`)
    onSubscribe(`notify_new_message_${userStore.userInfo?.id}`)
    onSubscribe(`notify_new_message_all`)
  } else {
    if (!whiteList.includes(options.path)) {
      onRouter('/pages/auth/sign-in', 'reLaunch')
    }
  }

  // 获取汇率 5分钟刷新一次
  userStore.onGetExchangeRate(true)
  setInterval(userStore.onGetExchangeRate, 5 * 60 * 1000)

  // 全局 toast
  uni.$on('toast', (msg) => {
    toast.show({
      msg,
      zIndex: 999,
    })
  })

  uni.$on('message', (msgData) => {
    const [topic, data, mode] = msgData
    if ((topic.includes('refresh') || topic.includes('notify_new_message')) && mode === 'mqtt') {
      // console.log('msgData', data)
      const page = getCurrentPages().slice(-1)[0]
      notifyData = data
      // c2c 通知
      if (data.type === 'c2c' && !page.route.includes('contact-merchant')) {
        const notifyList = uni.getStorageSync('notifyList') || []
        notifyList.unshift({
          ...data,
          id: data.orderId,
          content: data.content,
          createTime: data.time,
          unread: true,
        })
        uni.setStorageSync('notifyList', notifyList)
        showNotify({
          type: 'primary',
          message: t('c2c.index.newP2PMessage'),
          duration: 0,
        })
        return
      }

      // 通知
      // data.content = JSON.parse(data.content)
      // const defaultLang = import.meta.env.VITE_LOCALE
      // const currentLang = uni.getLocale()
      // const content = data.content[currentLang || defaultLang || 'en']
      showNotify({
        type: 'primary',
        message: data.title || onHtmlToText(data.content),
        duration: 0,
      })
    }
  })
})

onShow(() => {
  console.log('App Show')
})

onHide(() => {
  console.log('App Hide')
})
</script>

<style lang="scss">
// 单行省略，优先使用 unocss: text-ellipsis
.ellipsis {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

// 两行省略
.ellipsis-2 {
  display: -webkit-box;
  overflow: hidden;
  text-overflow: ellipsis;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

// 三行省略
.ellipsis-3 {
  display: -webkit-box;
  overflow: hidden;
  text-overflow: ellipsis;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
}
</style>
