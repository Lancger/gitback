<template>
  <wd-overlay :show="modelValue" :z-index="99">
    <view class="wrapper">
      <view class="popup">
        <view class="popup__head">
          <image
            class="popup__head__icon"
            src="@/static/images/icons/notice_popup_icon.png"
            mode="scaleToFill"
          />
        </view>
        <view class="notice-title">{{ data.title }}</view>
        <view class="notice-content">
          <scroll-view scroll-y class="max-h-20vh">
            <!-- <mp-html :content="data.content" /> -->
            <div v-html="data.content"></div>
          </scroll-view>
        </view>
        <view class="px-30rpx text-right font-size-26rpx">{{ formatDate(data.date) }}</view>
        <wd-button custom-class="mx-90rpx mt-30rpx" block @click="onClose">
          {{ $t('common.close') }}
        </wd-button>
      </view>
      <wd-icon
        custom-class="mt-120rpx"
        color=" #fff"
        name="close-circle"
        size="50rpx"
        @click="onClose"
      ></wd-icon>
    </view>
  </wd-overlay>
</template>

<script lang="ts" setup>
// @ts-expect-error 没有声明文件
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'
import { formatDate } from '@/utils/day'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  data: {
    type: Object,
    default: () => ({}),
  },
})

const emits = defineEmits(['update:modelValue', 'onClose'])

const onClose = () => {
  emits('update:modelValue', false)
  emits('onClose')
}
</script>

<style lang="scss" scoped>
.wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;

  .popup {
    position: relative;
    box-sizing: border-box;
    width: 602rpx;
    padding-bottom: 50rpx;
    background-color: var(--background-primary);
    border-radius: 16rpx;
    box-shadow: 0 12rpx 40rpx 0 #4f4f4f40;

    &::after {
      position: absolute;
      bottom: -30rpx;
      left: 50%;
      z-index: -1;
      width: 492rpx;
      height: 459rpx;
      content: '';
      background-color: var(--background-primary);
      border-radius: 16rpx;
      transform: translateX(-50%);
    }

    &__head {
      position: relative;
      width: 100%;
      height: 128rpx;
      background: url('@/static/images/icons/notice_popup_bg.png') no-repeat;
      background-size: cover;

      &__icon {
        position: absolute;
        top: 0;
        left: 50%;
        width: 326rpx;
        height: 304rpx;
        transform: translate(-35%, -50%);
      }
    }

    .notice-title {
      padding: 0 30rpx;
      margin-top: 30rpx;
      font-size: 32rpx;
      font-weight: 500;
      text-align: center;
    }

    .notice-content {
      padding: 40rpx 30rpx;
    }
  }
}
</style>
