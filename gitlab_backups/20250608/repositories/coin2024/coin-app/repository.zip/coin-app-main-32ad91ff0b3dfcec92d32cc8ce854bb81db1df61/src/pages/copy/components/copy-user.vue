<template>
  <wd-tabs
    custom-class="app-tabs--tag app-tabs--tag-small app-tabs--tag-info app-tabs--no-flex-1 mt-30rpx"
    v-model="tabIndex"
    swipeable
    animated
    :map-num="100"
    @change="onTabChange"
  >
    <block v-for="(item, index) in tab" :key="index">
      <wd-tab :title="item.label" :name="item.value"></wd-tab>
    </block>
  </wd-tabs>
  <!--  -->
  <!-- <view class="py-30rpx mx-30rpx b-b">
    <view class="flex items-center gap-10rpx">
      <view class="font-size-22rpx">Full margin balance</view>
    </view>
    <view class="font-size-56rpx font-600 mt-20rpx">
      2,000.00
      <text class="font-size-22rpx">USDT</text>
    </view>
    <view class="font-size-22rpx mt-20rpx">
      Total PnL achieved
      <text class="font-500">300.00</text>
    </view>
    <view class="flex flex-wrap mt-40rpx">
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">Total wallet assets(USDT)</view>
        <view class="font-500 mt-20rpx">7,359,258.52</view>
      </view>
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">Net Profit (USDT)</view>
        <view class="font-500 mt-20rpx">7,359,258.52</view>
      </view>
    </view>
  </view> -->
  <!-- product list -->
  <app-empty :no-data="list.length === 0">
    <order-list isTap :list="list" @click="handleClick" />
    <wd-loadmore :state="loadMoreState" />
  </app-empty>
</template>

<script lang="ts" setup>
import OrderList from './order-list.vue'
import { fetchGetMyOrderList } from '@/service/copy'
import { onRouter } from '@/utils'
import { t } from '@/locale'

const mode = inject<Ref<'spot' | 'futures'>>('mode', ref('spot'))
const pagePath = inject<Ref<'home' | 'user'>>('pagePath')
const tab = [
  { label: t('copy.inProgress'), value: '0' },
  { label: t('copy.ended'), value: '2' },
]
const tabIndex = ref('0')

const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
  onLoadMore,
} = usePagination({
  api: (params) => {
    return fetchGetMyOrderList({
      size: params.pageSize,
      current: params.pageNo,
      followMode: '',
      type: mode.value === 'spot' ? 1 : 2,
      state: tabIndex.value,
      startTime: '',
      endTime: '',
    })
  },
  params: {},
  // onLoadMoreFn: onReachBottom,
})

watch(mode, () => {
  getList()
})

onShow(() => {
  getList()
})

onReachBottom(() => {
  if (pagePath.value === 'user') {
    onLoadMore()
  }
})

const onTabChange = ({ name }) => {
  console.log(name)
  tabIndex.value = name
  getList()
}

const handleClick = (item) => {
  uni.setStorageSync('copyOrder', item)
  onRouter(`/pages/copy/detail`)
}
</script>

<style lang="scss" scoped>
//
</style>
