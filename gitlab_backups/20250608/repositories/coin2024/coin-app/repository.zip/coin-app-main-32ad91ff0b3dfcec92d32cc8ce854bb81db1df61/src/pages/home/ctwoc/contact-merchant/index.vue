<template>
  <app-navbar custom-class="bg-transparent" :title="$t('c2c.contactMerchant.title')"></app-navbar>
  <view class="chat-content">
    <view class="content-list">
      <view class="li" v-for="item in chatData" :key="item.id">
        <view
          class="other"
          v-if="item.blade_user_id != userInfo.blade_user_id && item.blade_user_id != '-1'"
        >
          <view class="time">
            <image class="icon" src="@img/avatar.png" />
            <span class="fit-tc-primary">{{ formatDate(item.create_time) }}</span>
          </view>
          <view class="content">
            <view class="text" v-if="item.content_type == '1'">{{ item.content }}</view>
            <view class="image" v-if="item.content_type == '2'">
              <image :src="item.content"></image>
            </view>
          </view>
        </view>
        <view class="system" v-if="item.blade_user_id == '-1'">
          <view class="normal-tips">
            {{ item.content }}
            <em class="fit-tc-tertiary">[{{ formatDate(item.create_time) }}]</em>
          </view>
        </view>
        <view class="own" v-if="item.blade_user_id == userInfo.blade_user_id">
          <view class="time">
            <span class="fit-tc-primary">{{ formatDate(item.create_time) }}</span>
            <image class="icon" src="@img/avatar.png" />
          </view>
          <view class="content">
            <view class="text" v-if="item.content_type == '1'">{{ item.content }}</view>
            <view class="image" v-if="item.content_type == '2'">
              <image :src="item.content"></image>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>
  <view class="fixed">
    <wd-input
      prefix-icon="picture"
      use-suffix-slot
      type="text"
      v-model="value"
      :placeholder="$t('c2c.contactMerchant.input')"
      @clickprefixicon="clickprefixicon"
    >
      <template #suffix>
        <wd-button :disabled="!value" @click="send" size="small">
          {{ $t('c2c.contactMerchant.send') }}
        </wd-button>
      </template>
    </wd-input>
  </view>
</template>
<script lang="ts" setup>
import { onSubscribe } from '@/utils/subscribe'
import { fetchGetOrderChatRecord, fetchSendOrderChatRecord } from '@/service/ctwoc'
import { useUserStore } from '@/store'
import _ from 'lodash'
import { formatDate } from '@/utils/day'

const { data, run } = useUpload<string>()
const chatData = ref([])
const userStore = useUserStore()
const userInfo = computed(() => {
  return userStore.userInfo ? userStore.userInfo : {}
})
const value = ref('')
const orderId = ref('')

onShow(() => {
  uni.$on('message', onMessage)
})

// onHide(() => {
//   uni.$off('message', onMessage)
// })

onUnload(() => {
  uni.$off('message', onMessage)
})

onLoad((e) => {
  orderId.value = e.orderId
  fetchGetOrderChatRecord(orderId.value).then((res) => {
    chatData.value = res.data
    scrollToBottom()
    onSubscribe(`CHAT_${orderId.value}`)
  })
})
watch(data, () => {
  fetchSendOrderChatRecordFun(data.value.link, 2)
})

function onMessage(msgData) {
  console.log(msgData)

  const [topic, data, mode] = msgData
  if (topic.includes('CHAT') && mode === 'mqtt') {
    if (data.isDelete) {
      chatData.value = chatData.value.filter((item) => item.id !== data.id)
      return
    }
    chatData.value.push(data)
    scrollToBottom()
  }
}

const send = _.debounce(() => {
  fetchSendOrderChatRecordFun(value.value, 1)
}, 300)

const clickprefixicon = () => {
  run()
}
const fetchSendOrderChatRecordFun = (content, contentType) => {
  fetchSendOrderChatRecord({
    content,
    contentType,
    orderId: orderId.value,
    userType: '1',
  }).then((res) => {
    if (contentType === 1) {
      value.value = ''
    }
  })
}

// 滚动到底部
const scrollToBottom = () => {
  nextTick(function () {
    const query = uni.createSelectorQuery()
    query
      .select(`.chat-content`)
      .boundingClientRect((data: any) => {
        uni.pageScrollTo({
          scrollTop: data.height || 99999999,
          duration: 200,
        })
      })
      .exec()
  })
}

//
</script>

<style lang="scss" scoped>
.page {
  background-color: var(--background-tertiary);
}
.chat-content {
  box-sizing: border-box;
  padding: 16px 16px 0;
  padding-bottom: 120rpx;
  .content-list {
    .li {
      margin-bottom: 24px;
      .other {
        .time {
          display: flex;
          align-items: center;
          font-size: 12px;
          .icon {
            width: 20px;
            height: 20px;
            margin-right: 10px;
            overflow: hidden;
            background-repeat: no-repeat;
            background-size: cover;
          }
          .online {
            display: inline-block;
            width: 12px;
            height: 12px;
            margin-right: 10px;
            border-radius: 50%;
          }
        }
        .content {
          margin-top: 8px;
          margin-left: 22px;
          font-size: 12px;
          font-weight: 600;
          .text {
            display: inline-block;
            // min-width: 100px;
            max-width: 290px;
            padding: 12px;
            background-color: var(--background-primary);
            border-radius: 2px 12px 12px 12px;
          }
        }
      }
      .system {
        font-size: 12px;
        text-align: center;
        .normal-tips {
          display: inline-block;
          padding: 4px;
          font-weight: 600;
          border-radius: 20px;
          em {
            margin-left: 4px;
          }
        }
      }
      .own {
        font-size: 12px;
        .time {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          .icon {
            width: 20px;
            height: 20px;
            margin-left: 10px;
            overflow: hidden;
            background-repeat: no-repeat;
            background-size: cover;
          }
        }
        .content {
          margin-top: 8px;
          margin-right: 26px;
          font-size: 12px;
          font-weight: 600;
          text-align: right;
          .text {
            display: inline-block;
            // min-width: 100px;
            max-width: 290px;
            padding: 12px;
            text-align: left;
            background-color: var(--background-primary);
            border-radius: 12px 2px 12px 12px;
          }
        }
      }

      image {
        display: inline-block;
        width: 150px;
        height: 150px;
      }
    }
  }
}
.fixed {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  :deep(.wd-input__value) {
    height: 100rpx;
    padding: 0 20rpx;
  }
}
</style>
