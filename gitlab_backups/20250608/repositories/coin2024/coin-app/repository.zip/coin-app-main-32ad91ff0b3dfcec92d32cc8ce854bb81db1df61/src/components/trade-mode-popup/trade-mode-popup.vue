<template>
  <wd-popup
    :model-value="show"
    position="bottom"
    :z-index="99"
    closable
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="mode-list">
      <view v-for="(item, index) in list" :key="index" class="mode-list-item" @click="onTap(index)">
        <image class="mode-list-item__cover" :src="item.url" mode="aspectFit" />
        <view class="mode-list-item__content">
          <view class="mode-list-item__title">{{ item.title }}</view>
          <view class="mode-list-item__desc">{{ item.desc }}</view>
        </view>
        <wd-checkbox v-if="modelValue === index" :model-value="true"></wd-checkbox>
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
const props = defineProps({
  modelValue: {
    type: Number,
    default: 0,
  },
  show: {
    type: Boolean,
    default: false,
  },
  list: {
    type: Array<any>,
    default: () => [],
  },
})

const emits = defineEmits(['update:modelValue', 'update:show'])

const onTap = (i) => {
  emits('update:modelValue', i)
  onClose()
}

const onClose = () => {
  emits('update:show', false)
}
</script>

<style lang="scss" scoped>
.mode-list {
  padding: 60rpx 30rpx;
  &-item {
    display: flex;
    align-items: center;
    padding: 30rpx 0;

    &__cover {
      width: 60rpx;
      height: 60rpx;
    }

    &__content {
      flex: 1;
      padding: 0 20rpx;
    }

    &__title {
      font-size: 30rpx;
      font-weight: 500;
    }

    &__desc {
      margin-top: 10rpx;
      font-size: 22rpx;
      color: var(--text-inactive);
    }

    :deep(.wd-checkbox__label) {
      display: none;
    }
  }
}
</style>
