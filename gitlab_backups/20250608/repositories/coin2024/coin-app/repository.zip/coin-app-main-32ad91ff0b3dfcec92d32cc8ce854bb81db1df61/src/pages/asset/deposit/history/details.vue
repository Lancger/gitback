<template>
  <app-navbar custom-class="bg-transparent" :title="title"></app-navbar>
  <view class="p-30rpx">
    <view class="avatar">
      <image class="w-70rpx h-70rpx" :src="detailsData.avatar"></image>
    </view>
    <view class="block"></view>
    <view class="text-align-center font-size-34rpx mt-20rpx">
      {{
        {
          '-1': $t('assets.cashDetail.failed'),
          '0': $t('assets.cashDetail.pending'),
          '1': `${type === '1' ? $t('assets.cashDetail.depositSuccess') : $t('assets.cashDetail.withdrawSuccess')}`,
          '2': $t('assets.cashDetail.pending'),
          '3': `${type === '1' ? $t('assets.cashDetail.depositSuccess') : $t('assets.cashDetail.withdrawSuccess')}`,
          '4': $t('assets.cashDetail.failed'),
        }[detailsData.log_status] || '---'
      }}
    </view>
    <view class="text-align-center font-size-50rpx font-500 mt-30rpx">
      {{ type === '1' ? '+' : '-' }} {{ toFormat(detailsData.amount, true) }}
      {{ detailsData.coin_symbol }}
    </view>
    <view class="text-align-center font-size-24rpx mt-20rpx" v-if="type === '2'">
      {{ $t('assets.cashDetail.actualArrivals') }}
      {{ toFormat(detailsData.arrived_amount, true) }}
    </view>
    <view class="title">{{ $t('assets.cashDetail.time') }}</view>
    <view class="content">{{ formatDate(detailsData.create_time) }}</view>
    <view class="title">{{ $t('assets.cashDetail.network') }}</view>
    <view class="content">{{ detailsData.chain_type || '---' }}</view>
    <view class="title">{{ $t('assets.cashDetail.transferAddress') }}</view>
    <view class="content break-all">
      {{ detailsData.address || '---' }}
    </view>
    <view class="title">{{ $t('assets.cashDetail.txid') }}</view>
    <view class="content flex">
      <view class="flex-1 break-all">
        {{ detailsData.hash || '---' }}
      </view>
      <image class="w-30rpx h-30rpx ml2" @click="copy" src="@/static/images/assets/copy.png" />
    </view>
    <template v-if="detailsData.remark">
      <view class="title">{{ $t('assets.cashDetail.remarks') }}</view>
      <view class="content break-all">{{ detailsData.remark || '---' }}</view>
    </template>
    <view class="title">{{ $t('assets.cashDetail.processingTime') }}</view>
    <view class="content">
      {{
        type === '1'
          ? formatDate(detailsData.completion_time)
          : formatDate(detailsData.withdrawal_time) || '---'
      }}
    </view>
  </view>
  <view class="btn" v-if="type === '2' && detailsData.log_status === '0'">
    <wd-button class="flex-1" @click="affirm" size="large">
      {{ $t('assets.cashDetail.cancelWithdrawal') }}
    </wd-button>
  </view>
</template>
<script lang="ts" setup>
import { useMessage } from 'wot-design-uni'
import _ from 'lodash'
import { t } from '@/locale'
import { fetchGetRechargeLog, fetchGetWithdrawalLog, fetchWithdrawalCancel } from '@/service/assets'
import { formatDate } from '@/utils/day'
import { toFormat } from '@/utils/number'

const title = ref('')
const id = ref(0)
const type = ref('')
const detailsData = ref<any>({})
const message = useMessage()

onLoad((e) => {
  id.value = e.id
  type.value = e.type
  if (e.type === '1') {
    title.value = t('assets.cashDetail.deposit')
    fetchGetRechargeLogFun()
  } else {
    title.value = t('assets.cashDetail.withdraw')
    fetchGetWithdrawalLogFun()
  }
})
const fetchGetRechargeLogFun = () => {
  fetchGetRechargeLog({
    id: id.value,
  }).then((res) => {
    detailsData.value = res.data.records[0]
  })
}

const fetchGetWithdrawalLogFun = () => {
  fetchGetWithdrawalLog({
    id: id.value,
  }).then((res) => {
    detailsData.value = res.data.records[0]
    console.log(detailsData.value.log_status)
  })
}

const copy = () => {
  uni.setClipboardData({
    data: detailsData.value.hash || 'b-b-style-dashed',
    success: function () {
      uni.showToast({
        title: t('common.success'),
        icon: 'none',
        duration: 2000,
      })
    },
  })
}

const affirm = _.debounce(() => {
  message
    .confirm({
      title: t('assets.cashDetail.cancelDialog.title'),
      msg: t('assets.cashDetail.cancelDialog.msg'),
    })
    .then((res) => {
      uni.showLoading()
      fetchWithdrawalCancel(id.value)
        .then((res) => {
          fetchGetWithdrawalLogFun()
        })
        .finally(() => {
          uni.hideLoading()
        })
    })
}, 300)
</script>

<style lang="scss" scoped>
.avatar {
  text-align: center;
}
.text-align-center {
  text-align: center;
}
.title {
  margin-top: 50rpx;
  font-size: 30rpx;
  color: var(--text-inactive);
}
.content {
  margin-top: 20rpx;
  font-size: 30rpx;
}
.flex {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.btn {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  display: flex;
  align-items: center;
  height: 130rpx;
  padding: 0 30rpx;
  box-shadow: 0px -5px 21.7px 0px #c6c6c640;
}
</style>
