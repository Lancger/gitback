<template>
  <view class="flex items-center h-88rpx gap-10rpx b-b">
    <view
      v-for="(item, index) in tab"
      :key="index"
      class="flex items-center justify-center"
      @click="onTabChange(index)"
    >
      <view
        :class="
          tabIndex === index
            ? 'font-500   color-[var(--text-primary)] bg-[var(--background-gary-4)] rd-5rpx'
            : null
        "
        class="min-w-60rpx h-36rpx px-10rpx lh-36rpx text-center font-size-24rpx color-[var(--text-inactive)] transition-all-300"
      >
        {{ item.label }}
      </view>
    </view>
  </view>
  <view class="mt-10rpx">
    <echarts-vue width="100%" height="450rpx" @onInit="onInit" />
  </view>
</template>

<script lang="ts" setup>
import * as echarts from 'echarts/core'
import dayjs from '@/utils/day'
import { toFixed } from '@/utils/number'
import { fetchFlexibleRateChart } from '@/service/earn'
import config from '@/config'

const props = defineProps({
  id: {
    type: [Number, String],
    default: null,
  },
})

let chartRef = null
const tab = [
  // { label: '24H', value: 1 },
  // { label: '7D', value: 7 },
  { label: '30D', value: 30 },
  { label: '1Year', value: 365 },
]
const tabIndex = ref(0)

watch(
  () => props.id,
  () => {
    getRateChart()
  },
)

const onTabChange = (index) => {
  tabIndex.value = index
  getRateChart()
}

function getTime(day) {
  return dayjs().subtract(day, 'day').valueOf()
}

function getRateChart() {
  const day = tab[tabIndex.value].value
  return fetchFlexibleRateChart({
    goodsId: props.id,
    startTime: getTime(day),
    goodsType: 1,
    type: day > 1 ? 1 : 0,
  }).then((res) => {
    chartRef.setOption({
      xAxis: {
        data: res.data.map((item) => {
          return day > 1
            ? dayjs(item.calc_time).format(config.dateFormat.YMD)
            : dayjs(item.calc_time).format(config.dateFormat.HM)
        }),
      },
      series: [
        {
          data: res.data.map((item) => +toFixed(+item.apr * 100)),
        },
      ],
    })
  })
}

const onInit = (chart) => {
  chartRef = chart
  if (chartRef) {
    const option = {
      tooltip: {
        trigger: 'axis',
        // axisPointer: {
        //   type: 'cross',
        //   label: {
        //     backgroundColor: '#6a7985',
        //   },
        // },
      },
      grid: {
        top: '3%',
        left: '1%',
        right: '1%',
        bottom: '3%',
        containLabel: true,
        show: true,
        borderColor: '#F5F5F5',
      },
      xAxis: [
        {
          type: 'category',
          boundaryGap: false,
          // nameLocation: 'middle',
          axisLine: {
            show: false,
            lineStyle: {
              color: '#999999',
            },
          },
          axisTick: {
            show: false,
          },
          data: [],
        },
      ],
      yAxis: [
        {
          type: 'value',
          axisLine: {
            lineStyle: {
              color: '#999999',
            },
          },
          splitLine: {
            lineStyle: {
              color: '#F5F5F5',
            },
          },
          axisLabel: {
            formatter: '{value}%',
          },
        },
      ],
      series: [
        {
          name: 'APR',
          type: 'line',
          // stack: 'Total',
          showSymbol: false,
          lineStyle: {
            color: '#049EE9',
          },
          areaStyle: {
            opacity: 0.8,
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: 'rgba(151, 221, 255, 0.8)',
              },
              {
                offset: 1,
                color: 'rgba(150, 220, 255, 0)',
              },
            ]),
          },
          smooth: true,
          emphasis: {
            focus: 'series',
          },
          data: [],
        },
      ],
    }

    option && chart.setOption(option)

    if (props.id) {
      getRateChart()
    }
  }
}
</script>

<style lang="scss" scoped>
//
</style>
