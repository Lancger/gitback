<template>
  <view class="tab-box">
    <view
      v-for="(item, index) in list"
      :key="index"
      :class="{ 'tab-box__item--active': modelValue === index }"
      class="tab-box__item"
      @click="emits('update:modelValue', index)"
    >
      {{ $t(item) }}
    </view>
  </view>
</template>

<script lang="ts" setup>
const props = defineProps({
  modelValue: {
    type: Number,
    default: 0,
  },
  list: {
    type: Array,
    default: () => [],
  },
})

const emits = defineEmits(['update:modelValue'])
</script>

<style lang="scss" scoped>
.tab-box {
  display: flex;
  // align-items: flex-end;
  margin-top: 30rpx;
  &__item {
    position: relative;
    // flex: 1;
    height: 50rpx;
    padding: 30rpx 0;
    font-size: 30rpx;
    font-weight: 500;
    line-height: 50rpx;
    color: var(--text-secondary);
    text-align: center;
    transition: all 0.3s;
    + .tab-box__item {
      margin-left: 80rpx;
    }
    &--active {
      font-size: 40rpx;
      font-weight: 600;
      color: var(--text-primary);
      &::after {
        position: absolute;
        bottom: 0;
        left: 50%;
        width: 40rpx;
        height: 19rpx;
        content: '';
        background: url('@img/icons/tab_active.png') no-repeat;
        background-size: 100%;
        transform: translateX(-50%);
      }
    }
  }
}
.page.dark {
  .tab-box__item {
    color: var(--text-primary);
  }
}
</style>
