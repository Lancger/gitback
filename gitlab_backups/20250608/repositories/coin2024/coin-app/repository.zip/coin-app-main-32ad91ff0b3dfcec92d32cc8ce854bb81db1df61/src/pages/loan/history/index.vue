<template>
  <app-navbar :title="$t('loan.repaymentRecord')"></app-navbar>
  <!--  -->
  <app-empty :no-data="list.length === 0">
    <view
      v-for="(v, i) in list"
      :key="i"
      class="p-30rpx py-40rpx m-30rpx rd-20rpx border-1 border-[#E5E5E5] border-solid"
    >
      <view class="flex flex-col gap-30rpx">
        <view class="flex items-center justify-between font-siz-24rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.loan') }}</view>
          <view>{{ toFormat(v.repaymentAmount, true) }} {{ v.loan_symbol }}</view>
        </view>
        <view class="flex items-center justify-between font-siz-24rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.collateral') }}</view>
          <view>{{ toFormat(v.pledge_amount, true) }} {{ v.pledge_symbol }}</view>
        </view>
        <view class="flex items-center justify-between font-siz-24rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.loanTime') }}</view>
          <view>{{ formatDate(v.create_time) }}</view>
        </view>
        <view class="flex items-center justify-between font-siz-24rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.repaymentTime') }}</view>
          <view>{{ formatDate(v.create_time) }}</view>
        </view>
      </view>
      <wd-button custom-class="mt-40rpx w-100%" @click="onDetail(v)">
        {{ $t('loan.viewDetails') }}
      </wd-button>
    </view>
    <wd-loadmore :state="loadMoreState" />
  </app-empty>
</template>

<script lang="ts" setup>
import { fetchLoanHistory } from '@/service/loan'
import { formatDate } from '@/utils/day'
import { toFormat } from '@/utils/number'
import { onRouter } from '@/utils'

const {
  data: list,
  loadMoreState,
  onInit: getList,
} = usePagination({
  api: (params) => {
    return fetchLoanHistory({
      pageNo: params.pageNo,
      pageSize: params.pageSize,
    })
  },
  params: {},
  onLoadMoreFn: onReachBottom,
})

const onDetail = (item) => {
  uni.setStorageSync('loanHistoryItem', item)
  onRouter(`/pages/loan/history/detail`)
}
</script>

<style lang="scss" scoped></style>
