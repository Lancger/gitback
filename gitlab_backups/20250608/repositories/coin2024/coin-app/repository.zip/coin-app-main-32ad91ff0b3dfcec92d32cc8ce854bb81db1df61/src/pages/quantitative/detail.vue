<template>
  <app-navbar :title="$t('quantitative.details')" />
  <view class="p-30rpx">
    <view class="flex items-center justify-between">
      <view class="flex items-center gap-10rpx">
        <view class="font-size-28rpx font-500">{{ productData.projectName }}</view>
        <view
          class="h-30rpx px-6rpx lh-30rpx font-size-20rpx bg-[var(--background-gary-4)] rd-5rpx"
        >
          {{ productData.lever }}X
        </view>
      </view>
      <view class="font-size-28rpx font-500">
        {{ productData.day }} {{ $t('quantitative.days') }}
      </view>
    </view>
    <!--  -->
    <view class="flex items-center justify-between mt-30rpx">
      <view class="font-size-24rpx">{{ $t('quantitative.hands') }}</view>
      <view class="font-size-22rpx">
        <text class="color-[var(--text-inactive)]">{{ $t('quantitative.available') }}:</text>
        {{ maxAmount }} {{ $t('quantitative.hands') }}
      </view>
    </view>
    <!--  -->
    <view
      class="flex items-center gap-20rpx h-90rpx px-30rpx mt-30rpx border border-[var(--border-color-inactive)] border-solid rd-10rpx"
    >
      <input
        v-model="form.amount"
        class="flex-1 font-size-30rpx"
        type="number"
        :placeholder="$t(`common.min`) + ' ' + productData.minBuyHandNum"
      />
      <wd-button
        plain
        size="small"
        custom-class="!h-42rpx font-size-22rpx"
        @click="form.amount = maxAmount"
      >
        {{ $t(`common.max`) }}
      </wd-button>
    </view>
    <view class="mt-30rpx font-size-24rpx">
      ≈{{ toFormat(totalAmount, 2) }}
      {{ productData.baseSymbol }}
    </view>
    <!--  -->
    <view class="flex flex-col gap-30rpx mt-40rpx">
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.amountPerLot') }}
        </view>
        <view>{{ productData.handPrice }} {{ productData.baseSymbol }}</view>
      </view>
      <!-- <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">Effective time</view>
        <view>{{ formatDate(productData.startTime) }}</view>
      </view>
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">Due time</view>
        <view>8768678567575223</view>
      </view> -->
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.serviceCharge') }}
        </view>
        <view>{{ toFormatPercent(productData.feeRate * 100) }}</view>
      </view>
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.mdd') }}
        </view>
        <view>{{ toFormatPercent(productData.maxDrawDown * 100) }}</view>
      </view>
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.profitRate') }}
        </view>
        <view>
          {{ toFormatPercent(productData.minProfitRate * 100) }} -
          {{ toFormatPercent(productData.maxProfitRate * 100) }}
        </view>
      </view>
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.expectedReturn') }}
        </view>
        <view class="up-color">
          {{ toFormat(totalAmount * productData.minProfitRate, 2) }}
          ~
          {{ toFormat(totalAmount * productData.maxProfitRate, 2) }}
          {{ productData.baseSymbol }}
        </view>
      </view>
    </view>
  </view>
  <!--  -->
  <app-footer background="var(--background-primary)" shadow>
    <view class="px-30rpx py-20rpx">
      <wd-button
        custom-class="!w-100%"
        size="large"
        :disabled="+form.amount <= 0"
        :loading="loading"
        @click="showDialog = true"
      >
        {{ $t('quantitative.subscribe') }}
      </wd-button>
    </view>
  </app-footer>

  <!-- 弹窗 -->
  <app-dialog
    v-model="showDialog"
    :title="$t('quantitative.tips')"
    :content="$t('quantitative.subscribeTips')"
    @onConfirm="onSubmit"
  ></app-dialog>
</template>

<script lang="ts" setup>
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'
import { toFixed, toFormat, toFormatPercent } from '@/utils/number'
import { fetchPlaceOrder } from '@/service/quantitative'
import { fetchGetCurrencyAccount } from '@/service/assets'

const productData = ref(uni.getStorageSync('quantitativeProduct'))
const loading = ref(false)
const walletData = ref<any>({})
const form = ref({
  amount: undefined,
  projectId: productData.value.id,
})
const showDialog = ref(false)
const maxAmount = computed(() => {
  return +toFixed(walletData.value.balance / productData.value.handPrice, 0)
})
const totalAmount = computed(() => {
  return form.value.amount * productData.value.handPrice
})

getWallet()

const onSubmit = async () => {
  loading.value = true
  try {
    const res = await fetchPlaceOrder(form.value)
    loading.value = false
    onRouter(`/pages/quantitative/result`, 'redirectTo')
  } catch (error) {
    loading.value = false
  }
}

function getWallet() {
  return fetchGetCurrencyAccount({ type: 1 }).then((res) => {
    walletData.value = res.data.find((item) => item.symbol === productData.value.baseSymbol) || {}
  })
}
</script>

<style lang="scss" scoped>
//
</style>
