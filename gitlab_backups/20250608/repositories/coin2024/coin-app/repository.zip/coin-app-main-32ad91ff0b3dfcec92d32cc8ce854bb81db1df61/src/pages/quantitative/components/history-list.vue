<template>
  <view
    v-for="(item, index) in list"
    :key="index"
    class="p-30rpx my-30rpx border-1 border-solid border-color-[var(--border-color-inactive)] bg-[var(--background-primary)] rd-20rpx"
    @click="onRouter(`/pages/quantitative/history/detail?id=${item.id}`)"
  >
    <view class="flex items-center justify-between gap-10rpx">
      <view class="font-size-28rpx font-500">{{ item.projectName }}</view>
      <wd-icon custom-class="color-[var(--text-inactive)]" name="arrow-right" size="28rpx" />
    </view>
    <view class="flex items-center gap-10rpx mt-16rpx">
      <view class="h-30rpx px-6rpx lh-30rpx font-size-20rpx bg-[var(--background-gary-4)] rd-5rpx">
        {{ item.day }} {{ $t('quantitative.days') }}
      </view>
      <view class="h-30rpx px-6rpx lh-30rpx font-size-20rpx bg-[var(--background-gary-4)] rd-5rpx">
        {{ item.lever }}X
      </view>
    </view>
    <!--  -->
    <view class="flex flex-col gap-30rpx mt-20rpx">
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.orderId') }}
        </view>
        <view>{{ item.id }}</view>
      </view>
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.orderAmount') }}
        </view>
        <view>{{ item.buyAmount }}</view>
      </view>
      <!-- <view class="flex items-center justify-between font-size-24rpx">
          <view class="color-[var(--text-inactive)]">Effective time</view>
          <view>{{ formatDate(item.startTime) }}</view>
        </view> -->
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.profitRate') }}
        </view>
        <view>{{ toFormatPercent(item.profitRate * 100) }}</view>
      </view>
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.profitAmount') }}
        </view>
        <view class="up-color">{{ item.profit }}</view>
      </view>
      <view class="flex items-center justify-between font-size-24rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('quantitative.dueTime') }}
        </view>
        <view>{{ formatDate(item.endTime) }}</view>
      </view>
    </view>
    <!-- <wd-button
      v-if="!item.settlementStatus"
      class="mt-30rpx"
      size="large"
      block
      @click.stop="onSettle(item)"
    >
      {{ $t('quantitative.settle') }}
    </wd-button> -->
  </view>

  <!-- dialog -->
  <app-dialog
    v-model="showDialog"
    :title="$t('quantitative.tips')"
    :content="$t('quantitative.settleTips')"
    @onConfirm="onSubmit"
  ></app-dialog>
</template>

<script lang="ts" setup>
import { formatDate } from '@/utils/day'
import { onRouter } from '@/utils'
import { fetchSettle } from '@/service/quantitative'
import { toFixed, toFormatPercent } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
})
const emits = defineEmits(['onCallback'])

const productItem = ref<any>(null)
const loading = ref(false)
const showDialog = ref(false)

const onSubmit = async () => {
  loading.value = true
  try {
    await fetchSettle({
      projectRecordId: productItem.value.id,
    })
    loading.value = false
    showDialog.value = false
    emits('onCallback')
  } catch (error) {
    loading.value = false
  }
}

const onSettle = (item: any) => {
  productItem.value = item
  showDialog.value = true
}
</script>

<style lang="scss" scoped>
//
</style>
