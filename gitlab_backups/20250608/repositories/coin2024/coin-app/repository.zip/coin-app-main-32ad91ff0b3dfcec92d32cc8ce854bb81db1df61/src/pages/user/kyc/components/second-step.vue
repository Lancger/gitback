<template>
  <view class="main">
    <view class="main__hint1">{{ $t('kyc.selectLabel') }}</view>
    <view class="main__name">{{ $t('kyc.country') }}</view>
    <view class="main__input">
      <view>{{ props.country }}</view>
    </view>
    <view class="main__name">{{ $t('kyc.lastName') }}</view>
    <view class="main__input">
      <wd-input
        class="flex-1"
        no-border
        type="text"
        v-model="form.surname"
        :placeholder="$t('kyc.lastName')"
      />
    </view>
    <view class="main__name">{{ $t('kyc.name') }}</view>
    <view class="main__input">
      <wd-input
        class="flex-1"
        no-border
        type="text"
        v-model="form.name"
        :placeholder="$t('kyc.name')"
      />
    </view>
    <view class="main__name">{{ $t('kyc.typeOfCertificate') }}</view>
    <wd-select-picker
      v-model="form.cardType"
      :title="$t('kyc.select')"
      use-default-slot
      :filter-placeholder="$t('common.search')"
      :columns="columns"
      :show-confirm="false"
      type="radio"
      @confirm="onConfirm"
    >
      <view class="main__input">
        <view v-if="cardLabel">{{ cardLabel }}</view>
        <view v-else class="main__input__placeholder">{{ $t('kyc.select') }}</view>
        <image class="main__input__img" src="@/static/images/user/arrows.png"></image>
      </view>
    </wd-select-picker>
    <view class="main__name">{{ $t('kyc.idNo') }}</view>
    <view class="main__input">
      <wd-input
        class="flex-1"
        no-border
        type="text"
        v-model="form.cardCode"
        :placeholder="$t('kyc.idNo')"
      />
    </view>
    <view class="main__hint3">
      {{ $t('kyc.tips') }}
    </view>
    <view class="flex gap-30rpx mt-30rpx">
      <wd-button type="info" plain @click="lastStep" size="large" style="width: 100%">
        {{ $t('kyc.lastStep') }}
      </wd-button>
      <wd-button size="large" @click="next" style="width: 100%">{{ $t('kyc.next') }}</wd-button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { fetchGetCertificatesType } from '@/service/user'
const columns = ref<Record<string, any>[]>([])
const value = ref('')

const form = ref({
  name: '',
  surname: '',
  cardType: '',
  cardCode: '',
})
const cardLabel = ref('')
const certificatesTypeList = ref([])
const emits = defineEmits(['next', 'lastStep'])
const props = defineProps({
  country: {
    type: String,
    default: '',
  },
  countryData: {
    type: Object,
    default: () => {},
  },
})

watch(
  () => props.countryData.card_type_list,
  (newVal) => {
    onInitIDCardType()
  },
)

const flag = () => {
  return !form.value.name || !form.value.surname || !form.value.cardType || !form.value.cardCode
}

const next = () => {
  if (flag()) {
    return
  }
  emits('next', 3, {
    ...form.value,
  })
}

const lastStep = () => {
  emits('lastStep', 1)
}

const initialData = () => {
  fetchGetCertificatesType({}).then((res: any) => {
    certificatesTypeList.value = res.data
    onInitIDCardType()
  })
}

const onInitIDCardType = () => {
  columns.value = []
  const currTypeArr = props.countryData.card_type_list?.split(',') || []
  if (currTypeArr.length === 0) return
  currTypeArr.forEach((item) => {
    certificatesTypeList.value.forEach((child) => {
      if (item === child.value) {
        columns.value.push({
          ...child,
          value: child.id,
          label: child.label,
        })
      }
    })
  })
  const [defaultSelect] = columns.value
  form.value.cardType = defaultSelect.id
  cardLabel.value = defaultSelect.label
}

const onConfirm = (event) => {
  cardLabel.value = event.selectedItems.label
  form.value.cardType = event.selectedItems.id
}
initialData()
</script>

<style lang="scss" scoped>
:deep(.wd-action-sheet__header) {
  height: 90rpx;
  font-size: 36rpx;
  font-weight: 700;
  line-height: 90rpx;
}
:deep(.wd-action-sheet__close) {
  top: 30rpx;
  right: 30rpx;
  font-size: 30rpx;
}
:deep(.wd-select-picker__wrapper.is-filterable) {
  height: 60vh;
  max-height: 60vh;
  padding: 0;
}
:deep(.wd-radio__label) {
  font-size: 30rpx;
  font-weight: 500;
}
:deep(.wd-radio.is-cell-radio) {
  padding: 20rpx 30rpx;
}
:deep(.wd-input__placeholder) {
  font-size: 30rpx;
  color: var(--text-inactive);
}
.main {
  padding-top: 60rpx;
  padding-right: 30rpx;
  padding-left: 30rpx;
  &__hint1 {
    padding-bottom: 10rpx;
    font-size: 40rpx;
    font-weight: bold;
    color: var(--text-primary);
  }
  &__name {
    margin-top: 40rpx;
    margin-bottom: 30rpx;
    font-size: 24;
    color: var(--text-primary);
  }
  &__input {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 90rpx;
    padding: 0 30rpx;
    font-size: 30rpx;
    color: var(--text-primary);
    background-color: var(--input-bg-color);
    border: 1px solid var(--input-border-color);
    border-radius: 10rpx;
    &__placeholder {
      color: var(--text-inactive);
    }
    &__img {
      width: 36rpx;
      height: 36rpx;
    }
  }
  &__hint3 {
    margin-top: 30rpx;
    font-size: 24rpx;
    line-height: 40rpx;
    color: var(--text-inactive);
  }
  .position-fixed {
    position: fixed;
    right: 30rpx;
    bottom: 128rpx;
    left: 30rpx;
    display: flex;
    gap: 30rpx;
  }
}
</style>
