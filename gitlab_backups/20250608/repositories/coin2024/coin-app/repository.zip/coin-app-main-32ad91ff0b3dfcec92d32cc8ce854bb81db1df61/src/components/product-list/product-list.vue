<template>
  <view class="product-list">
    <template v-for="(item, index) in list" :key="index">
      <view v-if="item.symbolName" class="product-list__item" @click="emits('click', item)">
        <view class="product-list__item__coin-info">
          <image
            class="product-list__item__coin-info__logo"
            :src="item.bzicon || item.avatar"
            mode="aspectFit"
          />
          <view class="product-list__item__coin-info__content">
            <view class="product-list__item__coin-info__name">
              {{ item.symbolName.split('/')[0] }}
              <text
                v-if="!hideCurrency"
                class="font-400 font-size-22rpx color-[var(--text-inactive)]"
              >
                /{{ item.symbolName.split('/')[1] }}
              </text>
            </view>
            <view v-if="item.isShowVol" class="product-list__item__coin-info__vol">
              {{ t('components.productList.24HVol') }}
              {{ userStore.exchangeRateCurrent.exchange_code }}{{ toFormatUnit(item.vol) }}
            </view>
          </view>
        </view>
        <view class="product-list__item__price">
          <view>{{ toFormat(item.close, item.base_coin_scale || item.baseCoinScale) }}</view>
          <view class="mt-10rpx font-size-22rpx font-400 color-[var(--text-inactive)]">
            {{ userStore.onExchangeRateConversion(item.close) }}
          </view>
        </view>
        <view :class="[item.zdf >= 0 ? 'up-color' : 'down-color']" class="product-list__item__rate">
          {{ item.zdf >= 0 ? '+' : '' }}{{ toFormatPercent(item.zdf) }}
        </view>
      </view>
    </template>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { useUserStore } from '@/store'
import { toFixed, toFormat, toFormatPercent, toFormatUnit } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  hideCurrency: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['click'])

const userStore = useUserStore()
</script>

<style lang="scss" scoped>
.product-list {
  margin: 0 30rpx;
  &__item {
    display: flex;
    align-items: center;
    padding: 30rpx;
    margin-bottom: 20rpx;
    background: var(--background-primary);
    border-radius: 20rpx;
    &__coin-info {
      display: flex;
      align-items: center;
      width: 40%;
      &__logo {
        flex-shrink: 0;
        width: 50rpx;
        height: 50rpx;
        border-radius: 50%;
      }
      &__content {
        flex: 1;
        padding-left: 20rpx;
      }
      &__name {
        font-size: 30rpx;
        font-weight: 500;
      }
      &__vol {
        margin-top: 12rpx;
        font-size: 20rpx;
        color: var(--text-inactive);
      }
    }
    &__price {
      width: 30%;
      font-size: 30rpx;
      font-weight: 500;
      text-align: right;
    }
    &__rate {
      width: 30%;
      font-size: 32rpx;
      font-weight: 500;
      text-align: right;
    }
  }
}
</style>
