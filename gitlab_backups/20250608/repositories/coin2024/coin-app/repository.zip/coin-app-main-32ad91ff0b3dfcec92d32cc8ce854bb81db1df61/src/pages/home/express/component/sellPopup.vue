<template>
  <wd-popup :model-value="sellShow" position="bottom" @close="close">
    <view class="popup">
      <view class="popup_icon" @click="close">
        <wd-icon name="close" size="18px" color="#878787"></wd-icon>
      </view>
      <view class="popup_h">
        <view class="popup_cree" v-for="v in props.sellColumns" :key="v.id" @click="clickCree(v)">
          <image class="w-43rpx h-42rpx mr2 ml1" :src="v.avatar" />
          <text class="popup_text">
            {{ v.symbol }}
          </text>
        </view>
      </view>
    </view>
  </wd-popup>
</template>
<script lang="ts" setup>
const props = defineProps({
  sellShow: {
    type: Boolean,
    default: false,
  },
  sellColumns: {
    type: Array<any>,
    default: [],
  },
})
const emits = defineEmits(['close', 'upData'])
const close = () => {
  emits('close')
}
const clickCree = (v) => {
  emits('upData', v, 'sellPopup')
}
</script>
<style lang="scss" scoped>
:deep(.wd-popup--bottom) {
  border-radius: 10px 10px 0 0;
}
.popup {
  padding: 30rpx;
  &_icon {
    text-align: right;
  }
  &_list {
    display: flex;
    align-items: center;
    height: 108rpx;
    margin-top: 20rpx;
    font-size: 32rpx;
  }
  &_h {
    max-height: 400px;
    margin-top: 50rpx;
    overflow: auto;
  }
  &_cree {
    display: flex;
    align-items: center;
    width: 100%;
    // justify-content: center;
    height: 88rpx;
  }
}
</style>
