<template>
  <wd-config-provider :class="['page', themeStore.theme]">
    <slot />
    <wd-toast />
    <wd-message-box />
    <wd-notify />
  </wd-config-provider>
</template>

<script lang="ts" setup>
import { useThemeStore } from '@/store'

const themeStore = useThemeStore()
</script>
