import { http } from '@/utils/http'

// 闪兑币种列表
export const fetchConvertTokenList = (symbol?) => {
  return http.get('/api/mjkj-web/coin/open/flashExchange/getSymbolList', { symbol })
}

// 闪兑汇率
export const fetchConvertExchangeRate = (params) => {
  return http.get('/api/mjkj-web/coin/open/flashExchange/getExchangeRate', params)
}

// 闪兑提交
export const fetchConvertSubmit = (data) => {
  return http.post('/api/mjkj-web/coin/flashExchange/flashExchange', data)
}

// 闪兑记录
export const fetchConvertRecords = (data) => {
  return http.post('/api/mjkj-web/coin/flashExchange/list', data)
}
