<template>
  <app-navbar :title="$t('earnNew.holdingDetails')"></app-navbar>
  <view class="px-30rpx">
    <view class="flex items-center gap-20rpx py-30rpx">
      <view class="flex items-center gap-20rpx">
        <image
          class="w-42rpx h-42rpx rd-50%"
          :src="productInfo.coinAvatar || productInfo.coin_avatar"
        />
        <view class="font-size-30rpx font-500">
          {{ productInfo.coinName || productInfo.coin_name }}
        </view>
      </view>
      <view class="w-1px h-24rpx bg-[var(--border-color)]"></view>
      <view
        class="h-30rpx line-height-30rpx px-8rpx font-size-20rpx bg-[var(--background-gary-4)] rd-5rpx"
      >
        {{ mode === 0 ? $t('earnNew.flexible') : $t('earnNew.fixed') }}
      </view>
    </view>
    <view v-if="mode === 1" class="font-size-22rpx color-[var(--color-primary)]">
      {{ $t('earnNew.fixedTips') }}
    </view>
    <view v-if="mode === 0" class="py-50rpx">
      <view class="color-[var(--text-active)]">{{ $t('earnNew.totalAmount') }}</view>
      <view class="mt-20rpx font-size-32rpx font-500">
        {{ toFormat(productInfo.fullPrice) }} {{ productInfo.coinName }}
      </view>
    </view>
    <view v-else class="py-25rpx">
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.plan') }}</view>
        <view class="font-500">{{ productInfo.coin_name }}-{{ productInfo.day }}D</view>
      </view>
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.amount') }}</view>
        <view class="font-500">
          <text class="font-size-32rpx font-600">{{ toFormat(productInfo.buy_cou) }}</text>
          {{ productInfo.coinName || productInfo.coin_name }}
        </view>
      </view>
    </view>
    <view class="b-t"></view>
    <view v-if="mode === 0" class="py-25rpx">
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.apr') }}</view>
        <view class="font-500">{{ toFormatPercent(productInfo.nowRateYear * 100) }}</view>
      </view>
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.yesterdayIncome') }}</view>
        <view class="font-500">
          {{ toFormat(productInfo.yesterdayProfit) }} {{ productInfo.coinName }}
        </view>
      </view>
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.totalIncome') }}</view>
        <view class="font-500">
          {{ toFormat(productInfo.totalProfit) }} {{ productInfo.coinName }}
        </view>
      </view>
    </view>
    <view v-else class="py-25rpx">
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.apr') }}</view>
        <view class="font-500">{{ toFixed(productInfo.rate_year * 100) }}%</view>
      </view>
      <!-- <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">Est. Earnings per day</view>
        <view class="font-500">
          {{ toFormat(productInfo.totalProfit) }} {{ productInfo.coin_name }}
        </view>
      </view> -->
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.cumulativeEarnings') }}</view>
        <view class="font-500">{{ toFormat(productInfo.profit) }} {{ productInfo.coin_name }}</view>
      </view>
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.termOfPlan') }}</view>
        <view class="font-500">{{ productInfo.day }} {{ $t('earnNew.day') }}</view>
      </view>
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.orderTime') }}</view>
        <view class="font-500">{{ formatDate(productInfo.create_time) }}</view>
      </view>
      <view class="flex items-center justify-between py-25rpx font-siz-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.settlementTime') }}</view>
        <view class="font-500">{{ formatDate(productInfo.unlock_time) }}</view>
      </view>
    </view>
  </view>
  <app-footer v-if="mode === 0" background="var(--background-primary)" shadow>
    <view class="px-30rpx py-20rpx">
      <wd-button custom-class="!w-100%" size="large" @click="showPopup = true">
        {{ $t('earnNew.redeem') }}
      </wd-button>
    </view>
  </app-footer>
  <!--  -->
  <wd-popup
    :model-value="showPopup"
    position="bottom"
    :z-index="99"
    closable
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="showPopup = false"
  >
    <view class="pt-40rpx px-30rpx">
      <view class="text-center font-size-30rpx font-500">{{ $t('earnNew.subscribe') }}</view>
      <view>
        <view class="py-30rpx">{{ $t('earnNew.amount') }}</view>
        <view
          class="flex items-center gap-20rpx h-90rpx px-30rpx border border-[var(--border-color)] border-solid rd-10rpx"
        >
          <input
            v-model="amount"
            class="flex-1 font-size-30rpx"
            type="digit"
            :placeholder="$t('earnNew.min') + ' ' + productInfo.minPrice"
            @input="onInput"
          />
          <view class="font-size-30rpx">{{ productInfo.coinName }}</view>
          <wd-button
            type="info"
            plain
            size="small"
            custom-class="!h-42rpx font-size-22rpx"
            @click="amount = productInfo.fullPrice"
          >
            {{ $t('earnNew.max') }}
          </wd-button>
        </view>
        <view class="mt-26rpx font-size-22rpx">
          <text class="color-[var(--text-inactive)] mr-10rpx">{{ $t('earnNew.available') }}</text>
          <text>{{ toFormat(productInfo.fullPrice) }} {{ productInfo.coinName }}</text>
        </view>
      </view>
      <view class="px-30rpx py-20rpx mx--30rpx mt-100rpx shadow">
        <wd-button size="large" block :loading="loading" @click="onSubmit">
          {{ $t('common.confirm') }}
        </wd-button>
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { onRouter } from '@/utils'
import { useUserStore } from '@/store'
import { BNumber, toFormat, toFixed, inputLimitToDigit, toFormatPercent } from '@/utils/number'
import {
  fetchFlexiblePositionDetail,
  fetchFixedItemDetail,
  fetchFlexibleRedeem,
} from '@/service/earn'
import { formatDate } from '@/utils/day'

const userStore = useUserStore()
const mode = ref(0) // 0 活期 1 定期
const productId = ref('')
const productInfo = ref<any>({})
const showPopup = ref(false)
const amount = ref('')
const loading = ref(false)

onLoad((options) => {
  mode.value = +options.t
  productId.value = options.id
  getInfo()
})

async function onSubmit() {
  if (+amount.value < productInfo.value.minPrice) {
    uni.showToast({
      title: `${t('earnNew.min')} ${productInfo.value.minPrice}`,
      icon: 'none',
    })
    return
  }
  loading.value = true
  try {
    const form = {
      buyCou: amount.value,
      wealthGoodsId: productId.value,
    }
    if (mode.value === 0) {
      await fetchFlexibleRedeem(form)
    }
    onRouter('/pages/earn/result', 'redirectTo')
  } catch (error) {
    loading.value = false
  }
}

const onInput = (e) => {
  const value = inputLimitToDigit(e.detail.value) || ''
  nextTick(() => {
    amount.value = value
  })
}

function getInfo() {
  if (mode.value === 0) {
    return fetchFlexiblePositionDetail(productId.value).then((res) => {
      productInfo.value = res.data
    })
  } else {
    productInfo.value = userStore.earnHistoryItemData
    // return fetchFixedItemDetail(productId.value).then((res) => {
    //   productInfo.value = res.data
    // })
  }
}
</script>

<style lang="scss" scoped>
.shadow {
  box-shadow: 0 -5rpx 22rpx 0 #c6c6c640;
}
</style>
