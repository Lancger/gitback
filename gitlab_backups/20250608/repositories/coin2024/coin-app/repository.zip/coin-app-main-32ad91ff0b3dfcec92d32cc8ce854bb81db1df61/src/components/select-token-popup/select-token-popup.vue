<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    :z-index="99"
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="pt-35rpx px-30rpx">
      <view class="search-box">
        <wd-icon name="search" size="26rpx"></wd-icon>
        <input
          v-model="keyword"
          class="search-box__input"
          type="text"
          :placeholder="$t('common.search')"
        />
      </view>
      <app-empty custom-class="h-60vh" :no-data="data.length === 0">
        <scroll-view class="max-h-60vh min-h-60vh" scroll-y>
          <view class="product-list">
            <template v-for="(item, index) in data" :key="index">
              <view v-if="item.symbolName" class="product-list-item" @click="onSelect(item)">
                <image class="product-list-item__logo" :src="item.avatar" mode="scaleToFill" />
                <view class="product-list-item__name">
                  {{ select ? item.symbolName : item.symbol_name.split('/')[0] }}
                  <text
                    v-if="!select"
                    class="font-400 font-size-22rpx color-[var(--text-inactive)]"
                  >
                    / {{ item.symbol_name.split('/')[1] }}
                  </text>
                </view>
                <wd-checkbox
                  v-if="select"
                  :model-value="selectValue === item[selectKey]"
                ></wd-checkbox>
                <view v-else class="product-list-item__price">
                  <view>{{ toFormat(item.close, item.base_coin_scale) }}</view>
                  <view
                    :class="[item.zdf >= 0 ? 'up-color' : 'down-color']"
                    class="mt-10rpx font-size-22rpx font-400"
                  >
                    {{ item.zdf >= 0 ? '+' : '' }}{{ toFormatPercent(item.zdf) }}
                  </view>
                </view>
              </view>
            </template>
          </view>
        </scroll-view>
      </app-empty>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import Fuse from 'fuse.js'
import { toFormat, toFixed, toFormatPercent } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  list: {
    type: Array<any>,
    default: () => [],
  },
  selectKey: {
    type: String,
    default: 'value',
  },
  selectValue: {
    type: [String, Number],
    default: '',
  },
  select: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['update:modelValue', 'onSelect'])

const fuseOptions = {
  includeScore: true,
  threshold: 0.0,
  keys: ['symbolName'],
}
const keyword = ref('')
const searchList = ref([])

watch(
  () => props.modelValue,
  (newValue) => {
    keyword.value = ''
    searchList.value = []
  },
)

watch(keyword, (newValue) => {
  const fuse = new Fuse(props.list, fuseOptions)

  searchList.value = fuse.search(newValue)
})

const data = computed(() => {
  return keyword.value ? searchList.value.map((item) => item.item) : props.list
})

const onSelect = (e) => {
  emits('onSelect', e)
  onClose()
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.search-box {
  display: flex;
  align-items: center;
  height: 70rpx;
  padding: 0 20rpx;
  background: var(--background-tertiary);
  border-radius: 100rpx;
  &__input {
    flex: 1;
    height: 100%;
    padding: 0 20rpx;
    font-size: 26rpx;
    line-height: 70rpx;
  }
}
.product-list {
  padding: 20rpx 0;
  :deep(.wd-checkbox__label) {
    display: none;
  }
  &-item {
    display: flex;
    align-items: center;
    padding: 20rpx 0;
    &__logo {
      width: 50rpx;
      height: 50rpx;
      border-radius: 50%;
    }
    &__name {
      flex: 1;
      padding: 0 20rpx;
      font-size: 30rpx;
      font-weight: 500;
    }
    &__price {
      font-size: 30rpx;
      font-weight: 500;
      text-align: right;
    }
  }
}
</style>
