<template>
  <app-navbar :title="$t('message.notify.title')" left-arrow></app-navbar>
  <app-empty :no-data="list.length === 0">
    <view
      v-for="(item, index) in list"
      :key="index"
      class="px-30rpx py-30rpx b-b"
      @click="onTap(item)"
    >
      <view class="flex items-center justify-between">
        <view class="font-size-28rpx font-500 ellipsis">
          {{ item.type === 'c2c' ? $t('c2c.index.newP2PMessage') : item.title }}
        </view>
      </view>
      <view
        class="mt-20rpx line-height-30rpx font-size-22rpx color-[var(--text-active)] ellipsis-2"
      >
        {{ item.type === 'c2c' ? toContent(item.content) : onHtmlToText(item.content) }}
      </view>
      <view class="flex items-center justify-between mt-20rpx">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ formatDate(item.sendTime || item.createTime) }}
        </view>
        <view
          v-if="(item.type === 'c2c' && item.unread) || (item.type !== 'c2c' && item.isRead !== 1)"
          class="w-10rpx h-10rpx bg-[var(--color-red)] rd-50%"
        ></view>
      </view>
    </view>
    <wd-loadmore :state="loadMoreState" />
  </app-empty>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import usePagination from '@/hooks/usePagination'
import { fetchMessageList, fetchReadMessage } from '@/service/message'
import { onRouter, onHtmlToText } from '@/utils'
import { formatDate } from '@/utils/day'

const notifyList = ref([])

const { data, loadMoreState, onInit } = usePagination({
  api: fetchMessageList,
  params: {
    pageNo: 1,
    pageSize: 12,
  },
  onLoadMoreFn: onReachBottom,
  isInit: false,
})

const list = computed(() => {
  return notifyList.value.concat(data.value).sort((a, b) => {
    return (
      new Date(b.sendTime || b.createTime).getTime() -
      new Date(a.sendTime || a.createTime).getTime()
    )
  })
})

onShow(() => {
  notifyList.value = uni.getStorageSync('notifyList') || []
  onInit()
})

const onTap = (item) => {
  if (item.type === 'c2c') {
    const array = uni.getStorageSync('notifyList') || []
    item.unread = false
    uni.setStorageSync(
      'notifyList',
      array.map((v) => {
        if (v.id === item.id) {
          return item
        }
        return v
      }),
    )
    onRouter(`/pages/home/ctwoc/paid/index?id=${item.id}`)
    return
  }

  uni.setStorageSync('notifyDetail', item)
  fetchReadMessage([item.id])
  onRouter(`/pages/message/detail`)
}

const toText = (HTML) => {
  const input = HTML
  return input
    .replace(/<(style|script|iframe)[^>]*?>[\s\S]+?<\/\1\s*>/gi, '')
    .replace(/<[^>]+?>/g, '')
    .replace(/\s+/g, ' ')
    .replace(/ /g, ' ')
    .replace(/&ldquo;/g, ' ')
    .replace(/&rdquo;/g, ' ')
    .replace(/&nbsp;/gi, '')
    .replace(/>/g, ' ')
}

const toContent = (content) => {
  return /.(png|jpg|jpeg|gif|webp|svg|ico|bmp)$/.test(content)
    ? `[${t('message.notify.photo')}]`
    : content
}
</script>

<style lang="scss" scoped></style>
