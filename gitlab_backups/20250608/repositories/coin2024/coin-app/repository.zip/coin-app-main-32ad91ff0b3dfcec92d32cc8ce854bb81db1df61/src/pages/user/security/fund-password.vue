<template>
  <app-navbar :title="$t('safe.payPasswordPage.set.title')" left-arrow></app-navbar>
  <view class="p-30rpx">
    <wd-form custom-class="auth-form mt-30rpx" ref="form" :model="model">
      <view>
        <view class="name">{{ $t('safe.payPasswordPage.set.fundPassword') }}</view>
        <wd-input
          prop="tradePwd"
          no-border
          clearable
          v-model="model.tradePwd"
          showPassword
          :placeholder="$t('safe.payPasswordPage.set.input.fundPassword')"
          :rules="[
            {
              required: false,
              validator: validatorTradePwd,
              message: $t('safe.payPasswordPage.set.rules.fundPassword'),
            },
          ]"
        ></wd-input>
      </view>
      <view>
        <view class="name">{{ $t('safe.payPasswordPage.confirmPassword') }}</view>
        <wd-input
          prop="tradePwd1"
          no-border
          clearable
          v-model="model.tradePwd1"
          showPassword
          :placeholder="$t('safe.payPasswordPage.input.confirmPassword')"
          :rules="[
            {
              required: false,
              validator: validatorTradePwd1,
              message: $t('safe.payPasswordPage.rules.confirmPassword'),
            },
          ]"
        ></wd-input>
      </view>
      <view>
        <view class="name">{{ $t('safe.payPasswordPage.loginPassword') }}</view>
        <wd-input
          prop="loginPwd"
          no-border
          clearable
          v-model="model.loginPwd"
          showPassword
          :placeholder="$t('safe.payPasswordPage.input.loginPassword')"
          :rules="[
            {
              required: false,
              validator: validatorLoginPwd,
              message: $t('safe.payPasswordPage.rules.loginPassword'),
            },
          ]"
        ></wd-input>
      </view>
    </wd-form>
    <wd-button size="large" block @click="confirm">{{ $t('common.confirm') }}</wd-button>
  </view>
  <wd-popup
    v-model="show"
    position="bottom"
    custom-style="height:70vh;paddingTop: 30rpx;"
    @close="show = false"
    closable
  >
    <verification
      :title="$t('safe.payPasswordPage.set.twoFactorTitle')"
      :hint="$t('safe.payPasswordPage.set.twoFactorDesc')"
      type="fund-password"
      @hidePopup="hidePopup"
    ></verification>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchTradePwd } from '@/service/user'
import verification from './components/verification.vue'
const model = reactive({
  tradePwd: '',
  tradePwd1: '',
  loginPwd: '',
  totpCode: '',
  phoneCode: '',
  emailCode: '',
})
const form = ref()
const show = ref(false)
const validatorTradePwd = (val) => {
  return /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,18}$/.test(val)
}
const validatorTradePwd1 = (val) => {
  if (val !== model.tradePwd) {
    return Promise.reject(new Error(t('safe.payPasswordPage.rules.confirmPasswordError')))
  } else {
    return Promise.resolve()
  }
}
const validatorLoginPwd = (val) => {
  return /^[a-zA-Z0-9`~!@#$%^&*()_\-+=<>.?:"{}]{6,20}$/.test(val)
}

const confirm = () => {
  form.value.validate().then(({ valid, errors }) => {
    if (valid) {
      show.value = true
    }
  })
}

const hidePopup = (code, trading, phone) => {
  if (trading === 0) {
    model.totpCode = code
    delete model.phoneCode
    delete model.emailCode
  } else if (phone) {
    model.phoneCode = code
    delete model.totpCode
    delete model.emailCode
  } else {
    model.emailCode = code
    delete model.totpCode
    delete model.phoneCode
  }

  uni.showLoading()
  fetchTradePwd(model)
    .then((res) => {
      uni.navigateBack()
    })
    .finally(() => {
      uni.hideLoading()
    })
}
</script>

<style lang="scss" scoped>
:deep(.wd-password-input) {
  margin: 60rpx 0 0 !important;
}
:deep(.wd-password-input__item) {
  background: var(--background-tertiary) !important;
  border: 1px solid var(--border-color);
  border-radius: 10rpx !important;
}
.name {
  margin-bottom: 30rpx;
  font-size: 24rpx;
  color: var(--text-primary);
}
</style>
