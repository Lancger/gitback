// 校验手机号
export function validPhone(val) {
  const reg = /^\d{3,15}$/
  return reg.test(val)
}

// 校验密码
export function validPassword(val) {
  const reg = /^[a-zA-Z0-9!@#$%^&*()_+\-=[\]{};':",.<>?]{6,20}$/
  return reg.test(val)
}

// 校验邮箱
export function validEmail(val) {
  const reg = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return reg.test(val)
}
