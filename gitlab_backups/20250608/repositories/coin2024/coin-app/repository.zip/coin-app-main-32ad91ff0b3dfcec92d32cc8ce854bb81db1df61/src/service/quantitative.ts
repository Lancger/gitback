import { http } from '@/utils/http'

// 获取产品列表
export const fetchProductList = (data) => {
  return http.post('/api/mjkj-web/coin/aiTrade/getProjectByPage', data)
}

// 下单
export const fetchPlaceOrder = (data) => {
  return http.post('/api/mjkj-web/coin/aiTrade/buy', data)
}

// 历史订单
export const fetchHistoryOrder = (data) => {
  return http.post('/api/mjkj-web/coin/aiTrade/getProjectRecordByPage', data)
}

// 历史记录详情
export const fetchHistoryOrderDetail = (data) => {
  return http.post('/api/mjkj-web/coin/aiTrade/getRecordDetailsByPage', data)
}

// 结算
export const fetchSettle = (data) => {
  return http.post('/api/mjkj-web/coin/aiTrade/earlySettlementProject', data)
}
