<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    :z-index="99"
    custom-style="border-radius: 30rpx 30rpx 0 0"
    @close="onClose"
  >
    <view class="relative pt-40rpx px-30rpx">
      <view class="font-size-30rpx font-500">Close</view>
      <view class="font-size-30rpx font-500 mt-44rpx">XRP 2.05 FSFGR</view>
      <view class="flex flex-col gap-y-30rpx mt-30rpx">
        <view class="flex items-center justify-between">
          <view class="color-[var(--text-inactive)]">Opening price(USDT)</view>
          <view class="font-500">0.0/4.9</view>
        </view>
        <view class="flex items-center justify-between">
          <view class="color-[var(--text-inactive)]">Mark price(USDT)</view>
          <view class="font-500">0.0/4.9</view>
        </view>
        <view class="flex items-center justify-between">
          <view class="color-[var(--text-inactive)]">Buy 1/Sell 1 price</view>
          <view class="font-500">0.0/4.9</view>
        </view>
        <view class="flex items-center justify-between">
          <view class="color-[var(--text-inactive)]">Volume available for closing</view>
          <view class="font-500">0.0/4.9</view>
        </view>
      </view>
      <!--  -->
      <view class="mt-40rpx flex items-center gap-20rpx">
        <view class="w-446rpx">
          <view class="font-size-22rpx color-[var(--text-inactive)]">Price</view>
          <view
            class="flex items-center gap-20rpx h-90rpx mt-30rpx px-30rpx font-size-28rpx font-500 bg-[var(--background-gary-4)] rd-10rpx"
          >
            <input type="text" class="flex-1 lh-90rpx" />
            <view class="color-[var(--text-inactive)]">USDT</view>
          </view>
        </view>
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">Type</view>
          <view
            class="flex items-center gap-20rpx h-90rpx mt-30rpx px-30rpx font-size-28rpx font-500 bg-[var(--background-gary-4)] rd-10rpx"
          >
            Limit
          </view>
        </view>
      </view>
      <!--  -->
      <view class="mt-40rpx flex items-center gap-20rpx">
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">Volume</view>
          <view
            class="flex items-center gap-20rpx h-90rpx mt-30rpx px-30rpx font-size-28rpx font-500 bg-[var(--background-gary-4)] rd-10rpx"
          >
            <input type="text" class="flex-1 lh-90rpx" />
            <view class="color-[var(--text-inactive)]">USDT</view>
          </view>
        </view>
      </view>
      <!--  -->
      <view class="mt-30rpx flex items-center gap-20rpx">
        <view class="w-25%">
          <view class="h-20rpx bg-[var(--background-gary-4)] rd-5rpx"></view>
          <view class="font-size-22rpx text-center mt-20rpx">25%</view>
        </view>
        <view class="w-25%">
          <view class="h-20rpx bg-[var(--background-gary-4)] rd-5rpx"></view>
          <view class="font-size-22rpx text-center mt-20rpx">50%</view>
        </view>
        <view class="w-25%">
          <view class="h-20rpx bg-[var(--background-gary-4)] rd-5rpx"></view>
          <view class="font-size-22rpx text-center mt-20rpx">75%</view>
        </view>
        <view class="w-25%">
          <view class="h-20rpx bg-[var(--background-gary-4)] rd-5rpx"></view>
          <view class="font-size-22rpx text-center mt-20rpx">100%</view>
        </view>
      </view>
      <!--  -->
      <view class="flex items-center justify-between mt-60rpx font-size-28rpx">
        <view class="color-[var(--text-inactive)]">Expected PnL</view>
        <view class="font-500">-1.300 USDT</view>
      </view>
      <!--  -->
      <view
        class="px-30rpx py-20rpx mx-[-30rpx] mt-30rpx bg-[var(--background-primary)] shadow-[var(--box-shadow)]"
      >
        <wd-button type="primary" size="large" block round :loading="loading" @click="onSubmit">
          {{ $t('common.confirm') }}
        </wd-button>
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'
import { inputLimitToDigit, BNumber, toFixed, toFormat } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  rowData: {
    type: Object,
    default: () => {},
  },
  assets: {
    type: Object,
    default: () => {},
  },
  mode: {
    type: String,
    default: 'placeOrder', // placeOrder / pay
  },
})

const emits = defineEmits(['update:modelValue', 'onCallBack'])

const loading = ref(false)
const amount = ref(undefined)
const isShow = ref(false)

const totalAmount = computed(() => {
  if (props.mode === 'pay') {
    return 0
  }

  return Number(BNumber(props.rowData.issuePriceHighest).times(amount.value))
})

async function onSubmit() {}

function onInput(e) {
  nextTick(() => {
    amount.value = +inputLimitToDigit(e.detail.value, 0) || undefined
  })
}

function onMax() {
  amount.value = props.rowData.balanceCirculation
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
:deep(.wd-popup) {
  overflow-y: visible !important;
}
</style>
