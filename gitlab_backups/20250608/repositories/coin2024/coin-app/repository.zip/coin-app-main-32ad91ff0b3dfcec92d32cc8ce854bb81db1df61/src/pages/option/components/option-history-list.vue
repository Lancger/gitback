<template>
  <view class="trade-order-list">
    <view
      v-for="(item, index) in list"
      :key="index"
      class="trade-order-list__item"
      @click="onRouter(`/pages/option/history/detail?id=${item.id}`)"
    >
      <view class="token-info">
        <!-- <image class="token-info__logo" src="@img/avatar.png" /> -->
        <view class="token-info__name">{{ item.pair_name }}-{{ item.time_name }}</view>
      </view>
      <view class="absolute top-34rpx right-30rpx text-right">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('options.history.settlementAmount') }}
        </view>
        <view class="mt-20rpx font-size-22rpx font-500">{{ item.delivery_amount }}</view>
      </view>
      <view class="flex items-center mt-20rpx">
        <view class="tag-list">
          <view :class="[item.up_down === 1 ? 'buy' : 'sell']" class="tag-list__item">
            {{ item.up_down === 1 ? $t('options.up') : $t('options.down') }}
          </view>
          <view class="tag-list__item">{{ $t('options.title') }}</view>
        </view>
        <view class="order-date">{{ formatDate(item.begin_time) }}</view>
      </view>
      <view class="order-detail">
        <view class="order-detail__item">
          <view class="order-detail__item__title">{{ $t('options.history.orderNumber') }}</view>
          <view class="order-detail__item__content">{{ item.order_no }}</view>
        </view>
        <view class="order-detail__item !text-right">
          <view class="order-detail__item__title">
            {{ $t('options.history.orderAmount') }}
          </view>
          <view class="order-detail__item__content">{{ item.bet_amount }} USDT</view>
        </view>
        <view class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('options.history.deliveryTime') }}
          </view>
          <view class="order-detail__item__content">{{ formatDate(item.end_time) }}</view>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
})
</script>

<style lang="scss" scoped>
.trade-order-list {
  &__item {
    position: relative;
    padding: 30rpx;
    border-bottom: 1px solid var(--border-color-inactive);
    .token-info {
      display: flex;
      align-items: center;
      &__logo {
        width: 40rpx;
        height: 40rpx;
        border-radius: 50%;
      }
      &__name {
        // margin-left: 20rpx;
        font-size: 30rpx;
        font-weight: 500;
      }
    }
    .tag-list {
      display: flex;
      gap: 10rpx;
      align-items: center;
      &__item {
        height: 30rpx;
        padding: 0 14rpx;
        font-size: 20rpx;
        line-height: 30rpx;
        background: var(--background-gary-4);
        border-radius: 5rpx;
      }
      &__item.buy {
        color: var(--color-green);
        background: #07ba831a;
      }
      &__item.sell {
        color: var(--color-red);
        background: #ff4e431a;
      }
    }
    .order-date {
      margin-left: 20rpx;
      font-size: 22rpx;
      color: var(--text-inactive);
    }
    .order-detail {
      display: flex;
      flex-wrap: wrap;
      gap: 20rpx 0;
      margin-top: 30rpx;
      &__item {
        box-sizing: border-box;
        width: 33.33%;
        &:nth-of-type(3n - 1) {
          text-align: center;
        }
        &:nth-of-type(3n) {
          text-align: right;
        }
        &__title {
          font-size: 22rpx;
          color: var(--text-inactive);
        }
        &__content {
          margin-top: 20rpx;
          font-size: 22rpx;
          font-weight: 500;
        }
      }
    }
  }
}
</style>
