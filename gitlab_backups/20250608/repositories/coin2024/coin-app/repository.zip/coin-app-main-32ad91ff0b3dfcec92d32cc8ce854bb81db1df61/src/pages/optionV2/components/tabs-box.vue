<template>
  <view class="flex h-90rpx px-60rpx b-b">
    <view
      :class="modelValue === 0 ? 'tab-active' : null"
      class="flex-1 flex items-center justify-center gap-10rpx font-size-28rpx font-500 color-[var(--text-inactive)] transition-all-300"
      @click="handleChange(0)"
    >
      <view>{{ $t('optionV2.up') }}</view>
      <text class="i-carbon-arrow-up-right"></text>
    </view>
    <view
      :class="modelValue === 1 ? 'tab-active' : null"
      class="flex-1 flex items-center justify-center gap-10rpx font-size-28rpx font-500 color-[var(--text-inactive)] transition-all-300"
      @click="handleChange(1)"
    >
      <view>{{ $t('optionV2.down') }}</view>
      <text class="i-carbon-arrow-down-right"></text>
    </view>
  </view>
</template>

<script lang="ts" setup>
const props = defineProps({
  modelValue: {
    type: Number,
    default: 0,
  },
})

const emit = defineEmits(['update:modelValue'])

const handleChange = (index: number) => {
  emit('update:modelValue', index)
}
</script>

<style lang="scss" scoped>
.tab-active {
  position: relative;
  color: var(--text-primary);
  &::after {
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 36rpx;
    height: 4rpx;
    content: '';
    background-color: var(--color-primary);
    transform: translateX(-50%);
  }
}
</style>
