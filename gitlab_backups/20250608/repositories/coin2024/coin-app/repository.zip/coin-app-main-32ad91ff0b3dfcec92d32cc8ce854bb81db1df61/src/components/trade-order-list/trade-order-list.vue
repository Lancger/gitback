<template>
  <view class="trade-order-list">
    <view v-for="(item, index) in list" :key="index" class="trade-order-list__item">
      <wd-button
        custom-class="order-btn"
        type="info"
        size="small"
        block
        @click="emits('onCancel', item)"
      >
        {{ $t('components.tradeOrderList.cancel') }}
      </wd-button>
      <view class="flex items-center">
        <view class="token-info">
          <!-- <image class="token-info__logo" src="@img/avatar.png" /> -->
          <view class="token-info__name">{{ item.symbol }}</view>
        </view>
        <view v-if="tradeMode === 'spot'" class="tag-list">
          <view class="tag-list__item">{{ $t('components.tradeOrderList.spot') }}</view>
          <view class="tag-list__item">
            {{
              mode === 'limit'
                ? $t('components.tradeOrderList.limit')
                : $t('components.tradeOrderList.tp/sl')
            }}
          </view>
          <view
            :class="{ buy: +item.direction === 1, sell: +item.direction === 2 }"
            class="tag-list__item"
          >
            {{
              +item.direction === 1
                ? $t('components.tradeOrderList.buy')
                : $t('components.tradeOrderList.sell')
            }}
          </view>
        </view>
        <view v-if="tradeMode === 'futures'" class="tag-list">
          <view class="tag-list__item">{{ $t('components.tradeOrderList.futures') }}</view>
          <view class="tag-list__item">
            {{
              mode === 'limit'
                ? $t('components.tradeOrderList.limit')
                : $t('components.tradeOrderList.tp/sl')
            }}
          </view>
          <view
            :class="{
              buy: +item.direction === 1 || +item.direction === 3,
              sell: +item.direction === 2 || +item.direction === 4,
            }"
            class="tag-list__item"
          >
            <template v-if="+item.direction === 1">
              {{ $t('components.tradeOrderList.open') }}({{ $t('components.tradeOrderList.long') }})
            </template>
            <template v-if="+item.direction === 2">
              {{ $t('components.tradeOrderList.open') }}({{
                $t('components.tradeOrderList.short')
              }})
            </template>
            <template v-if="+item.direction === 3">
              {{ $t('components.tradeOrderList.close') }}({{
                $t('components.tradeOrderList.long')
              }})
            </template>
            <template v-if="+item.direction === 4">
              {{ $t('components.tradeOrderList.close') }}({{
                $t('components.tradeOrderList.short')
              }})
            </template>
          </view>
        </view>
      </view>
      <view class="order-date">{{ formatDate(item.date) }}</view>
      <template v-if="tradeMode === 'spot'">
        <view v-if="mode === 'limit'" class="order-detail">
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.price') }} (USDT)
            </view>
            <view class="order-detail__item__content">{{ item.price }}</view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.volume') }} ({{ item.symbol.split('/')[0] }})
            </view>
            <view class="order-detail__item__content">{{ item.qty }}</view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.amount') }} (USDT)
              <!-- ({{ item.direction === '1' ? 'USDT' : item.symbol.split('/')[0] }}) -->
            </view>
            <view class="order-detail__item__content">{{ item.total }}</view>
          </view>
          <!-- <view class="order-detail__item">
            <view class="order-detail__item__title">Turnover ratio</view>
            <view class="order-detail__item__content">{{ item.ratio }}</view>
          </view> -->
        </view>
        <view v-if="mode === 'stopLimit'" class="order-detail">
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.triggerPrice') }} (USDT)
            </view>
            <view class="order-detail__item__content">{{ item.stopPrice }}</view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.limitPrice') }} (USDT)
            </view>
            <view class="order-detail__item__content">{{ item.price }}</view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.volume') }}
            </view>
            <view class="order-detail__item__content">{{ item.qty }}</view>
          </view>
        </view>
      </template>
      <template v-if="tradeMode === 'futures'">
        <view v-if="mode === 'limit'" class="order-detail">
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.volume') }} ({{
                futuresConfig.unit === 'u' ? item.symbol.split('/')[0] : futuresConfig.unitLabel
              }})
            </view>
            <view class="order-detail__item__content">{{ item.qty }}</view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.margin') }} (USDT)
            </view>
            <view class="order-detail__item__content">{{ onEmptyText(item.frozen_balance) }}</view>
          </view>
          <!-- <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.marginRatio') }}
            </view>
            <view class="order-detail__item__content">--%</view>
          </view> -->
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.orderPrice') }}(USDT)
            </view>
            <view class="order-detail__item__content">{{ item.price }}</view>
          </view>
          <!-- <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.markPrice') }} (USDT)
            </view>
            <view class="order-detail__item__content">--</view>
          </view> -->
          <!-- <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.liqPrice') }} (USDT)
            </view>
            <view class="order-detail__item__content">--</view>
          </view> -->
          <!-- <view class="order-detail__item">
            <view class="order-detail__item__title">Turnover ratio</view>
            <view class="order-detail__item__content">{{ item.ratio }}</view>
          </view> -->
        </view>
        <view v-if="mode === 'stopLimit'" class="order-detail">
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.triggerPrice') }} (USDT)
            </view>
            <view class="order-detail__item__content">{{ item.stopPrice }}</view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.limitPrice') }} (USDT)
            </view>
            <view class="order-detail__item__content">{{ item.price }}</view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeOrderList.volume') }} ({{
                futuresConfig.unit === 'u' ? item.symbol.split('/')[0] : futuresConfig.unitLabel
              }})
            </view>
            <view class="order-detail__item__content">{{ item.qty }}</view>
          </view>
        </view>
      </template>
      <!-- <view class="order-btn-list">
        <wd-button custom-class="order-btn-list__item" type="info" block>Edit</wd-button>
        <wd-button
          custom-class="order-btn-list__item"
          type="info"
          block
          @click="emits('onCancel', item)"
        >
          Cancel
        </wd-button>
      </view> -->
    </view>
  </view>
</template>

<script lang="ts" setup>
import { useTradeStore } from '@/store'
import { onEmptyText } from '@/utils'
import { formatDate } from '@/utils/day'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  mode: {
    type: String,
    default: 'limit', // limit / stopLimit
  },
  tradeMode: {
    type: String,
    default: 'spot', // spot / futures
  },
})

const emits = defineEmits(['onCancel'])

const { futuresConfig } = useTradeStore()
</script>

<style lang="scss" scoped>
.trade-order-list {
  &__item {
    position: relative;
    padding: 30rpx;
    border-bottom: 1px solid var(--background-gary-4);
    .order-btn {
      position: absolute;
      top: 30rpx;
      right: 30rpx;
      height: 40rpx !important;
      font-size: 20rpx;
    }
    .token-info {
      display: flex;
      align-items: center;
      &__logo {
        width: 40rpx;
        height: 40rpx;
        margin-right: 20rpx;
        border-radius: 50%;
      }
      &__name {
        font-size: 30rpx;
        font-weight: 500;
      }
    }
    .tag-list {
      position: relative;
      display: flex;
      gap: 10rpx;
      align-items: center;
      padding-left: 10rpx;
      margin-left: 10rpx;
      &::after {
        position: absolute;
        top: 50%;
        left: 0;
        width: 1px;
        height: 24rpx;
        content: '';
        background: var(--border-color);
        transform: translateY(-50%);
      }
      &__item {
        height: 30rpx;
        padding: 0 14rpx;
        font-size: 20rpx;
        line-height: 30rpx;
        background: var(--background-gary-4);
        border-radius: 5rpx;
      }
      &__item.buy {
        color: var(--color-green);
        background: #07ba831a;
      }
      &__item.sell {
        color: var(--color-red);
        background: #ff4e431a;
      }
    }
    .order-date {
      margin-top: 20rpx;
      font-size: 22rpx;
      color: var(--text-inactive);
    }
    .order-detail {
      display: flex;
      flex-wrap: wrap;
      gap: 20rpx 0;
      margin-top: 30rpx;
      &__item {
        box-sizing: border-box;
        width: 33.33%;
        &:nth-of-type(3n - 1) {
          text-align: center;
        }
        &:nth-of-type(3n) {
          text-align: right;
        }
        &__title {
          font-size: 22rpx;
          color: var(--text-inactive);
        }
        &__content {
          margin-top: 20rpx;
          font-size: 26rpx;
          font-weight: 500;
        }
      }
    }
    .order-btn-list {
      display: flex;
      // flex-wrap: wrap;
      gap: 20rpx;
      align-items: center;
      margin-top: 20rpx;
      &__item {
        flex: 1;
        // width: calc(50% - 20rpx);
        height: 60rpx !important;
        font-size: 26rpx;
        font-weight: 500;
      }
    }
  }
}
</style>
