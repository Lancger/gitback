<template>
  <app-navbar title="Detail"></app-navbar>
  <view class="p-30rpx">
    <view class="flex flex-col items-center justify-center gap-20rpx h-186rpx bg-#000000 rd-10rpx">
      <image class="w-160rpx h-160rpx rd-50%" :src="productData.avatar" mode="heightFix" />
      <!-- <view class="font-size-26rpx font-600 color-#fff">{{ productData.pname }}</view> -->
    </view>
    <!--  -->
    <view class="flex items-center gap-30rpx mt-30rpx">
      <view class="flex-1">
        <view class="font-size-30rpx font-500">{{ productData.pname }}</view>
        <view class="flex items-center gap-10rpx mt-10rpx">
          <view class="font-size-22rpx color-[var(--text-inactive)]">{{ productData.symbol }}</view>
        </view>
      </view>
      <view class="w-60% text-right">
        <view class="font-size-22rpx color-[var(--text-inactive)] mb-15rpx">
          {{ $t('icoV2.schedule') }}
        </view>
        <wd-progress :percentage="productData.progress" color="''" />
      </view>
    </view>
    <!--  -->
    <view class="flex flex-col gap-20rpx mt-30rpx">
      <view class="flex items-center justify-between font-size-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('icoV2.issuePrice') }}</view>
        <view>{{ toFormat(productData.price, true) }} USDT</view>
      </view>
      <view class="flex items-center justify-between font-size-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('icoV2.issueQuantity') }}</view>
        <view>{{ toFormat(productData.circulation, 0) }}</view>
      </view>
      <view class="flex items-center justify-between font-size-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('icoV2.expirationTime') }}</view>
        <view>{{ formatDate(productData.stop_time) }}</view>
      </view>
      <view class="flex items-center justify-between font-size-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('icoV2.announcementTime') }}</view>
        <view>{{ formatDate(productData.win_time) }}</view>
      </view>
      <view class="flex items-center justify-between font-size-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('icoV2.volumeLimit') }}</view>
        <view>
          {{ toFormat(productData.person_quota_min, 0) }} /
          {{ toFormat(productData.person_quota_max, 0) }}
          {{ productData.symbol }}
        </view>
      </view>
      <view class="flex items-center justify-between font-size-22rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('icoV2.subscriptionLimit') }}</view>
        <view>
          {{ toFormat(productData.person_quota_min, 0) }} /
          {{ toFormat(productData.person_quota_max, 0) }}
        </view>
      </view>
    </view>
    <!--  -->
    <view v-if="productData.description" class="mt-50rpx">
      <view class="font-size-30rpx font-500">{{ $t('icoV2.tokenInfo') }}</view>
      <view class="mt-20rpx flex items-end gap-20rpx">
        <div
          v-html="productData.description"
          :class="isShow ? null : 'ellipsis-3'"
          class="font-size-22rpx lh-36rpx color-[var(--text-inactive)]"
        ></div>
        <wd-icon
          :name="isShow ? 'arrow-up' : 'arrow-down'"
          size="30rpx"
          @click="isShow = !isShow"
        ></wd-icon>
      </view>
    </view>
    <!--  -->
    <view class="mt-50rpx">
      <view class="font-size-30rpx font-500">{{ $t('icoV2.participationProcess') }}</view>
      <view class="mt-20rpx font-500 color-[var(--text-active)] lh-36rpx">
        <view>{{ $t('icoV2.participationProcess1') }}</view>
        <view>{{ $t('icoV2.participationProcess2') }}</view>
        <view>{{ $t('icoV2.participationProcess3') }}</view>
        <view>{{ $t('icoV2.participationProcess4') }}</view>
      </view>
    </view>
    <!--  -->
    <view class="mt-50rpx">
      <view class="font-size-30rpx font-500">{{ $t('icoV2.riskWarning') }}</view>
      <view class="mt-20rpx font-500 color-[var(--text-active)]">
        {{ $t('icoV2.riskWarning1') }}
      </view>
      <view class="flex flex-col mt-50rpx">
        <view class="flex gap-10rpx">
          <view
            class="flex items-center w-256rpx min-h-80rpx px-20rpx font-size-24rpx font-500 color-[var(--text-inactive)] bg-[var(--background-secondary)] box-border ellipsis"
          >
            {{ $t('icoV2.issueToken') }}
          </view>
          <view
            class="flex items-center flex-1 h-auto py-28rpx font-size-24rpx font-500 px-30rpx bg-[var(--background-secondary)] box-border"
          >
            {{ productData.symbol }}
          </view>
        </view>
        <view class="flex gap-10rpx">
          <view
            class="flex items-center w-256rpx min-h-80rpx px-20rpx font-size-24rpx font-500 color-[var(--text-inactive)] box-border ellipsis"
          >
            {{ $t('icoV2.subscriptionTime') }}
          </view>
          <view
            class="flex items-center flex-1 h-auto font-size-24rpx font-500 px-30rpx box-border"
          >
            {{ formatDate(productData.start_time) }} - {{ formatDate(productData.stop_time) }}
          </view>
        </view>
        <view class="flex gap-10rpx">
          <view
            class="flex items-center w-256rpx min-h-80rpx px-20rpx font-size-24rpx font-500 color-[var(--text-inactive)] bg-[var(--background-secondary)] box-border ellipsis"
          >
            {{ $t('icoV2.listedTime') }}
          </view>
          <view
            class="flex items-center flex-1 h-auto py-28rpx font-size-24rpx font-500 px-30rpx bg-[var(--background-secondary)] box-border"
          >
            {{ formatDate(productData.ipo_time) }}
          </view>
        </view>
        <view class="flex gap-10rpx">
          <view
            class="flex items-center w-256rpx min-h-80rpx px-20rpx font-size-24rpx font-500 color-[var(--text-inactive)] box-border ellipsis"
          >
            {{ $t('icoV2.currencyOfPayment') }}
          </view>
          <view
            class="flex items-center flex-1 h-auto font-size-24rpx font-500 px-30rpx box-border"
          >
            USDT
          </view>
        </view>
        <view class="flex gap-10rpx">
          <view
            class="flex items-center w-256rpx min-h-80rpx px-20rpx font-size-24rpx font-500 color-[var(--text-inactive)] bg-[var(--background-secondary)] box-border ellipsis"
          >
            {{ $t('icoV2.issuePrice') }}
          </view>
          <view
            class="flex items-center flex-1 h-auto py-28rpx font-size-24rpx font-500 px-30rpx bg-[var(--background-secondary)] box-border"
          >
            {{ toFormat(productData.price, true) }} USDT
          </view>
        </view>
        <view class="flex gap-10rpx">
          <view
            class="flex items-center w-256rpx min-h-80rpx px-20rpx font-size-24rpx font-500 color-[var(--text-inactive)] box-border ellipsis"
          >
            {{ $t('icoV2.issueQuantity') }}
          </view>
          <view
            class="flex items-center flex-1 h-auto font-size-24rpx font-500 px-30rpx box-border"
          >
            {{ toFormat(productData.circulation, 0) }} {{ productData.symbol }}
          </view>
        </view>
        <view class="flex gap-10rpx">
          <view
            class="flex items-center break-words w-256rpx min-h-80rpx px-20rpx font-size-24rpx font-500 color-[var(--text-inactive)] bg-[var(--background-secondary)] box-border"
          >
            {{ $t('icoV2.subscriptionConditions') }}
          </view>
          <view
            class="flex items-center flex-1 h-auto py-28rpx font-size-24rpx font-500 px-30rpx bg-[var(--background-secondary)] box-border"
          >
            <view class="flex flex-col gap-20rpx">
              <view>{{ $t('icoV2.subscriptionConditions1') }}</view>
              <view>{{ $t('icoV2.subscriptionConditions2') }}</view>
            </view>
          </view>
        </view>
      </view>
    </view>
  </view>

  <app-footer background="var(--background-primary)" shadow>
    <view class="flex flex-col gap-20rpx p-30rpx">
      <view class="font-size-22rpx color-[var(--color-red)]">
        {{ $t('icoV2.riskWarning2') }}
      </view>
      <wd-button custom-class="!m-0" size="large" @click="showPopup = true">
        {{ $t('icoV2.subscribe') }}
      </wd-button>
    </view>
  </app-footer>

  <!--  -->
  <ico-popup
    v-model="showPopup"
    :row-data="productData"
    :assets="walletData"
    mode="placeOrder"
    onCallBack="onBack"
  ></ico-popup>
</template>

<script lang="ts" setup>
import icoPopup from './components/ico-popup.vue'
import { formatDate } from '@/utils/day'
import { toFormat, toFixed } from '@/utils/number'
import { fetchGetCurrencyAccount } from '@/service/assets'

const showPopup = ref(false)
const isShow = ref(false)
const walletData = ref({})
const productData = ref(uni.getStorageSync('icoProductData') || {})

onLoad(() => {
  getWallet()
})

const onBack = () => {
  uni.navigateBack()
}

function getWallet() {
  return fetchGetCurrencyAccount({ type: 1 }).then((res) => {
    walletData.value = res.data.find((item) => item.symbol === 'USDT') || {}
  })
}
</script>

<style lang="scss" scoped>
//
</style>
