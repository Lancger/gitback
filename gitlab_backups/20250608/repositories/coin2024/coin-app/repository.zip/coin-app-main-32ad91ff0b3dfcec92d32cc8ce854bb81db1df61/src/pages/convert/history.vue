<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar :title="$t('convert.record')" left-arrow></app-navbar>
  <app-empty :no-data="data.length === 0">
    <view v-for="(item, index) in data" :key="index" class="px-30rpx py-30rpx b-b">
      <view class="flex items-center justify-between font-size-30rpx font-500">
        <view>{{ item.from_symbol }}-{{ item.to_symbol }}</view>
        <view>{{ item.from_amount }}/{{ item.to_amount }}</view>
      </view>
      <view
        class="flex items-center justify-between mt-20rpx font-size-26rpx color-[var(--text-inactive)]"
      >
        <view>
          {{ formatDate(item.create_time) }}
        </view>
        <view>{{ $t('convert.rate') }}: {{ item.rate }}</view>
      </view>
    </view>
    <wd-loadmore :state="loadMoreState" />
  </app-empty>
</template>

<script lang="ts" setup>
import usePagination from '@/hooks/usePagination'
import { fetchConvertRecords } from '@/service/convert'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'

const { data, loadMoreState } = usePagination({
  api: fetchConvertRecords,
  params: {
    pageNo: 1,
    pageSize: 12,
  },
  onLoadMoreFn: onReachBottom,
})

const toText = (HTML) => {
  const input = HTML
  return input
    .replace(/<(style|script|iframe)[^>]*?>[\s\S]+?<\/\1\s*>/gi, '')
    .replace(/<[^>]+?>/g, '')
    .replace(/\s+/g, ' ')
    .replace(/ /g, ' ')
    .replace(/&ldquo;/g, ' ')
    .replace(/&rdquo;/g, ' ')
    .replace(/&nbsp;/gi, '')
    .replace(/>/g, ' ')
}
</script>

<style lang="scss" scoped></style>
