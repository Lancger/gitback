<template>
  <view class="trade-order-list">
    <view v-for="(item, index) in list" :key="index" class="trade-order-list__item">
      <view class="flex items-center">
        <view class="token-info">
          <!-- <image class="token-info__logo" src="@img/avatar.png" /> -->
          <view class="token-info__name">{{ item.symbol_name }}</view>
        </view>
        <view v-if="tradeMode === 'spot'" class="tag-list">
          <view class="tag-list__item">{{ $t('components.tradeHistoryList.spot') }}</view>
          <view v-if="mode === 'order'" class="tag-list__item">
            <template v-if="item.exchange_type === 'xh_xjwt'">
              {{ $t('components.tradeHistoryList.limit') }}
            </template>
            <template v-if="item.exchange_type === 'xh_sjwt'">
              {{ $t('components.tradeHistoryList.market') }}
            </template>
            <template v-if="item.exchange_type === 'xh_zyzs'">
              {{ $t('components.tradeHistoryList.stopLimit') }}
            </template>
          </view>
          <view :class="[+item.direction === 1 ? 'buy' : 'sell']" class="tag-list__item">
            {{
              +item.direction === 1
                ? $t('components.tradeHistoryList.buy')
                : $t('components.tradeHistoryList.sell')
            }}
          </view>
        </view>
        <view v-if="tradeMode === 'futures'" class="tag-list">
          <view class="tag-list__item">{{ $t('components.tradeHistoryList.futures') }}</view>
          <view v-if="mode === 'order'" class="tag-list__item">
            <template v-if="item.exchange_type === 'ubw_jhwt'">
              {{ $t('components.tradeHistoryList.stopLimit') }}
            </template>
            <template v-else>{{ $t('components.tradeHistoryList.limit') }}</template>
          </view>
          <view class="tag-list__item">{{ item.leverage }}X</view>
          <view
            :class="[+item.direction === 1 || +item.direction === 3 ? 'buy' : 'sell']"
            class="tag-list__item"
          >
            <template v-if="+item.direction === 1">
              {{ $t('components.tradeHistoryList.open') }}({{
                $t('components.tradeHistoryList.long')
              }})
            </template>
            <template v-if="+item.direction === 2">
              {{ $t('components.tradeHistoryList.open') }}({{
                $t('components.tradeHistoryList.short')
              }})
            </template>
            <template v-if="+item.direction === 3">
              {{ $t('components.tradeHistoryList.close') }}({{
                $t('components.tradeHistoryList.long')
              }})
            </template>
            <template v-if="+item.direction === 4">
              {{ $t('components.tradeHistoryList.close') }}({{
                $t('components.tradeHistoryList.short')
              }})
            </template>
          </view>
        </view>
        <!-- <view v-if="tradeMode === 'futures' && mode !== 'make'" class="order-date">
          {{ item.create_time }}
        </view> -->
        <!-- <view
          v-if="mode === 'order' || tradeMode === 'spot'"
          class="flex-1 flex items-center justify-end"
        >
          <view class="font-size-22rpx text-right">{{ onStatusText(item) }}</view>
          <wd-icon
            v-if="tradeMode === 'spot'"
            custom-class="ml-10rpx color-[var(--text-inactive)]"
            name="arrow-right"
            size="22rpx"
          ></wd-icon>
        </view> -->
      </view>
      <view class="flex items-center justify-between mt-20rpx">
        <view class="order-date">{{ formatDate(item.create_time) }}</view>
        <view
          v-if="mode === 'order' || tradeMode === 'spot'"
          class="flex-1 flex items-center justify-end"
        >
          <view class="font-size-22rpx text-right">{{ onStatusText(item) }}</view>
        </view>
      </view>
      <view v-if="tradeMode === 'spot'" class="order-detail">
        <template v-if="mode === 'order'">
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.price') }}(USDT)
            </view>
            <view class="order-detail__item__content">
              {{ toFormat(item.entrust_price, true) }}
            </view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.volume') }}({{ item.entrust_symbol }})
            </view>
            <view class="order-detail__item__content">
              {{ toFormat(item.entrust_balance, true) }}
            </view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.amount') }} (USDT)
            </view>
            <view class="order-detail__item__content">
              {{ BNumber(item.success_balance).times(item.success_price).toFixed(2) }}
            </view>
          </view>
        </template>
        <template v-else>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.price') }}(USDT)
            </view>
            <view class="order-detail__item__content">
              {{ toFormat(item.success_price, true) }}
            </view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.volume') }}({{
                +item.direction === 1 ? item.balance_symbol : item.frozen_symbol
              }})
            </view>
            <view class="order-detail__item__content">
              {{
                toFormat(
                  +item.direction === 1
                    ? BNumber(item.balance).plus(item.fee_balance)
                    : item.frozen_balance,
                  true,
                )
              }}
            </view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.amount') }}(USDT)
            </view>
            <view class="order-detail__item__content">
              {{
                toFormat(
                  +item.direction === 2
                    ? BNumber(item.balance).plus(item.fee_balance)
                    : item.frozen_balance,
                  true,
                )
              }}
            </view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.fee') }}({{ item.fee_symbol }})
            </view>
            <view class="order-detail__item__content">
              {{ toFormat(item.fee_balance, true) }}
            </view>
          </view>
        </template>
      </view>
      <view v-if="tradeMode === 'futures'" class="order-detail">
        <template v-if="mode === 'order'">
          <view class="order-detail__item">
            <view class="order-detail__item__title ellipsis">
              {{ $t('components.tradeHistoryList.volume') }} ({{
                futuresConfig.unit === 'u' ? item.entrust_symbol : futuresConfig.unitLabel
              }})
            </view>
            <view class="order-detail__item__content">
              {{ toFormat(item.entrust_balance, true) }}
            </view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.margin') }} (USDT)
            </view>
            <view class="order-detail__item__content">
              {{ onEmptyText(toFormat(item.bzj, true)) }}
            </view>
          </view>
          <!-- <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.marginRatio') }}
            </view>
            <view class="order-detail__item__content">--%</view>
          </view> -->
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.orderPrice') }}(USDT)
            </view>
            <view class="order-detail__item__content">
              {{ toFormat(item.entrust_price, item.base_coin_scale) }}
            </view>
          </view>
          <!-- <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.liqPrice') }} (USDT)
            </view>
            <view class="order-detail__item__content">--</view>
          </view> -->
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.fee') }} (USDT)
            </view>
            <view class="order-detail__item__content">{{ toFormat(item.fee_balance, true) }}</view>
          </view>
        </template>
        <template v-else>
          <view class="order-detail__item">
            <view class="order-detail__item__title ellipsis">
              {{ $t('components.tradeHistoryList.volume') }} ({{
                futuresConfig.unit === 'u' ? item.entrust_symbol : futuresConfig.unitLabel
              }})
            </view>
            <view class="order-detail__item__content">
              {{ toFormat(item.entrust_balance, true) }}
            </view>
          </view>
          <template v-if="+item.direction >= 3">
            <view class="order-detail__item">
              <view class="order-detail__item__title">
                {{ $t('components.tradeHistoryList.pl') }} (USDT)
              </view>
              <view
                :class="[item.profit >= 0 ? 'up-color' : 'down-color']"
                class="order-detail__item__content !font-size-32rpx"
              >
                {{ item.profit > 0 ? '+' : null }}{{ toFormat(item.profit) }}
              </view>
            </view>
            <view class="order-detail__item">
              <view class="order-detail__item__title ellipsis">
                {{ $t('components.tradeHistoryList.pl') }}%
              </view>
              <view
                :class="[item.profit >= 0 ? 'up-color' : 'down-color']"
                class="order-detail__item__content !font-size-32rpx"
              >
                {{ item.profit > 0 ? '+' : null }}{{ item.plRatio }}
              </view>
            </view>
          </template>
          <view v-else class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.margin') }} (USDT)
            </view>
            <view class="order-detail__item__content">
              {{ onEmptyText(toFormat(item.bzj, true)) }}
            </view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.entryPrice') }} (USDT)
            </view>
            <view class="order-detail__item__content">
              {{ toFormat(item.open_price, +item.base_coin_scale) }}
            </view>
          </view>
          <view v-if="+item.direction >= 3" class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.exitPrice') }} (USDT)
            </view>
            <view class="order-detail__item__content">
              {{ toFormat(item.success_price, +item.base_coin_scale) }}
            </view>
          </view>
          <view class="order-detail__item">
            <view class="order-detail__item__title">
              {{ $t('components.tradeHistoryList.fee') }} (USDT)
            </view>
            <view class="order-detail__item__content">{{ toFormat(item.fee_balance, true) }}</view>
          </view>
        </template>
      </view>
      <view
        v-if="tradeMode === 'futures' && mode === 'make' && +item.direction >= 3 && showShare"
        class="flex justify-end mt-20rpx"
      >
        <wd-button
          custom-class="m-0"
          size="small"
          icon="share"
          block
          @click="emits('onShare', item)"
        >
          {{ $t('common.share') }}
        </wd-button>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { useTradeStore } from '@/store'
import { onEmptyText } from '@/utils'
import { formatDate } from '@/utils/day'
import { BNumber, toFixed, toFormat } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  mode: {
    type: String,
    default: 'order', // order-委托 / make-成交
  },
  tradeMode: {
    type: String,
    default: 'spot', // spot-现货 / futures-合约
  },
  showShare: {
    type: Boolean,
    default: true,
  },
})

const emits = defineEmits(['onShare'])

const { futuresConfig } = useTradeStore()

function onStatusText(e) {
  if (props.tradeMode === 'spot') {
    return t('components.tradeHistoryList.filled')
  } else {
    switch (e.entrust_status) {
      case -1:
        return t('components.tradeHistoryList.cancel')
      case 0:
        return t('components.tradeHistoryList.commission')
      case 1:
        return t('components.tradeHistoryList.filled')
      default:
        return t('components.tradeHistoryList.filled')
    }
  }
}
</script>

<style lang="scss" scoped>
.trade-order-list {
  &__item {
    position: relative;
    padding: 30rpx;
    margin: 30rpx;
    background: var(--background-primary);
    border-radius: 20rpx;
    .token-info {
      display: flex;
      align-items: center;
      &__logo {
        width: 40rpx;
        height: 40rpx;
        margin-right: 20rpx;
        border-radius: 50%;
      }
      &__name {
        font-size: 30rpx;
        font-weight: 500;
      }
    }
    .tag-list {
      display: flex;
      gap: 10rpx;
      align-items: center;
      margin-left: 10rpx;
      &__item {
        height: 30rpx;
        padding: 0 14rpx;
        font-size: 20rpx;
        line-height: 30rpx;
        background: var(--background-gary-4);
        border-radius: 5rpx;
      }
      &__item.buy {
        color: var(--color-green);
        background: #07ba831a;
      }
      &__item.sell {
        color: var(--color-red);
        background: #ff4e431a;
      }
    }
    .order-date {
      font-size: 22rpx;
      color: var(--text-inactive);
    }
    .order-detail {
      display: flex;
      flex-wrap: wrap;
      gap: 20rpx 0;
      margin-top: 20rpx;
      &__item {
        box-sizing: border-box;
        width: 33.33%;
        &:nth-of-type(3n - 1) {
          text-align: center;
        }
        &:nth-of-type(3n) {
          text-align: right;
        }
        &__title {
          font-size: 22rpx;
          color: var(--text-inactive);
        }
        &__content {
          margin-top: 20rpx;
          font-size: 26rpx;
          font-weight: 500;
        }
      }
    }
  }
}
</style>
