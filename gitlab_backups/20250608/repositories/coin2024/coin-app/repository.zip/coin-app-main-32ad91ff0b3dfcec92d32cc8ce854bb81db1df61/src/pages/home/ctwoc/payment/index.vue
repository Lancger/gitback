<template>
  <app-navbar custom-class="bg-transparent" :title="$t('c2c.payment.title')"></app-navbar>

  <view class="sum">{{ data.sum }} {{ data.valueCoin.name }}</view>
  <view class="pay">
    {{ data.index === 2 ? $t('c2c.payment.youPay') : $t('c2c.payment.youReceive') }}
    {{ data.value }}
    {{ data.valueCree.local_currency }}
  </view>

  <view class="ctwoc">
    <view class="ctwoc_title">{{ $t('c2c.payment.c2c') }}</view>

    <view class="ctwoc_text" v-if="data.index === 2">{{ $t('c2c.payment.tips') }}</view>

    <view class="ctwoc_bank flex-jc">
      <view>
        <view class="ctwoc_bank_name">{{ $t('c2c.payment.bankTransfer') }}</view>
        <view class="ctwoc_bank_text">
          {{ $t('c2c.payment.unitPrice') }}
          {{ data.rate || BNumber(data.value).div(data.sum) + data.valueCree.local_currency }}
        </view>
      </view>
      <view>
        <!-- <image class="w-30rpx h-30rpx mr2 ml1" src="@/static/images/assets/weixuanzhong.png" /> -->
        <image class="w-30rpx h-30rpx mr2 ml1" src="@/static/images/assets/xuanzhong.png" />
      </view>
    </view>
  </view>

  <!-- <view class="support">Support payment</view> -->

  <view></view>

  <view class="btn">
    <!-- <view class="btn_subscribe">Next</view> -->
    <view class="btn_subscribewhine" @click="navigator">{{ $t('c2c.payment.next') }}</view>
  </view>
</template>

<script lang="ts" setup>
import { fetchOneclick } from '@/service/ctwoc'
import { BNumber } from '@/utils/number'

const oneList = ref()
const data = ref()
const flag = ref('')
onLoad((e) => {
  flag.value = e.type
  data.value = uni.getStorageSync('buyAndSell')
  getDataList()
})

const getDataList = () => {
  return fetchOneclick().then((res) => {
    oneList.value = res.data[0].method
  })
}

function navigator(url: string) {
  uni.setStorageSync('payment', data.value)
  uni.redirectTo({
    url: `/pages/home/ctwoc/buy-preview/index${flag.value ? '?type=express' : ''}`,
  })
}
</script>

<style lang="scss" scoped>
.btn {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 130rpx;
  box-shadow: 0px -5px 21.7px 0px #c6c6c640;
  &_subscribe {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--text-inactive) !important;
    text-align: center;
    background-color: var(--border-color-inactive);
    border-radius: 100rpx;
  }

  &_subscribewhine {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--wot-color-white) !important;
    text-align: center;
    background-color: #00a7ed;
    border-radius: 100rpx;
  }
}
.support {
  font-family: Asap;
  font-size: 36rpx;
  font-weight: 700;
  text-align: center;
}
.sum {
  margin: 120rpx 0 40rpx 0;
  font-family: Asap;
  font-size: 50rpx;
  font-weight: 500;
  color: var(--text-primary);
  text-align: center;
}
.pay {
  font-family: Asap;
  font-size: 24rpx;
  font-weight: 500;
  color: var(--text-primary);
  text-align: center;
}

.flex-jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.ctwoc {
  box-sizing: border-box;
  width: 690rpx;
  padding: 30rpx;
  margin: 60rpx auto;
  border: 2rpx solid #e3e3e3;
  border-radius: 10rpx;
  &_title {
    font-family: Asap;
    font-size: 28rpx;
    font-weight: 500;
    color: var(--text-primary);
  }
  &_text {
    margin-top: 15rpx;
    font-family: Asap;
    font-size: 22rpx;
    color: var(--text-inactive);
  }
  &_bank {
    box-sizing: border-box;
    width: 630rpx;
    padding: 30rpx;
    margin: 40rpx auto;
    background-color: var(--background-gary-4);
    border-radius: 10rpx;
    &_name {
      padding-left: 20rpx;
      font-family: Asap;
      font-size: 28rpx;
      font-weight: 500;
      color: var(--text-primary);
      border-left: 8rpx solid #00a7ed;
    }
    &_text {
      padding-left: 28rpx;
      margin-top: 10rpx;
    }
  }
}
</style>
