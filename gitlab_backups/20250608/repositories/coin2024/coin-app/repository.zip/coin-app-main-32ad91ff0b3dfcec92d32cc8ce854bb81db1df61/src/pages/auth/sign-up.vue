<template>
  <app-navbar custom-class="!bg-transparent"></app-navbar>
  <view class="p-30rpx pb-200rpx">
    <view class="font-size-40rpx font-700">{{ $t('auth.signUp') }}</view>
    <view class="font-size-28rpx mt-20rpx color-[var(--text-active)]">
      {{ $t('auth.signUpPage.desc') }}
    </view>
    <tab-box v-if="isTab" v-model="tabsIndex" :list="tabs" />
    <wd-form
      :custom-class="`auth-form ${isTab ? 'mt-30rpx' : 'mt-100rpx'}`"
      ref="form"
      :model="model"
      :rules="modelRules"
    >
      <wd-input
        v-model.trim="model.account"
        prop="account"
        no-border
        clearable
        :use-prefix-slot="isPhone"
        :placeholder="accountPlaceholder"
      >
        <template #prefix>
          <area-select-picker @on-confirm="onSelectPickerConfirm">
            <view class="center font-size-26rpx font-500">
              <view class="mr-10rpx">+{{ model.areaCode }}</view>
              <wd-icon name="arrow-down" size="26rpx"></wd-icon>
            </view>
          </area-select-picker>
        </template>
      </wd-input>
      <wd-input
        v-if="!isTwoFactor"
        v-model.trim="model.smsCode"
        prop="smsCode"
        type="number"
        no-border
        clearable
        use-suffix-slot
        :maxlength="6"
        :placeholder="$t('auth.smsCode')"
      >
        <template #suffix>
          <sms-button
            :api="smsApi"
            :api-params="smsApiParams"
            :check-pass="onCheckSMS"
          ></sms-button>
        </template>
      </wd-input>
      <wd-input
        v-model.trim="model.password"
        prop="password"
        no-border
        show-password
        clearable
        :placeholder="$t('auth.password')"
      />
      <wd-input
        v-model.trim="model.confirmPassword"
        prop="confirmPassword"
        no-border
        show-password
        clearable
        :placeholder="$t('auth.confirmPassword')"
      />
      <wd-input
        v-model.trim="model.InvitationCode"
        :disabled="isDisableInvitationCode"
        prop="InvitationCode"
        no-border
        clearable
        :placeholder="$t('auth.invitationCode')"
      />
    </wd-form>
  </view>
  <app-footer>
    <view class="p-30rpx">
      <wd-button type="primary" size="large" :loading="loading" block @click="handleSubmit">
        {{ $t('auth.signUp') }}
      </wd-button>
      <view class="tip" @click="closeOutside">
        <wd-popover
          :model-value="showPopover"
          disabled
          :content="$t('auth.rules.agreement')"
          placement="top"
        >
          <wd-checkbox
            v-model="tip"
            size="large"
            custom-class="!flex !flex-items-center"
            custom-label-class="label-class"
          >
            {{ $t('auth.agreementText') }}
            <text class="tip__link" @click.stop="onRouter(`/pages/news/details?code=A2`)">
              {{ $t('auth.userAgreement') }}
            </text>
            {{ $t('auth.and') }}
            <text class="tip__link" @click.stop="onRouter(`/pages/news/details?code=A3`)">
              {{ $t('auth.privacyPolicy') }}
            </text>
          </wd-checkbox>
        </wd-popover>
      </view>
    </view>
  </app-footer>
</template>

<script lang="ts" setup>
import { useQueue } from 'wot-design-uni'
import TabBox from './components/tab-box.vue'
import { t } from '@/locale'
import { useUserStore } from '@/store'
import { onRouter } from '@/utils'
import { validEmail, validPassword, validPhone } from '@/utils/validate'
import { fetchCheckInviteCode } from '@/service/auth'
import { fetchSendEmail, fetchSendSMS } from '@/service/base'
import useAuth from './hook/useAuth'

const { tabs, tabsIndex, isTab, isTwoFactor } = useAuth()
const { closeOutside } = useQueue()
const userStore = useUserStore()

const model = reactive({
  tenantId: '000000',
  scope: 'all',
  type: 'account',
  grant_type: 'member',
  loginType: 'register',
  deviceId: '123abc456def789ghi',
  account: '',
  email: '',
  emailCode: '',
  phone: '',
  phoneCode: '',
  areaCode: import.meta.env.VITE_AREACODE,
  password: '',
  confirmPassword: '',
  InvitationCode: '',
  smsCode: '',
})
const modelRules: any = {
  account: [
    { required: true, message: t('auth.account') },
    {
      required: false,
      validator: (value) => {
        if (isPhone.value && !validPhone(value)) {
          return Promise.reject(t('auth.rules.phone'))
        }
        if (!isPhone.value && !validEmail(value)) {
          return Promise.reject(t('auth.rules.email'))
        }
        return Promise.resolve()
      },
    },
  ],
  password: [
    { required: true, message: t('auth.password') },
    {
      required: false,
      validator: (value) => {
        if (!validPassword(value)) {
          return Promise.reject(t('auth.rules.password'))
        }
        return Promise.resolve()
      },
    },
  ],
  confirmPassword: [
    { required: true, message: t('auth.confirmPassword') },
    {
      required: false,
      validator: (value) => {
        if (value !== model.password) {
          return Promise.reject(t('auth.rules.confirmPassword'))
        }
        return Promise.resolve()
      },
    },
  ],
  InvitationCode: [{ required: true, message: t('auth.invitationCode') }],
}
if (!isTwoFactor.value) {
  modelRules.smsCode = [{ required: true, message: t('auth.smsCode') }]
}
const form = ref(null)
const tip = ref(false)
const showPopover = ref(false)
const loading = ref(false)
const isDisableInvitationCode = ref(false)

const isPhone = computed(() =>
  isTab.value ? tabsIndex.value === 0 : /^\d{3,}$/.test(model.account),
)
const accountPlaceholder = computed(() => {
  return isTab.value ? (isPhone.value ? t('auth.phone') : t('auth.email')) : t('auth.account')
})
const smsApi = computed(() => {
  return isPhone.value ? fetchSendSMS : fetchSendEmail
})

const smsApiParams = computed(() => {
  if (model.email) {
    return {
      email: model.email,
      type: 1,
    }
  }

  return {
    phone: model.phone,
    areaCode: model.areaCode,
    type: 1,
  }
})

onLoad((e) => {
  model.InvitationCode = e.code || null
  isDisableInvitationCode.value = !!e.code
})

watchEffect(() => {
  if (isPhone.value) {
    model.phone = model.account
    model.email = ''
  } else {
    model.email = model.account
    model.phone = ''
  }
})

watch(tip, (newVal) => {
  showPopover.value = !newVal
})

const onCheckSMS = () => {
  if (isPhone.value && !validPhone(model.phone)) {
    uni.showToast({
      title: t('auth.rules.phone'),
      icon: 'none',
    })
    return false
  }
  if (!isPhone.value && !validEmail(model.email)) {
    uni.showToast({
      title: t('auth.rules.email'),
      icon: 'none',
    })
    return false
  }
  return true
}

const onSelectPickerConfirm = (e) => {
  model.areaCode = e.code
}

function handleSubmit() {
  form.value
    .validate()
    .then(async ({ valid, errors }) => {
      if (valid) {
        if (!tip.value) {
          showPopover.value = true
          return
        }
        const form = { ...model }
        if (form.smsCode) {
          form.phoneCode = form.phone ? form.smsCode : ''
          form.emailCode = form.email ? form.smsCode : ''
        }
        delete form.account
        delete form.confirmPassword
        delete form.smsCode
        userStore.authForm = form
        loading.value = true
        try {
          if (isTwoFactor.value) {
            if (form.InvitationCode) {
              await fetchCheckInviteCode(form.InvitationCode)
            }
            onRouter('/pages/auth/two-factor?t=auth')
            loading.value = false
          } else {
            userStore
              .onAuth(userStore.authForm)
              .then((res) => {
                uni.showToast({
                  title: t('common.success'),
                })
                uni.reLaunch({
                  url: '/pages/home/index',
                })
              })
              .finally(() => {
                loading.value = false
              })
          }
        } catch (error) {
          loading.value = false
        }
      }
    })
    .catch((error) => {
      console.log(error, 'error')
    })
}
</script>

<style lang="scss" scoped>
:deep(.app-footer-bar__main) {
  position: absolute;
}
.tip {
  display: flex;
  justify-content: center;
  margin-top: 30rpx;
  &__link {
    color: var(--text-primary);
    text-decoration: underline;
    // color: #e05f5f;
  }
  :deep(.label-class) {
    font-size: 20rpx !important;
    color: var(--text-secondary) !important;
  }
  :deep(.wd-checkbox__shape) {
    flex-shrink: 0 !important;
  }
  :deep(.wd-checkbox__txt) {
    word-break: break-all !important;
  }
}

.page {
  background: var(--background-primary) var(--auth-bg) no-repeat;
  background-size: 100% 744rpx;
}
</style>
