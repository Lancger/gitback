<template>
  <app-navbar custom-class="bg-transparent" :title="$t('assets.withdraw.title')">
    <template #right>
      <wd-icon name="view-module" size="22px" @click="navigator()"></wd-icon>
    </template>
  </app-navbar>

  <view class="titleSelect">{{ $t('assets.withdraw.select') }}</view>
  <view class="cell flex-jc" @click="show = true">
    <view class="flex">
      <image class="w-60rpx h-60rpx" v-if="coinboj.avatar" :src="coinboj.avatar" mode="aspectFit" />
      <view>
        <text class="title">{{ coinboj.symbol }}</text>
        <!-- <text class="c9">/{{ coinboj.full_name }}</text> -->
      </view>
    </view>
    <view>
      <wd-icon name="arrow-right" size="22px"></wd-icon>
    </view>
  </view>

  <view class="titleSelect">{{ $t('assets.withdraw.selectChain') }}</view>
  <view class="flex flex-wrap gap-20rpx pl-30rpx">
    <view
      :class="[index == v.chain_type ? 'select select_bg' : 'select']"
      v-for="v in coinboj.networkList"
      :key="v.chain_type"
      @click="chainTypeClick(v)"
    >
      {{ v.chain_type }}
    </view>
  </view>

  <view class="titleSelect">{{ $t('assets.withdraw.walletAddress') }}</view>

  <view class="cell flex-jc">
    <!-- <view class="flex" @click="navigator('/pages/asset/withdraw/addressbook')">
      Type or paste the withdrawal address
    </view> -->
    <wd-input
      class="flex-1"
      type="text"
      no-border
      v-model.trim="address"
      :placeholder="$t('assets.withdraw.walletAddressPlaceholder')"
    />
  </view>

  <template v-if="hasMemo">
    <view class="titleSelect">Tag</view>

    <view class="cell flex-jc">
      <!-- <view class="flex" @click="navigator('/pages/asset/withdraw/addressbook')">
      Type or paste the withdrawal address
    </view> -->
      <wd-input
        class="flex-1"
        type="text"
        no-border
        v-model.trim="tag"
        :placeholder="$t('assets.withdraw.memoPlaceholder')"
      />
    </view>
    <view class="p-30rpx">
      <wd-notice-bar :text="$t('assets.withdraw.memoTips')" prefix="warn-bold" />
    </view>
  </template>

  <view class="titleSelect">{{ $t('assets.withdraw.qty') }}</view>

  <view class="cell flex-jc">
    <view class="flex">
      <wd-input
        type="digit"
        no-border
        v-model="sum"
        :placeholder="$t('assets.withdraw.min') + '  ' + withdrawMin"
        @input="onInput"
      />
    </view>
    <view>
      <view class="flex flex-jc w10">
        <view>{{ coinboj.symbol }}</view>
        <view style="color: #00a7ed" @click="onInput({ value: coinboj.balance })">
          {{ $t('assets.withdraw.max') }}
        </view>
      </view>
    </view>
  </view>

  <view class="hint">
    <view class="hint_text">
      {{ $t('assets.withdraw.totalBalance') }} {{ coinboj.balance }} {{ coinboj.symbol }}
    </view>
  </view>

  <view class="mb-300rpx px-30rpx">
    <view>
      <view class="font-size-28rpx font-500 line-height-40rpx">
        <text class="down-color">*</text>
        {{ t('assets.withdraw.p1.title', { min: withdrawMin, symbol: coinboj.symbol }) }}
      </view>
      <view class="color-[var(--text-inactive)]">
        {{ $t('assets.withdraw.p1.desc') }}
      </view>
    </view>
    <view class="mt-20rpx">
      <view class="font-size-28rpx font-500 line-height-40rpx">
        <text class="down-color">*</text>
        {{ t('assets.withdraw.p2.title', { symbol: coinboj.symbol }) }}
      </view>
    </view>
    <view class="mt-20rpx">
      <view class="color-[var(--text-inactive)] line-height-40rpx">
        <text class="down-color">*</text>
        {{ $t('assets.withdraw.p3.desc') }}
      </view>
    </view>
  </view>

  <view class="Confirm">
    <view class="maxsum flex-jc">
      <view class="maxsum_max">{{ $t('assets.withdraw.chainFee') }}</view>
      <view class="sum">{{ fee }} {{ coinboj.symbol }}</view>
    </view>

    <view class="maxsum flex-jc">
      <view class="maxsum_max">{{ $t('assets.withdraw.amountReceived') }}</view>
      <view class="sum">{{ +sum ? +toFixed(sum - fee, dec) : 0 }} {{ coinboj.symbol }}</view>
    </view>

    <wd-button :disabled="disabled" block size="large" @click="onNext">
      {{ $t('common.confirm') }}
    </wd-button>
  </view>
  <wd-popup
    v-model="show"
    position="bottom"
    custom-style="border-radius: 20rpx 20rpx 0 0; overflow: auto;"
  >
    <view class="titleSelect">{{ $t('common.select') }}</view>
    <scroll-view class="max-h-50vh" scroll-y>
      <view class="popup flex-jc" v-for="(v, i) in columns" :key="i" @click="coinClick(v)">
        <view class="flex">
          <image class="w-50rpx h-50rpx" v-if="v.avatar" :src="v.avatar" mode="aspectFit" />
          <view class="popup_name">{{ v.symbol }}</view>
        </view>
        <view>
          <image
            class="w-32rpx h-32rpx"
            src="@/static/images/assets/xuanzhong.png"
            mode="aspectFit"
            v-if="coinboj.symbol === v.symbol"
          />
          <image
            v-else
            class="w-32rpx h-32rpx"
            src="@/static/images/assets/weixuanzhong.png"
            mode="aspectFit"
          />
        </view>
      </view>
    </scroll-view>
  </wd-popup>

  <!-- 身份验证 -->
  <identity-verification
    v-model="showIDVerification"
    :model="IDVerificationModel"
    @onCallback="confirm"
  />
</template>

<script lang="ts" setup>
import _ from 'lodash'
import { useMessage } from 'wot-design-uni'
import { fetchWithdrawal, fetchGetRechargeCurrency } from '@/service/assets'
import cryptoJS from '@/utils/crypto'
import { t } from '@/locale'
import { useUserStore } from '@/store'
import { onRouter } from '@/utils'
import { inputLimitToDigit, toFixed } from '@/utils/number'

const { VITE_WITHDRAWAUTH, VITE_FORCEAUTHBIND } = import.meta.env
const message = useMessage()
const userStore = useUserStore()
const columns = ref([])
const show = ref(false)
const sum = ref<any>('')
const index = ref<string>('')
const address = ref<string>('')
const withdrawFee = ref<number>(0)
const withdrawFeeRate = ref(0)
const withdrawMin = ref<any>(0)
const showIDVerification = ref(false)
const IDVerificationModel = ref('pay')
const tag = ref<string>('')
const dec = ref(6)
const coinboj = ref<any>({
  avatar: '',
  symbol: '',
  balance: '',
  full_name: '',
  networkList: [],
})
const IDVerificationModelMap = {
  google: {
    messageBox: {
      msg: t('tips.google.messageBox.msg'),
      title: t('tips.google.messageBox.title'),
      confirmButtonText: t('tips.google.messageBox.confirmButtonText'),
    },
    url: '/pages/user/security/google-authenticator',
    check: () => {
      return userInfo.value.google_key === 1
    },
  },
  pay: {
    messageBox: {
      msg: t('tips.payPassword.messageBox.msg'),
      title: t('tips.payPassword.messageBox.title'),
      confirmButtonText: t('tips.payPassword.messageBox.confirmButtonText'),
    },
    url: '/pages/user/security/fund-password',
    check: () => {
      return userInfo.value.pay_pwd === 1
    },
  },
}

const userInfo = computed(() => userStore.userInfo)

const fee = computed(() => {
  return withdrawFeeRate.value > 0
    ? +toFixed(sum.value * withdrawFeeRate.value, dec.value)
    : withdrawFee.value
})

const hasMemo = ref(false)

onLoad(() => {
  rechargeCurrency()
})

const onInput = ({ value }) => {
  value = inputLimitToDigit(value, dec.value)

  nextTick(() => {
    sum.value = value
  })
}

const disabled = computed(() => {
  if (!address.value || !sum.value) {
    return true
  }
  if (parseFloat(sum.value) < parseFloat(withdrawMin.value)) {
    return true
  } else {
    return false
  }
})

const onNext = () => {
  const obj = IDVerificationModelMap[IDVerificationModel.value]
  if (VITE_WITHDRAWAUTH === 'true') {
    // 绑定完

    // 绑定完
    if (obj.check()) {
      showIDVerification.value = true
      return
    }

    // 是否需要强制绑定
    if (VITE_FORCEAUTHBIND === 'true') {
      message
        .confirm({
          ...obj.messageBox,
        })
        .then((res) => {
          onRouter(obj.url, 'redirectTo')
        })
      return
    }
  }

  confirm()
}

const confirm = _.debounce(() => {
  uni.showLoading()
  const data = {
    address: address.value,
    amount: sum.value,
    coinSymbol: coinboj.value.symbol,
    chainType: index.value,
    remark: '',
    memo: tag.value,
  }
  const form = cryptoJS.encrypt(JSON.stringify(data))
  return fetchWithdrawal(form)
    .then((res) => {
      if (res.code !== 200) {
        uni.showToast({
          icon: 'none',
          title: res.msg,
        })
      } else {
        navigator()
      }
    })
    .finally(() => {
      uni.hideLoading()
    })
}, 300)

const chainTypeClick = (v) => {
  index.value = v.chain_type
  withdrawFee.value = v.withdraw_fee
  withdrawMin.value = v.withdraw_min
  withdrawFeeRate.value = +v.withdraw_fee_rate
  dec.value = v.original_decimals || 6
  hasMemo.value = v.hasMemo || false
}

const coinClick = (v) => {
  coinboj.value = v
  const networkItem = v.networkList[0]
  index.value = networkItem.chain_type
  withdrawFee.value = networkItem.withdraw_fee
  withdrawMin.value = networkItem.withdraw_min
  withdrawFeeRate.value = +networkItem.withdraw_fee_rate
  dec.value = networkItem.original_decimals || 6
  hasMemo.value = networkItem.hasMemo || false
  sum.value = ''
  address.value = ''
  show.value = false
}
const rechargeCurrency = () => {
  return fetchGetRechargeCurrency({ type: 2 }).then((res) => {
    columns.value = res.data
    coinboj.value = res.data[0] || {}
    const networkItem = coinboj.value.networkList[0]
    index.value = networkItem.chain_type
    withdrawFee.value = networkItem.withdraw_fee
    withdrawMin.value = networkItem.withdraw_min
    withdrawFeeRate.value = +networkItem.withdraw_fee_rate
    dec.value = networkItem.original_decimals || 6
    hasMemo.value = networkItem.hasMemo || false
  })
}

function navigator() {
  uni.setStorageSync('assetType', '2')
  uni.navigateTo({
    url: '/pages/asset/deposit/history/index',
  })
}
</script>

<style lang="scss" scoped>
.popup {
  padding: 30rpx;

  &_name {
    margin-left: 20rpx;
    font-size: 30rpx;
    font-weight: 500;
    color: var(--text-primary) !important;
  }
}
.Confirm {
  position: absolute;
  bottom: 30rpx;
  left: 50%;
  background-color: var(--background-primary) !important;
  transform: translate(-50%, 0);
}
.maxsum {
  width: 690rpx;
  margin: 20rpx auto 40rpx;
  &_max {
    color: var(--text-inactive) !important;
  }
}
.hint {
  width: 690rpx;
  margin: 20rpx auto 20rpx;
  &_text {
    color: var(--text-inactive) !important;
  }
}
.select {
  min-width: 140rpx;
  height: 60rpx;
  padding: 0 10rpx;
  line-height: 60rpx;
  color: var(--text-primary) !important;
  text-align: center;
  background-color: var(--background-tertiary) !important;
  border-radius: 8rpx;
}
.select_bg {
  color: #00a7ed !important;
  background-color: #dff4fc !important;
}

.img {
  width: 233rpx;
  height: 233rpx;
  margin: 133rpx auto 70rpx;
}

.titleSelect {
  margin: 30rpx 0;
  margin-left: 30rpx;
  font-family: Asap;
  font-size: 24rpx;
  color: var(--text-primary) !important;
}
.cell {
  box-sizing: border-box;
  width: 690rpx;
  padding: 20rpx;
  margin: auto;
  background-color: var(--background-primary);
  border: 1px solid #cccccc;
  border-radius: 10rpx;
  .c9 {
    color: var(--text-inactive) !important;
  }
  .title {
    margin-left: 10px;
    font-family: Asap;
    font-size: 28rpx;
    font-weight: 500;
  }
  .sum {
    margin-top: 10rpx;
    font-size: 26rpx;
    font-weight: 500;
  }
}
.flex {
  align-items: center;
  min-width: 100px;
}
.flex-jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
</style>
