<template>
  <view class="flex flex-col justify-center items-center pt-448rpx">
    <image class="w-160rpx h-160rpx" src="@img/result/success.png" />
    <view class="mt-40rpx font-size-36rpx font-500">{{ $t('earnNew.success') }}</view>
  </view>
  <view class="fixed bottom-128rpx left-0 right-0 px-30rpx">
    <wd-button custom-class="!w-100%" size="large" @click="onBack">
      {{ $t('earnNew.ok') }}
    </wd-button>
    <!-- <wd-button
      custom-class="!w-100% mt-30rpx"
      type="info"
      plain
      size="large"
      @click="onRouter('/pages/earn/histroy/index', 'redirectTo')"
    >
      {{ $t('earnNew.viewOrders') }}
    </wd-button> -->
  </view>
</template>

<script lang="ts" setup>
import { onRouter } from '@/utils'

const onBack = () => {
  uni.navigateBack()
}
</script>

<style lang="scss" scoped>
//
</style>
