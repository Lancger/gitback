<template>
  <app-navbar :title="$t('icoV2.title')">
    <template #right>
      <image
        class="w-36rpx h-36rpx"
        :src="onImageToThemeImage('/static/images/icons/records02.png')"
        @click="onRouter('/pages/icoV2/history')"
      />
    </template>
  </app-navbar>
  <wd-tabs
    custom-class="app-tabs--no-flex-1 b-b classify-tab"
    :model-value="listParams.projectType"
    swipeable
    animated
    :map-num="100"
    @change="onTabChange"
  >
    <block v-for="(item, index) in tab" :key="index">
      <wd-tab :title="$t(item.label)" :name="item.value"></wd-tab>
    </block>
  </wd-tabs>
  <wd-tabs
    custom-class="app-tabs--no-flex-1 type-tabs"
    v-model="statusTabIndex"
    swipeable
    animated
    :map-num="100"
    :slidable-num="3"
    @change="onStatusTabChange"
  >
    <block v-for="(item, index) in statusTab" :key="index">
      <wd-tab :title="$t(item.label)"></wd-tab>
    </block>
  </wd-tabs>
  <wd-skeleton
    :loading="loading"
    animation="flashed"
    :row-col="[
      { margin: '30rpx 30rpx 0', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
    ]"
  >
    <app-empty :no-data="list.length === 0">
      <ico-card-list
        :list="list"
        :mode="listMode"
        :is-all="isAll"
        @click="onListClick"
      ></ico-card-list>
      <wd-loadmore :state="loadMoreState" />
    </app-empty>
  </wd-skeleton>

  <!-- 申请 -->
  <ico-apply-popup v-model="showApply"></ico-apply-popup>
  <!-- 弹窗 -->
  <ico-popup
    v-model="showPopup"
    :row-data="rowData"
    :assets="walletData"
    :mode="rowData.isPay ? 'pay' : 'placeOrder'"
    @onCallBack="onPopupCallBack"
  ></ico-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import icoPopup from './components/ico-popup.vue'
import icoCardList from './components/ico-card-list.vue'
import icoApplyPopup from './components/ico-apply-popup.vue'
import { onRouter, onImageToThemeImage } from '@/utils'
import { toFixed } from '@/utils/number'
import {
  fetchIcoProductList,
  fetchIcoSubscribeRecords,
  fetchIcoPlacingRecords,
  fetchIcoCheckPlacingPermission,
} from '@/service/ico'
import { fetchGetCurrencyAccount } from '@/service/assets'

type modeType = 'base' | 'selfPay' // base 基础模式 selfPay 手动认缴模式
const subscriptionMode = 'base' as modeType
const placementMode = 'base' as modeType

const tab = ref([
  {
    label: 'icoV2.all',
    value: 'all',
  },
  {
    label: 'icoV2.subscription',
    value: 'purchase',
  },
  {
    label: 'icoV2.placement',
    value: 'allot',
  },
])
const statusTab = computed(() => {
  if (isAll.value) {
    return [
      {
        label: 'icoV2.upcoming',
        value: 1,
      },
      {
        label: 'icoV2.offering',
        value: 2,
      },
      {
        label: 'icoV2.ended',
        value: 4,
      },
    ]
  }

  return [
    {
      label: 'icoV2.upcoming',
      value: 1,
    },
    {
      label: 'icoV2.offering',
      value: 2,
    },
    {
      label: 'icoV2.pending',
      value: 3,
    },
    {
      label: 'icoV2.winnings',
      value: 4,
    },
  ]
})
const statusTabIndex = ref(0)
const listParams = reactive({
  projectType: 'all',
  stage: 1,
  pageNo: 1,
  pageSize: 20,
})
const showPopup = ref(false)
const rowData = ref<any>({})
const walletData = ref({})
const showApply = ref(false)

const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
} = usePagination({
  api: async (params) => {
    if (statusTabIndex.value > 1 && !isAll.value) {
      const form = {
        state: statusTabIndex.value === 2 ? 'purchased' : 'pending_subscription',
        pay_state: 0,
        pageNo: params.pageNo,
        pageSize: params.pageSize,
      }

      if (listParams.projectType === 'purchase') {
        return fetchIcoSubscribeRecords(form).then((res) => {
          res.data.records = res.data.records.map((item) => {
            return {
              ...item,
              isPay: subscriptionMode === 'selfPay',
            }
          })
          return res
        })
      } else {
        return fetchIcoPlacingRecords(form).then((res) => {
          res.data.records = res.data.records.map((item) => {
            return {
              ...item,
              isPay: placementMode === 'selfPay',
            }
          })
          return res
        })
      }
    } else {
      const isSubscribed = statusTab.value[statusTabIndex.value].value === 2
      const isEnd = statusTab.value[statusTabIndex.value].value === 4
      if (isAll.value) {
        try {
          const purchaseRes = await fetchIcoProductList({
            ...params,
            projectType: 'purchase',
            pageNo: 1,
            pageSize: 999,
          })

          const allotRes = await fetchIcoProductList({
            ...params,
            projectType: 'allot',
            pageNo: 1,
            pageSize: 999,
          })

          let records = [...purchaseRes.data.records, ...allotRes.data.records].map((item) => {
            return {
              ...item,
              isSubscribed,
              isEnd,
              progress: Number(toFixed((item.total * 100) / item.circulation)),
            }
          })

          if (isEnd) {
            records = records.sort(
              (a, b) => new Date(b.stop_time).getTime() - new Date(a.stop_time).getTime(),
            )
          }

          return Promise.resolve({
            ...purchaseRes,
            data: {
              ...purchaseRes.data,
              records,
              total: records.length,
            },
          })
        } catch (error) {
          return Promise.resolve({
            msg: '',
            code: 200,
            data: {
              records: [],
              total: 0,
            },
          })
        }
      }

      return fetchIcoProductList(params).then((res) => {
        res.data.records = res.data.records.map((item) => {
          return {
            ...item,
            isSubscribed,
            isEnd,
            progress: Number(toFixed((item.total * 100) / item.circulation)),
          }
        })

        return res
      })
    }
  },
  params: listParams,
  onLoadMoreFn: onReachBottom,
  isInit: false,
})
const isAll = computed(() => listParams.projectType === 'all')
const listMode = computed(() => {
  if (isAll.value) {
    return 'subscribed'
  }

  if (statusTabIndex.value === 2) {
    return 'pending'
  }

  if (statusTabIndex.value === 3) {
    return 'win'
  }

  return 'subscribed'
})

onShow(() => {
  getList()
})

const onPopupCallBack = () => {
  getWallet()
  getList()
}

const onListClick = async (row) => {
  rowData.value = row
  if (row.isSubscribed) {
    uni.setStorageSync('icoProductData', row)
    onRouter('/pages/icoV2/detail')
  }

  if (row.isPay) {
    showPopup.value = +row.pay_state === 0
  }
}

const onTabChange = (event) => {
  listParams.projectType = event.name
  getList()
}

const onStatusTabChange = (event) => {
  statusTabIndex.value = event.index
  listParams.stage = statusTab.value[event.index].value
  getList()
}

function getWallet() {
  return fetchGetCurrencyAccount({ type: 1 }).then((res) => {
    walletData.value = res.data.find((item) => item.symbol === 'USDT') || {}
  })
}
</script>

<style lang="scss" scoped>
.classify-tab {
  :deep(.wd-tabs__line) {
    bottom: 0 !important;
  }
}

.type-tabs {
  :deep(.wd-tabs__nav) {
    background: var(--background-secondary) !important;
  }
  :deep(.wd-tabs__line) {
    display: none;
  }
}

.page.dark {
  .type-tabs {
    :deep(.wd-tabs__nav-item.is-active) {
      color: var(--color-primary);
    }
  }
}
</style>
