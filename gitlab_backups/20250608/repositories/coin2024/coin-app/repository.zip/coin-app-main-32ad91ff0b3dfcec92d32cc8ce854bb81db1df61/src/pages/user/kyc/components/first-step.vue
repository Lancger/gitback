<template>
  <view class="main">
    <view class="main__hint1">{{ $t('kyc.selectLabel') }}</view>
    <view class="main__hint2">{{ $t('kyc.countryLabel') }}</view>
    <area-select-picker
      selectMode="country"
      @on-confirm="onSelectPickerConfirm"
      v-model="form.country"
    >
      <view class="main__input">
        <view v-if="form.countryName">{{ form.countryName }}</view>
        <view v-else class="main__input__placeholder">{{ $t('kyc.select') }}</view>
        <wd-icon name="caret-down-small" size="22px"></wd-icon>
      </view>
    </area-select-picker>
    <view class="main__hint3">
      {{ $t('kyc.tips') }}
    </view>
    <view class="mt-100rpx">
      <wd-button :disabled="!form.countryName" type="primary" size="large" block @click="next">
        {{ $t('kyc.next') }}
      </wd-button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { fetchGetNationList } from '@/service/user'

const form = ref({
  cardBack: '',
  cardCode: '',
  cardFront: '',
  cardType: '',
  country: '',
  countryName: '',
  name: '',
  surname: '',
  countryData: {},
})

const initialData = () => {
  fetchGetNationList({
    pageSize: '-521',
    column: 'sort',
    order: 'asc',
    is_auth: '1',
  }).then((res: any) => {
    const [defaultSelect] = res.data.records
    form.value.countryData = defaultSelect
    form.value.country = defaultSelect.id
    form.value.countryName = defaultSelect.zh_name
  })
}

const emits = defineEmits(['next'])
const next = () => {
  emits('next', 2, {
    countryName: form.value.countryName,
    country: form.value.country,
    countryData: form.value.countryData,
  })
}

const onSelectPickerConfirm = (e) => {
  form.value.country = e.id
  form.value.countryName = e.zh_name
  form.value.countryData = e
}

initialData()
</script>

<style lang="scss" scoped>
.main {
  padding-top: 60rpx;
  padding-right: 30rpx;
  padding-left: 30rpx;
  &__hint1 {
    font-size: 40rpx;
    font-weight: bold;
    color: var(--text-primary);
  }
  &__hint2 {
    margin-top: 56rpx;
    margin-bottom: 30rpx;
    font-size: 24;
    color: var(--text-primary);
  }
  &__input {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 90rpx;
    padding: 0 30rpx;
    font-size: 30rpx;
    color: var(--text-primary);
    background-color: var(--input-bg-color);
    border: 1px solid var(--input-border-color);
    border-radius: 10rpx;
    &__placeholder {
      color: var(--text-inactive);
    }
    &__img {
      width: 14rpx;
      height: 10rpx;
    }
  }
  &__hint3 {
    margin-top: 30rpx;
    font-size: 24rpx;
    line-height: 40rpx;
    color: var(--text-inactive);
  }
  .position-fixed {
    position: fixed;
    right: 30rpx;
    bottom: 128rpx;
    left: 30rpx;
  }
}
</style>
