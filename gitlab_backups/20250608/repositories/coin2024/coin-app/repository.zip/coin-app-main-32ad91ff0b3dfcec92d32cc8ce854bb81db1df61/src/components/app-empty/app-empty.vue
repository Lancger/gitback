<template>
  <view class="app-empty">
    <slot v-if="!noData"></slot>
    <view v-else :class="[customClass]" class="flex justify-center items-center flex-col">
      <image
        class="w-300rpx h-177rpx"
        :src="onImageToThemeImage('/static/images/empty/default.png')"
      />
      <view class="mt-30rpx color-[var(--text-inactive)]">{{ $t('common.noData') }}</view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { onImageToThemeImage } from '@/utils'

const props = defineProps({
  noData: {
    type: Boolean,
    default: false,
  },
  customClass: {
    type: String,
    default: 'h-70vh',
  },
})
</script>

<style lang="scss" scoped>
//
</style>
