<template>
  <view class="news-list">
    <view
      v-for="(item, index) in list"
      :key="index"
      class="news-list__item"
      @click="onRouter(`/pages/news/details?id=${item.id}`)"
    >
      <view class="news-list__item__content">
        <view class="news-list__item__title ellipsis-2">{{ item.article_title }}</view>
        <view class="news-list__item__date">{{ formatDate(item.article_time) }}</view>
      </view>
      <image class="news-list__item__cover" :src="item.article_img" mode="aspectFill" />
    </view>
  </view>
</template>

<script lang="ts" setup>
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
})
</script>

<style lang="scss" scoped>
.news-list {
  margin: 0 30rpx;
  &__item {
    display: flex;
    align-items: center;
    padding: 30rpx;
    margin-top: 20rpx;
    background: var(--background-primary);
    border-radius: 16rpx;
    &__content {
      flex: 1;
      padding-right: 30rpx;
    }
    &__cover {
      flex-shrink: 0;
      width: 200rpx;
      height: 120rpx;
      border-radius: 12rpx;
    }
    &__title {
      font-size: 32rpx;
      font-weight: 500;
    }
    &__date {
      margin-top: 18rpx;
      color: var(--text-inactive);
    }
  }
}
</style>
