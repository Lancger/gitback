<template>
  <app-navbar
    :title="$t('c2c.appeal.title')"
    left-arrow
    custom-class="!bg-transparent"
  ></app-navbar>
  <view class="hint">
    <view>
      {{ $t('c2c.appeal.p1') }}
    </view>
    <view class="mt-20rpx">
      {{ $t('c2c.appeal.p2') }}
    </view>
  </view>
  <view class="p-30rpx pb-140rpx">
    <wd-form custom-class="auth-form mt-30rpx" ref="form" :model="model">
      <view class="name" v-if="model.type !== '4'">{{ $t('c2c.appeal.reasonForAppeal') }}</view>
      <wd-select-picker
        use-default-slot
        v-model="value"
        type="radio"
        :columns="exchangeRateList"
        @confirm="confirm"
        filterable
        v-if="model.type !== '4'"
      >
        <wd-input
          prop="reason"
          no-border
          clearable
          suffix-icon="arrow-right"
          v-model="model.reason"
          :placeholder="$t('c2c.appeal.reasonForAppeal')"
          :rules="[{ required: true, message: $t('c2c.appeal.reasonForAppeal') }]"
        />
      </wd-select-picker>
      <view class="name">{{ $t('c2c.appeal.description') }}</view>
      <wd-textarea
        class="mb-30rpx"
        prop="description"
        v-model="model.description"
        :placeholder="$t('c2c.appeal.description')"
        :rules="[{ required: true, message: $t('c2c.appeal.description') }]"
      />
      <view class="name">{{ $t('c2c.appeal.addCredentials') }}</view>
      <view class="mb-20rpx">
        <view class="upload__img">
          <view class="upload__relative" v-for="(item, index) in fileList" :key="item">
            <image :src="item"></image>
            <wd-icon
              @click="deleteImg(index)"
              class="upload__absolute"
              name="error-fill"
              size="30rpx"
            ></wd-icon>
          </view>

          <view v-if="fileList.length < 5" class="upload" @click="run()">
            <wd-icon name="camera" size="22px"></wd-icon>
          </view>
        </view>
      </view>
      <view class="name" v-if="model.type !== '4'">{{ $t('c2c.appeal.contact') }}</view>
      <wd-input
        prop="contact"
        no-border
        clearable
        v-model="model.contact"
        :placeholder="$t('c2c.appeal.contact')"
        :rules="[{ required: true, message: $t('c2c.appeal.contact') }]"
        v-if="model.type !== '4'"
      />
      <view class="name" v-if="model.type !== '4'">{{ $t('c2c.appeal.contactNumber') }}</view>
      <wd-input
        prop="phone"
        no-border
        clearable
        v-model="model.phone"
        :placeholder="$t('c2c.appeal.contactNumber')"
        :rules="[{ required: true, message: $t('c2c.appeal.contactNumber') }]"
        v-if="model.type !== '4'"
      />
    </wd-form>
    <view class="appeal">
      <wd-button @click="appeal" class="flex-1" block size="large">
        {{ model.type === '4' ? $t('c2c.appeal.additionalDescription') : $t('c2c.appeal.appeal') }}
      </wd-button>
    </view>
  </view>
</template>
<script lang="ts" setup>
import { t } from '@/locale'
import { fetchGetDictItems, fetchGetServicePayment, fetchAppeal } from '@/service/ctwoc'
import { useUserStore } from '@/store'

const userStore = useUserStore()
const { data, run } = useUpload<string>()
const params = ref<any>({})
const form = ref(null)
const model = reactive({
  userId: userStore.userInfo.merchant
    ? userStore.userInfo.merchant.member_id
    : userStore.userInfo.id,
  orderId: '',
  type: '1',
  reason: '',
  description: '',
  proof: '',
  contact: '',
  phone: '',
})

const fileList = ref<any>([])
const value = ref('')
const exchangeRateList = ref([])
const bSType = ref('')

onLoad((e) => {
  params.value = e
  model.orderId = e.orderId
  model.type = e.type || '1'
  bSType.value = bSType.value === '1' ? 'order_appeal_reason_buy' : 'order_appeal_reason_sell'
  initialize()
})

watch(data, () => {
  fileList.value.push(data.value.link)
})

const initialize = () => {
  fetchGetDictItems(bSType.value).then((res) => {
    exchangeRateList.value = res.data.map((item) => {
      return {
        value: item.value,
        label: item.label,
        ...item,
      }
    })
    value.value = exchangeRateList.value[0].value
    if (model.type !== '4') {
      model.reason = exchangeRateList.value[0].label
    }
  })
  fetchGetServicePayment({
    orderId: params.value.orderId,
  }).then((res) => {
    console.log(res)
  })
}

const confirm = ({ value, selectedItems }) => {
  model.reason = selectedItems.label
}

const deleteImg = (index) => {
  fileList.value.splice(index, 1)
}

const appeal = () => {
  console.log(fileList.value)

  if (fileList.value.length === 0) {
    return uni.showToast({
      icon: 'none',
      title: t('c2c.appeal.upload'),
    })
  }
  model.proof = fileList.value.join(',')
  form.value
    .validate()
    .then(({ valid, errors }) => {
      if (valid) {
        uni.showLoading()
        fetchAppeal(model)
          .then((res) => {
            uni.navigateTo({
              url: `/pages/home/ctwoc/appeal-details/index?orderId=${params.value.orderId}`,
            })
          })
          .finally(() => {
            uni.hideLoading()
          })
      }
    })
    .catch((error) => {
      console.log(error, 'error')
    })
}
</script>
<style lang="scss" scoped>
.hint {
  padding: 30rpx;
  font-size: 22rpx;
  font-weight: 500;
}
:deep(.wd-textarea) {
  border: 1px solid #d3d5db !important;
  border-radius: 20rpx !important;
}
.name {
  margin-top: 40rpx;
  margin-bottom: 30rpx;
  font-size: 24rpx;
}

.upload__img {
  display: flex;
  flex-wrap: wrap;
  gap: 20rpx;
  align-items: center;
  image {
    width: 150rpx;
    height: 150rpx;
  }
}
.upload {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 150rpx;
  height: 150rpx;
  background-color: var(--border-color-inactive);
}

.flex {
  margin-bottom: 20rpx;
}

.appeal {
  position: fixed;
  right: 0;
  bottom: 0;
  left: 0;
  display: flex;
  align-items: center;
  height: 130rpx;
  padding: 0 30rpx;
  background-color: #fff;
  box-shadow: 0px -5px 21.7px 0px #c6c6c640;
}

.upload__relative {
  position: relative;
}

.upload__absolute {
  position: absolute;
  top: -15rpx;
  right: -15rpx;
  z-index: 99;
}
</style>
