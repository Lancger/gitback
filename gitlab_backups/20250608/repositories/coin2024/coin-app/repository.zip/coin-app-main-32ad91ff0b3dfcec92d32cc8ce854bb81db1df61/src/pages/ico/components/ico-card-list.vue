<template>
  <view class="ico-card-list">
    <view v-for="(item, index) in list" :key="index" class="ico-card-list__item">
      <view class="flex items-center justify-between">
        <view class="coin-info">
          <image class="coin-info__logo" :src="item.avatar" mode="scaleToFill" />
          <view class="coin-info__name">{{ item.symbol }}</view>
          <!-- <view class="coin-info__desc">{{ item.symbol }}</view> -->
        </view>
        <view v-if="isSub" class="w-60% text-right">
          <view class="font-size-22rpx color-[var(--text-inactive)] mb-16rpx">
            {{ $t('ico.schedule') }}
          </view>
          <wd-progress :percentage="item.progress" color="''" />
        </view>
      </view>
      <view class="detail-list">
        <view class="detail-list__item">
          <view class="detail-list__item__label">{{ $t('ico.offeringPrice') }}</view>
          <view class="detail-list__item__value">{{ toFormat(item.price, true) }} USDT</view>
        </view>
        <view class="detail-list__item">
          <view class="detail-list__item__label">{{ $t('ico.issueQuantity') }}</view>
          <view class="detail-list__item__value">{{ toFormat(item.circulation, 0) }}</view>
        </view>
        <view class="detail-list__item">
          <view class="detail-list__item__label">{{ $t('ico.startTime') }}</view>
          <view class="detail-list__item__value">{{ formatDate(item.start_time) }}</view>
        </view>
        <view class="detail-list__item">
          <view class="detail-list__item__label">{{ $t('ico.closingTime') }}</view>
          <view class="detail-list__item__value">{{ formatDate(item.stop_time) }}</view>
        </view>
      </view>
      <wd-button
        v-if="isSub"
        custom-class="mt-30rpx !w-100%"
        size="large"
        @click="emits('click', item)"
      >
        {{ $t('ico.subscribe') }}
      </wd-button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { formatDate } from '@/utils/day'
import { toFormat } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  isSub: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['click'])
</script>

<style lang="scss" scoped>
.ico-card-list {
  padding: 40rpx;
  &__item {
    padding: 30rpx 40rpx;
    margin-bottom: 40rpx;
    // width: 670rpx;
    background: linear-gradient(180deg, #fafdff 0%, #d8efff 100%);
    border-radius: 20rpx;
    :deep(.wd-button) {
      box-shadow: 0 4rpx 20rpx 0 #59cdfd !important;
    }
    .coin-info {
      display: flex;
      align-items: center;
      &__logo {
        width: 46rpx;
        height: 46rpx;
        margin-right: 20rpx;
        border-radius: 50%;
      }
      &__name {
        font-size: 30rpx;
        font-weight: 500;
      }
      &__desc {
        font-size: 22rpx;
        color: var(--text-inactive);
      }
    }
    .detail-list {
      padding: 30rpx 40rpx;
      margin-top: 40rpx;
      background: #fff;
      border-radius: 16rpx;
      &__item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        font-size: 22rpx;
        + .detail-list__item {
          margin-top: 30rpx;
        }
        &__label {
          color: var(--text-inactive);
        }
      }
    }
  }
}
.page.dark {
  .ico-card-list__item {
    background: linear-gradient(359.07deg, #2d2d2d 63.38%, #27444f 102.27%);
    .detail-list {
      background: #3c444a;
    }
  }
}
</style>
