<template>
  <wd-popup
    :model-value="show"
    position="bottom"
    :z-index="99"
    closable
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="p-30rpx b-b">
      <view class="font-size-30rpx font-500">{{ $t('options.confirmOrder.title') }}</view>
      <view class="font-size-22rpx font-500 mt-20rpx">
        <text :class="[data.isUp ? 'up-color' : 'down-color']">
          {{ $t('options.confirmOrder.buy') }}
        </text>
        {{ data.productName }}
        <text :class="[data.isUp ? 'up-color' : 'down-color']">
          {{ data.isUp ? $t('options.up') : $t('options.down') }}
        </text>
        {{ $t('options.confirmOrder.option') }}
      </view>
    </view>
    <view class="p-30rpx">
      <view class="flex justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('options.confirmOrder.orderAmount') }}
        </view>
        <view class="font-500">{{ data.amount }} USDT</view>
      </view>
      <view class="flex justify-between mt-30rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('options.confirmOrder.yieldRate') }}</view>
        <view class="font-500">{{ data.rate }}</view>
      </view>
    </view>
    <view class="mt-15rpx px-30rpx">
      <text class="color-[var(--text-inactive)]">{{ $t('options.available') }}</text>
      {{ balance }} USDT
    </view>
    <view class="px-30rpx py-20rpx mt-30rpx shadow-[var(--box-shadow)]">
      <wd-button size="large" :loading="loading" block @click="emits('onConfirm')">
        {{ $t('common.confirm') }}
      </wd-button>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { inputLimitToDigit } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Number,
    default: 1,
  },
  show: {
    type: Boolean,
    default: false,
  },
  balance: {
    type: [String, Number],
    default: '',
  },
  data: {
    type: Object,
    default: () => {},
  },
  loading: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['update:modelValue', 'update:show', 'onConfirm'])

const onClose = () => {
  emits('update:show', false)
}
</script>

<style lang="scss" scoped></style>
