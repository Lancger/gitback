<template>
  <app-navbar>
    <template #title>
      <view class="h-100% flex items-center">
        <wd-segmented :options="list" v-model:value="current">
          <template #label="{ option }">
            <view>{{ option.label }}</view>
          </template>
        </wd-segmented>
      </view>
    </template>
  </app-navbar>
  <!--  -->
  <component :is="pagePath === 'home' ? copyHome : copyUser"></component>
  <!-- tabbar -->
  <wd-tabbar
    v-model="pagePath"
    fixed
    :bordered="false"
    placeholder
    safeAreaInsetBottom
    :zIndex="90"
  >
    <wd-tabbar-item
      v-for="item in tabbarList"
      :key="item.pagePath"
      :title="item.text"
      :name="item.pagePath"
    >
      <template #icon="{ active }">
        <wd-img
          height="42rpx"
          width="42rpx"
          :src="active ? item.selectedIconPath : item.iconPath"
        ></wd-img>
      </template>
    </wd-tabbar-item>
  </wd-tabbar>
</template>

<script lang="ts" setup>
import copyHome from './components/copy-home.vue'
import copyUser from './components/copy-user.vue'
import { t } from '@/locale'

const list = ref([
  { label: t('copy.spot'), value: 'spot' },
  { label: t('copy.futures'), value: 'futures' },
])
const current = ref('spot')

const tabbarList = ref<any[]>([
  {
    text: t('copy.aiFollow'),
    iconPath: '/static/images/copy/tabbar01.png',
    selectedIconPath: '/static/images/copy/tabbar01_act.png',
    pagePath: 'home',
  },
  {
    text: t('copy.portfolio'),
    iconPath: '/static/images/copy/tabbar02.png',
    selectedIconPath: '/static/images/copy/tabbar02_act.png',
    pagePath: 'user',
  },
])
const pagePath = ref('home')

provide('pagePath', pagePath)
provide('mode', current)

watch(pagePath, () => {
  uni.pageScrollTo({
    scrollTop: 0,
    duration: 300,
  })
})

onLoad((options) => {
  current.value = options.mode || 'spot'
})
</script>

<style lang="scss" scoped>
:deep(.wd-tabbar) {
  background: var(--wot-tabbar-bg) !important;
  box-shadow: var(--wot-tabbar-shadow, '') !important;
}
:deep(.wd-tabbar-item__body) {
  .wd-tabbar-item__body-title {
    margin-top: 5px !important;
    font-weight: 500;
  }
  .is-active {
    font-weight: 600;
  }
}
</style>
