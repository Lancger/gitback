<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    :z-index="99"
    closable
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="pt-40rpx px-30rpx">
      <view class="font-size-30rpx font-500 text-center">
        {{ mode === 'pay' ? $t('icoV2.payment') : $t('icoV2.detail') }}
      </view>
      <!--  -->
      <view class="flex items-center gap-20rpx mt-40rpx">
        <image class="w-46rpx h-46rpx rd-50%" :src="rowData.avatar" mode="scaleToFill" />
        <view class="flex-1">
          <view class="font-size-30rpx font-500">{{ rowData.pname }}</view>
          <view class="flex items-center gap-10rpx mt-10rpx">
            <view class="font-size-22rpx color-[var(--text-inactive)]">
              {{ rowData.symbol }}
            </view>
          </view>
        </view>
        <view v-if="mode !== 'pay'" class="w-50% text-right">
          <view class="font-size-22rpx color-[var(--text-inactive)] mb-15rpx">
            {{ $t('icoV2.schedule') }}
          </view>
          <wd-progress :percentage="rowData.progress" color="''" />
        </view>
      </view>
      <!--  -->
      <block v-if="mode !== 'pay'">
        <view class="flex flex-col gap-30rpx mt-30rpx">
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.offeringPrice') }}</view>
            <view>{{ toFormat(rowData.price, true) }} USDT</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.issueQuantity') }}</view>
            <view>{{ toFormat(rowData.circulation, 0) }}</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.startTime') }}</view>
            <view>{{ formatDate(rowData.start_time) }}</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.closingTime') }}</view>
            <view>{{ formatDate(rowData.stop_time) }}</view>
          </view>
        </view>
        <!--  -->
        <view
          class="flex items-center gap-20rpx h-100rpx mt-40rpx px-30rpx border-1 border-solid border-[var(--border-color)] rd-10rpx box-border"
        >
          <view class="flex-1">
            <view class="font-size-22rpx color-[var(--text-inactive)]">
              {{ $t('icoV2.subscribe') }}
            </view>
            <input
              v-model="amount"
              class="font-size-30rpx mt-10rpx"
              type="number"
              :placeholder="`${$t('common.min')} ${rowData.person_quota_min}`"
              @input="onInput"
            />
          </view>
          <view class="flex items-center font-size-30rpx">
            <!-- <view class="pr-20rpx mr-20rpx border-r-1 border-r-solid border-r-#333]">
            {{ $t('ipo.shares') }}
          </view> -->
            <view class="color-[var(--color-primary)]" @click="onMax">
              {{ $t('common.max') }}
            </view>
          </view>
        </view>
      </block>
      <view v-else class="flex flex-col gap-30rpx mt-30rpx">
        <view class="flex items-center justify-between font-size-22rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('icoV2.unitPrice') }}</view>
          <view>{{ rowData.subscribed_price }} USDT</view>
        </view>
        <view class="flex items-center justify-between font-size-22rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('icoV2.subscribeQuantity') }}</view>
          <view>{{ rowData.allotment_quantity }}</view>
        </view>
        <view class="flex items-center justify-between font-size-22rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('icoV2.listingTime') }}</view>
          <view>{{ formatDate(rowData.ipo_time) }}</view>
        </view>
      </view>
      <!--  -->
      <view
        class="flex items-center gap-20rpx h-100rpx mt-30rpx px-30rpx bg-[var(--background-gary-4)] border-1 border-solid border-[var(--border-color)] rd-10rpx box-border"
      >
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ mode !== 'pay' ? $t('icoV2.total') : $t('icoV2.willFreeze') }}
          </view>
          <input class="font-size-30rpx mt-10rpx" disabled :value="toFormat(totalAmount, true)" />
        </view>
        <view class="flex items-center font-size-30rpx">USDT</view>
      </view>
      <!--  -->
      <view v-if="mode !== 'pay'" class="flex items-center gap-20rpx font-size-22rpx mt-30rpx">
        <view>
          <text class="color-[var(--text-inactive)]">{{ $t('icoV2.available') }}</text>
          {{ toFormat(assets.balance, true) }} {{ assets.currency }}
        </view>
        <view class="underline" @click="onRouter('/pages/asset/deposit/index')">
          {{ $t('icoV2.topUp') }}
        </view>
      </view>
      <!--  -->
      <view
        class="px-30rpx py-20rpx mx-[-30rpx] mt-30rpx bg-[var(--background-primary)] shadow-[var(--box-shadow)]"
      >
        <wd-button type="primary" size="large" block round :loading="loading" @click="onSubmit">
          {{ mode === 'pay' ? $t('common.confirm') : $t('common.submit') }}
        </wd-button>
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchIcoSubscribe, fetchIcoSubscribePay } from '@/service/ico'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'
import { inputLimitToDigit, BNumber, toFixed, toFormat } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  rowData: {
    type: Object,
    default: () => {},
  },
  assets: {
    type: Object,
    default: () => {},
  },
  mode: {
    type: String,
    default: 'placeOrder', // placeOrder / pay
  },
})

const emits = defineEmits(['update:modelValue', 'onCallBack'])

const loading = ref(false)
const amount = ref(undefined)

const totalAmount = computed(() => {
  if (props.mode !== 'pay') {
    return toFixed(BNumber(amount.value || 0).times(props.rowData.price || 0))
  }

  return Number(BNumber(props.rowData.subscribed_price).times(props.rowData.allotment_quantity))
})

const funMap = {
  placeOrder: onPlaceOrder,
  pay: onPay,
}

async function onPay() {
  loading.value = true
  try {
    await fetchIcoSubscribePay({
      recordId: props.rowData.id,
    })
    uni.showToast({
      title: t('common.success'),
      icon: 'success',
      duration: 2000,
    })
    emits('onCallBack', props.mode)
    onClose()
    loading.value = false
  } catch (e) {
    loading.value = false
  }
}

async function onPlaceOrder() {
  if (+amount.value < props.rowData.person_quota_min) {
    uni.showToast({
      title: `${t('icoV2.min')} ${props.rowData.person_quota_min}`,
      icon: 'none',
    })
    return
  }
  loading.value = true
  try {
    await fetchIcoSubscribe({
      projectId: props.rowData.id,
      purchaseQuantity: amount.value,
    })
    emits('onCallBack', props.mode)
    onClose()
    loading.value = false
  } catch (e) {
    loading.value = false
  }
}

async function onSubmit() {
  funMap[props.mode]()
}
function onInput(e) {
  nextTick(() => {
    amount.value = inputLimitToDigit(e.detail.value)
  })
}

function onMax() {
  amount.value = props.rowData.person_quota_max
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.ico-popup {
  padding: 0 30rpx;
  &__title {
    height: 90rpx;
    font-size: 30rpx;
    font-weight: 500;
    line-height: 90rpx;
    text-align: center;
  }
  &__top {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  &__btn {
    padding: 30rpx;
    margin: 30rpx -30rpx 0;
    box-shadow: var(--box-shadow);
  }
  .coin-info {
    display: flex;
    align-items: center;
    &__logo {
      width: 46rpx;
      height: 46rpx;
      margin-right: 20rpx;
      border-radius: 50%;
    }
    &__name {
      font-size: 30rpx;
      font-weight: 500;
    }
    &__desc {
      font-size: 22rpx;
      color: var(--text-inactive);
    }
  }
  .progress {
    &__title {
      font-size: 22rpx;
      color: var(--text-inactive);
      text-align: right;
    }
    &__main {
      display: flex;
      align-items: center;
      width: 320rpx;
      margin-top: 10rpx;
      &__line {
        flex: 1;
      }
      &__text {
        font-size: 24rpx;
      }
    }
  }
  .detail-list {
    padding: 30rpx 0;
    &__item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 24rpx;
      + .detail-list__item {
        margin-top: 30rpx;
      }
      &__label {
        color: var(--text-inactive);
      }
    }
  }
  .input-box {
    box-sizing: border-box;
    display: flex;
    align-items: center;
    padding: 20rpx 30rpx;
    margin-bottom: 30rpx;
    border: 1px solid var(--border-color);
    border-radius: 10rpx;
    &--disabled {
      background: var(--background-gary-4);
    }
    &__left {
      flex: 1;
    }
    &__title {
      font-size: 18rpx;
      color: var(--text-inactive);
    }
    &__input {
      margin-top: 10rpx;
      font-size: 30rpx;
    }
    &__unit {
      font-size: 30rpx;
      &__btn {
        position: relative;
        padding-left: 60rpx;
        color: var(--color-primary);
        &::after {
          position: absolute;
          top: 50%;
          left: 30rpx;
          width: 1px;
          height: 30rpx;
          content: '';
          background: #000;
          transform: translateY(-50%);
        }
      }
    }
  }
  .asset {
    font-size: 22rpx;
    &__title {
      color: var(--text-inactive);
    }
    &__btn {
      padding-left: 10rpx;
      text-decoration: underline;
    }
  }
}
</style>
