<route lang="json5" type="page">
{
  layout: 'tabbar',
}
</route>

<template>
  <view class="header">
    <wd-tabs
      v-model="tabKey"
      custom-class="app-tabs app-tabs--no-flex-1 app-tabs--large"
      swipeable
      animated
      :map-num="100"
    >
      <block v-for="(item, index) in tab" :key="index">
        <wd-tab :title="$t(item.label)" :name="item.value"></wd-tab>
      </block>
    </wd-tabs>
    <!-- <wd-icon custom-class="!font-700" name="ellipsis" size="40rpx"></wd-icon> -->
  </view>
  <view class="h-88rpx"></view>
  <KeepAlive>
    <component :is="tabKey == 'spot' ? tradeSpot : convertHome"></component>
  </KeepAlive>
</template>

<script lang="ts" setup>
import convertHome from '../convert/components/convert-home.vue'
import tradeSpot from './components/trade-spot.vue'

const tab = [
  { label: 'trade.tabs.spot', value: 'spot' },
  // { label: 'convert.title', value: 'convert' },
]
const tabKey = ref('spot')
</script>

<style lang="scss" scoped>
.header {
  position: fixed;
  top: 0;
  z-index: 10;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  width: 100%;
  padding: 0 30rpx 0 0;
  background: var(--background-secondary);
}
.page {
  background: var(--background-secondary);
}
.page.blue {
  .header {
    background: var(--color-primary);
    :deep(.wd-tabs__line) {
      display: none;
    }
    // :deep(.wd-tabs__nav-item) {
    //   color: var(--text-primary) !important;
    // }
    :deep(.wd-tabs__nav-item.is-active) {
      color: var(--text-primary) !important;
    }
  }
}
</style>
