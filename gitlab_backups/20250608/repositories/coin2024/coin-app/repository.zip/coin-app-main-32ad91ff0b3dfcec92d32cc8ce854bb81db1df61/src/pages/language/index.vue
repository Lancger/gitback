<template>
  <app-navbar :title="$t('language')">
    <!-- <template #right>
      <view class="font-size-28rpx">Save</view>
    </template> -->
  </app-navbar>
  <view>
    <view
      v-for="(item, index) in list"
      :key="index"
      class="flex items-center justify-between h-100rpx px-30rpx b-b"
      @click="onSwitch(item.value)"
    >
      <view class="font-size-28rpx font-500">{{ item.label }}</view>
      <wd-checkbox :model-value="locale === item.value"></wd-checkbox>
    </view>
  </view>
</template>

<script lang="ts" setup>
import i18n from '@/locale'
import { fetchSetLanguage } from '@/service/user'
import { useUserStore } from '@/store'

const userStore = useUserStore()
const locale = computed(() => i18n.global.locale)

const list = [
  {
    label: 'English', // 英语
    value: 'en',
  },
  {
    label: 'Deutsch', // 德语
    value: 'de',
  },
  {
    label: 'Français', // 法语
    value: 'fr',
  },
  {
    label: '日本語', // 日语
    value: 'ja',
  },
  {
    label: '한국어', // 韩语
    value: 'ko',
  },
  {
    label: 'Español', // 西班牙语
    value: 'es',
  },
  {
    label: 'Português', // 葡萄牙语
    value: 'pt',
  },
  {
    label: 'Türkçe', // 土耳其语
    value: 'tr',
  },
  {
    label: 'ไทย', // 泰语
    value: 'th',
  },
  {
    label: 'العربية', // 阿拉伯语
    value: 'ar',
  },
  {
    label: 'Bahasa Melayu', // 马来语
    value: 'ms',
  },
  {
    label: 'Pусский', // 俄语
    value: 'ru',
  },
  {
    label: '繁体中文',
    value: 'zh-Hant',
  },
]

const onSwitch = (locale) => {
  uni.setLocale(locale)
  i18n.global.locale = locale
  if (userStore.isLogined) {
    fetchSetLanguage(locale === 'zh-Hant' ? 'zh_tw' : locale)
  }
}
</script>

<style lang="scss" scoped>
:deep(.wd-checkbox__label) {
  display: none;
}
</style>
