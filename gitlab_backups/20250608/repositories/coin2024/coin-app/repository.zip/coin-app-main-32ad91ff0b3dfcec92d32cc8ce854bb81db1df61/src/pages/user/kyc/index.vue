<template>
  <view>
    <app-navbar :title="$t('kyc.title')" left-arrow></app-navbar>
    <first-step @next="next" v-show="step === 1"></first-step>
    <second-step
      @next="next"
      @lastStep="lastStep"
      v-show="step === 2"
      :country="form.countryName"
      :countryData="form.countryData"
    ></second-step>
    <third-step @next="next" :form="form" @lastStep="lastStep" v-show="step === 3"></third-step>
  </view>
</template>

<script lang="ts" setup>
import firstStep from './components/first-step.vue'
import secondStep from './components/second-step.vue'
import thirdStep from './components/third-step.vue'
import { useUserStore } from '@/store'

const userStore = useUserStore()
const step = ref(1)
const form = ref({
  cardCode: '',
  cardType: '',
  country: '',
  countryName: '',
  name: '',
  surname: '',
  countryData: {},
})
const status = computed(() => {
  return +userStore.userInfo.real_name_status
})

onLoad((options) => {
  if (!options.edit) {
    if (status.value === 1 || status.value === -1) {
      uni.redirectTo({
        url: '/pages/user/kyc/details/index',
      })
    }
  }
})

const next = (num: any, obj: any) => {
  Object.assign(form.value, obj)
  step.value = num
}

const lastStep = (num: any) => {
  step.value = num
}
</script>

<style lang="scss" scoped></style>
