<template>
  <view :class="`vip-level--${level}`" class="vip-level">{{ name }}</view>
</template>

<script lang="ts" setup>
const props = defineProps({
  level: {
    type: [String, Number],
    default: 1,
  },
  name: {
    type: String,
    default: '',
  },
})
</script>

<style lang="scss" scoped>
.vip-level {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: center;
  width: max-content;
  height: 28rpx;
  padding: 0 10rpx;
  font-size: 22rpx;
  background: linear-gradient(90deg, rgba(228, 228, 228, 0.1) 0%, rgba(172, 172, 172, 0.1) 100%);
  border: 1px solid #9a9a9a;
  border-radius: 5rpx;
  &--1 {
    color: var(--color-primary);
    // background: linear-gradient(90deg, rgba(255, 216, 100, 0.1) 0%, rgba(255, 165, 9, 0.1) 100%);
    border: 1px solid var(--color-primary);
  }
  &--2 {
    color: #00d55c;
    background: linear-gradient(90deg, rgba(139, 255, 100, 0.1) 0%, rgba(0, 213, 92, 0.1) 100%);
    border: 1px solid #00d55c;
  }
  &--3 {
    color: #06c6c0;
    background: linear-gradient(90deg, rgba(100, 234, 255, 0.1) 0%, rgba(96, 217, 213, 0.1) 100%);
    border: 1px solid #06c6c0;
  }
  &--4 {
    color: #164fc9;
    background: linear-gradient(90deg, rgba(100, 173, 255, 0.1) 0%, rgba(22, 79, 201, 0.1) 100%);
    border: 1px solid #164fc9;
  }
  &--5 {
    color: #c560d9;
    background: linear-gradient(90deg, rgba(250, 100, 255, 0.1) 0%, rgba(197, 96, 217, 0.1) 100%);
    border: 1px solid #c560d9;
  }
}
</style>
