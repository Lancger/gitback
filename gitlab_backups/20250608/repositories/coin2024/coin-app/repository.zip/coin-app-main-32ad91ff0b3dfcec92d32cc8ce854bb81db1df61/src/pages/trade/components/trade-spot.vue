<template>
  <!-- wrap -->
  <view class="wrap">
    <view class="flex items-center px-30rpx py-15rpx">
      <view class="flex-1">
        <view class="flex items-center">
          <view class="flex items-center mr-20rpx" @click="showSelectToken = true">
            <view class="font-size-30rpx font-700">{{ symbol }}</view>
            <wd-icon custom-class="!font-700" name="caret-down-small" size="30rpx"></wd-icon>
          </view>
          <view :class="[tokenData.zdf >= 0 ? 'up-color' : 'down-color']" class="font-size-22rpx">
            <text class="mr-20rpx">
              {{ toFormat(tokenData.close, tokenConfigData.base_coin_scale) }}
            </text>
            <text>{{ toFormatPercent(tokenData.zdf) }}</text>
          </view>
        </view>
        <view class="mt-10rpx font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('trade.spot.title') }}
        </view>
      </view>
      <image
        class="w-36rpx h-36rpx"
        :src="onImageToThemeImage('/static/images/icons/k-line.png')"
        @click="onRouter(`/pages/market/detail?symbol=${symbol}&type=xh`)"
      />
    </view>
    <view class="flex p-30rpx px-20rpx">
      <view class="w-40%">
        <order-book
          :order-book-data="orderBookData"
          :token-data="tokenData"
          :tokenConfig="tokenConfigData"
        ></order-book>
      </view>
      <view class="flex-1 p-l-20rpx overflow-hidden">
        <view class="trade-tag">
          <view
            v-for="(item, index) in directionList"
            :key="index"
            :class="{
              'in-active': form.direction === item.value,
              'trade-tag__item-buy': index === 0,
              'trade-tag__item-sell': index === 1,
            }"
            class="trade-tag__item"
            @click="onSwitchDirection(item)"
          >
            <text class="trade-tag__item__text">{{ $t(item.label) }}</text>
          </view>
        </view>
        <view class="trade-type border-box" @click="showMode = true">
          <view class="trade-type__name">{{ modeList[mode].title }}</view>
          <wd-icon
            custom-class="!font-700 color-[var(--text-inactive)]"
            name="caret-down-small"
            size="26rpx"
          ></wd-icon>
        </view>
        <app-input
          v-if="modeKey === 'zyzs'"
          v-model="form.triggerPrice"
          type="digit"
          custom-class="mt-20rpx"
          :placeholder="`${$t('trade.spot.triggerPrice')} (USDT)`"
          :formatter="inputLimitToDigit"
          @update:model-value="onInputEvent('price', $event)"
        >
          <template #right>
            <view class="exchange-rate">
              ≈{{ userStore.onExchangeRateConversion(form.triggerPrice) }}
            </view>
          </template>
        </app-input>
        <view
          v-if="modeKey === 'sjwt'"
          class="mt-20rpx h-72rpx font-size-26rpx font-500 line-height-72rpx text-center color-[var(--text-inactive)] rounded-10rpx bg-[var(--background-gary-4)]"
        >
          {{ $t('trade.spot.marketPrice') }}
        </view>
        <app-input
          v-else
          v-model="form.price"
          type="digit"
          custom-class="mt-20rpx"
          :placeholder="`${$t('trade.spot.price')} (USDT)`"
          :formatter="(value) => inputLimitToDigit(value, tokenConfigData.base_coin_scale)"
          @update:model-value="onInputEvent('price', $event)"
        >
          <template #right>
            <view class="exchange-rate">≈{{ userStore.onExchangeRateConversion(form.price) }}</view>
          </template>
        </app-input>
        <app-input
          v-model="form.amount"
          type="digit"
          custom-class="mt-20rpx"
          :placeholder="`${$t('trade.spot.volume')} (${tokenConfigData.coin_symbol})`"
          :formatter="(value) => inputLimitToDigit(value, tokenDecimal)"
          @update:model-value="onInputEvent('amount', $event)"
        ></app-input>
        <view class="mt-7rpx flex justify-between">
          <text class="color-[var(--text-inactive)]">
            {{ form.direction === 1 ? $t('trade.spot.maxBuy') : $t('trade.spot.maxSell') }}
          </text>
          <text class="color-[var(--text-active)]">
            {{ toFormat(maxNum, true) || 0 }}
            {{ form.direction === 1 ? tokenConfigData.coin_symbol : tokenConfigData.base_symbol }}
          </text>
        </view>
        <view class="mt-20rpx px-20rpx">
          <app-slider v-model="sliderValue" @update:model-value="onSlider"></app-slider>
        </view>
        <app-input
          v-model="tokenPriceTotal"
          type="digit"
          custom-class="mt-20rpx"
          :placeholder="`${$t('trade.spot.amount')} (USDT)`"
          :formatter="(value) => inputLimitToDigit(value, tokenConfigData.base_coin_scale)"
          @update:model-value="onInputEvent('total', $event)"
        ></app-input>
        <view class="mt-14rpx flex justify-between">
          <text class="color-[var(--text-inactive)]">{{ $t('trade.spot.fee') }}</text>
          <text class="color-[var(--text-active)]">
            {{ fee || 0 }}
            {{ form.direction === 1 ? tokenConfigData.coin_symbol : tokenConfigData.base_symbol }}
          </text>
        </view>
        <view class="mt-14rpx flex justify-between">
          <text class="color-[var(--text-inactive)]">{{ $t('trade.spot.available') }}</text>
          <text class="color-[var(--text-active)]">
            <template v-if="form.direction === 1">
              {{ toFormat(walletData.bbBaseBalance) }} {{ tokenConfigData.base_symbol }}
            </template>
            <template v-else>
              {{ toFormat(walletData.bbCoinBalance, true) }} {{ tokenConfigData.coin_symbol }}
            </template>
          </text>
        </view>
        <view v-if="modeKey === 'zyzs'" class="mt-14rpx flex justify-between">
          <text class="color-[var(--text-inactive)]">{{ $t('trade.spot.amount') }}</text>
          <text class="color-[var(--text-active)]">{{ tokenPriceTotal || 0 }} USDT</text>
        </view>
        <wd-button
          v-if="userStore.isLogined"
          custom-class="mt-20rpx"
          :type="form.direction === 1 ? 'success' : 'error'"
          block
          :loading="submitLoading"
          @click="onNext"
        >
          {{ form.direction === 1 ? $t('trade.spot.buy') : $t('trade.spot.sell') }}
          {{ tokenConfigData.coin_symbol }}
        </wd-button>
        <wd-button v-else custom-class="mt-20rpx" block @click="onRouter('/pages/auth/sign-in')">
          {{ $t('common.signIn') }} / {{ $t('common.signUp') }}
        </wd-button>
      </view>
    </view>
  </view>
  <!-- 订单 -->
  <view class="order-wrap">
    <view class="order-wrap__tab">
      <wd-tabs
        custom-class="app-tabs app-tabs--no-flex-1"
        v-model="orderTabIndex"
        swipeable
        animated
        :map-num="100"
        @change="onOrderTabChange"
      >
        <block v-for="(item, index) in orderTab" :key="index">
          <wd-tab custom-class="b-b" :title="$t(item.label)" :name="item.value">
            <view v-if="item.value === 'assets'" class="assets-box">
              <view class="font-size-30rpx font-500">{{ $t('trade.spot.assets.title') }}</view>
              <view class="assets-box__list">
                <view class="assets-box__list__item !block">
                  <view class="flex items-center">
                    <image
                      class="assets-box__list__item__cover"
                      :src="tokenConfigData.coin_avatar"
                      mode="aspectFit"
                    />
                    <view class="assets-box__list__item__title">
                      {{ tokenConfigData.coin_symbol }}
                    </view>
                    <view class="assets-box__list__item__num">
                      {{ toFormat(walletData.bbCoinBalance, true) }}
                    </view>
                  </view>
                  <block v-if="config.spotPnL">
                    <view class="flex justify-between pl-62rpx mt-10rpx font-size-22rpx">
                      <view class="flex-1"></view>
                      <view class="color-[var(--text-inactive)]">
                        {{ toFormat(tokenData.close * walletData.bbCoinBalance) }}
                        {{ tokenConfigData.base_symbol }}
                      </view>
                    </view>
                    <view class="flex justify-between pl-62rpx mt-10rpx font-size-22rpx">
                      <view class="color-[var(--text-inactive)]">
                        {{ $t('trade.totalPnL') }}
                      </view>
                      <view
                        :class="+getCoinPnL(tokenData.close).rate >= 0 ? 'up-color' : 'down-color'"
                      >
                        {{
                          toFormat(getCoinPnL(tokenData.close).pnl, walletData.coin_coin_scale)
                        }}({{
                          toFormatPercent(
                            getCoinPnL(tokenData.close).rate,
                            walletData.coin_coin_scale,
                          )
                        }})
                      </view>
                    </view>
                    <view class="flex justify-between pl-62rpx mt-10rpx font-size-22rpx">
                      <view class="color-[var(--text-inactive)]">
                        {{ $t('trade.averageCost') }}
                      </view>
                      <view>
                        {{ toFormat(walletData.coinAvgPrice, true) }}
                        {{ tokenConfigData.base_symbol }}
                      </view>
                    </view>
                  </block>
                </view>
                <view class="assets-box__list__item">
                  <image
                    class="assets-box__list__item__cover"
                    :src="tokenConfigData.base_avatar"
                    mode="aspectFit"
                  />
                  <view class="assets-box__list__item__title">
                    {{ tokenConfigData.base_symbol }}
                  </view>
                  <view class="assets-box__list__item__num">
                    {{ toFormat(walletData.bbBaseBalance) }}
                  </view>
                </view>
              </view>
              <view class="flex justify-between py-55rpx gap-20rpx">
                <wd-button
                  custom-class="flex-1"
                  type="info"
                  :round="false"
                  @click="onRouter('/pages/home/express/index')"
                >
                  {{ $t('trade.spot.assets.buy') }}
                </wd-button>
                <wd-button
                  custom-class="flex-1"
                  type="info"
                  :round="false"
                  @click="onRouter('/pages/asset/deposit/index')"
                >
                  {{ $t('trade.spot.assets.topUp') }}
                </wd-button>
                <wd-button
                  custom-class="flex-1"
                  type="info"
                  :round="false"
                  @click="onRouter('/pages/asset/transfer/index')"
                >
                  {{ $t('trade.spot.assets.transfer') }}
                </wd-button>
              </view>
            </view>
            <!-- 委托 -->
            <app-empty
              v-if="item.value === 'ptwt'"
              :no-data="limitOrder.length === 0"
              custom-class="h-500rpx"
            >
              <trade-order-list
                :list="limitOrder"
                @onCancel="
                  (e) => {
                    onShowDialog('orderCancel'), (rowData = e)
                  }
                "
              ></trade-order-list>
            </app-empty>
            <app-empty
              v-if="item.value === 'sjwt'"
              :no-data="marketOrder.length === 0"
              custom-class="h-500rpx"
            >
              <trade-order-list trade-mode="spot" :list="marketOrder"></trade-order-list>
            </app-empty>
            <app-empty
              v-if="item.value === 'zyzs'"
              :no-data="stopLimitOrder.length === 0"
              custom-class="h-500rpx"
            >
              <trade-order-list
                trade-mode="spot"
                mode="stopLimit"
                :list="stopLimitOrder"
                @onCancel="
                  (e) => {
                    onShowDialog('stopLimitCancel'), (rowData = e)
                  }
                "
              ></trade-order-list>
            </app-empty>
          </wd-tab>
        </block>
      </wd-tabs>
      <!-- <image
          class="absolute top-28rpx right-30rpx w-32rpx h-32rpx"
          src="@img/icons/records.png"
          @click="onRouter('/pages/trade/history/index?t=spot')"
        /> -->
      <!-- <view
          class="absolute top-27rpx right-30rpx font-size-28rpx font-500"
          @click="onRouter('/pages/trade/history/index?t=spot')"
        >
          {{ $t('trade.spot.history') }}
        </view> -->
    </view>
  </view>

  <!-- 选择币种 -->
  <select-token-popup
    v-model="showSelectToken"
    :list="spotList"
    @onSelect="onSelectToken"
  ></select-token-popup>
  <!-- 选择交易模式 -->
  <trade-mode-popup v-model="mode" v-model:show="showMode" :list="modeList"></trade-mode-popup>
  <!-- 下单确认 -->
  <confirm-order-dialog
    v-model="showConfirmDialog"
    :data="{ ...form, symbol: symbol, mode: modeKey, decimal: tokenConfigData.coin_coin_scale }"
    :loading="submitLoading"
    @onConfirm="onSubmit"
  ></confirm-order-dialog>
  <!-- dialog -->
  <app-dialog
    v-model="showDialog"
    :title="$t(dialogMain.title)"
    :content="$t(dialogMain.content)"
    :loading="dialogLoading"
    @onConfirm="onDialogConfirm"
  ></app-dialog>
</template>

<script lang="ts" setup>
import Schema from 'async-validator'
import confirmOrderDialog from './confirm-order-dialog.vue'
import { t } from '@/locale'
import { useTradeStore, useUserStore } from '@/store'
import { onImageToThemeImage, onRouter } from '@/utils'
import { toFixed, toFormat, inputLimitToDigit, BNumber, toFormatPercent } from '@/utils/number'
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'
import {
  fetchSpotWallet,
  fetchTokenConfig,
  fetchTokenData,
  fetchPlaceOrder,
  fetchOrderList,
  fetchOrderCancel,
  tradeMode,
  tradeOrderMode,
} from '@/service/trade'
import { fetchMarketData, fetchGetSpot } from '@/service/market'
import config from '@/config'

const tradeStore = useTradeStore()
const userStore = useUserStore()
const directionList = [
  {
    label: 'trade.spot.buy',
    value: 1,
  },
  {
    label: 'trade.spot.sell',
    value: 2,
  },
]
const modeList = computed(() => {
  return [
    {
      url: '/static/images/trade/market-order.png',
      title: t('trade.mode.market.title'),
      desc: t('trade.mode.market.desc'),
      value: 'sjwt',
    },
    {
      url: '/static/images/trade/limit-order.png',
      title: t('trade.mode.limit.title'),
      desc: t('trade.mode.limit.desc'),
      value: 'xjwt',
    },
    // {
    //   url: '/static/images/trade/stop-limit-order.png',
    //   title: 'Stop-limit Order',
    //   desc: 'Will trigger a limit order at a fixed stop price',
    //   value: 'zyzs',
    // },
  ]
})
const showSelectToken = ref(false)
const showMode = ref(false)
const mode = ref(0)
const orderBookData = ref({})
const symbol = computed(() => tradeStore.spotSymbol)
const walletData = ref<any>({})
const tokenData = ref<any>({})
const tokenConfigData = ref<any>({})
const formDefault = () => {
  return {
    exchangeCoinStr: '',
    direction: 1,
    triggerPrice: '',
    price: '',
    amount: '',
    money: '',
  }
}
const form = reactive<any>(formDefault())
const tokenPriceTotal = ref<any>('')
const modeKey = computed(() => modeList.value[mode.value].value)
const orderTab = ref([
  {
    label: 'trade.spot.tabs.assets',
    value: 'assets',
  },
  {
    label: 'trade.spot.tabs.orders',
    value: 'ptwt',
  },
  {
    label: 'trade.spot.history',
    value: 'history',
  },
  // {
  //   label: 'TP/SL',
  //   value: 'zyzs',
  // },
])
const orderTabIndex = ref('assets')
const limitOrder = ref([])
const marketOrder = ref([])
const stopLimitOrder = ref([])
const submitLoading = ref(false)
const spotList = ref([])
const sliderValue = ref(0)
const showConfirmDialog = ref(false)
const rowData = ref<any>({})

const subMap = ref({
  [`xh_detail_${symbol.value}`]: onTokenFn,
  [`xh_deptH_${symbol.value}`]: onOrderBookFn,
  all_symbol_detail: onAllSymbolFun,
})

const tokenDecimal = computed(() => tokenConfigData.value.coin_coin_scale) // BNumber(tokenConfigData.value.min_buy_cou || 0).dp()

const maxNum = computed(() => {
  if (form.direction === 1) {
    return Number(
      toFixed(BNumber(walletData.value.bbBaseBalance).div(form.price), tokenDecimal.value),
    )
  } else {
    return Number(
      toFixed(
        BNumber(form.price).times(walletData.value.bbCoinBalance),
        tokenConfigData.value.base_coin_scale,
      ),
    )
  }
})

const fee = computed(() => {
  if (form.direction === 1) {
    return toFormat(
      BNumber(form.amount || 0).times(tokenConfigData.value.buy_fee),
      tokenConfigData.value.coin_coin_scale,
    )
  } else {
    return toFormat(
      BNumber(tokenPriceTotal.value || 0).times(tokenConfigData.value.sell_fee),
      tokenConfigData.value.base_coin_scale,
    )
  }
})

watch(symbol, async () => {
  form.exchangeCoinStr = symbol.value
  onUnsubscribe(getSubTopic())
  await getTokenData()
  getTokenConfig()
  getWallet()
  getOrderBook()
  onFormDefault()
  subMap.value = {
    [`xh_detail_${symbol.value}`]: onTokenFn,
    [`xh_deptH_${symbol.value}`]: onOrderBookFn,
    all_symbol_detail: onAllSymbolFun,
  }
  onSubscribe(getSubTopic())
})

watch(mode, () => {
  onFormDefault()
})

watch(
  () => form.direction,
  () => {
    onFormDefault()
  },
)

onLoad(async () => {
  getTokenConfig()
  getOrderBook()
  await getLimitOrder()
  // await getMarketOrder()
  await getStopLimitOrder()
})

onShow(async () => {
  await getTokenData()
  await getSpot()
  getWallet()
  form.exchangeCoinStr = symbol.value
  onSubscribe(getSubTopic())
  uni.$on('message', onMessage)
})

onHide(() => {
  onUnsubscribe(getSubTopic())
  uni.$off('message', onMessage)
})

onUnload(() => {
  onUnsubscribe(getSubTopic())
  uni.$off('message', onMessage)
})

// 计算当前币种的盈亏
function getCoinPnL(price: number = 0) {
  const avgPrice = +walletData.value.coinAvgPrice
  const balance = +walletData.value.bbCoinBalance || 0
  const totalIncome = BNumber(price).minus(avgPrice).times(balance)
  if (balance === 0) return { rate: 0, pnl: 0 }
  return {
    rate: BNumber(totalIncome).div(BNumber(avgPrice).times(balance)).times(100),
    pnl: totalIncome,
  }
}

function getSubTopic() {
  if (subscribeMode === 'mqtt') {
    return Object.keys(subMap.value)
  } else {
    const allSymbol = spotList.value
      .filter((item) => Boolean(item.subText))
      .map((item) => `ws.market.CSPOT.${item.subText}.1`)
    return [
      `ws.depth.CSPOT.${tokenData.value.subText}.1`,
      `ws.market.CSPOT.${tokenData.value.subText}.1`,
      ...allSymbol,
    ]
  }
}

const onOrderTabChange = ({ index, name }) => {
  switch (name) {
    case 'ptwt':
      getLimitOrder()
      break
    case 'zyzs':
      getStopLimitOrder()
      break
    case 'assets':
      getWallet()
      break
    case 'history':
      onRouter('/pages/trade/history/index?t=spot')
      nextTick(() => {
        orderTabIndex.value = 'assets'
      })
      break
    default:
  }
}

// dialog
const showDialog = ref(false)
const dialogMainMap = {
  orderCancel: {
    title: 'trade.spot.orderCancelDialog.title',
    content: 'trade.spot.orderCancelDialog.content',
    fun: onLimitOrderCancel,
  },
  stopLimitCancel: {
    title: 'trade.spot.stopLimitCancelDialog.title',
    content: 'trade.spot.stopLimitCancelDialog.content',
    fun: onStopLimitOrderCancel,
  },
}
const dialogKey = ref('orderCancel')
const dialogLoading = ref(false)
const dialogMain = computed(() => dialogMainMap[dialogKey.value])

const onShowDialog = (key) => {
  dialogKey.value = key
  showDialog.value = true
}

const onDialogConfirm = async () => {
  await dialogMain.value.fun()
  showDialog.value = false
}

const onSelectToken = (e) => {
  tradeStore.spotSymbol = e.symbolName
}

function onLimitOrderCancel() {
  return fetchOrderCancel({
    idList: [rowData.value.id],
    type: 'ptwt',
  }).then((res) => {
    getLimitOrder()
  })
}

function onStopLimitOrderCancel() {
  return fetchOrderCancel({
    idList: [rowData.value.id],
    type: 'zyzs',
  }).then((res) => {
    getStopLimitOrder()
  })
}

const onNext = () => {
  const validator = new Schema({
    amount: {
      type: 'string',
      required: true,
      message: t('trade.spot.amount'),
      validator: (rule, value) => {
        return Boolean(+value)
      },
    },
    price: {
      type: 'string',
      required: true,
      message: t('trade.spot.price'),
      validator: (rule, value) => {
        return Boolean(+value)
      },
    },
  })
  validator
    .validate(form)
    .then(() => {
      showConfirmDialog.value = true
    })
    .catch(({ errors, fields }) => {
      uni.showToast({
        icon: 'none',
        title: errors[0].message,
      })
    })
}

function onSubmit() {
  submitLoading.value = true
  return fetchPlaceOrder(modeKey.value as tradeMode, form)
    .then(async (res) => {
      uni.showToast({
        title: t('common.success'),
        icon: 'none',
      })
      submitLoading.value = false
      showConfirmDialog.value = false
      onFormDefault()
      getWallet()
      switch (modeKey.value) {
        case 'xjwt':
          getLimitOrder(true)
          break
        case 'sjwt':
          // getMarketOrder(true)
          break
        case 'zyzs':
          getStopLimitOrder(true)
          break
        default:
      }
    })
    .catch((_) => {
      submitLoading.value = false
    })
}

const onSlider = (val) => {
  if (form.direction === 1) {
    // 买
    form.amount = val
      ? toFixed(
          Number(
            BNumber(walletData.value.bbBaseBalance)
              .div(tokenData.value.close)
              .times(val / 100),
          ),
          tokenDecimal.value,
        )
      : null
  } else {
    // 卖
    form.amount = val
      ? toFixed(
          Number(BNumber(walletData.value.bbCoinBalance).times(val / 100)),
          BNumber(walletData.value.bbCoinBalance).dp(),
        )
      : null
  }

  tokenPriceTotal.value = val ? Number(BNumber(form.price).times(form.amount)) : null

  if (modeKey.value === 'sjwt') {
    form.money = tokenPriceTotal.value
  }
}

// 输入框
function onInputEvent(type, value) {
  switch (type) {
    case 'price':
    case 'amount':
      tokenPriceTotal.value = Number(BNumber(form.price).times(form.amount)) || ''
      break
    case 'total':
      form.amount = toFixed(
        Number(BNumber(tokenPriceTotal.value).div(form.price)),
        tokenDecimal.value,
      )
      break
    default:
  }

  if (modeKey.value === 'sjwt') {
    form.money = tokenPriceTotal.value
  }

  const max = form.direction === 1 ? maxNum.value : walletData.value.bbCoinBalance
  if (max > 0) {
    sliderValue.value = (form.amount / max) * 100
    if (sliderValue.value >= 100) {
      nextTick(() => {
        form.amount = max
      })
    }
  }
}

// 切换方向
function onSwitchDirection(item) {
  form.direction = item.value
  form.amount = ''
  tokenPriceTotal.value = ''
}

function getLimitOrder(select?: boolean) {
  return fetchOrderList('ptwt', {
    pageNo: 1,
    pageSize: -521,
  }).then((res) => {
    limitOrder.value = res.data.map((item) => {
      return {
        ...item,
        symbol: item.symbol_name,
        direction: item.direction,
        date: item.create_time,
        price: item.entrust_price,
        qty: Number(item.entrust_balance),
        total:
          +item.direction === 2
            ? BNumber(item.entrust_price).times(item.entrust_balance)
            : Number(item.entrust_total_balance),
        ratio: `${toFixed(BNumber(item.success_balance).div(item.entrust_balance).times(100))}%`,
      }
    })
    if (
      orderTab.value.findIndex((item) => item.value === 'ptwt') === -1 &&
      limitOrder.value.length > 0
    ) {
      orderTab.value.push({
        label: 'trade.spot.tabs.orders',
        value: 'ptwt',
      })
    }

    if (limitOrder.value.length > 0 && select) {
      orderTabIndex.value = 'ptwt'
    }

    // if (limitOrder.value.length <= 0) {
    //   orderTab.value = orderTab.value.filter((item) => item.value !== 'ptwt')
    //   orderTabIndex.value = 'assets'
    // }
  })
}

function getMarketOrder(select?: boolean) {
  return fetchOrderList('sjwt', {
    pageNo: 1,
    pageSize: -521,
  }).then((res) => {
    marketOrder.value = res.data.map((item) => {
      return {
        ...item,
        symbol: item.symbol_name,
        direction: item.direction,
        date: item.create_time,
        price: item.entrust_price,
        qty: Number(item.entrust_balance),
        total: Number(item.entrust_total_balance),
        ratio: `${toFixed(BNumber(item.success_balance).div(item.entrust_balance).times(100))}%`,
      }
    })
    if (
      orderTab.value.findIndex((item) => item.value === 'sjwt') === -1 &&
      marketOrder.value.length > 0
    ) {
      orderTab.value.push({
        label: 'Market Orders',
        value: 'sjwt',
      })
    }

    if (marketOrder.value.length > 0 && select) {
      orderTabIndex.value = 'sjwt'
    }

    // if (marketOrder.value.length <= 0) {
    //   orderTab.value = orderTab.value.filter((item) => item.value !== 'sjwt')
    //   orderTabIndex.value = 'assets'
    // }
  })
}

function getStopLimitOrder(select?: boolean) {
  return fetchOrderList('zyzs', {
    pageNo: 1,
    pageSize: -521,
  }).then((res) => {
    stopLimitOrder.value = res.data.map((item) => {
      return {
        ...item,
        symbol: item.symbol_name,
        direction: item.direction,
        date: item.create_time,
        price: item.entrust_price,
        qty: Number(item.entrust_balance),
        total: Number(item.entrust_total_balance),
        stopPrice: Number(item.trigger_price),
      }
    })
    if (
      orderTab.value.findIndex((item) => item.value === 'zyzs') === -1 &&
      stopLimitOrder.value.length > 0
    ) {
      orderTab.value.push({
        label: 'Stop Limit Orders',
        value: 'zyzs',
      })
    }

    if (stopLimitOrder.value.length > 0 && select) {
      orderTabIndex.value = 'zyzs'
    }

    // if (stopLimitOrder.value.length <= 0) {
    //   orderTab.value = orderTab.value.filter((item) => item.value !== 'zyzs')
    //   orderTabIndex.value = 'assets'
    // }
  })
}

function onAllSymbolFun(data) {
  if (data.type !== 'xh' && subscribeMode === 'mqtt') return
  let findFun
  if (subscribeMode === 'ws') {
    findFun = (item) => data.symbol === item.subText
  } else {
    findFun = (item) => data.symbolName === item.symbolName
  }
  // 现货列表
  const sIndex = spotList.value.findIndex(findFun)
  if (sIndex !== -1) {
    spotList.value.splice(sIndex, 1, {
      ...spotList.value[sIndex],
      close: data.close,
      zdf: data.zdf,
    })
  }
}

function onTokenFn(data) {
  Object.assign(tokenData.value, data)
  if (modeKey.value === 'sjwt') {
    form.price = tokenData.value.close
  }
}

function onOrderBookFn(data) {
  orderBookData.value = data
}

function onMessage(msgData) {
  const [topic, data] = msgData
  if (subMap.value[topic] && subscribeMode === 'mqtt') {
    subMap.value[topic](data)
    return
  }

  if (topic.indexOf('market') !== -1) {
    if (data.symbol === tokenData.value.subText) {
      onTokenFn(data)
    }
    onAllSymbolFun(data)
  }

  if (topic.indexOf('depth') !== -1) {
    onOrderBookFn(data)
  }
}

function getTokenData() {
  return fetchTokenData({
    symbolNameList: [symbol.value],
    type: 'xh',
  }).then((res) => {
    tokenData.value = res.data[symbol.value]
    form.price = tokenData.value.close
  })
}

function getTokenConfig() {
  return fetchTokenConfig(`xh/${symbol.value.replace('/', '_')}`).then((res) => {
    tokenConfigData.value = res.data
  })
}

function getWallet() {
  return fetchSpotWallet(symbol.value.replace('/', '_')).then((res) => {
    walletData.value = res.data
  })
}

function getOrderBook() {
  return fetchMarketData({
    type: `deptH_xh_deptH_${symbol.value}`,
  }).then((res) => {
    orderBookData.value = res.data
  })
}

function getSpot() {
  return fetchGetSpot().then((res) => {
    spotList.value = res.data
  })
}

function onFormDefault() {
  Object.assign(form, {
    exchangeCoinStr: symbol.value,
    price: tokenData.value.close,
    triggerPrice: '',
    amount: '',
    money: '',
  })
  tokenPriceTotal.value = ''
  sliderValue.value = 0
}
</script>

<style lang="scss" scoped>
.order-wrap {
  margin-top: 20rpx;
  background: var(--background-primary);
  &__tab {
    position: relative;
    display: flex;
    align-items: center;
    border-bottom: 1px solid var(--background-gary-4);
    :deep(.wd-tabs__line) {
      display: none;
    }
  }
  .assets-box {
    padding: 30rpx;
    &__list {
      padding: 20rpx 30rpx 10rpx;
      margin: 0 -30rpx;
      border-bottom: 1px solid var(--background-gary-4);
      &__item {
        display: flex;
        align-items: center;
        padding: 20rpx 0;
        &__cover {
          width: 50rpx;
          height: 50rpx;
          border-radius: 50%;
        }
        &__title {
          flex: 1;
          padding: 0 20rpx;
          font-size: 30rpx;
          font-weight: 500rpx;
        }
        &__num {
          font-size: 30rpx;
          font-weight: 500rpx;
        }
      }
    }
  }
}
.border-box {
  position: relative;
  &::after {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
    box-sizing: border-box;
    width: 200%;
    height: 200%;
    pointer-events: none;
    content: '';
    border: 1px solid var(--border-color);
    transform: scale(0.5, 0.5);
    transform-origin: 0 0;
  }
}
.wrap {
  background: var(--background-primary);
  border-radius: 20rpx 20rpx 0 0;
  .exchange-rate {
    align-self: flex-end;
    padding-bottom: 8rpx;
    font-size: 20rpx;
    color: var(--text-inactive);
  }
  .trade-type {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12rpx 20rpx;
    margin-top: 20rpx;
    &::after {
      border-radius: 10rpx;
    }
    &__name {
      font-size: 26rpx;
      font-weight: 500;
    }
  }
  .trade-tag {
    display: flex;
    gap: 40rpx;
    align-items: center;
    &__item {
      position: relative;
      box-sizing: border-box;
      width: 50%;
      height: 60rpx;
      font-size: 26rpx;
      font-weight: 500;
      line-height: 60rpx;
      text-align: center;
      background: var(--background-gary-7);
      border-radius: 100rpx;
      transition: all 0.3s;
      &__text {
        position: relative;
        z-index: 2;
      }
      &::before {
        position: absolute;
        top: 0;
        right: -10rpx;
        z-index: 1;
        width: 50%;
        height: 100%;
        content: '';
        background-color: inherit;
        transform: translate(0) rotate(0) skewX(-35deg) skewY(0) scaleX(1) scaleY(1);
      }
      + .trade-tag__item {
        &::before {
          right: auto;
          left: -10rpx;
        }
      }
    }
    &__item-buy.in-active {
      color: #fff;
      background: var(--color-green);
    }
    &__item-sell.in-active {
      color: #fff;
      background: var(--color-red);
    }
  }
}
</style>
