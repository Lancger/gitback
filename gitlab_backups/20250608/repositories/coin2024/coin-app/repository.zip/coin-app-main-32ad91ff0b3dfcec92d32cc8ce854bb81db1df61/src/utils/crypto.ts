import CryptoJS from 'crypto-js'

const AES_KEY = 'YgDAc1LCCwH2Wff99IaYxseN0K4A38bV'

/**
 * AES加密
 * @param data 待加密数据
 * @returns 加密后的Base64字符串
 */
function encrypt(data: string): string {
  const dataBytes = CryptoJS.enc.Utf8.parse(data)
  const keyBytes = CryptoJS.enc.Utf8.parse(AES_KEY)
  const encrypted = CryptoJS.AES.encrypt(dataBytes, keyBytes, {
    iv: keyBytes,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  })
  return CryptoJS.enc.Base64.stringify(encrypted.ciphertext)
}

/**
 * AES解密
 * @param data 待解密的Base64字符串
 * @returns 解密后的字符串
 */
function decrypt(data: string): string {
  const keyBytes = CryptoJS.enc.Utf8.parse(AES_KEY)
  const decrypted = CryptoJS.AES.decrypt(data, keyBytes, {
    iv: keyBytes,
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.Pkcs7,
  })
  return CryptoJS.enc.Utf8.stringify(decrypted)
}

export default {
  encrypt,
  decrypt,
}
