<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar
    :title="pageMode === 'spot' ? $t('trade.spot.history') : $t('futures.index.history.title')"
  ></app-navbar>
  <view class="fixed top-44px left-0 right-0 z-10 w-100%">
    <wd-tabs
      v-if="tab.length > 0"
      v-model="tabValue"
      swipeable
      animated
      :map-num="100"
      @change="onTabsChange"
    >
      <block v-for="(item, index) in tab" :key="index">
        <wd-tab :title="item.label" :name="item.value"></wd-tab>
      </block>
    </wd-tabs>
    <view @click="closeOutside">
      <wd-drop-menu v-if="tabValue === 0">
        <wd-drop-menu-item
          v-model="tokenValue"
          icon="fill-arrow-down"
          icon-size="35rpx"
          icon-name="check-circle-filled"
          :options="tokenOptions"
          @change="onTokenChange"
        />
        <wd-drop-menu-item
          v-model="tradeValue"
          icon="fill-arrow-down"
          icon-size="35rpx"
          icon-name="check-circle-filled"
          :options="tradeOptions"
          @change="onTradeChange"
        />
        <wd-drop-menu-item
          v-model="directionValue"
          icon="fill-arrow-down"
          icon-size="35rpx"
          icon-name="check-circle-filled"
          :options="directionOptions"
          @change="onDirectionChange"
        />
      </wd-drop-menu>
      <wd-drop-menu v-else>
        <wd-drop-menu-item
          v-model="tokenValue"
          icon="fill-arrow-down"
          icon-size="35rpx"
          icon-name="check-circle-filled"
          :options="tokenOptions"
          @change="onTokenChange"
        />
      </wd-drop-menu>
    </view>
  </view>
  <view v-if="tab.length > 0" class="h-[calc(80px)]"></view>
  <view v-else class="h-[calc(30px)]"></view>
  <wd-skeleton
    :loading="dataLoading"
    animation="flashed"
    :row-col="[
      { margin: '30rpx 30rpx 0', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
    ]"
  >
    <app-empty :no-data="list.length === 0">
      <trade-history-list
        v-if="tabValue !== 2"
        :list="list"
        :mode="tabValue === 0 ? 'order' : 'make'"
        :tradeMode="pageMode"
        @onShare="onShare"
      ></trade-history-list>
      <block v-else>
        <view
          v-for="(item, index) in list"
          :key="index"
          class="m-30rpx p-30rpx bg-[--background-primary] rd-20rpx"
        >
          <view class="flex items-center justify-between">
            <view class="flex items-center gap-20rpx">
              <view class="font-size-30rpx font-500">
                {{ item.symbol_name.split('/')[0] }}
                <text class="font-size-22rpx font-400 color-[var(--text-inactive)]">
                  /{{ item.symbol_name.split('/')[1] }}
                </text>
              </view>
              <view
                class="px-10rpx h-30rpx line-height-30rpx font-size-20rpx bg-[var(--background-gary-4)] rd-5rpx"
              >
                {{ $t('futures.index.history.holdingFee') }}
              </view>
            </view>
            <view class="font-size-26rpx font-500 color-[var(--active)]">
              -{{ item.night_fee }}
            </view>
          </view>
          <view class="flex items-center mt-30rpx font-size-22rpx color-[var(--text-inactive)]">
            <view>{{ formatDate(item.create_time) }}</view>
            <!-- <view>Frozen 185.65</view> -->
          </view>
        </view>
      </block>
      <wd-loadmore :state="loadMoreState" />
    </app-empty>
  </wd-skeleton>

  <!-- 海报 -->
  <futures-poster
    v-model="showShare"
    :row-data="{
      ...rowData,
      leverage: `${rowData.leverage}X`,
      pl: rowData.profit,
      plRatio: rowData.plRatio,
      avg_price: toFixed(rowData.open_price, rowData.base_coin_scale),
      closePrice: toFixed(rowData.success_price, rowData.base_coin_scale),
    }"
  ></futures-poster>
</template>

<script lang="ts" setup>
import { useQueue } from 'wot-design-uni'
import { BNumber, toFixed, toFormatPercent } from '@/utils/number'
import { t } from '@/locale'
import { fetchOrderRecords } from '@/service/trade'
import { fetchFundingRateRecords } from '@/service/futures'
import { formatDate } from '@/utils/day'

const dataLoading = ref(true)
const listParams = reactive({
  current: 1,
  size: 12,
  currentType: 'xh',
  entrustType: null,
  jhwtType: null,
  symbolName: '',
  tradeType: '',
  type: 5,
  isShowRevoke: null,
})
const showShare = ref(false)
const rowData = ref<any>({})

const {
  data: list,
  loadMoreState,
  onInit: getList,
} = usePagination({
  api: (params) => {
    if (tabValue.value !== 2) {
      return fetchOrderRecords(params).then((res) => {
        res.data.records = res.data.records.map((item) => {
          return {
            ...item,
            plRatio: `${toFormatPercent((+item.profit * 100) / item.bzj)}`,
          }
        })

        return res
      })
    } else {
      return fetchFundingRateRecords({
        symbolName: params.symbolName,
        pageNo: params.current,
        pageSize: params.size,
      })
    }
  },
  params: listParams,
  onLoadMoreFn: onReachBottom,
  pageNoKey: 'current',
  pageSizeKey: 'size',
  isInit: false,
})

const { closeOutside } = useQueue()

const pageMode = ref('spot') // spot futures
const modeMap = {
  spot: {
    tradeOptions: [
      { label: 'Limit Order', value: 0, key: 'xh', type: 1 },
      { label: 'Market Order', value: 1, key: 'sjwt', type: 4 },
      { label: 'Trigger Order', value: 2, key: 'xh_zyzs', type: 3 },
    ],
    directionOptions: [
      { label: 'Side', value: 0, type: '' },
      { label: 'Buy', value: 1, type: 1 },
      { label: 'Sell', value: 2, type: 2 },
    ],
  },
  futures: {
    tradeOptions: [
      { label: t('futures.index.history.limitOrder'), value: 0, type: 5 },
      // { label: 'Market Order', value: 2 },
      { label: t('futures.index.history.triggerOrder'), value: 1, type: 3 },
    ],
    directionOptions: [
      { label: t('futures.index.history.side'), value: 0, type: '' },
      {
        label: `${t('futures.index.history.open')}(${t('futures.index.history.long')})`,
        value: 1,
        type: 1,
      },
      {
        label: `${t('futures.index.history.open')}(${t('futures.index.history.short')})`,
        value: 2,
        type: 2,
      },
      {
        label: `${t('futures.index.history.close')}(${t('futures.index.history.long')})`,
        value: 3,
        type: 3,
      },
      {
        label: `${t('futures.index.history.close')}(${t('futures.index.history.short')})`,
        value: 4,
        type: 4,
      },
    ],
  },
}
const tab = ref([
  {
    label: t('futures.index.history.orders'),
    value: 0,
  },
  {
    label: t('futures.index.history.transactions'),
    value: 1,
  },
  // {
  //   label: t('futures.index.history.holdingFee'),
  //   value: 2,
  // },
])
const tabValue = ref<any>(0)
const tokenValue = ref<any>(0)
const tradeValue = ref<any>(0)
const directionValue = ref<any>(0)

const tokenOptions = ref<Record<string, any>[]>([{ label: t('common.all'), value: 0 }])
const tradeOptions = computed(() => modeMap[pageMode.value].tradeOptions)
const directionOptions = computed(() => modeMap[pageMode.value].directionOptions)

onLoad(async (options) => {
  pageMode.value = options.t
  if (pageMode.value === 'spot') {
    tab.value = []
    tabValue.value = 1
  }
  onFilter()
  try {
    await getList()
    dataLoading.value = false
  } catch (error) {
    dataLoading.value = false
  }
})

const onShare = (data) => {
  showShare.value = true
  rowData.value = data
}

function onFilter() {
  Object.assign(listParams, {
    currentType: null,
    entrustType: null,
    type: null,
    tradeType: null,
  })
  if (pageMode.value === 'spot') {
    listParams.currentType = tabValue.value === 0 ? tradeOptions.value[tradeValue.value].key : 'xh'
    listParams.entrustType = tabValue.value === 0 ? tradeOptions.value[tradeValue.value].type : null
    listParams.type = tabValue.value === 0 ? 2 : 3
  } else {
    listParams.currentType = 'ubw'
    // listParams.jhwtType = 2
    listParams.type = tabValue.value === 0 ? tradeOptions.value[tradeValue.value].type : 6
  }
  listParams.tradeType = directionOptions.value[directionValue.value].type
}

async function onTokenChange({ value }) {
  onFilter()
  dataLoading.value = true
  try {
    await getList()
    dataLoading.value = false
  } catch (error) {
    dataLoading.value = false
  }
}

async function onTradeChange(e) {
  onFilter()
  dataLoading.value = true
  try {
    await getList()
    dataLoading.value = false
  } catch (error) {
    dataLoading.value = false
  }
}

async function onDirectionChange(e) {
  onFilter()
  dataLoading.value = true
  try {
    await getList()
    dataLoading.value = false
  } catch (error) {
    dataLoading.value = false
  }
}

async function onTabsChange({ name }) {
  tabValue.value = name
  onFilter()
  dataLoading.value = true
  try {
    await getList()
    dataLoading.value = false
  } catch (error) {
    dataLoading.value = false
  }
}
</script>

<style lang="scss" scoped>
// :deep(.wd-drop-menu__list) {
//   background: transparent;
// }
:deep(.wd-drop-menu__item) {
  flex: none;
  width: 33.33%;
  height: 35px;
  line-height: 35px;
}
.page {
  background: var(--background-secondary);
}
</style>
