interface paginationType {
  api: (params: any) => Promise<IResData<any>>
  params: any
  no?: number
  size?: number
  onLoadMoreFn?: (fn: () => void) => void
  pageNoKey?: string
  pageSizeKey?: string
  isInit?: boolean
}

export default function usePagination(options: paginationType) {
  const {
    api,
    params,
    no = 1,
    size = 12,
    onLoadMoreFn,
    pageNoKey = 'pageNo',
    pageSizeKey = 'pageSize',
    isInit = true,
  } = options
  const data = ref([])
  const pageNo = ref(no)
  const pageSize = ref(size)
  const loading = ref(false)
  const isNoData = ref(false)
  const loadMoreState = ref<'loading' | 'error' | 'finished'>('finished')

  onLoadMoreFn && onLoadMoreFn(onLoadMore)

  onMounted(() => {
    if (isInit) {
      getData()
    }
  })

  async function onLoadMore() {
    if (loading.value || isNoData.value) return
    ++pageNo.value
    loading.value = true
    loadMoreState.value = 'loading'
    try {
      await getData()
      loading.value = false
      loadMoreState.value = 'finished'
    } catch (error) {
      --pageNo.value
      loading.value = false
      loadMoreState.value = 'finished'
    }
  }

  function getData() {
    params[pageNoKey] = pageNo.value
    params[pageSizeKey] = pageSize.value
    return api(params).then((res) => {
      if (Array.isArray(res.data)) {
        res.data = {
          records: res.data,
          total: 0,
        }
      }
      data.value = pageNo.value > 1 ? data.value.concat(res.data.records) : res.data.records
      isNoData.value = data.value.length === res.data.total || res.data.records.length === 0
    })
  }

  async function onInit() {
    isNoData.value = false
    loading.value = true
    loadMoreState.value = 'loading'
    pageNo.value = no
    try {
      await getData()
      loading.value = false
      loadMoreState.value = 'finished'
    } catch (error) {
      loading.value = false
      loadMoreState.value = 'finished'
    }
  }

  return {
    pageNo,
    pageSize,
    loading,
    data,
    loadMoreState,
    onLoadMore,
    onInit,
  }
}
