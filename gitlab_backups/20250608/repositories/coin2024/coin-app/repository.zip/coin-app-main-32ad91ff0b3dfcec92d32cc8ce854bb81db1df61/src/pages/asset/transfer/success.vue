<template>
  <app-navbar custom-style="background-color: none;" title=""></app-navbar>

  <view class="norecord">
    <view class="norecord_img">
      <image class="w160rpx h160rpx" src="@/static/images/assets/success.png" mode="aspectFit" />
    </view>
    <view class="norecord_sum">135.31 USDT</view>
    <view class="norecord_text">Your crypto has been deposided to your Funding account.</view>
  </view>
  <view class="btn">View assets</view>
</template>

<script lang="ts" setup></script>

<style lang="scss" scoped>
.page {
  background: var(--background-secondary) var(--background-linear-gradient-1) no-repeat;
  background-size: 100% 744rpx;
}

.btn {
  position: absolute;
  bottom: 30%;
  left: 50%;
  width: 400rpx;
  height: 90rpx;
  margin: 50rpx auto;
  line-height: 90rpx;
  color: #fff !important;
  text-align: center;
  background-color: #00a7ed;
  border-radius: 100rpx;
  transform: translate(-50%, -30%);
}

.norecord {
  &_img {
    width: 160rpx;
    height: 160rpx;
    margin: 346rpx auto 20rpx;
  }
  &_sum {
    margin-top: 30rpx;
    font-size: 54rpx;
    color: var(-text-primary) !important;
    text-align: center;
  }
  &_text {
    margin-top: 30rpx;
    color: var(--text-active) !important;
    text-align: center;
  }
}
</style>
