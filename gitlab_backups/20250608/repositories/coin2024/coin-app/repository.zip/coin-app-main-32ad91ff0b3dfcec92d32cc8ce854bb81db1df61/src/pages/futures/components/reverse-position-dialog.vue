<template>
  <wd-overlay :show="modelValue" :z-index="99" @click="onClose">
    <view class="wrapper">
      <view class="dialog" @click.stop>
        <view class="dialog__title">{{ $t('futures.index.reversePositionDialog.title') }}</view>
        <view class="flex items-center font-500 mt-40rpx gap-10rpx">
          <text :class="[rowData.direction === 1 ? 'up-color' : 'down-color']">
            {{ rowData.direction === 1 ? $t('futures.index.long') : $t('futures.index.short') }}
          </text>
          <view>
            {{ rowData.symbol_name }}
          </view>
          <view class="tag">{{ rowData.leverage }}</view>
        </view>
        <view class="order-list">
          <view class="order-list-item">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.reversePositionDialog.price') }}
            </view>
            <view>{{ $t('futures.index.reversePositionDialog.market') }}</view>
          </view>
          <view v-if="rowData.unit === 'cont'" class="order-list-item">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.confirmOrderDialog.volume') }}
            </view>
            <view>{{ rowData.balance }} {{ rowData.unitLabel }}</view>
          </view>
          <view class="order-list-item">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.reversePositionDialog.margin') }}
            </view>
            <view>{{ toFormat(rowData.principal_amount, true) }} USDT</view>
          </view>
          <!-- <view class="order-list-item">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.reversePositionDialog.marginRatio') }}
            </view>
            <view>{{ rowData.marginRatio }}</view>
          </view> -->
          <view class="order-list-item b-t">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.reversePositionDialog.available') }}
            </view>
            <view>{{ toFormat(rowData.principal_amount, true) }} USDT</view>
          </view>
          <view class="flex gap-16rpx p-20rpx mt-10rpx line-height-30rpx bg-#FF4E430D rd-8rpx">
            <wd-icon
              custom-class="color-[var(--color-red)]"
              name="error-circle-filled"
              size="22rpx"
            ></wd-icon>
            <view class="font-size-20rpx color-[var(--color-red)]">
              {{ $t('futures.index.reversePositionDialog.tips') }}
            </view>
          </view>
        </view>
        <view class="dialog__foot">
          <wd-button custom-class="flex-1" type="info" plain @click="onClose">
            {{ $t('common.cancel') }}
          </wd-button>
          <wd-button custom-class="flex-1" :loading="loading" @click="onSubmit">
            {{ $t('common.confirm') }}
          </wd-button>
        </view>
      </view>
    </view>
  </wd-overlay>
</template>

<script lang="ts" setup>
import { fetchPlaceOrder } from '@/service/futures'
import { toFormat } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  rowData: {
    type: Object,
    default: () => ({}),
  },
})

const emits = defineEmits(['update:modelValue', 'onCallback'])

const loading = ref(false)

const onSubmit = async () => {
  try {
    loading.value = true
    await fetchPlaceOrder('close/reverse', {
      exchangeCoinStr: props.rowData.symbol_name,
      price: props.rowData.avg_price, // 委托价
      amount: props.rowData.balance, // 数量
      // 3=平仓-平多 4=平仓-平空
      direction: props.rowData.direction === 1 ? 3 : 4, // 方向
      pattern: props.rowData.pattern, // 逐仓=1，全仓=2
      patternType: props.rowData.pattern_type, // 并仓=1，分仓=2
      contractType: props.rowData.contract_type, // 合约类型
      closeLogContractOrderCode: props.rowData.order_code, // 订单号
    })
    onClose()
    emits('onCallback')
    loading.value = false
  } catch (error) {
    loading.value = false
  }
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;

  .tag {
    height: 24rpx;
    padding: 0 6rpx;
    font-size: 20rpx;
    line-height: 24rpx;
    color: var(--color-primary);
    background: #00a7ed1a;
    border-radius: 5rpx;
  }

  .dialog {
    box-sizing: border-box;
    width: 540rpx;
    padding: 30rpx;
    background-color: var(--background-primary);
    border-radius: 20rpx;
    &__title {
      font-size: 30rpx;
      font-weight: 500;
      text-align: center;
    }
    .order-list {
      padding: 10rpx 0 50rpx;
      &-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 15rpx 0;
      }
    }
    &__foot {
      display: flex;
      gap: 14rpx;
      align-items: center;
    }
  }
}
</style>
