<template>
  <app-navbar :title="$t('search.title')"></app-navbar>
  <view class="header">
    <view class="search-box">
      <wd-icon name="search" size="32rpx"></wd-icon>
      <input
        v-model="keyword"
        type="text"
        class="search-box__input"
        :placeholder="$t('search.input')"
      />
    </view>
    <!-- <view class="font-size-30rpx font-700 ml-30rpx">Confirm</view> -->
  </view>
  <view class="h-130rpx"></view>
  <!-- <view class="history-wrap">
    <view class="history-wrap__head">
      <view class="history-wrap-title">Search History</view>
      <view class="history-wrap-del">Delete</view>
    </view>
    <view class="history-wrap__list">
      <view v-for="(item, index) in 10" :key="index" class="history-wrap__list-item">BTC/USDT</view>
    </view>
  </view> -->
  <view v-if="keyword">
    <wd-tabs
      custom-class="app-tabs app-tabs--no-flex-1 app-tabs--large"
      :model-value="0"
      swipeable
      animated
      :map-num="100"
    >
      <wd-tab :title="$t('search.spot')">
        <app-empty class="px-30rpx" :no-data="searchSpotList.length === 0">
          <search-product-list
            :list="searchSpotList"
            show-follow
            @click="onRouter(`/pages/market/detail?symbol=${$event.symbol}&type=xh`)"
          ></search-product-list>
        </app-empty>
      </wd-tab>
      <wd-tab :title="$t('search.futures')">
        <app-empty class="px-30rpx" :no-data="searchFuturesList.length === 0">
          <search-product-list
            :list="searchFuturesList"
            show-follow
            @click="onRouter(`/pages/market/detail?symbol=${$event.symbol}&type=ubw`)"
          ></search-product-list>
        </app-empty>
      </wd-tab>
    </wd-tabs>
  </view>
  <view v-else class="hot-wrap">
    <view class="hot-wrap__head">
      <image class="hot-wrap__icon" src="@img/icons/hot.png" mode="scaleToFill" />
      <view class="hot-wrap__title">{{ $t('search.hot') }}</view>
    </view>
    <app-empty :no-data="hotList.length === 0">
      <search-product-list
        :list="hotList"
        show-rank
        @click="onRouter(`/pages/market/detail?symbol=${$event.symbol}&type=xh`)"
      ></search-product-list>
    </app-empty>
  </view>
</template>

<script lang="ts" setup>
import Fuse from 'fuse.js'
import searchProductList from './components/search-product-list.vue'
import { fetchHotProduct, fetchGetFutures, fetchGetSpot } from '@/service/market'
import { onRouter } from '@/utils'
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'

const hotList = ref<any>([])
const spotList = ref<any>([])
const futuresList = ref<any>([])
const keyword = ref()
const fuseOptions = {
  includeScore: true,
  threshold: 0.0,
  keys: ['symbol'],
}

const searchSpotList = ref([])
const searchFuturesList = ref([])

onLoad(async () => {
  await getHot()
  await getSpot()
  await getFutures()
  onSubscribe(getSubTopic())
  uni.$on('message', onMessage)
})

watch(keyword, (newValue) => {
  const fuseOne = new Fuse(spotList.value, fuseOptions)
  const fuseTwo = new Fuse(futuresList.value, fuseOptions)

  searchSpotList.value = fuseOne.search(newValue).map((item) => item.item)
  searchFuturesList.value = fuseTwo.search(newValue).map((item) => item.item)
})

onUnload(() => {
  onUnsubscribe(getSubTopic())
  uni.$off('message', onMessage)
})

function getSubTopic() {
  if (subscribeMode === 'mqtt') {
    return 'all_symbol_detail'
  } else {
    return [
      ...hotList.value
        .filter((item) => Boolean(item.subText))
        .map((item) => `ws.market.CSPOT.${item.subText}.1`),
      ...spotList.value
        .filter((item) => Boolean(item.subText))
        .map((item) => `ws.market.CSPOT.${item.subText}.1`),
      ...futuresList.value
        .filter((item) => Boolean(item.subText))
        .map((item) => `ws.market.CSPOT.${item.subText}.1`),
    ]
  }
}

function onMessage(msgData) {
  const [topic, data] = msgData
  if (topic !== 'all_symbol_detail' && subscribeMode === 'mqtt') return
  onUpdate(data)
}

function onUpdate(data) {
  let findFun
  if (subscribeMode === 'ws') {
    findFun = (item) => data.symbol === item.subText
  } else {
    findFun = (item) => data.symbolName === item.symbolName
  }
  if (data.type === 'xh' || subscribeMode === 'ws') {
    // 热门
    const hIndex = hotList.value.findIndex((item) => {
      if (subscribeMode === 'ws') {
        return data.symbol === item.subText
      }
      return data.symbolName === item.symbol
    })
    if (hIndex !== -1) {
      hotList.value.splice(hIndex, 1, {
        ...hotList.value[hIndex],
        price: data.close,
        rate: data.zdf,
      })
    }
    // 现货
    const sIndex = spotList.value.findIndex(findFun)
    if (sIndex !== -1) {
      spotList.value.splice(sIndex, 1, {
        ...spotList.value[sIndex],
        price: data.close,
        rate: data.zdf,
      })
    }
    // 搜索结果
    const ssIndex = searchSpotList.value.findIndex(findFun)
    if (ssIndex !== -1) {
      searchSpotList.value.splice(ssIndex, 1, {
        ...searchSpotList.value[ssIndex],
        price: data.close,
        rate: data.zdf,
      })
    }
  }
  // 合约
  if (data.type === 'ubw' || subscribeMode === 'ws') {
    const fIndex = futuresList.value.findIndex(findFun)
    if (fIndex !== -1) {
      futuresList.value.splice(fIndex, 1, {
        ...futuresList.value[fIndex],
        price: data.close,
        rate: data.zdf,
      })
    }
    // 搜索结果
    const sfIndex = searchFuturesList.value.findIndex(findFun)
    if (sfIndex !== -1) {
      searchFuturesList.value.splice(sfIndex, 1, {
        ...searchFuturesList.value[sfIndex],
        price: data.close,
        rate: data.zdf,
      })
    }
  }
}

function getHot() {
  return fetchHotProduct().then((res) => {
    hotList.value = res.data.map((item) => {
      return {
        ...item,
        symbol: `${item.coinSymbol}/${item.baseSymbol}`,
        logo: item.avatar,
        price: item.close,
        rate: item.zdf,
      }
    })
  })
}

function getSpot() {
  return fetchGetSpot().then((res) => {
    spotList.value = res.data.map((item) => {
      return {
        ...item,
        symbol: item.symbol_name,
        logo: item.avatar,
        price: item.close,
        rate: item.zdf,
        isFollow: item.collect,
      }
    })
  })
}

function getFutures() {
  return fetchGetFutures().then((res) => {
    futuresList.value = res.data.map((item) => {
      return {
        ...item,
        symbol: item.symbol_name,
        logo: item.avatar,
        price: item.close,
        rate: item.zdf,
        isFollow: item.collect,
      }
    })
  })
}
</script>

<style lang="scss" scoped>
.history-wrap {
  padding: 0 30rpx;
  margin-top: 40rpx;
  &__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  &-title {
    font-size: 24rpx;
  }
  &-del {
    font-size: 24rpx;
    color: var(--text-inactive);
  }
  &__list {
    display: flex;
    flex-wrap: wrap;
    gap: 20rpx;
    align-items: center;
    margin-top: 20rpx;
    &-item {
      min-width: 155rpx;
      height: 54rpx;
      padding: 0 20rpx;
      font-size: 22rpx;
      line-height: 54rpx;
      text-align: center;
      background: var(--background-gary-4);
      border-radius: 100rpx;
    }
  }
}
.hot-wrap {
  padding: 30rpx;
  &__head {
    display: flex;
    align-items: center;
  }
  &__icon {
    width: 32rpx;
    height: 32rpx;
    margin-right: 16rpx;
  }
  &__title {
    font-size: 28rpx;
    font-weight: 700;
  }
}
.search-box {
  display: flex;
  flex: 1;
  align-items: center;
  height: 70rpx;
  padding: 0 30rpx;
  background: var(--background-tertiary);
  border-radius: 100rpx;
  &__input {
    flex: 1;
    height: 100%;
    padding: 0 20rpx;
    font-size: 26rpx;
  }
}
.header {
  position: fixed;
  top: 44px;
  right: 0;
  left: 0;
  z-index: 100;
  display: flex;
  align-items: center;
  padding: 30rpx;
  background: var(--background-primary);
}
</style>
