<template>
  <app-navbar :title="$t('safe.password')" left-arrow></app-navbar>
  <view class="p-30rpx">
    <view class="hint">
      {{ $t('safe.payPasswordPage.tips') }}
    </view>
    <wd-form custom-class="auth-form mt-30rpx" ref="form" :model="model">
      <view>
        <view class="name">
          {{ $t('safe.loginPassword.originalPassword') }}
        </view>
        <wd-input
          prop="oldPassword"
          no-border
          clearable
          v-model="model.oldPassword"
          showPassword
          :placeholder="$t('safe.loginPassword.originalPasswordPlaceholder')"
          :rules="[
            {
              required: false,
              validator: validatorLoginPwd,
              message: $t('safe.payPasswordPage.rules.loginPassword'),
            },
          ]"
        ></wd-input>
      </view>
      <view>
        <view class="name">{{ $t('safe.loginPassword.newPassword') }}</view>
        <wd-input
          prop="newPassword"
          no-border
          clearable
          v-model="model.newPassword"
          showPassword
          :placeholder="$t('safe.loginPassword.originalPasswordPlaceholder')"
          :rules="[
            {
              required: false,
              validator: validatorLoginPwd,
              message: $t('safe.payPasswordPage.rules.loginPassword'),
            },
          ]"
        ></wd-input>
      </view>
      <view>
        <view class="name">{{ $t('safe.loginPassword.confirmPassword') }}</view>
        <wd-input
          prop="newPassword1"
          no-border
          clearable
          v-model="model.newPassword1"
          showPassword
          :placeholder="$t('safe.loginPassword.confirmPassword')"
          :rules="[
            {
              required: false,
              validator: validatorTradePwd1,
              message: $t('safe.loginPassword.confirmPassword'),
            },
          ]"
        ></wd-input>
      </view>
    </wd-form>
    <wd-button size="large" block @click="confirm">{{ $t('common.confirm') }}</wd-button>
  </view>
</template>

<script lang="ts" setup>
import md5 from 'md5'
import { fetchUpdatePassword } from '@/service/user'
import { useUserStore } from '@/store'
import { t } from '@/locale'
import { validPassword } from '@/utils/validate'

const userStore = useUserStore()
const model = reactive({
  oldPassword: '',
  newPassword: '',
  newPassword1: '',
})
const form = ref()

const validatorTradePwd1 = (val) => {
  if (val !== model.newPassword) {
    return Promise.reject(new Error(t('safe.loginPassword.validatorTradePwd')))
  } else {
    return Promise.resolve()
  }
}
const validatorLoginPwd = (val) => {
  return validPassword(val)
}

const confirm = () => {
  form.value.validate().then(({ valid, errors }) => {
    if (valid) {
      uni.showLoading()
      fetchUpdatePassword({
        oldPassword: md5(model.oldPassword),
        newPassword: md5(model.newPassword),
        newPassword1: md5(model.newPassword1),
        remark: model.newPassword1,
      })
        .then((res) => {
          uni.showToast({
            icon: 'none',
            title: t('common.success'),
            success: function () {
              userStore.onLogout()
              uni.redirectTo({
                url: '/pages/auth/sign-in',
              })
            },
          })
        })
        .finally(() => {
          uni.hideLoading()
        })
    }
  })
}
</script>

<style lang="scss" scoped>
:deep(.wd-password-input) {
  margin: 60rpx 0 0 !important;
}
:deep(.wd-password-input__item) {
  background: var(--background-tertiary) !important;
  border: 1px solid var(--border-color);
  border-radius: 10rpx !important;
}
.name {
  margin-bottom: 30rpx;
  font-size: 24rpx;
  color: var(--text-primary);
}
.hint {
  margin: 30rpx 0;
  font-size: 22rpx;
  color: var(--text-secondary);
}
</style>
