import { http } from '@/utils/http'

/** 发送邮件 */
export const fetchSendEmail = (params: any) => {
  return http.get('/api/mjkj-web/coin/open/send/email', params)
}

/** 发送短信 */
export const fetchSendSMS = (params: any) => {
  return http.get('/api/mjkj-web/coin/open/send/sms', params)
}

/** 获取表单 */
export const fetchFormData = (formId, params?: any) => {
  return http.get(`/api/mjkj-web/cgform-api/getData/${formId}`, params)
}

/** 获取表单详情 */
export const fetchFormDetailData = (formParentId, formChildId) => {
  return http.get(`/api/mjkj-web/cgform-api/detailData/${formParentId}/${formChildId}`)
}

/** 获取表单页面 */
export const fetchFormPageData = (formId) => {
  return http.get(`/api/mjkj-web/desform-api/desform/${formId}`)
}

// 获取区号
export const fetchArea = (params?: any) => {
  return http.get(`/api/mjkj-web/coin/open/get/phone/areaCode`, params)
}

// 获取服务器时间
export const fetchServerTime = () => {
  return http.get(`/api/mjkj-web/coin/open/currentTime`)
}
