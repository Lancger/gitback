<template>
  <app-navbar :title="$t('user.title')" custom-class="!bg-transparent">
    <template #right>
      <image
        class="w-56rpx h-56rpx mr-30rpx"
        :src="onImageToThemeImage('/static/images/user/theme.png')"
        @click="onRouter('/pages/theme/index')"
      ></image>
      <image
        class="w-56rpx h-56rpx"
        :src="onImageToThemeImage('/static/images/user/language.png')"
        @click="onRouter('/pages/language/index')"
      ></image>
    </template>
  </app-navbar>
  <view class="relative z-10 pl-30rpx pr-30rpx pb-100rpx">
    <view
      class="pt-50rpx pl-10rpx pr-10rpx pb-40rpx flex flex-items-center"
      @click="
        !userStore.isLogined
          ? onRouter('/pages/auth/sign-in', 'reLaunch')
          : onRouter('/pages/user/profile')
      "
    >
      <image v-if="userInfo.avatar" class="w-90rpx h-90rpx rd-50%" :src="userInfo.avatar"></image>
      <image v-else class="w-90rpx h-90rpx rd-50%" src="@img/avatar.png" />
      <view class="message" v-if="userStore.isLogined">
        <view class="message__name">
          {{ userInfo.name }}
        </view>
        <view class="message__uid">
          UID:{{ userInfo.uid }}
          <image
            class="w-30rpx h-30rpx"
            @click.stop="onCopy(userInfo.uid)"
            src="@/static/images/icons/copy.png"
          />
          <vip-level
            v-if="config.isVip"
            :level="userInfo.member_level || 1"
            :name="userInfo.nameStr"
            @click.stop="onRouter('/pages/vip/index')"
          />
        </view>
      </view>
      <view class="message" v-else>
        <view class="message__name">{{ $t('common.signIn') }}/{{ $t('common.signUp') }}</view>
      </view>
      <!-- <image class="w-36rpx h-36rpx" src="@/static/images/user/arrows.png"></image> -->
      <wd-icon custom-class="color-[var(--arrow-color)]" name="arrow-right" size="36rpx"></wd-icon>
    </view>
    <view class="share_img flex items-center pl-40rpx color-#fff box-border" @click="onShare">
      <view class="font-size-40rpx font-700">{{ $t('user.banner.title') }}</view>
      <!-- <view class="mt-10rpx font-size-24rpx font-500">{{ $t('user.banner.subtitle') }}</view> -->
      <view
        style="background: #ffffff4d; backdrop-filter: blur(10rpx)"
        class="absolute top-50% right-40rpx px-25rpx h-60rpx lh-60rpx border-solid border-1 border-#fff translate-y-[-50%] rd-100rpx"
      >
        {{ $t('user.banner.btn') }}
      </view>
    </view>
    <!--  -->
    <view class="operation-box">
      <view
        class="operation-box__item"
        v-for="(item, index) in card"
        :key="index"
        @click="onEvent(item)"
      >
        <image class="operation-box__item__img" :src="item.src" mode=""></image>
        <view class="operation-box__item__name">
          {{ item.title }}
        </view>
      </view>
    </view>
    <!--  -->
    <view v-for="(item, index) in list" :key="index" class="list-box">
      <template v-for="(v, i) in item" :key="i">
        <view v-if="v.type !== 'select'" class="list-box__item" @click="onEvent(v)">
          <image class="list-box__item__img" :src="onImageToThemeImage(v.src)" mode=""></image>
          <view class="list-box__item__name">
            <text>{{ v.title }}</text>
            <text
              v-if="v.content"
              :class="{ dot: v.type === 'idCard' && +realNameStatus !== 2 }"
              class="font-size-24rpx font-400"
            >
              {{ v.content }}
            </text>
          </view>
          <!-- <image
              class="list-box__item__arrows"
              src="@/static/images/user/arrows.png"
              mode=""
            ></image> -->
          <wd-icon
            custom-class="color-[var(--arrow-color)]"
            name="arrow-right"
            size="30rpx"
          ></wd-icon>
        </view>
        <wd-select-picker
          v-else
          use-default-slot
          v-model="selectValue"
          type="radio"
          :columns="exchangeRateList"
          @confirm="onSelectConfirm"
          filterable
        >
          <view class="list-box__item">
            <image class="list-box__item__img" :src="onImageToThemeImage(v.src)" mode=""></image>
            <view class="list-box__item__name">
              <text>{{ v.title }}</text>
              <text v-if="v.content" class="font-size-24rpx font-400">
                {{ v.content }}
              </text>
            </view>
            <!-- <image
                class="list-box__item__arrows"
                src="@/static/images/user/arrows.png"
                mode=""
              ></image> -->
            <wd-icon
              custom-class="color-[var(--arrow-color)]"
              name="arrow-right"
              size="30rpx"
            ></wd-icon>
          </view>
        </wd-select-picker>
      </template>
    </view>
  </view>
  <view
    class="fixed bottom-10rpx left-0 right-0 text-center font-size-18rpx color-[var(--text-inactive)]"
  >
    Version {{ versionName }}-{{ formatDate(buildTime) }}
  </view>
</template>

<script lang="ts" setup>
import vipLevel from '../vip/components/vip-level.vue'
import { t } from '@/locale'
import { useMessage } from 'wot-design-uni'
import { useUserStore, useSystemStore, useThemeStore } from '@/store'
import { onImageToThemeImage, onRouter } from '@/utils'
import { formatDate } from '@/utils/day'
import { versionName } from '@/manifest.json'
import { onUnsubscribe } from '@/utils/subscribe'
import config from '@/config'

const buildTime = document.querySelector('html').getAttribute('build-time')

const message = useMessage()
const userStore = useUserStore()
const { onService } = useSystemStore()
const themeStore = useThemeStore()

const userInfo = computed(() => {
  return userStore.userInfo ? userStore.userInfo : {}
})

const exchangeRateList = computed(() => {
  return userStore.exchangeRateList.map((item) => {
    return {
      value: item.id,
      label: item.quote_currency,
      ...item,
    }
  })
})

const selectValue = computed(() => {
  return userStore.exchangeRateCurrent && userStore.exchangeRateCurrent.id
})

const realNameStatus = computed(() => {
  return +userStore.userInfo.real_name_status || 0
})

const card = computed(() => {
  return [
    {
      title: t('user.bank'),
      src: '/static/images/user/bank-account.png',
      type: 'bank',
      url: '/pages/user/bank/index',
    },
    {
      title: t('user.safe'),
      src: '/static/images/user/password.png',
      type: 'nav',
      url: '/pages/user/security/index',
    },
  ]
})

const list = computed<any>(() => {
  return [
    [
      {
        title: t('user.idCard'),
        src: '/static/images/user/id-card.png',
        content: realNameStatus.value === 2 ? t('user.verified') : t('user.unverified'),
        url: '/pages/user/kyc/index',
        type: 'idCard',
      },
      {
        title: t('user.exchangeRates'),
        src: '/static/images/user/exchange-rates.png',
        content: userStore.exchangeRateCurrent && userStore.exchangeRateCurrent.quote_currency,
        type: 'select',
      },
    ],
    [
      {
        title: t('user.service'),
        src: '/static/images/user/customer-service.png',
        type: 'service',
      },
      {
        title: t('user.aboutUs'),
        src: '/static/images/user/about-us.png',
        url: `/pages/news/details?code=gywm1`,
        type: 'nav',
      },
      {
        title: t('user.clearCache'),
        src: '/static/images/user/clear.png',
        type: 'clear',
      },
    ],
    [
      {
        title: t('user.logout'),
        src: '/static/images/user/log-out.png',
        url: '/pages/auth/sign-in',
        type: 'logout',
      },
    ],
  ]
})

onShow(() => {
  userStore.getUserInfo()
})

const onSelectConfirm = ({ value, selectedItems }) => {
  userStore.onSetExchangeRateCurrent(selectedItems)
}

const onEvent = (e) => {
  const status = realNameStatus.value
  switch (e.type) {
    case 'bank':
      if (status === 2) {
        return onRouter(e.url)
      }
      if (status === 1 || status === -1) {
        return onRouter('/pages/user/kyc/details/index')
      }
      message
        .confirm({
          title: t('user.tips'),
          confirmButtonText: t('user.kycDialog.confirmButtonText'),
          msg: t('user.kycDialog.msg'),
        })
        .then(() => {
          onRouter('/pages/user/kyc/index')
        })
      break
    case 'idCard':
      if (status !== 0) {
        onRouter('/pages/user/kyc/details/index')
      } else {
        onRouter(e.url)
      }
      break
    case 'clear':
      message.alert(t('user.clearSuccess'))
      break
    case 'logout':
      message
        .confirm({
          title: t('user.tips'),
          msg: t('user.logoutDialog.msg'),
        })
        .then(() => {
          config.c2cChat && onUnsubscribe(`refresh_${userInfo.value?.blade_user_id}`)
          onUnsubscribe(`notify_new_message_${userStore.userInfo?.blade_user_id}`)
          onUnsubscribe(`notify_new_message_all`)
          userStore.onLogout()
          uni.reLaunch({
            url: e.url,
          })
        })
      break
    case 'service':
      onService()
      break
    default:
      onRouter(e.url)
  }
}

const onShare = () => {
  const url = `${window.location.origin}/#/pages/auth/sign-up?code=${userStore.userInfo.promotion_code}`
  onCopy(url)
}

const onCopy = (data) => {
  uni.setClipboardData({
    data,
    success: function () {
      uni.showToast({
        title: t('user.copySuccess'),
        icon: 'none',
        duration: 2000,
      })
    },
  })
}
</script>

<style lang="scss" scoped>
.message {
  flex: 1;
  padding-left: 20rpx;

  &__name {
    font-size: 28rpx;
    color: var(--text-primary);
  }

  &__uid {
    display: flex;
    gap: 10rpx;
    align-items: center;
    margin-top: 20rpx;
    font-size: 24rpx;
    color: var(--text-secondary);
  }
}

.share_img {
  position: relative;
  z-index: 2;
  width: 100%;
  height: 168rpx;
  background: url('/static/images/user/share.png') no-repeat;
  background-size: 100%;
}

.operation-box {
  box-sizing: border-box;
  display: flex;
  padding-top: 88rpx;
  padding-bottom: 42rpx;
  margin-top: -48rpx;
  background-color: var(--background-primary);
  border-radius: 20rpx;

  &__item {
    flex: 1;
    text-align: center;

    &__img {
      width: 56rpx;
      height: 56rpx;
    }

    &__name {
      margin-top: 10rpx;
      font-size: 28rpx;
      font-weight: 500;
    }
  }
}

.list-box {
  padding: 0 30rpx;
  margin-top: 30rpx;
  background-color: var(--background-primary);
  border-radius: 20rpx;
  &__item {
    display: flex;
    align-items: center;
    height: 116rpx;
    + .list-box__item {
      border-top: 1rpx solid var(--background-gary-4);
    }
    &__img {
      width: 56rpx;
      height: 56rpx;
    }

    &__name {
      display: flex;
      flex: 1;
      align-items: center;
      justify-content: space-between;
      padding-right: 10rpx;
      padding-left: 20rpx;
      font-size: 28rpx;
      font-weight: 500;
      color: var(--text-primary);
      .dot {
        position: relative;
      }
      .dot::after {
        position: absolute;
        top: calc(50% - 4rpx);
        left: -20rpx;
        display: block;
        width: 8rpx;
        height: 8rpx;
        content: '';
        background-color: var(--color-red);
        border-radius: 50%;
      }
    }

    &__arrows {
      width: 30rpx;
      height: 30rpx;
    }
  }
}

.page {
  background: var(--background-secondary) var(--background-linear-gradient-2) no-repeat;
  background-size: 100% 403rpx;
}

.page.dark {
  .message__uid {
    color: var(--text-active);
  }
}
</style>
