<template>
  <!-- <wd-tabs
    custom-class="app-tabs--tag app-tabs--tag-info app-tabs--no-flex-1 mt-30rpx"
    :model-value="1"
    swipeable
    animated
    :map-num="100"
  >
    <block v-for="(item, index) in ['7Days', '15Days', '30Days']" :key="index">
      <wd-tab :title="item"></wd-tab>
    </block>
  </wd-tabs> -->
  <app-empty :no-data="list.length === 0">
    <product-list :list="list" @click="handleClick"></product-list>
    <wd-loadmore :state="loadMoreState" />
  </app-empty>
  <!-- popup -->
  <product-popup v-model="showPopup" :row-data="rowData"></product-popup>
</template>

<script lang="ts" setup>
import ProductList from './product-list.vue'
import ProductPopup from './product-popup.vue'
import { fetchGetProductList } from '@/service/copy'

const mode = inject<Ref<'spot' | 'futures'>>('mode', ref('spot'))
const pagePath = inject<Ref<'home' | 'user'>>('pagePath')
const showPopup = ref(false)
const rowData = ref<any>({})

const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
  onLoadMore,
} = usePagination({
  api: (params) => {
    return fetchGetProductList({
      size: params.pageSize,
      current: params.pageNo,
      nickname: '',
      type: mode.value === 'spot' ? 1 : 2,
    })
  },
  params: {},
  // onLoadMoreFn: onReachBottom,
})

watch(mode, () => {
  getList()
})

onShow(() => {
  getList()
})

onReachBottom(() => {
  if (pagePath.value === 'home') {
    onLoadMore()
  }
})

const handleClick = (item: any) => {
  rowData.value = item
  showPopup.value = true
}
</script>

<style lang="scss" scoped>
//
</style>
