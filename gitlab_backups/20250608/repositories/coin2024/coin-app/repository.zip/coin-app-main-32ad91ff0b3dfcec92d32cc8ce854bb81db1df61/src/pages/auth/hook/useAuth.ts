export default function useAuth() {
  const tabs = ['auth.phone', 'auth.email']
  const tabsIndex = ref(0)
  const isTab = ref(false)
  const isTwoFactor = ref(true)

  return {
    tabs,
    tabsIndex,
    isTab,
    isTwoFactor,
  }
}
