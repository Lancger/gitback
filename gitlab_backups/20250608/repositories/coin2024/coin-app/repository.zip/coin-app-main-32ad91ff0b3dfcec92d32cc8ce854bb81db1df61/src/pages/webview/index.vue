<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar v-if="!hideNavbar" :title="title" left-arrow></app-navbar>
  <iframe
    :src="url"
    :class="[hideNavbar ? 'h-100vh' : 'h-[calc(100vh-44px)]']"
    class="w-100% bg-[var(--background-primary)] border-none"
  ></iframe>
</template>

<script lang="ts" setup>
const appName = import.meta.env.VITE_APP_TITLE
const title = ref('')
const url = ref('')
const hideNavbar = ref(false)

onLoad((options) => {
  console.log(options)
  title.value = options.title || appName
  url.value = decodeURIComponent(options.url)
  hideNavbar.value = /(ichatlink|meiqia)/.test(url.value)

  console.log(hideNavbar.value)
})
</script>

<style lang="scss" scoped></style>
