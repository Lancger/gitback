<template>
  <wd-overlay :show="modelValue" :z-index="99" @click="onClose">
    <view class="wrapper">
      <view id="capture" class="poster">
        <view class="flex items-center justify-between">
          <view class="flex items-center gap-10rpx">
            <image
              v-if="userStore.userInfo.avatar"
              class="w-45rpx h-45rpx rd-50%"
              :src="userStore.userInfo.avatar"
              mode="aspectFit"
            />
            <image v-else class="w-45rpx h-45rpx rd-50%" src="@img/avatar.png" mode="aspectFit" />
            <!-- <view class="font-size-22rpx">UID: {{ userStore.userInfo.uid }}</view> -->
          </view>
          <view class="font-size-20rpx">{{ formatDate(dayjs()) }}</view>
        </view>
        <view class="font-size-30rpx mt-50rpx">
          {{ rowData.symbol_name }} {{ $t('components.futuresPoster.perpetual') }}
        </view>
        <view class="flex items-center gap-20rpx mt-20rpx font-size-24rpx">
          <view
            :class="[
              +rowData.direction === 1 || +rowData.direction === 3 ? 'up-color' : 'down-color',
            ]"
            class="pr-20rpx b-r"
          >
            <template v-if="+rowData.direction === 1">
              {{ $t('components.tradeHistoryList.open') }}({{
                $t('components.tradeHistoryList.long')
              }})
            </template>
            <template v-if="+rowData.direction === 2">
              {{ $t('components.tradeHistoryList.open') }}({{
                $t('components.tradeHistoryList.short')
              }})
            </template>
            <template v-if="+rowData.direction === 3">
              {{ $t('components.tradeHistoryList.close') }}({{
                $t('components.tradeHistoryList.long')
              }})
            </template>
            <template v-if="+rowData.direction === 4">
              {{ $t('components.tradeHistoryList.close') }}({{
                $t('components.tradeHistoryList.short')
              }})
            </template>
          </view>
          <view class="pr-20rpx b-r">{{ rowData.leverage }}</view>
          <view>
            {{ (rowData.entrust_balance || rowData.balance) + tradeStore.futuresConfig.unitLabel }}
            {{ +rowData.direction < 3 ? $t('components.futuresPoster.holding') : null }}
          </view>
        </view>
        <view
          :class="[rowData.pl > 0 ? 'up-color' : 'down-color']"
          class="mt-30rpx font-size-100rpx font-600"
        >
          {{ rowData.pl >= 0 ? '+' : null }}{{ rowData.plRatio || '0.00%' }}
        </view>
        <!-- <view :class="[rowData.pl > 0 ? 'up-color' : 'down-color']" class="font-size-22rpx">
          {{ rowData.pl > 0 ? '+' : null }}{{ rowData.pl }} USDT
        </view> -->
        <view class="flex items-center gap-20rpx mt-70rpx">
          <view>{{ $t('components.futuresPoster.entryPrice') }}</view>
          <view>{{ toFormat(rowData.avg_price, true) }}</view>
        </view>
        <view class="flex items-center gap-20rpx mt-10rpx">
          <view>
            {{
              +rowData.direction >= 3
                ? $t('components.futuresPoster.exitPrice')
                : $t('components.futuresPoster.lastPrice')
            }}
          </view>
          <view>{{ toFormat(rowData.closePrice, true) }}</view>
        </view>
        <!-- <view class="flex items-center gap-10rpx mt-30rpx">
          <view>{{ $t('components.futuresPoster.referralCode') }}</view>
          <view>{{ userStore.userInfo.promotion_code }}</view>
        </view> -->
        <!-- <view class="absolute bottom-50rpx right-30rpx">
          <vue-qr
            class="w-200rpx h-200rpx"
            id="qrcode"
            :text="link"
            :margin="0"
            logo-src=""
          ></vue-qr>
        </view> -->
      </view>
      <wd-button custom-class="mt-30rpx" size="large" icon="download" @click="onSave">
        {{ $t('common.download') }}
      </wd-button>
    </view>
  </wd-overlay>
</template>

<script lang="ts" setup>
import _ from 'lodash'
import dayjs from 'dayjs'
import html2canvas from 'html2canvas'
import vueQr from 'vue-qr/src/packages/vue-qr.vue'
import { useUserStore, useTradeStore } from '@/store'
import { toFormat } from '@/utils/number'
import { formatDate } from '@/utils/day'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  rowData: {
    type: Object,
    default: () => ({}),
  },
})

const emits = defineEmits(['update:modelValue'])

const userStore = useUserStore()
const tradeStore = useTradeStore()

const link = `${window.location.origin}/#/pages/auth/sign-up?code=${userStore.userInfo.promotion_code}`

const onSave = () => {
  html2canvas(document.querySelector('#capture')).then(function (canvas) {
    const url = canvas.toDataURL()
    uni.previewImage({
      urls: [url],
    })
    // const randomString = _.sampleSize(
    //   'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
    //   10,
    // ).join('')
    // const a = document.createElement('a')
    // a.href = url
    // a.download = randomString
    // a.click()
    // nextTick(() => {
    //   a.remove()
    // })
  })
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;

  .poster {
    position: relative;
    box-sizing: border-box;
    width: 80%;
    min-height: 650rpx;
    padding: 40rpx 30rpx 60rpx;
    background-color: var(--background-primary);
    border-radius: 10rpx;
  }
}
</style>
