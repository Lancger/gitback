<template>
  <view class="trade-order-list">
    <view v-for="(item, index) in list" :key="index" class="trade-order-list__item">
      <view class="order-countdown">
        <view class="order-countdown__title">{{ $t('options.positionList.countdown') }}</view>
        <view class="order-countdown__content">
          <wd-count-down
            :time="dayjs(item.end_time_number).valueOf() - dayjs().valueOf()"
            @finish="emits('onCountDownEnd')"
          >
            <template #default="{ current }">
              <text class="custom-count-down">{{ current.hours }}</text>
              <text class="custom-count-down-colon">:</text>
              <text class="custom-count-down">{{ current.minutes }}</text>
              <text class="custom-count-down-colon">:</text>
              <text class="custom-count-down">{{ current.seconds }}</text>
            </template>
          </wd-count-down>
        </view>
      </view>
      <view class="flex items-center">
        <view class="token-info">
          <!-- <image class="token-info__logo" src="@img/avatar.png" /> -->
          <view class="token-info__name">{{ item.pair_name }}-{{ item.time_name }}</view>
        </view>
        <!-- <view class="position-lever">Cross/combined 10X</view> -->
      </view>
      <view class="flex items-center mt-20rpx">
        <view class="tag-list">
          <view :class="[item.up_down === 1 ? 'buy' : 'sell']" class="tag-list__item">
            {{ item.up_down === 1 ? $t('options.up') : $t('options.down') }}
          </view>
          <view class="tag-list__item">{{ $t('options.title') }}</view>
        </view>
        <view class="order-date">{{ formatDate(item.begin_time) }}</view>
      </view>
      <view class="order-detail">
        <view class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('options.positionList.orderNumber') }}
          </view>
          <view class="order-detail__item__content">{{ item.order_no }}</view>
        </view>
        <view class="order-detail__item text-right">
          <view class="order-detail__item__title">
            {{ $t('options.positionList.orderAmount') }}
          </view>
          <view class="order-detail__item__content">{{ item.bet_amount }} USDT</view>
        </view>
        <view class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('options.positionList.deliveryTime') }}
          </view>
          <view class="order-detail__item__content">{{ formatDate(item.end_time) }}</view>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { formatDate } from '@/utils/day'
import dayjs from 'dayjs'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
})

const emits = defineEmits(['onCountDownEnd'])
</script>

<style lang="scss" scoped>
.trade-order-list {
  border-top: 1px solid var(--border-color-inactive);
  &__item {
    position: relative;
    padding: 30rpx;
    border-bottom: 1px solid var(--border-color-inactive);
    .order-countdown {
      position: absolute;
      top: 34rpx;
      right: 30rpx;
      z-index: 1;
      &__title {
        font-size: 22rpx;
        color: var(--text-inactive);
        text-align: right;
      }
      &__content {
        margin-top: 18rpx;
      }
      .custom-count-down {
        display: inline-block;
        width: 32rpx;
        font-size: 20rpx;
        line-height: 32rpx;
        color: #fff;
        text-align: center;
        background-color: var(--color-primary);
        border-radius: 5rpx;
      }

      .custom-count-down-colon {
        display: inline-block;
        margin: 0 10rpx;
        color: var(--color-primary);
      }
    }
    .order-btn {
      position: absolute;
      top: 30rpx;
      right: 30rpx;
      height: 40rpx;
      font-size: 20rpx;
    }
    .token-info {
      display: flex;
      align-items: center;
      &__logo {
        width: 40rpx;
        height: 40rpx;
        border-radius: 50%;
      }
      &__name {
        // margin-left: 20rpx;
        font-size: 30rpx;
        font-weight: 500;
      }
    }
    .tag-list {
      display: flex;
      gap: 10rpx;
      align-items: center;
      &__item {
        height: 30rpx;
        padding: 0 14rpx;
        font-size: 20rpx;
        line-height: 30rpx;
        background: var(--background-gary-4);
        border-radius: 5rpx;
      }
      &__item.buy {
        color: var(--color-green);
        background: #07ba831a;
      }
      &__item.sell {
        color: var(--color-red);
        background: #ff4e431a;
      }
    }
    .order-date {
      margin-left: 20rpx;
      font-size: 22rpx;
      color: var(--text-inactive);
    }
    .order-detail {
      display: flex;
      flex-wrap: wrap;
      gap: 20rpx 0;
      margin-top: 30rpx;
      &__item {
        box-sizing: border-box;
        width: 33.33%;
        &:nth-of-type(3n - 1) {
          text-align: center;
        }
        &:nth-of-type(3n) {
          text-align: right;
        }
        &__title {
          font-size: 22rpx;
          color: var(--text-inactive);
        }
        &__content {
          margin-top: 20rpx;
          font-size: 22rpx;
          font-weight: 500;
        }
      }
    }
    .position-lever {
      position: relative;
      padding-left: 10rpx;
      margin-left: 10rpx;
      font-size: 25rpx;
      font-weight: 500;
      &::after {
        position: absolute;
        top: 50%;
        left: 0;
        width: 1px;
        height: 24rpx;
        content: '';
        background: var(--border-color);
        transform: translateY(-50%);
      }
    }
  }
}
</style>
