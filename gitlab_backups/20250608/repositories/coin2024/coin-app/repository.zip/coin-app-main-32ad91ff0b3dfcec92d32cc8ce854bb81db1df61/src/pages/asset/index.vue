<route lang="json5" type="page">
{
  layout: 'tabbar',
}
</route>

<template>
  <wd-tabs
    custom-class="app-tabs app-tabs--no-flex-1"
    v-model="tabIndex"
    swipeable
    animated
    :map-num="100"
    @click="onTabs"
  >
    <block v-for="(item, index) in walletList" :key="index">
      <wd-tab :title="item.name" :name="item.type"></wd-tab>
    </block>
  </wd-tabs>
  <!-- card -->
  <view class="wallet">
    <view class="px-15rpx">
      <view class="flex items-center justify-between">
        <view class="flex items-center gap-20rpx">
          <view class="flex items-center gap-10rpx">
            <text class="font-size-32rpx font-500">{{ $t('assets.index.account') }}</text>
            <text class="color-[var(--wallet-name-color)]">{{ walletData.name }}</text>
          </view>
          <wd-icon
            :name="isAssetsHide ? 'eye-close' : 'view'"
            size="30rpx"
            @click="isAssetsHide = !isAssetsHide"
          ></wd-icon>
        </view>
        <view
          class="flex items-center gap-10rpx"
          @click="onRouter(`/pages/asset/details/index?billsType=${tabIndex}`)"
        >
          <image
            class="w-28rpx h-28rpx"
            :src="onImageToThemeImage('/static/images/assets/bil.png')"
            mode="aspectFit"
          />
          <view class="font-size-28rpx font-500 color-[var(--bills-text-color)]">
            {{ $t('assets.index.bills') }}
          </view>
        </view>
      </view>
      <view class="flex items-end mt-30rpx gap-20rpx">
        <view class="font-size-60rpx font-600 color-[var(--color-primary)]">
          {{ onAssetsHide(toFormat(walletData.usdt || walletData.balanceUsdt)) }}
        </view>
        <view class="pb-10rpx font-size-22rpx font-500">USDT</view>
      </view>
      <view class="mt-20rpx font-size-26rpx color-[var(--text-inactive)]">
        ≈
        {{
          onAssetsHide(
            userStore.onExchangeRateConversion(walletData.usdt || walletData.balanceUsdt, 2),
          )
        }}
        {{ userStore.exchangeRateCurrent.quote_currency }}
      </view>
    </view>
    <view class="flex gap-20rpx mt-45rpx">
      <wd-button
        v-if="tabIndex === '0' || tabIndex === '1'"
        :round="false"
        custom-class="flex-1"
        @click="onRouter('/pages/asset/deposit/index')"
      >
        {{ $t('assets.index.deposit') }}
      </wd-button>
      <wd-button
        v-if="tabIndex === '0' || tabIndex === '1'"
        plain
        :round="false"
        custom-class="flex-1"
        @click="onRouter('/pages/asset/withdraw/index')"
      >
        {{ $t('assets.index.withdraw') }}
      </wd-button>
      <wd-button
        plain
        :round="false"
        custom-class="flex-1"
        @click="onRouter('/pages/asset/transfer/index')"
      >
        {{ $t('assets.index.transfer') }}
      </wd-button>
      <wd-button
        v-if="tabIndex === '7'"
        plain
        :round="false"
        custom-class="flex-1"
        @click="onRouter('/pages/home/earn/index')"
      >
        {{ $t('assets.index.earnCoins') }}
      </wd-button>
    </view>
  </view>
  <!-- list -->
  <wd-skeleton
    :loading="loading && list.length === 0 && tabIndex !== '0'"
    animation="flashed"
    :row-col="[
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
    ]"
  >
    <!-- 0 -->
    <view v-if="tabIndex == '0'">
      <template v-for="(v, i) in walletList" :key="i">
        <view
          v-if="+v.type !== 0"
          class="flex items-center rd-20rpx my-20rpx mx-30rpx px-30rpx py-25rpx bg-[var(--wallet-bg)]"
          @click="onTabs({ name: v.type })"
        >
          <image class="w-60rpx h-60rpx mr-30rpx" :src="onIconsUrl(v.type)" mode="aspectFit" />
          <view class="flex-1 font-size-28rpx font-500">{{ v.name }}</view>
          <view class="text-right">
            <view class="font-size-26rpx font-500">
              {{ onAssetsHide(toFormat(v.usdt || v.balanceUsdt)) }}
              <text class="font-size-22rpx font-400">USDT</text>
            </view>
            <view class="mt-10rpx color-[var(--text-inactive)]">
              {{ onAssetsHide(userStore.onExchangeRateConversion(v.usdt || v.balanceUsdt, 2)) }}
            </view>
          </view>
        </view>
      </template>
    </view>
    <!-- 1 -->
    <block v-if="tabIndex == '1' || tabIndex == '4' || tabIndex == '7'">
      <block v-for="(v, i) in list" :key="i">
        <view
          v-if="+v.balance || +v.frozen_balance || v.symbol === 'USDT'"
          class="rd-20rpx my-20rpx mx-30rpx p-30rpx bg-[var(--wallet-bg)]"
        >
          <view class="flex justify-between items-center">
            <view class="flex items-center">
              <image class="w-50rpx h-50rpx mr-20rpx rd-50%" :src="v.avatar" mode="scaleToFill" />
              <view class="font-size-30rpx font-500">
                {{ v.symbol }}
                <!-- <text class="font-size-22rpx font-400 color-[var(--text-inactive)]">
                  /{{ v.full_name }}
                </text> -->
              </view>
            </view>
            <!-- <view v-if="tabIndex == '1' && config.spotPnL" class="text-right">
              <view class="font-size-22rpx color-[var(--text-inactive)]">
                {{ $t('assets.index.totalPnL') }}
              </view>
              <view class="mt-10rpx font-size-26rpx font-500 break-all">
                <text :class="v.total_income >= 0 ? 'up-color' : 'down-color'">
                  {{ onAssetsHide(toFormat(v.total_income || 0, v.base_coin_scale)) }}
                </text>
                USDT
              </view>
            </view> -->
            <!-- v-if="tabIndex == '4'" -->
            <view class="text-right">
              <view class="font-size-22rpx color-[var(--text-inactive)]">
                {{ $t('assets.index.valuation') }}
              </view>
              <view class="mt-10rpx font-size-26rpx font-500 break-all">
                {{ onAssetsHide(userStore.onExchangeRateConversion(v.usdt, 2)) }}
              </view>
            </view>
          </view>
          <view class="flex mt-40rpx">
            <view class="w-33.33%">
              <view class="font-size-22rpx color-[var(--text-inactive)]">
                {{ $t('assets.index.available') }}
              </view>
              <view class="mt-10rpx font-size-26rpx font-500 break-all">
                {{ onAssetsHide(toFormat(v.balance || 0, v.base_coin_scale)) }}
              </view>
            </view>
            <view class="w-33.33% text-center">
              <view class="font-size-22rpx color-[var(--text-inactive)]">
                {{ $t('assets.index.frozen') }}
              </view>
              <view class="mt-10rpx font-size-26rpx font-500 break-all">
                {{ onAssetsHide(toFormat(v.frozen_balance || 0, v.base_coin_scale)) }}
              </view>
            </view>
            <view v-if="tabIndex === '1' && config.spotPnL" class="w-33.33% text-right">
              <view class="font-size-22rpx color-[var(--text-inactive)]">
                {{ $t('assets.index.totalPnL') }}
              </view>
              <view
                :class="v.total_income >= 0 ? 'up-color' : 'down-color'"
                class="mt-10rpx font-size-26rpx font-500 break-all"
              >
                {{ onAssetsHide(toFormat(v.total_income || 0, v.base_coin_scale)) }}
              </view>
            </view>
            <view v-if="tabIndex === '4'" class="w-33.33% text-right">
              <view class="font-size-22rpx color-[var(--text-inactive)]">
                {{ $t('assets.index.unrealizedPnL') }}
              </view>
              <view class="mt-10rpx font-size-26rpx font-500 break-all">
                {{ onAssetsHide(toFormat(v.unprofit || 0, v.base_coin_scale)) }}
              </view>
            </view>
          </view>
        </view>
      </block>
    </block>

    <block v-if="tabIndex == '2' || tabIndex == '8' || tabIndex == '9'">
      <view class="flex mx-30rpx px-30rpx font-size-22rpx color-[var(--text-inactive)]">
        <view class="flex-1">{{ $t('assets.index.crypto') }}</view>
        <view class="w-30% text-right">{{ $t('assets.index.available') }}</view>
        <view class="w-30% text-right">{{ $t('assets.index.valuation') }}</view>
      </view>
      <block v-for="(v, i) in list" :key="i">
        <view
          v-if="+v.balance || +v.frozen_balance || v.symbol === 'USDT'"
          class="flex items-center mx-30rpx my-20rpx p-30rpx bg-[var(--background-primary)] rd-20rpx"
        >
          <view class="flex items-center flex-1">
            <image class="w-50rpx h-50rpx mr-20rpx rd-50%" :src="v.avatar" mode="scaleToFill" />
            <view class="font-size-30rpx font-500">
              {{ v.symbol }}
              <!-- <text class="font-size-22rpx font-400 color-[var(--text-inactive)]">
                /{{ v.full_name }}
              </text> -->
            </view>
          </view>
          <view class="w-30% text-right font-size-26rpx font-500 break-all">
            {{ onAssetsHide(toFormat(v.balance || 0, v.base_coin_scale)) }}
          </view>
          <view class="w-30% text-right font-size-26rpx font-500 break-all">
            {{ onAssetsHide(userStore.onExchangeRateConversion(v.usdt, 2)) }}
          </view>
        </view>
      </block>
    </block>
  </wd-skeleton>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchGetCurrencyAccount, fetchGetWalletAccount } from '@/service/assets'
import { useUserStore } from '@/store'
import { onImageToThemeImage, onRouter } from '@/utils'
import { toFormat } from '@/utils/number'
import config from '@/config'

const userStore = useUserStore()
const tabIndex = ref<string>('0')
const walletList = ref<any>([])
const isAssetsHide = ref(false)
const loading = ref(true)
const listMap = ref({})

const walletData = computed(() => {
  return walletList.value.find((item) => item.type === tabIndex.value) || {}
})

const list = computed(() => {
  return listMap.value[tabIndex.value] || []
})

onShow(async () => {
  await getWallet()
  getList(tabIndex.value)
  loading.value = false
})

const onIconsUrl = (type) => {
  if (type === '1') {
    return '/static/images/assets/wallet.png'
  } else if (type === '2') {
    return '/static/images/assets/spot.png'
  } else if (type === '4') {
    return '/static/images/assets/futures.png'
  } else if (type === '7') {
    return '/static/images/assets/finance.png'
  } else if (type === '8') {
    return '/static/images/assets/spot.png'
  } else if (type === '9') {
    return '/static/images/assets/options.png'
  }
}

const onAssetsHide = (val) => {
  return isAssetsHide.value ? '*****' : val
}

const onTabs = async (event) => {
  tabIndex.value = event.name
  loading.value = true
  getWallet()
  await getList(tabIndex.value)
  loading.value = false
}

const getList = (type: any) => {
  return fetchGetCurrencyAccount({
    type,
  }).then((res) => {
    listMap.value[type] = res.data
  })
}

const getWallet = () => {
  return fetchGetWalletAccount().then((res) => {
    walletList.value = res.data
    const lastElement = walletList.value[walletList.value.length - 1]
    lastElement.name = t('assets.index.overview')
    lastElement.balanceUsdt = lastElement.balanceUsdt || lastElement.usdt
    walletList.value.unshift(lastElement)
    walletList.value.splice(-1, 1)
  })
}
</script>

<style lang="scss" scoped>
:deep(.app-tabs) {
  border-bottom: 1px solid #f1f1f1;
}
.wallet {
  box-sizing: border-box;
  width: 690rpx;
  height: 379rpx;
  padding: 30rpx 25rpx 0;
  margin: 20rpx auto;
  background: url('/static/images/assets/bg.png') no-repeat;
  background-size: 100%;
}
.page {
  --wallet-bg: var(--background-primary);
  --bills-text-color: var(--color-primary);
  --wallet-name-color: var(--text-active);
  background: var(--background-secondary) var(--background-linear-gradient-3) no-repeat;
  background-size: 100% 726rpx;
}
.page.dark {
  --wallet-bg: var(--background-secondary);
  --bills-text-color: var(--color-white);
  --wallet-name-color: var(--color-white);
  background: var(--background-primary) var(--background-linear-gradient-3) no-repeat;
  background-size: 100% 726rpx;

  :deep(.app-tabs) {
    border-bottom: none;
  }
  :deep(.wd-tabs__nav-item) {
    color: rgba(255, 255, 255, 0.8) !important;
  }
  :deep(.wd-tabs__nav-item.is-active) {
    color: var(--color-white) !important;
  }

  .wallet {
    background: url('/static/images/assets/dark/bg.png') no-repeat;
    background-size: 100%;
  }
}
</style>
