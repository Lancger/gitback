<template>
  <app-navbar :title="$t('earnNew.detail.title')"></app-navbar>
  <view class="main px-30rpx">
    <view class="flex items-center gap-20rpx py-30rpx">
      <view class="flex items-center gap-20rpx">
        <image
          class="w-42rpx h-42rpx rd-50%"
          :src="productInfo.coinAvatar || productInfo.coin_avatar"
        />
        <view class="font-size-30rpx font-500">
          {{ productInfo.coinName || productInfo.coin_name }}
        </view>
      </view>
      <view class="w-1px h-24rpx bg-[var(--border-color)]"></view>
      <view
        class="h-30rpx line-height-30rpx px-8rpx font-size-20rpx bg-[var(--background-gary-4)] rd-5rpx"
      >
        {{ mode === 0 ? $t('earnNew.flexible') : $t('earnNew.fixed') }}
      </view>
    </view>
    <view class="px-30rpx py-15rpx rd-10rpx bg-[var(--background-tertiary)]">
      <view class="flex items-center justify-between py-15rpx font-size-28rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.apr') }}</view>
        <view>{{ toFormatPercent((+productInfo.rateYear || +productInfo.rate_year) * 100) }}</view>
      </view>
      <view v-if="mode === 1" class="flex items-center justify-between py-15rpx font-size-28rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('earnNew.term') }}</view>
        <view>{{ productInfo.day }} {{ $t('earnNew.day') }}</view>
      </view>
    </view>
    <!-- charts -->
    <view v-if="mode === 0 && showInterestRateChart === 'true'" class="mt-20rpx">
      <interest-rate-chart :id="productInfo.id" />
    </view>
    <!-- <view
      v-if="mode === 1"
      class="px-30rpx py-30rpx mt-40rpx border border-[var(--border-color)] border-solid rd-20rpx"
    >
      <view class="flex items-center justify-between">
        <view>
          {{ $t(`earnNew.subscribed`) }}
          <text class="font-size-20rpx color-[var(--text-inactive)]">
            ({{ productInfo.coinName || productInfo.coin_name }})
          </text>
        </view>
        <view>
          {{ $t(`earnNew.total`) }}
          <text class="font-size-20rpx color-[var(--text-inactive)]">
            ({{ productInfo.coinName || productInfo.coin_name }})
          </text>
        </view>
      </view>
      <view style="--wot-progress-height: 22rpx; --wot-progress-padding: 0" class="my-20rpx">
        <wd-progress
          :percentage="(productInfo.total_buy_cou * 100) / productInfo.buy_total_cou"
          color="''"
          hide-text
        />
      </view>
      <view class="flex items-center justify-between font-size-22rpx color-[var(--text-active)]">
        <view>{{ toFormat(productInfo.total_buy_cou, true) }}</view>
        <view>{{ toFormat(productInfo.buy_total_cou, true) }}</view>
      </view>
    </view> -->
    <view>
      <view class="py-30rpx">{{ $t(`earnNew.amount`) }}</view>
      <view
        class="flex items-center gap-20rpx h-90rpx px-30rpx border border-[var(--border-color)] border-solid rd-10rpx"
      >
        <input
          v-model="amount"
          class="flex-1 font-size-30rpx"
          type="digit"
          :placeholder="$t(`earnNew.min`) + ' ' + min"
          @input="onInput"
        />
        <view class="font-size-30rpx">{{ productInfo.coinName || productInfo.coin_name }}</view>
        <wd-button
          type="info"
          plain
          size="small"
          custom-class="!h-42rpx font-size-22rpx"
          @click="onMax"
        >
          {{ $t(`earnNew.max`) }}
        </wd-button>
      </view>
      <view v-if="mode === 1" class="mt-26rpx font-size-22rpx">
        <text class="color-[var(--text-inactive)] mr-10rpx">
          {{ $t(`earnNew.estimatedTotalRevenue`) }}
        </text>
        <text>{{ pl }} {{ productInfo.coinName || productInfo.coin_name }}</text>
      </view>
      <view class="mt-26rpx font-size-22rpx">
        <text class="color-[var(--text-inactive)] mr-10rpx">{{ $t(`earnNew.available`) }}</text>
        <text>{{ balance }} {{ productInfo.coinName || productInfo.coin_name }}</text>
      </view>
    </view>
    <view class="my-50rpx">
      <view class="mb-20rpx">
        <view class="flex gap-16rpx">
          <view class="w-40rpx flex justify-center">
            <view
              class="w-30rpx h-30rpx font-size-20rpx font-600 line-height-30rpx color-#fff text-center bg-[var(--color-primary)] rd-50%"
            >
              1
            </view>
          </view>
          <view class="font-size-24rpx">{{ $t(`earnNew.subscriptionTime`) }}</view>
        </view>
        <view class="flex gap-16rpx mt-16rpx">
          <image class="w-40rpx h-40rpx" src="../../static/images/earn/arrows_down.png" />
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ formatDate(date.subTime) }}
          </view>
        </view>
      </view>
      <view class="mb-20rpx">
        <view class="flex gap-16rpx">
          <view class="w-40rpx flex justify-center">
            <view
              class="w-30rpx h-30rpx font-size-20rpx font-600 line-height-30rpx color-#fff text-center bg-[var(--color-primary)] rd-50%"
            >
              2
            </view>
          </view>
          <view class="font-size-24rpx">{{ $t(`earnNew.interestAccrualTime`) }}</view>
        </view>
        <view class="flex gap-16rpx mt-16rpx">
          <image class="w-40rpx h-40rpx" src="../../static/images/earn/arrows_down.png" />
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ formatDate(date.startTime) }}
          </view>
        </view>
      </view>
      <view class="mb-20rpx">
        <view class="flex gap-16rpx">
          <view class="w-40rpx flex justify-center">
            <view
              class="w-30rpx h-30rpx font-size-20rpx font-600 line-height-30rpx color-#fff text-center bg-[var(--color-primary)] rd-50%"
            >
              3
            </view>
          </view>
          <view class="font-size-24rpx">
            {{ mode === 0 ? $t(`earnNew.firstDistributionTime`) : $t(`earnNew.coinDepositPeriod`) }}
          </view>
        </view>
        <view class="flex gap-16rpx mt-16rpx">
          <view class="font-size-22rpx color-[var(--text-inactive)] ml-56rpx">
            {{ formatDate(date.endTime) }}
          </view>
        </view>
      </view>
    </view>
    <view class="my-30rpx font-size-30rpx">{{ $t(`earnNew.faq`) }}</view>
    <wd-collapse v-model="values">
      <wd-collapse-item
        v-for="(item, index) in 6"
        :key="index"
        :title="$t(`earnNew.detail.faq${index + 1}.title`)"
        :name="String(index)"
      >
        {{ $t(`earnNew.detail.faq${index + 1}.content`) }}
      </wd-collapse-item>
    </wd-collapse>
  </view>
  <app-footer background="var(--background-primary)" shadow>
    <view class="px-30rpx py-20rpx">
      <wd-button custom-class="!w-100%" size="large" :loading="loading" @click="onSubmit">
        {{ $t(`earnNew.subscribe`) }}
      </wd-button>
    </view>
  </app-footer>
</template>

<script lang="ts" setup>
import InterestRateChart from './components/interest-rate-chart.vue'
import dayjs from 'dayjs'
import { t } from '@/locale'
import { onRouter } from '@/utils'
import { BNumber, toFormat, toFixed, inputLimitToDigit, toFormatPercent } from '@/utils/number'
import {
  fetchFlexibleItemDetail,
  fetchFixedItemDetail,
  fetchFlexibleSubmit,
  fetchFixedSubmit,
  fetchWallet,
} from '@/service/earn'
import { formatDate } from '@/utils/day'

const showInterestRateChart = import.meta.env.VITE_SHOW_INTEREST_RATE_CHART

const values = ref<string[]>([''])
const mode = ref(0) // 0 活期 1 定期
const productId = ref('')
const productInfo = ref<any>({})
const loading = ref(false)
const amount = ref<any>('')
const balance = ref(0)
const date = reactive<any>({
  subTime: null,
  startTime: null,
  endTime: null,
})

const min = computed(() => {
  return productInfo.value.buyMinCou || productInfo.value.buy_min_cou
})

const pl = computed(() => {
  if (productInfo.value.goods_type === 1) {
    return toFixed(BNumber(amount.value || 0).times(productInfo.value.rate_year))
  }
  return toFixed(
    BNumber(amount.value || 0)
      .times(productInfo.value.day / 365)
      .times(productInfo.value.rate_year),
  )
})

onLoad((options) => {
  mode.value = +options.t
  productId.value = options.id
  getInfo()
})

async function onSubmit() {
  if (+amount.value < min.value) {
    uni.showToast({
      title: `${t('earnNew.min')} ${min.value}`,
      icon: 'none',
    })
    return
  }
  loading.value = true
  try {
    const form = {
      buyCou: amount.value,
      wealthGoodsId: productId.value,
    }
    if (mode.value === 0) {
      await fetchFlexibleSubmit(form)
    } else {
      await fetchFixedSubmit(form)
    }
    onRouter('/pages/earn/result', 'redirectTo')
  } catch (error) {
    loading.value = false
  }
}

const onMax = () => {
  amount.value = balance.value
}

const onInput = (e) => {
  const value = inputLimitToDigit(e.detail.value, min.value > 0 ? BNumber(min.value).dp() : 2) || ''
  nextTick(() => {
    amount.value = value
  })
}

function getInfo() {
  if (mode.value === 0) {
    return fetchFlexibleItemDetail(productId.value).then((res) => {
      productInfo.value = res.data
      date.subTime = res.data.nowTime
      date.startTime = res.data.currentStartTime
      date.endTime = res.data.currentEndTime
      getWallet(res.data.coinName)
    })
  } else {
    return fetchFixedItemDetail(productId.value).then((res) => {
      productInfo.value = res.data
      date.subTime = dayjs().valueOf()
      date.startTime = dayjs().add(2, 'day').valueOf()
      date.endTime = dayjs()
        .add(+res.data.day + 2, 'day')
        .valueOf()
      getWallet(res.data.coin_name)
    })
  }
}

function getWallet(token) {
  return fetchWallet(token).then((res) => {
    balance.value = res.data.wealthBalance
  })
}
</script>

<style lang="scss" scoped>
.main {
  --wot-collapse-header-padding: 40rpx 0;
  --wot-collapse-title-fs: 28rpx;
  --wot-fw-medium: 400;
  --wot-collapse-body-padding: 40rpx 0;
  --wot-collapse-body-fs: 24rpx;
}
</style>
