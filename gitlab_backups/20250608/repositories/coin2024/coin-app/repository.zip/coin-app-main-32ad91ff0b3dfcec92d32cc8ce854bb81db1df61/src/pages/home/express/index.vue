<template>
  <app-navbar custom-class="bg-transparent">
    <template #title>
      <view class="search-box flex" @click="show = true">
        {{ $t('c2c.express.index.title') }}
        <wd-icon name="caret-down-small" size="22px"></wd-icon>
      </view>
    </template>
    <template #right>
      <image
        @click="onRouter('/pages/home/ctwoc/history/index?serviceType=1')"
        class="w32rpx h32rpx"
        :src="onImageToThemeImage('/static/images/icons/records.png')"
      ></image>
    </template>
  </app-navbar>
  <view class="pl-3 pr-3">
    <view class="buysell flex-jc">
      <view class="buysell_box">
        <view :class="index === 2 ? 'buysell_buy' : 'buysell_sell'" @click="payclick(2)">
          {{ $t('c2c.express.index.buy') }}
        </view>
        <view :class="index === 1 ? 'buysell_buy' : 'buysell_sell'" @click="payclick(1)">
          {{ $t('c2c.express.index.sell') }}
        </view>
      </view>
    </view>
    <view v-if="index === 2">
      <view class="crypto">{{ $t('c2c.express.index.youPay') }}</view>
      <view class="flex buy">
        <view class="w70">
          <wd-input
            type="number"
            no-border
            v-model="harvestNum"
            :placeholder="
              buyMin
                ? $t('common.min') + ' ' + toFormat(buyMin)
                : $t('c2c.express.index.pleaseEnter')
            "
            @input="inputNum('harvestNum')"
          />
        </view>
        <view class="buy_type" @click="buyShow = true">
          <image class="w-40rpx h-40rpx mr2 ml1" :src="listObj.receiveIcon" />
          <text class="buy_text">{{ listObj.fiat_currency }}</text>
          <wd-icon name="caret-down-small" size="20px" v-if="!buyShow"></wd-icon>
          <wd-icon name="caret-up-small" size="20px" v-else></wd-icon>
        </view>
      </view>
      <view class="crypto">{{ $t('c2c.express.index.youReceive') }}</view>
      <view class="flex buy">
        <view class="w70">
          <wd-input
            type="number"
            no-border
            v-model="payOutNum"
            :placeholder="
              buyMin
                ? $t('common.min') + ' ' + toFormat((buyMin / rate).toFixed(2))
                : $t('c2c.express.index.pleaseEnter')
            "
            @input="inputNum('payOutNum')"
          />
        </view>
        <view class="buy_type" @click="sellShow = true">
          <image class="w-40rpx h-40rpx mr2 ml1" :src="listObj.payIcon" />
          <text class="buy_text">{{ listObj.coin_symbol }}</text>
          <wd-icon name="caret-down-small" size="20px" v-if="!sellShow"></wd-icon>
          <wd-icon name="caret-up-small" size="20px" v-else></wd-icon>
        </view>
      </view>
    </view>
    <view v-else>
      <view class="crypto">{{ $t('c2c.express.index.youSell') }}</view>
      <view class="flex buy">
        <view class="w70">
          <wd-input
            type="number"
            no-border
            v-model="payOutNum"
            :placeholder="$t('c2c.express.index.pleaseEnter')"
            @input="inputNum('payOutNum')"
          />
        </view>
        <view class="buy_type" @click="sellShow = true">
          <image class="w-40rpx h-40rpx mr2 ml1" :src="listObj.payIcon" />
          <text class="buy_text">{{ listObj.coin_symbol }}</text>
          <wd-icon name="arrow-down" size="14px" v-if="!sellShow"></wd-icon>
          <wd-icon name="arrow-up" size="14px" v-else></wd-icon>
        </view>
      </view>
      <view class="available">
        {{ $t('c2c.express.index.available') }}
        <text class="ml-1">{{ available }} {{ listObj.coin_symbol }}</text>
        <text class="ml-2" @click="onRouter('/pages/asset/transfer/index')">
          {{ $t('c2c.express.index.transfer') }}
        </text>
      </view>
      <view class="crypto">{{ $t('c2c.express.index.youReceive') }}</view>
      <view class="flex buy">
        <view class="w70">
          <wd-input
            type="number"
            no-border
            v-model="harvestNum"
            :placeholder="$t('c2c.express.index.pleaseEnter')"
            @input="inputNum('harvestNum')"
          />
        </view>
        <view class="buy_type" @click="buyShow = true">
          <image class="w-40rpx h-40rpx mr2 ml1" :src="listObj.receiveIcon" />
          <text class="buy_text">{{ listObj.fiat_currency }}</text>
          <wd-icon name="arrow-down" size="14px" v-if="!buyShow"></wd-icon>
          <wd-icon name="arrow-up" size="14px" v-else></wd-icon>
        </view>
      </view>
    </view>
    <view class="text">
      {{ 1 + listObj.coin_symbol || 0 }} = {{ rate || 0 + listObj.fiat_currency || 0 }}
      <view class="flex">
        <wd-count-down
          ref="countDown"
          custom-class="count-down"
          :time="time"
          format="ss"
          @finish="finish"
        />
        <text>{{ $t('c2c.express.index.sRefresh') }}</text>
      </view>
    </view>
    <view class="btn">
      <view class="btn_subscribe" v-if="!forbidden">
        {{ $t('c2c.express.index.selectPaymentMethod') }}
      </view>
      <view class="btn_subscribewhine" v-else @click="navigator">
        {{ $t('c2c.express.index.selectPaymentMethod') }}
      </view>
    </view>

    <view class="glide" @click="onRouter(`/pages/home/ctwoc/history/index?serviceType=1`)">
      {{ $t('c2c.express.index.pendingOrder') }}
    </view>

    <wd-message-box selector="wd-message-box-slot"></wd-message-box>

    <wd-popup v-model="show" position="bottom" custom-style="height: 200px;">
      <view class="popup">
        <view class="popup_icon" @llick="show = false">
          <wd-icon name="close" size="18px" color="#878787"></wd-icon>
        </view>

        <view
          class="popup_list"
          v-for="(v, i) in columns"
          :key="i"
          @click="(onRouter(v.url, 'redirectTo'), (show = false))"
        >
          <image class="w-43rpx h-42rpx mr2 ml1" :src="onImageToThemeImage(v.icon)" />
          <text class="popup_text">{{ v.name }}</text>
        </view>
      </view>
    </wd-popup>
    <!-- 购买或者卖出的弹框 -->
    <buy-popup
      @close="buyShow = false"
      @upData="upData"
      :buyShow="buyShow"
      :buyValue="buyValue"
      :buyColumns="buyColumns"
    ></buy-popup>
    <!-- 付出或者收获的弹框 -->
    <sell-popup
      @close="sellShow = false"
      @upData="upData"
      :sellShow="sellShow"
      :sellValue="sellValue"
      :sellColumns="sellColumns"
    ></sell-popup>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchOneclick, fetchGetDataRete, fetchSubmitOrder } from '@/service/ctwoc'
import { fetchGetCurrencyAccount } from '@/service/assets'
import { toFormat, BNumber } from '@/utils/number'
import { useMessage } from 'wot-design-uni'
import { onImageToThemeImage, onRouter } from '@/utils'
import { useUserStore } from '@/store'
import { fetchGetData, fetchGetPayment } from '@/service/user'
import buyPopup from './component/buyPopup.vue'
import sellPopup from './component/sellPopup.vue'

const userInfo = useUserStore().userInfo
const message = useMessage('wd-message-box-slot')
const listObj = ref<any>({})
const payOutNum = ref()
const harvestNum = ref<any>('')
const title = ref('')
const time = ref<number>(30 * 1000)
const countDown = ref<any>(null)
const buyShow = ref(false)
const show = ref<boolean>(false)
const buyValue = ref('')
const buyColumns = ref([]) // 选择要购买或者卖出的币种
const sellShow = ref(false)
const sellValue = ref('')
const sellColumns = ref([]) // 选择要付出或者收获的币种
const index = ref(2) // 判断当前是买还是卖 2是买 1是卖
const account = ref<any>([]) // 币种余额
const currency = ref<any>({}) // 页面币种集合
const exchangeData = ref([]) // 汇率数据
const coinId = ref(0) // 选择要购买或者卖出的id
const countryId = ref(0) // 选择要付出或者收获的id
const myPayMethods = ref([]) // 判断有无银行卡
const buyMin = ref(0)

const columns = [
  {
    name: t('c2c.index.express'),
    icon: '/static/images/home/exp.png',
    url: '/pages/home/express/index',
  },
  {
    name: t('c2c.index.c2c'),
    icon: '/static/images/home/ctc.png',
    url: '/pages/home/ctwoc/index',
  },
]

onShow((e) => {
  // listObj.value = uni.getStorageSync('ctwoc')
  initialData()
})
const rate = computed(() => {
  let rate = 0
  // 计算汇率
  exchangeData.value.forEach((item) => {
    if (
      item.base_currency === listObj.value.coin_symbol &&
      item.quote_currency === listObj.value.fiat_currency
    ) {
      rate = item.rate
    }
  })
  return rate
})
const available = computed(() => {
  let available = ''
  // 计算余额
  account.value.forEach((item) => {
    if (item.symbol === listObj.value.coin_symbol) {
      available = `${toFormat(item.balance || 0)}`
    }
  })
  return available
})
const initialData = () => {
  fetchGetCurrencyAccount({
    type: 1,
  }).then((res) => {
    account.value = res.data
  })
  fetchOneclick().then((res) => {
    currency.value = res.data[0]
    regroup()
  })
  fetchGetDataRete({
    pageSize: -521,
    column: 'id',
    order: 'desc',
  }).then((res) => {
    exchangeData.value = res.data.records
  })
  fetchGetData().then((res) => {
    console.log(res)
    myPayMethods.value = res.data.records
    fetchGetPayment().then((ress) => {
      myPayMethods.value = myPayMethods.value.map((item) => {
        ress.data.forEach((child) => {
          if (item.id === child.pay_method_id) {
            item.data = child
          }
        })
        return item
      })
    })
  })
}
const regroup = () => {
  // 购买或者卖出的币种
  buyColumns.value = currency.value.country.filter((item) => {
    return index.value === 2 ? item.is_buy === '1' : item.is_sell === '1'
  })
  // 付出或者收获的币种
  sellColumns.value = currency.value.coin.filter((item) => {
    return index.value === 2 ? item.is_buy === '1' : item.is_sell === '1'
  })
  const buyItem =
    buyColumns.value.find(
      (item) =>
        item.local_currency === (listObj.value.fiat_currency || import.meta.env.VITE_CURRENCY),
    ) || buyColumns.value[0]
  const sellItem =
    sellColumns.value.find((item) => item.symbol === (listObj.value.coin_symbol || 'USDT')) ||
    sellColumns.value[0]
  listObj.value.receiveIcon = buyItem.currency_icon
  listObj.value.fiat_currency = buyItem.local_currency
  countryId.value = buyItem.id
  listObj.value.payIcon = sellItem.avatar
  listObj.value.coin_symbol = sellItem.symbol
  coinId.value = sellItem.id
  buyMin.value = buyItem.min_recharge_amount || 0
}
const inputNum = (name) => {
  if (name === 'payOutNum') {
    harvestNum.value = BNumber(payOutNum.value).times(rate.value).toFixed(2).toString()
  } else {
    payOutNum.value = BNumber(harvestNum.value).div(rate.value).toFixed(2).toString()
  }
}
const navigator = () => {
  console.log(countryId.value)

  // if (userInfo.real_name_status !== '2') {
  //   message
  //     .confirm({
  //       msg: t('c2c.express.index.kycDialog.msg'),
  //       title: t('c2c.express.index.kycDialog.title'),
  //       confirmButtonText: t('c2c.express.index.kycDialog.confirmButtonText'),
  //     })
  //     .then((res) => {
  //       uni.navigateTo({
  //         url: '/pages/user/kyc/index',
  //       })
  //     })
  //   return
  // } else if (index.value === 1) {
  //   const skfsArr = myPayMethods.value.filter(
  //     (item) => item.data && item.data.country_id === countryId.value,
  //   )
  //   const isBindPayS = myPayMethods.value.filter((item) => item.data)
  //   if (isBindPayS.length) {
  //     if (skfsArr.length === 0) {
  //       // 绑卡不合适
  //       return message
  //         .confirm({
  //           msg: t('c2c.express.index.bankDialog.msg'),
  //           title: t('c2c.express.index.bankDialog.title'),
  //           confirmButtonText: t('c2c.express.index.bankDialog.confirmButtonText'),
  //         })
  //         .then((res) => {
  //           uni.navigateTo({
  //             url: '/pages/user/bank/index',
  //           })
  //         })
  //     }
  //   } else {
  //     // 未绑卡提示
  //     return message
  //       .confirm({
  //         msg: t('c2c.express.index.unBankDialog.msg'),
  //         title: t('c2c.express.index.unBankDialog.title'),
  //         confirmButtonText: t('c2c.express.index.unBankDialog.confirmButtonText'),
  //       })
  //       .then((res) => {
  //         uni.navigateTo({
  //           url: '/pages/user/bank/index',
  //         })
  //       })
  //   }
  // }
  const obj = {
    coinCou: payOutNum.value,
    coinId: coinId.value,
    coinSymbol: listObj.value.coin_symbol,
    countryId: countryId.value,
    fiatCurrency: listObj.value.fiat_currency,
    fiatCurrencyAmount: harvestNum.value,
    payMethodId: currency.value.method[0].id,
    serviceType: 1,
    type: index.value === 2 ? 1 : 2,
  }

  const data = {
    sum: payOutNum.value,
    value: harvestNum.value,
    rate: rate.value,
    valueCree: {
      local_currency: listObj.value.fiat_currency,
    },
    valueCoin: {
      name: listObj.value.coin_symbol,
    },
    index: index.value,
    id: listObj.value.id,
  }
  uni.setStorageSync('buyAndSell', data)
  uni.setStorageSync('express', obj)
  // uni.navigateTo({
  //   url: '/pages/home/ctwoc/payment/index?type=express',
  // })
  onSubmitOrder()
}

function onSubmitOrder() {
  uni.showLoading()
  const obj = uni.getStorageSync('express')
  return fetchSubmitOrder(obj)
    .then((res) => {
      onRouter(`/pages/home/ctwoc/paid/index?id=${res.data}`, 'redirectTo')
    })
    .finally(() => {
      uni.hideLoading()
    })
}
const forbidden = computed(() => {
  return parseFloat(payOutNum.value) > 0 && parseFloat(harvestNum.value) > 0
})

const finish = () => {
  countDown.value.reset()
  initialData()
}

const payclick = (type) => {
  index.value = type
  console.log(rate.value)
}

// 弹框更新数据
const upData = (v, type) => {
  if (type === 'buyPopup') {
    listObj.value.receiveIcon = v.currency_icon
    listObj.value.fiat_currency = v.local_currency
    countryId.value = v.id
    buyShow.value = false
  } else {
    listObj.value.payIcon = v.avatar
    listObj.value.coin_symbol = v.symbol
    coinId.value = v.id
    sellShow.value = false
  }
}
</script>

<style lang="scss" scoped>
.popup {
  padding: 30rpx;
  &_icon {
    text-align: right;
  }
  &_list {
    display: flex;
    align-items: center;
    height: 108rpx;
    margin-top: 20rpx;
    font-size: 32rpx;
  }
  &_h {
    height: 400px;
    margin-top: 50rpx;
    overflow: auto;
  }
  &_cree {
    display: flex;
    align-items: center;
    width: 100%;
    // justify-content: center;
    height: 88rpx;
  }
}
.buysell {
  display: flex;
  align-items: center;
  width: 690rpx;
  margin: 20rpx auto;

  &_box {
    display: flex;
    align-items: center;
    width: 308rpx;
    height: 56rpx;
    padding: 0 5rpx;
    font-size: 26rpx;
    background-color: var(--background-gary-5);
    border-radius: 27rpx;
  }
  &_buy {
    width: 150rpx;
    height: 48rpx;
    font-weight: 500;
    line-height: 48rpx;
    color: var(--text-primary);
    text-align: center;
    background-color: var(--background-primary) !important;
    border-radius: 27rpx;
  }
  &_bg {
    background-color: var(--background-primary);
  }
  &_sell {
    width: 150rpx;
    height: 48rpx;
    line-height: 48rpx;
    color: var(--text-inactive);
    text-align: center;
    border-radius: 27rpx;
  }
}
.flex {
  display: flex;
  align-items: center;
  justify-content: center;
}

.glide {
  color: var(--text-primary);
  text-align: center;
  text-decoration: underline;
}
.btn {
  margin-top: 80rpx;
  &_subscribe {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--text-inactive) !important;
    text-align: center;
    background-color: var(--border-color-inactive);
    border-radius: 100rpx;
  }

  &_subscribewhine {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--wot-color-white) !important;
    text-align: center;
    background-color: #00a7ed;
    border-radius: 100rpx;
  }
}
.text {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 20rpx;
  color: var(--text-inactive);
  .count-down {
    color: var(--text-inactive);
  }
}
.available {
  margin-top: 20rpx;
  color: var(--text-inactive);
  text {
    color: var(--text-primary);
  }
}
.flex {
  display: flex;
  align-items: center;
}
.buy {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 100rpx;
  margin-top: 20rpx;
  border-bottom: 2rpx solid var(--border-color-active);
  &_type {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 198rpx;
    height: 72rpx;
    background: var(--background-gary-4);
    border-radius: 10rpx;
    image {
      border-radius: 50%;
    }
  }
}

.crypto {
  margin-top: 30rpx;
  margin-bottom: 10rpx;
  font-size: 30rpx;
}
</style>
