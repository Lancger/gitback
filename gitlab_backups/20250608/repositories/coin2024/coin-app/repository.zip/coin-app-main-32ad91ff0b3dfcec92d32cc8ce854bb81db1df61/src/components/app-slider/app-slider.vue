<template>
  <view class="app-slider">
    <div
      class="app-slider__tooltip"
      :style="`left: ${(100 / max) * sliderVal}%; opacity: ${labelVisible ? 1 : 0}`"
    >
      {{ (100 / max) * sliderVal }}%
    </div>
    <wd-slider
      v-model="sliderVal"
      :min="min"
      :max="max"
      hide-label
      hide-min-max
      active-color="''"
      @dragstart="onDragstart"
      @dragmove="onDragmove"
      @dragend="onDragend"
    />
    <view class="app-slider__num">
      <!-- :style="{ left: item.label }" -->
      <view
        v-for="(item, index) in options"
        :key="index"
        :style="{ left: `${(100 / max) * item.value}%` }"
        :class="{ active: sliderVal >= item.value }"
        class="app-slider__num__item"
        @click="onSliderTap(item.value)"
      >
        <view class="app-slider__num__item__dot"></view>
        <view class="app-slider__num__item__name">{{ item.label }}</view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
const props = defineProps({
  modelValue: {
    type: Number,
    default: 0,
  },
  min: {
    type: Number,
    default: 0,
  },
  max: {
    type: Number,
    default: 100,
  },
  options: {
    type: Array<any>,
    default: () => [
      {
        label: '0%',
        value: 0,
      },
      {
        label: '25%',
        value: 25,
      },
      {
        label: '50%',
        value: 50,
      },
      {
        label: '75%',
        value: 75,
      },
      {
        label: '100%',
        value: 100,
      },
    ],
  },
})

const labelVisible = ref<boolean>(false)

const emits = defineEmits(['update:modelValue'])

const sliderVal = ref(props.modelValue)

watchEffect(() => {
  sliderVal.value = props.modelValue
})

// watchEffect(() => {
//   emits('update:modelValue', sliderVal.value)
// })
const onSliderTap = (value) => {
  sliderVal.value = value
  emits('update:modelValue', value)
}
const onDragstart = ({ value }) => {
  labelVisible.value = true
  emits('update:modelValue', value)
}

const onDragmove = ({ value }) => {
  emits('update:modelValue', value)
}

const onDragend = ({ value }) => {
  labelVisible.value = false
  emits('update:modelValue', value)
}
</script>

<style lang="scss" scoped>
.app-slider {
  --wot-slider-line-color: var(--color-primary);
  position: relative;
  padding-bottom: 20rpx;
  :deep(.wd-slider) {
    height: 72rpx;
  }
  :deep(.wd-slider__button-wrapper) {
    z-index: 10;
  }
  :deep(.wd-slider__button) {
    // width: 24rpx;
    // height: 24rpx;
    // background: #fff;
    border: 4rpx solid var(--color-primary) !important;
    // box-shadow: none;
  }
  &__tooltip {
    position: absolute;
    top: -40rpx;
    left: 0;
    min-width: 50rpx;
    padding: 4rpx 12rpx;
    color: #fff;
    text-align: center;
    background: rgba(0, 0, 0, 0.8);
    border-radius: 10rpx;
    opacity: 0;
    transition: opacity 0.3s;
    transform: translateX(-50%);
    &::after {
      position: absolute;
      bottom: 0;
      left: 50%;
      width: 0;
      height: 0;
      content: '';
      border-top: 10rpx solid rgba(0, 0, 0, 0.8);
      border-right: 10rpx solid transparent;
      border-left: 10rpx solid transparent;
      transform: translate(-50%, 100%);
    }
  }
  &__num {
    position: absolute;
    top: 50%;
    right: 0;
    left: 0;
    display: flex;
    justify-content: space-between;
    transform: translateY(-18rpx);
    &__item {
      position: absolute;
      top: 0;
      left: 0;
      transform: translateX(-50%);
      &__dot {
        box-sizing: border-box;
        width: 16rpx;
        height: 16rpx;
        margin: auto;
        background: #fff;
        border: 4rpx solid var(--border-color);
        border-radius: 50%;
        &:last-child {
          margin: auto;
        }
      }

      &__name {
        margin-top: 14rpx;
        font-size: 20rpx;
        color: var(--text-inactive);
        text-align: center;
      }

      // &:first-child {
      //   .app-slider__num__item__dot {
      //     margin: 0;
      //   }
      // }
      // &:last-child {
      //   .app-slider__num__item__dot {
      //     margin: 0 0 0 auto;
      //   }
      // }
    }
    .active {
      .app-slider__num__item__dot {
        border-color: var(--color-primary);
      }
      .app-slider__num__item__name {
        color: var(--color-primary);
      }
    }
  }
}
</style>
