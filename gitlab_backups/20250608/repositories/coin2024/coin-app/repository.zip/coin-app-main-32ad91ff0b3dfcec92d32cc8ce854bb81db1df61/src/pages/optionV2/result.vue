<template>
  <view class="flex items-center justify-center flex-col h-100vh">
    <image class="w-200rpx h-200rpx" src="/static/images/result/success.png" mode="scaleToFill" />
    <view class="font-size-32rpx font-600 mt-30rpx">
      {{ $t('optionV2.successful') }}
    </view>
    <view class="font-size-30rpx font-500 mt-42rpx">
      {{ $t('optionV2.buy') }} {{ data.title }}
      {{ +data.mode === 1 ? $t('optionV2.up') : $t('optionV2.down') }}
      {{ $t('optionV2.option') }}.
    </view>
    <view class="font-size-22rpx color-[var(--text-inactive)] text-center mt-30rpx">
      {{ $t('optionV2.expirationDate') }} {{ formatDate(data.date) }}
    </view>
    <view
      class="w-514rpx font-size-22rpx color-[var(--text-inactive)] text-center lh-36rpx mt-42rpx"
    >
      {{ $t('optionV2.viewPositions') }}
    </view>
    <view class="w-100% flex items-center gap-20rpx px-30rpx mt-356rpx box-border">
      <wd-button custom-class="!flex-1" size="large" type="info" block @click="handleBack">
        {{ $t('optionV2.back') }}
      </wd-button>
      <wd-button custom-class="!flex-1" size="large" block @click="handleViewOrders">
        {{ $t('optionV2.viewOrders') }}
      </wd-button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'

const data = ref<any>({})

onLoad((options) => {
  data.value = options
})

const handleBack = () => {
  uni.navigateBack()
}

const handleViewOrders = () => {
  onRouter('/pages/optionV2/order/index', 'redirectTo')
}
</script>

<style lang="scss" scoped>
//
</style>
