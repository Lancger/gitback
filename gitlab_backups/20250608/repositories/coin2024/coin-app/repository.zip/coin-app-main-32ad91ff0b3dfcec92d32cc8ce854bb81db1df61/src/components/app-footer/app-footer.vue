<template>
  <view class="app-footer-bar">
    <view
      class="app-footer-bar__main"
      :class="{
        'app-footer-bar__main--show': modelValue,
        'app-footer-bar__main--shadow': shadow,
        'app-footer-bar__main--tabbar': isTabbar,
        'pb-safe': safe,
      }"
      :style="{ background }"
    >
      <slot></slot>
    </view>
    <view
      class="app-footer-bar__placeholder"
      :class="{
        'pb-safe': safe,
      }"
      :style="{ height: height + 'px' }"
      v-if="modelValue"
    ></view>
  </view>
</template>

<script setup>
const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  background: {
    type: String,
    default: '',
  },
  safe: {
    type: Boolean,
    default: true,
  },
  shadow: {
    type: Boolean,
    default: false,
  },
  isTabbar: {
    type: Boolean,
    default: false,
  },
})

const height = ref(0)

onMounted(() => {
  uni
    .createSelectorQuery()
    .in(this)
    .select('.app-footer-bar__main')
    .fields({
      node: true,
      size: true,
    })
    .exec((res) => {
      height.value = res[0].height + 10
    })
})
</script>

<style lang="scss" scoped>
// fix: 部分设备键盘弹出，定位元素挡住内容
// @media (min-aspect-ratio: 14 / 16) {
//   .app-footer-bar {
//     display: none;
//   }
// }
.app-footer-bar {
  &__main {
    position: fixed;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 5;
    transition: all 1s ease-in-out;
    transform: translateY(200%);
    &--tabbar {
      /* #ifdef H5 */
      bottom: var(--window-bottom);
      /* #endif */
    }
    &--shadow {
      box-shadow: var(--box-shadow);
    }
    &--show {
      transform: translateY(0);
    }
  }
}
</style>
