<template>
  <view class="market-trades">
    <view class="market-trades__head">
      <view class="market-trades__head__item">
        {{ $t('market.detail.marketTrades.price') }} (USDT)
      </view>
      <view class="market-trades__head__item">
        {{ $t('market.detail.marketTrades.amount') }} ({{ tokenConfig.coin_symbol }})
      </view>
      <view class="market-trades__head__item">{{ $t('market.detail.marketTrades.time') }}</view>
    </view>
    <view class="market-trades__list">
      <view v-for="(item, index) in list" :key="index" class="market-trades__list__item">
        <view
          :class="[item.direction ? 'up-color' : 'down-color']"
          class="market-trades__list__item-content"
        >
          {{ toFormat(item.price, tokenConfig.base_coin_scale) || '--' }}
        </view>
        <view class="market-trades__list__item-content">
          {{ toFormat(item.amount, tokenConfig.coin_coin_scale || tokenConfig.coin_scale) || '--' }}
        </view>
        <view class="market-trades__list__item-content">
          {{ item.time ? dayjs(item.time).format(config.dateFormat.HMS) : '--' }}
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import dayjs from 'dayjs'
import { toFormat } from '@/utils/number'
import config from '@/config'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  tokenConfig: {
    type: Object,
    default: () => ({}),
  },
})
</script>

<style lang="scss" scoped>
.market-trades {
  min-height: 60vh;
  &__head {
    box-sizing: border-box;
    display: flex;
    align-items: center;
    height: 60rpx;
    padding: 0 20rpx;
    border-bottom: 1px solid var(--background-gary-4);
    &__item {
      flex: 1;
      font-size: 22rpx;
      color: var(--text-inactive);
      &:nth-of-type(2) {
        text-align: center;
      }
      &:nth-of-type(3) {
        text-align: right;
      }
    }
  }
  &__list {
    padding: 15rpx 20rpx;
    &__item {
      display: flex;
      align-items: center;
      padding: 15rpx 0;
      &-content {
        flex: 1;
        font-size: 22rpx;
        &:nth-of-type(1) {
          font-weight: 500;
        }
        &:nth-of-type(2) {
          text-align: center;
        }
        &:nth-of-type(3) {
          color: var(--text-inactive);
          text-align: right;
        }
      }
    }
  }
}
</style>
