import BigNumber from 'bignumber.js'
import config from '@/config'

BigNumber.config({
  FORMAT: {
    // string to prepend
    prefix: '',
    // decimal separator
    decimalSeparator: config.decimalSeparator,
    // grouping separator of the integer part
    groupSeparator: config.groupingSeparator,
    // primary grouping size of the integer part
    groupSize: 3,
    // secondary grouping size of the integer part
    secondaryGroupSize: 0,
    // grouping separator of the fraction part
    fractionGroupSeparator: ' ',
    // grouping size of the fraction part
    fractionGroupSize: 0,
    // string to append
    suffix: '',
  },
})

/**
 * 数字格式化
 * @param num 值
 * @param decimal 精度
 * @returns 1,000
 */
export const toFormat = (num, decimal: number | boolean = 2) => {
  if (!num) return 0
  if (typeof decimal === 'boolean' && decimal) {
    decimal = BigNumber(num).dp()
  }
  return BigNumber(num).toFormat(+decimal as number, 1)
}

/**
 *  保留小数
 * @param num 值
 * @param decimal 精度
 * @returns 1.00
 */
export const toFixed = (num, decimal: number | boolean = 2) => {
  if (!num) return 0
  if (typeof decimal === 'boolean' && decimal) {
    decimal = BigNumber(num).dp()
  }
  return BigNumber(num).toFixed(+decimal as number, 1)
}

/**
 * 算术
 * 文档 https://mikemcl.github.io/bignumber.js/#bignumber
 * plus 加
 * minus 减
 * div 除
 * times 乘
 *
 * example BNumber(100).plus(10).div(20) // 5.5
 */
export const BNumber = BigNumber

/**
 * 限制输入为数字
 * @param value 值
 * @param decimal 精度
 * @returns string
 */
export const inputLimitToDigit = (value: string, decimal = 2) => {
  const reg = decimal === 0 ? /^\d+$/ : new RegExp(`^\\d+((\\.?)|(\\.?\\d{0,${decimal}}))$`)
  // true
  if (reg.test(value)) {
    return value
  }
  // NaN
  if (isNaN(Number(value))) {
    return ''
  }
  //
  if (/\./.test(value)) {
    const [val, dec] = value.split('.')

    if (decimal === 0) {
      return val
    }

    return value.substring(-1, value.length - (dec.length - decimal))
  }

  return ''
}

export function toFormatUnit(num, decimal?: number | boolean) {
  if (Math.abs(num) >= 1.0e12) {
    return toFormat(num / 1.0e12) + 'T'
  } else if (Math.abs(num) >= 1.0e9) {
    return toFormat(num / 1.0e9) + 'B'
  } else if (Math.abs(num) >= 1.0e6) {
    return toFormat(num / 1.0e6) + 'M'
  } else if (Math.abs(num) >= 1.0e3) {
    return toFormat(num / 1.0e3) + 'K'
  }
  return toFormat(num, decimal)
}

// 展示%数字
export const toFormatPercent = (num, decimal = 2) => {
  return `${toFormat(Number(num).toFixed(decimal), decimal)}%`
}
