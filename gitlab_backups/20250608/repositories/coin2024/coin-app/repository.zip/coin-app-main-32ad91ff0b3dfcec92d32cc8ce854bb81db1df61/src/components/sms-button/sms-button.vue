<template>
  <wd-button :loading="loading" :disabled="isDisabled" type="primary" size="small" @click="onSend">
    {{ isDisabled ? t('components.smsButton.time', { count }) : t('components.smsButton.send') }}
  </wd-button>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
const props = defineProps({
  api: {
    type: Function,
    default: () => {},
  },
  apiParams: {
    type: Object,
    default: null,
  },
  checkPass: {
    type: Function,
    default: null,
  },
})
const count = ref(60)
const loading = ref(false)
const isDisabled = ref(false)

const onCountDown = () => {
  if (count.value > 0) {
    isDisabled.value = true
    count.value--
    setTimeout(onCountDown, 1000)
  } else {
    isDisabled.value = false
    count.value = 60
  }
}

async function onSend() {
  if (props.checkPass) {
    if (!props.checkPass()) return
  }
  loading.value = true
  try {
    await props.api(props.apiParams)
    loading.value = false
    onCountDown()
  } catch (error) {
    loading.value = false
  }
}

defineExpose({
  onSend,
})
</script>

<style lang="scss" scoped>
//
</style>
