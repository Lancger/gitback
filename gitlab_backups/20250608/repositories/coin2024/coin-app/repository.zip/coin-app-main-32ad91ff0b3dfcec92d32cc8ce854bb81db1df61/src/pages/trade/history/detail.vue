<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar title="Order details"></app-navbar>
  <view class="wrap">
    <view class="font-size-30rpx font-700">BTC/USDT</view>
    <view class="tag-list">
      <view class="tag-list__item buy">Limit</view>
      <view class="tag-list__item buy">Buy</view>
      <view class="tag-list__item">Spot</view>
    </view>
    <view class="detail-list">
      <view class="detail-list__item">
        <view class="detail-list__item__label">Status</view>
        <view class="detail-list__item__value">Filled</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">Order type</view>
        <view class="detail-list__item__value">Limit order</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">Order price</view>
        <view class="detail-list__item__value">67,920.2 USDT</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">Order quantity</view>
        <view class="detail-list__item__value">67,920.2 USDT</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">Order amount</view>
        <view class="detail-list__item__value">67,920.2 USDT</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">TP/SL</view>
        <view class="detail-list__item__value">67,920.2 USDT</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">Fill price</view>
        <view class="detail-list__item__value">67,920.2 USDT</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">Filled</view>
        <view class="detail-list__item__value">0.00001 BTC</view>
      </view>
    </view>
    <view class="detail-list">
      <view class="detail-list__item">
        <view class="detail-list__item__label">Order total</view>
        <view class="detail-list__item__value">0.6 USDT</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">Fee</view>
        <view class="detail-list__item__value">0 BTC</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">Created</view>
        <view class="detail-list__item__value">03/18 18:52:16</view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { fetchOrderDetail } from '@/service/trade'
</script>

<style lang="scss" scoped>
.wrap {
  padding: 30rpx;
  .tag-list {
    display: flex;
    gap: 10rpx;
    align-items: center;
    margin: 20rpx 0 30rpx;
    &__item {
      height: 30rpx;
      padding: 0 14rpx;
      font-size: 20rpx;
      line-height: 30rpx;
      background: var(--background-gary-4);
      border-radius: 5rpx;
    }
    &__item.buy {
      color: var(--color-green);
      background: #07ba831a;
    }
    &__item.buy {
      color: var(--color-red);
      background: #ff4e431a;
    }
  }
  .detail-list {
    padding: 15rpx 0;
    border-top: 1px solid var(--background-gary-4);
    &__item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 15rpx 0;

      &__label {
        color: var(--text-inactive);
      }
    }
  }
}
</style>
