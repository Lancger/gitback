<template>
  <app-navbar :title="$t('safe.googlePage.title')" custom-class="!bg-transparent"></app-navbar>
  <view class="p-30rpx" v-if="!flag">
    <view class="input" @click="confirm">
      <text>{{ $t('safe.googlePage.h1') }}</text>
      <wd-icon name="arrow-right" size="22px"></wd-icon>
    </view>
    <view class="title">{{ $t('safe.googlePage.bindingSteps') }}</view>
    <view class="hint">{{ $t('safe.googlePage.p1') }}</view>
    <view class="hint">{{ $t('safe.googlePage.p2') }}</view>
    <view class="hint">{{ $t('safe.googlePage.p3') }}</view>
    <view class="secretKey">{{ secretKey }}</view>
    <view class="text-center">
      <wd-button @click="copy" class="mt-30rpx">{{ $t('safe.googlePage.copy') }}</wd-button>
    </view>
    <view class="mt-30rpx text-center">{{ $t('safe.googlePage.qrCode') }}</view>
    <view class="img">
      <vue-qr class="img_qrcode" ref="qrcode" :text="address" logo-src=""></vue-qr>
    </view>
    <wd-button class="mt-30rpx" block @click="show = true">
      {{ $t('safe.googlePage.nextStep') }}
    </wd-button>
    <wd-popup v-model="show" position="right" custom-style="width:100vw" @close="show = false">
      <view class="popup">
        <view class="popup-title">
          <view class="placeholder"></view>
          <view class="">{{ $t('safe.googlePage.popup.title') }}</view>
          <wd-icon class="icon" name="close" size="22px" @click="show = false"></wd-icon>
        </view>
        <view class="popup__hint">
          {{ $t('safe.googlePage.popup.desc') }}
        </view>
        <view>
          <!-- 密码输入框 -->
          <wd-password-input
            v-model="verificationCode"
            :mask="false"
            :gutter="10"
            :length="6"
            :focused="showKeyboard"
            @focus="showKeyboard = true"
          />
          <!-- 数字键盘 -->
          <wd-number-keyboard
            v-model="verificationCode"
            v-model:visible="showKeyboard"
            :maxlength="6"
            @close="showKeyboard = false"
          />
        </view>
        <wd-button class="mt-60rpx" size="large" block :disabled="disabled" @click="ok">
          {{ $t('common.confirm') }}
        </wd-button>
      </view>
    </wd-popup>
  </view>
  <!-- 重置页面 -->
  <view class="p-30rpx reset" v-else>
    <view class="head">
      <text>{{ $t('safe.googlePage.bind') }}</text>
    </view>
    <view class="hint">
      {{ $t('safe.googlePage.bindDesc') }}
    </view>
    <wd-button class="po-fixed" size="large" block @click="resetShow = true">
      {{ $t('safe.googlePage.reset') }}
    </wd-button>
  </view>
  <wd-popup
    v-model="resetShow"
    position="bottom"
    custom-style="height:70vh;paddingTop: 30rpx;"
    @close="resetShow = false"
    closable
  >
    <verification
      :title="$t('safe.googlePage.twoFactorTitle')"
      :hint="$t('safe.googlePage.twoFactorDesc')"
      type="google-authenticator"
      @hidePopup="hidePopup"
    ></verification>
  </wd-popup>
</template>

<script lang="ts" setup>
import { useMessage } from 'wot-design-uni'
import { t } from '@/locale'
import { fetchGetGoogleVerification, fetchGoogleVerificationBindingOrReset } from '@/service/user'
import { useUserStore } from '@/store'
import vueQr from 'vue-qr/src/packages/vue-qr.vue'
import verification from './components/verification.vue'
const userStore = useUserStore()
const message = useMessage()
const model = reactive({
  antiCode: '',
})
const secretKey = ref('')
const address = ref<string>('')
const show = ref(false)
const resetShow = ref(false)
const verificationCode = ref('')
const showKeyboard = ref(false)
const disabled = ref(true)
const qrcode = ref<typeof vueQr>()
const flag = ref(false)
onLoad(() => {
  fetchGetGoogleVerification({}).then((res) => {
    secretKey.value = res.data.secretKey
    address.value = res.data.qrCodeText
  })
  if (userStore.userInfo.google_key) {
    flag.value = true
  }
})
watch(verificationCode, (newVal) => {
  if (newVal.length === 6) {
    disabled.value = false
  } else {
    disabled.value = true
  }
})
const copy = () => {
  uni.setClipboardData({
    data: secretKey.value,
    success: function () {
      uni.showToast({
        title: t('common.success'),
        icon: 'none',
        duration: 2000,
      })
    },
  })
}
const confirm = () => {
  message.alert({
    title: t('safe.googlePage.message.title'),
    msg: t('safe.googlePage.message.msg'),
  })
}

const ok = () => {
  disabled.value = true
  uni.showLoading()
  fetchGoogleVerificationBindingOrReset({
    code: verificationCode.value,
    type: 1,
  })
    .then(() => {
      userStore.getUserInfo().then(() => {
        uni.showToast({
          title: t('common.success'),
          icon: 'none',
          success: function () {
            uni.navigateBack()
          },
        })
      })
    })
    .finally(() => {
      uni.hideLoading()
    })
}

const hidePopup = () => {
  flag.value = false
  resetShow.value = false
}
</script>

<style lang="scss" scoped>
:deep(.wd-password-input) {
  margin: 60rpx 0 0 !important;
}
:deep(.wd-password-input__item) {
  background: var(--background-tertiary) !important;
  border: 1px solid var(--border-color);
  border-radius: 10rpx !important;
}
.arrow {
  color: var(--text-inactive);
}
.input {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 90rpx;
  padding: 0 30rpx;
  font-size: 30rpx;
  color: var(--text-inactive);
  background-color: var(--input-bg-color);
  border: 1px solid var(--input-border-color);
}
.title {
  margin-top: 30rpx;
  font-size: 24rpx;
  font-weight: 500;
  color: var(--text-primary);
}
.hint {
  margin-top: 30rpx;
  font-size: 22rpx;
  color: var(--text-primary);
}

.secretKey {
  margin-top: 30rpx;
  font-weight: 600;
  text-align: center;
}
.img {
  width: 400rpx;
  height: 400rpx;
  margin: 30rpx auto 30rpx;
  &_qrcode {
    width: 400rpx;
    height: 400rpx;
  }
}
.popup {
  padding: 30rpx;
  .popup-title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 30rpx;
    font-weight: 500;
    color: var(--text-primary);
    text-align: center;
    .placeholder {
      width: 22px;
      height: 22px;
    }
  }
  &__hint {
    margin-top: 60rpx;
    font-size: 36rpx;
    color: var(--text-primary);
    text-align: center;
  }
}
.reset {
  .head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    text:nth-child(1) {
      font-size: 30rpx;
      font-weight: 500;
      color: var(--text-primary);
    }
    text:nth-child(2) {
      color: var(--text-inactive);
    }
  }
  .hint {
    margin-top: 40rpx;
    font-size: 26rpx;
    line-height: 30rpx;
    color: var(--text-primary);
  }
  .po-fixed {
    position: fixed;
    right: 30rpx;
    bottom: 30rpx;
    left: 30rpx;
  }
}
</style>
