import dayjs from 'dayjs'
import utc from 'dayjs/plugin/utc'
import timezone from 'dayjs/plugin/timezone'
import advancedFormat from 'dayjs/plugin/advancedFormat'

dayjs.extend(utc)
dayjs.extend(timezone)
dayjs.extend(advancedFormat)

const { VITE_FORMATDATE } = import.meta.env
export const formatDate = (date, format?) => {
  return dayjs(date).format(format || VITE_FORMATDATE)
}

export default dayjs
