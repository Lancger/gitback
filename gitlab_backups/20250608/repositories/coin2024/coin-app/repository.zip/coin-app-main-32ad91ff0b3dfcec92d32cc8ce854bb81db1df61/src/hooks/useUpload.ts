import Compressor from 'compressorjs'
import { t } from '@/locale'
// TODO: 别忘加更改环境变量的 VITE_UPLOAD_BASEURL 地址。
const VITE_UPLOAD_BASEURL = import.meta.env.VITE_UPLOAD_BASEURL

/**
 * useUpload 是一个定制化的请求钩子，用于处理上传图片。
 * @param formData 额外传递给后台的数据，如{name: '菲鸽'}。
 * @returns 返回一个对象{loading, error, data, run}，包含请求的加载状态、错误信息、响应数据和手动触发请求的函数。
 */
export default function useUpload<T = string>(formData: Record<string, any> = {}) {
  const loading = ref(false)
  const error = ref(false)
  const data = ref<T>()
  const run = () => {
    // #ifdef MP-WEIXIN
    // 微信小程序从基础库 2.21.0 开始， wx.chooseImage 停止维护，请使用 uni.chooseMedia 代替。
    // 微信小程序在2023年10月17日之后，使用本API需要配置隐私协议
    uni.chooseMedia({
      count: 1,
      mediaType: ['image'],
      success: (res) => {
        loading.value = true
        const tempFilePath = res.tempFiles[0].tempFilePath
        uploadFile<T>({ tempFilePath, formData, data, error, loading })
      },
      fail: (err) => {
        console.error('uni.chooseMedia err->', err)
        error.value = true
      },
    })
    // #endif
    // #ifndef MP-WEIXIN
    uni.showActionSheet({
      itemList: [t('common.camera'), t('common.album')],
      success: function (r) {
        uni.chooseImage({
          count: 1,
          sourceType: [r.tapIndex === 0 ? 'camera' : 'album'],
          success: (res) => {
            if (res.tempFiles[0].size <= 0) {
              uni.showToast({
                title: t('common.fileCannotBeEmpty'),
                icon: 'none',
              })
              return
            }
            loading.value = true
            const tempFilePath = res.tempFilePaths[0]
            uploadFile<T>({ tempFilePath, formData, data, error, loading })

            // const tempFiles = res.tempFiles[0]
            // const a = new Compressor(tempFiles, {
            //   quality: 0.6,
            //   convertSize: 3000000,
            //   success(result: any) {
            //     const tempFilePath = URL.createObjectURL(result)
            //     const fData = new FormData()
            //     // The third parameter is required for server
            //     fData.append('file', result, result.name)
            //     uploadFile<T>({ tempFilePath, formData, data, error, loading })
            //   },
            //   error(err) {
            //     error.value = true
            //     uni.showToast({
            //       title: err.message,
            //       icon: 'none',
            //     })
            //   },
            // })
          },
          fail: (err) => {
            console.error('uni.chooseImage err->', err)
            error.value = true
          },
        })
      },
    })
    // #endif
  }

  return { loading, error, data, run }
}

function uploadFile<T>({ tempFilePath, formData, data, error, loading }) {
  uni.uploadFile({
    url: `${VITE_UPLOAD_BASEURL}/api/mjkj-web/cgform-api/upload/file`,
    filePath: tempFilePath,
    name: 'file',
    formData,
    success: (uploadFileRes) => {
      const uploadData = JSON.parse(uploadFileRes.data)
      data.value = uploadData.data
    },
    fail: (err) => {
      console.error('uni.uploadFile err->', err)
      error.value = true
    },
    complete: () => {
      loading.value = false
    },
  })
}
