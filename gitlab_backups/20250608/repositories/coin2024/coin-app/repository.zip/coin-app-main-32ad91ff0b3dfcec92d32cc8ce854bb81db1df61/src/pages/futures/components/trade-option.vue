<template>
  <view :key="chartKey" class="bg-[var(--background-primary)] rd-t-20rpx">
    <view class="w-100% h-700rpx">
      <k-line-chart
        v-if="tokenItem.base_coin_scale"
        :symbol="tokenItem.symbolName"
        :topicSymbol="tokenItem.subText"
        k-type="ubw"
        :precision="tokenItem.base_coin_scale"
        :chart-style="10"
        :showVol="false"
        :showMA="false"
        showLine
      ></k-line-chart>
      <view v-else class="center w-100% h-100%">
        <wd-loading :size="30" />
      </view>
    </view>
  </view>

  <wd-skeleton
    :loading="list.length === 0"
    animation="flashed"
    :row-col="[
      { margin: '30rpx 30rpx 0', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
    ]"
  >
    <view class="product-list">
      <view
        v-for="(item, index) in list"
        :key="index"
        class="product-list__item"
        @click="onRouter(`/pages/option/index?id=${item.id}`)"
      >
        <view class="flex items-center justify-between">
          <view class="flex items-center">
            <image class="product-list__item__cover" :src="item.avatar" mode="aspectFit" />
            <view class="product-list__item__name">
              <text class="font-500">{{ item.contract.split('/')[0] }}</text>
              <text class="font-size-22rpx color-[var(--text-inactive)]">
                /{{ item.contract.split('/')[1] }}
              </text>
            </view>
          </view>
          <view
            :class="[item.rate >= 0 ? 'up-color' : 'down-color']"
            class="product-list__item__rate"
          >
            {{ toFormatPercent(item.rate || 0) }}
          </view>
        </view>
        <view class="product-list__item__btn">
          <view class="product-list__item__btn-item buy">
            <view class="product-list__item__btn-item__title">{{ $t('options.up') }}</view>
            <view class="product-list__item__btn-item__ratio">
              {{ item.scenePairList[0].up_odds.odds }}
            </view>
          </view>
          <view class="product-list__item__btn-item sell">
            <view class="product-list__item__btn-item__title">{{ $t('options.down') }}</view>
            <view class="product-list__item__btn-item__ratio">
              {{ item.scenePairList[0].down_odds.odds }}
            </view>
          </view>
        </view>
      </view>
    </view>
  </wd-skeleton>
</template>

<script lang="ts" setup>
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'
import { fetchOptionsList } from '@/service/options'
import { fetchGetFutures, fetchGetOptions } from '@/service/market'
import { BNumber, toFixed, toFormatPercent } from '@/utils/number'
import { onRouter } from '@/utils'

const list = ref([])
const subMap = {
  all_symbol_detail: onUpdate,
}
const optionsList = ref([])
const tokenItem = ref<any>({})
const chartKey = ref('')

onLoad(async () => {
  await getOptions()
  await getList()
  nextTick(() => {
    tokenItem.value = optionsList.value[0]
    list.value.forEach((item) => {
      optionsList.value.forEach((v) => {
        if (v.symbolName === item.contract) {
          item.rate = v.zdf
        }
      })
    })
  })
})

onShow(() => {
  nextTick(() => {
    chartKey.value = Date.now().toString()
  })
  onSubscribe(getSubTopic())
  uni.$on('message', onMessage)
})

// onHide(() => {
//   onUnsubscribe(getSubTopic())
//   uni.$off('message', onMessage)
// })

onUnload(() => {
  onUnsubscribe(getSubTopic())
  uni.$off('message', onMessage)
})

function getSubTopic() {
  if (subscribeMode === 'mqtt') {
    return Object.keys(subMap)
  } else {
    return [
      ...optionsList.value
        .filter((item) => Boolean(item.subText))
        .map((item) => `ws.market.CSPOT.${item.subText}.1`),
    ]
  }
}

function onMessage(msgData) {
  const [topic, data] = msgData
  if (subMap[topic]) {
    subMap[topic](data)
  }
}

function onUpdate(data) {
  if (data.type !== 'ubw' && subscribeMode === 'mqtt') return
  list.value.forEach((item, index) => {
    if (item.contract === data.symbolName && subscribeMode === 'mqtt') {
      item.rate = data.zdf
    }
    if (item.subText === data.symbol && subscribeMode === 'ws') {
      item.rate = data.zdf
    }
  })
}

function getOptions() {
  return fetchGetOptions().then((res) => {
    optionsList.value = res.data
  })
}

function getList() {
  return fetchOptionsList().then((res) => {
    list.value = res.data
  })
}
</script>

<style lang="scss" scoped>
.product-list {
  padding: 30rpx;
  &__item {
    padding: 30rpx;
    margin-bottom: 20rpx;
    background: var(--background-primary);
    border-radius: 20rpx;
    &__cover {
      width: 50rpx;
      height: 50rpx;
      border-radius: 50%;
    }
    &__name {
      padding: 0 20rpx;
      font-size: 30rpx;
    }
    &__rate {
      font-size: 32rpx;
      font-weight: 500;
    }
    &__btn {
      display: flex;
      gap: 20rpx;
      align-items: center;
      margin-top: 20rpx;
      &-item {
        display: flex;
        flex: 1;
        align-items: center;
        justify-content: space-between;
        height: 70rpx;
        padding: 0 30rpx;
        border-radius: 100rpx;
        &__title {
          font-size: 30rpx;
          font-weight: 500;
        }
        &__ratio {
          font-size: 22rpx;
          color: var(--text-active);
        }
      }
      &-item.buy {
        color: var(--color-green);
        background: #07ba8314;
      }
      &-item.sell {
        color: var(--color-red);
        background: #ff4e4314;
      }
    }
  }
}
</style>
