<template>
  <app-navbar></app-navbar>
  <!--  -->
  <view class="text-center pt-200rpx">
    <image
      class="block w-100rpx h-100rpx m-auto"
      src="/static/images/result/success02.png"
      mode="scaleToFill"
    />
    <view class="font-size-30rpx font-600 mt-30rpx">{{ $t('loan.loanSuccessful') }}</view>
    <view class="font-size-50rpx font-600 mt-20rpx">{{ data.loan }}</view>
    <view class="flex flex-col gap-40rpx p-60rpx py-50rpx mt-40rpx">
      <view class="flex items-center justify-between font-siz-26rpx font-500">
        <view class="color-[var(--text-inactive)]">{{ $t('loan.collateral') }}</view>
        <view>{{ data.pledge }}</view>
      </view>
    </view>
    <view class="flex mt-20rpx gap-30rpx mx-60rpx">
      <wd-button custom-class="flex-1" type="info" size="large" @click="onBack">
        {{ $t('loan.ok') }}
      </wd-button>
      <wd-button
        custom-class="flex-1"
        size="large"
        @click="onRouter('/pages/loan/order/index', 'redirectTo')"
      >
        {{ $t('loan.viewOrder') }}
      </wd-button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { onRouter } from '@/utils'

const data = ref<any>({})

onLoad((options) => {
  data.value = options
})

const onBack = () => {
  uni.navigateBack()
}
</script>

<style lang="scss" scoped>
//
</style>
