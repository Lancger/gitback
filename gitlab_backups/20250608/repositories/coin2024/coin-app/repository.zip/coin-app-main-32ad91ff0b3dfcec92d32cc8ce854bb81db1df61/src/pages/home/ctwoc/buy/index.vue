<template>
  <app-navbar custom-class="bg-transparent" title="Earn">
    <template #title>
      <view class="search-box flex" @click="show = true">
        C2C
        <wd-icon name="caret-down-small" size="22px"></wd-icon>
      </view>
    </template>
  </app-navbar>

  <view class="crypto">You pay</view>

  <view class="flex buy">
    <view class="w70">
      <wd-input type="number" no-border v-model="value" placeholder="请输入" />
    </view>
    <view class="buy_type" @click="showCree = true">
      <image class="w-40rpx h-40rpx mr2 ml1" :src="valueCree.icon" />
      <text class="buy_text">{{ valueCree.local_currency }}</text>
      <wd-icon name="caret-down-small" size="22px"></wd-icon>
    </view>
  </view>
  <!-- <view class="text">100-200</view> -->
  <view class="crypto">You receive</view>

  <view class="flex buy">
    <view class="w70">
      <wd-input type="number" no-border v-model="sum" placeholder="请输入" />
    </view>
    <view class="buy_type" @click="showcoin = true">
      <image class="w-40rpx h-40rpx mr2 ml1" :src="valueCoin.avatar" />
      <text class="buy_text">{{ valueCoin.name }}</text>
      <wd-icon name="caret-down-small" size="22px"></wd-icon>
    </view>
  </view>
  <view class="text">100-200</view>

  <view class="btn">
    <view class="btn_subscribe" v-if="!value">Select payment method</view>
    <view class="btn_subscribewhine" v-else @click="navigator">Select payment method</view>
  </view>

  <view class="glide">Pending order</view>

  <wd-popup v-model="show" position="bottom" custom-style="height: 200px;">
    <view class="popup">
      <view class="popup_icon" @llick="show = false">
        <wd-icon name="close" size="18px" color="#878787"></wd-icon>
      </view>

      <view class="popup_list" v-for="(v, i) in columns" :key="i" @llick="show = false">
        <image class="w-43rpx h-42rpx mr2 ml1" :src="v.icon" />
        <text class="popup_text">{{ v.name }}</text>
      </view>
    </view>
  </wd-popup>

  <wd-popup v-model="showCree" position="bottom" custom-style="height: 200px;">
    <view class="popup">
      <view class="popup_icon" @click="showCree = false">
        <wd-icon name="close" size="18px" color="#878787"></wd-icon>
      </view>
      <view class="popup_h">
        <view class="popup_list" v-for="(v, i) in oneList" :key="i" @click="showCreeclick(v)">
          <image class="w-43rpx h-42rpx mr2 ml1" :src="v.icon" />
          <text class="popup_text">{{ v.local_currency }}</text>
        </view>
      </view>
    </view>
  </wd-popup>

  <wd-popup v-model="showcoin" position="bottom" custom-style="min-height: 200px;">
    <view class="popup">
      <view class="popup_icon" @click="showcoin = false">
        <wd-icon name="close" size="18px" color="#878787"></wd-icon>
      </view>

      <view class="popup_h">
        <view class="popup_list" v-for="(v, i) in coinList" :key="i" @click="showcoinclick(v)">
          <image class="w-43rpx h-42rpx mr2 ml1" :src="v.avatar" />
          <text class="popup_text">{{ v.name }}</text>
        </view>
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { ref, watch } from 'vue'
import epx from '@/static/images/home/exp.png'
import ctc from '@/static/images/home/ctc.png'
import { fetchOneclick, fetchGetDataRete } from '@/service/ctwoc'
import { onLoad } from '@dcloudio/uni-app'

const index = ref()
const id = ref()
const show = ref<boolean>(false)
const showCree = ref<boolean>(false)
const showcoin = ref<boolean>(false)
const value = ref()
const sum = ref()
const valuerate = ref()

const oneList = ref<any>([
  {
    icon: '',
    local_currency: '',
  },
])
const coinList = ref<any>([
  {
    avatar: '',
    name: '',
  },
])

const rateList = ref()
const valueCree = ref({
  icon: '',
  local_currency: '',
})
const valueCoin = ref({
  avatar: '',
  name: '',
})

const columns = ref([
  {
    name: 'Express',
    icon: epx,
  },
  {
    name: 'C2C',
    icon: ctc,
  },
])

onLoad((options) => {
  index.value = options.index
  id.value = options.id
  getDataList()
})

const dataList = () => {
  return fetchGetDataRete({
    pageSize: -521,
    column: 'id',
    order: 'desc',
  }).then((res) => {
    rateList.value = res.data.records
    rateList.value.forEach((item) => {
      if (
        valueCree.value.local_currency === item.quote_currency &&
        valueCoin.value.name === item.base_currency
      ) {
        valuerate.value = item.rate
      }
    })
  })
}

const ratefun = () => {
  rateList.value.forEach((item) => {
    if (
      valueCree.value.local_currency === item.quote_currency &&
      valueCoin.value.name === item.base_currency
    ) {
      valuerate.value = item.rate
      sum.value = Number(Number(value.value) / Number(valuerate.value))
      value.value = Number(Number(sum.value) * Number(valuerate.value))
    }
  })
}

const showcoinclick = (v) => {
  valueCoin.value = v
  ratefun()
  showcoin.value = false
}
const showCreeclick = (v) => {
  valueCree.value = v
  sum.value = 0
  value.value = 0
  ratefun()
  showCree.value = false
}

// dataList

const getDataList = () => {
  return fetchOneclick().then((res) => {
    dataList()
    oneList.value = res.data[0].country.filter((item) => item.is_buy === '1')
    valueCree.value = oneList.value[0]
    coinList.value = res.data[0].coin
    valueCoin.value = res.data[0].coin[0]
  })
}

watch(value, (newValue: any, oldValue) => {
  sum.value = Number(Number(newValue) / Number(valuerate.value))
})

watch(sum, (newValue: any, oldValue) => {
  value.value = Number(Number(newValue) * Number(valuerate.value))
})

function navigator(url: string) {
  const data = {
    value: value.value,
    sum: sum.value,
    valueCree: valueCree.value,
    valueCoin: valueCoin.value,
    index: index.value,
    id: id.value,
  }
  uni.navigateTo({
    url: `/pages/home/ctwoc/payment/index?data=${JSON.stringify(data)}`,
  })
}
</script>

<style lang="scss" scoped>
.buysell {
  display: flex;
  align-items: center;
  justify-content: center;

  margin: 20rpx auto;

  &_box {
    display: flex;
    align-items: center;
    width: 308rpx;
    height: 56rpx;
    padding: 0 5rpx;
    background-color: #f6f6f6;
    border-radius: 27rpx;
  }

  &_buy {
    width: 150rpx;
    height: 48rpx;
    line-height: 48rpx;
    text-align: center;
    background-color: #fff !important;
    border-radius: 27rpx;
  }

  &_sell {
    width: 150rpx;
    height: 48rpx;
    line-height: 48rpx;
    text-align: center;
    border-radius: 27rpx;
  }
}
.popup {
  padding: 30rpx;
  &_icon {
    position: fixed;
    right: 30rpx;
    text-align: right;
  }
  &_h {
    max-height: 300px;
    margin-top: 50rpx;
    overflow: auto;
  }
  &_list {
    display: flex;
    align-items: center;
    height: 108rpx;
    margin-top: 20rpx;
    font-size: 32rpx;
  }
  &_h {
    height: 400px;
    margin-top: 50rpx;
    overflow: auto;
  }
  &_cree {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 88rpx;
  }
}
.flex {
  display: flex;
  align-items: center;
  justify-content: center;
}
:deep(.uni-input-wrapper) {
  font-family: Asap;
  font-size: 36rpx;
  font-weight: 600;
  text-align: left;
}
.glide {
  color: var(--text-primary);
  text-align: center;
  text-decoration: underline;
}
.btn {
  margin-top: 80rpx;
  &_subscribe {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--text-inactive) !important;
    text-align: center;
    background-color: var(--border-color-inactive);
    border-radius: 100rpx;
  }

  &_subscribewhine {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--wot-color-white) !important;
    text-align: center;
    background-color: #00a7ed;
    border-radius: 100rpx;
  }
}
.text {
  margin-top: 10rpx;
  color: var(--text-inactive);
}
.page {
  padding: 30rpx;
}
.flex {
  display: flex;
  align-items: center;
}
.buy {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 100rpx;
  margin-top: 20rpx;
  border-bottom: 2rpx solid var(--border-color-inactive);
  &_type {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 198rpx;
    height: 72rpx;
    background: var(--background-gary-4);
    border-radius: 10rpx;
  }
}

.crypto {
  margin-top: 30rpx;
  margin-bottom: 10rpx;
  font-size: 30rpx;
}
</style>
