<template>
  <wd-popup :model-value="modelValue" position="bottom" :z-index="99" @close="onClose">
    <view class="relative pt-80rpx px-30rpx">
      <image
        class="absolute top-0 left-30rpx w-90rpx h-90rpx rd-50% translate-y-[-50%]"
        src="/static/images/avatar.png"
        mode="scaleToFill"
      />
      <view class="font-size-32rpx font-500">{{ rowData.nickname }}</view>
      <view class="flex items-end py-30rpx b-b">
        <view class="lh-36rpx color-[var(--text-inactive)] ellipsis-3">
          {{ rowData.description }}
        </view>
      </view>
      <!-- tabs  -->
      <view class="">
        <wd-tabs v-model="form.followMode" swipeable animated :map-num="100" :slidable-num="2">
          <block v-for="(item, index) in tab" :key="index">
            <wd-tab :title="item.label" :name="item.value"></wd-tab>
          </block>
        </wd-tabs>
      </view>
      <!-- <view class="font-size-22rpx lh-30rpx color-[var(--text-inactive)] mt-45rpx">
        Orders will be opened proportionally (Your available margin balance / the lead trader's
        available margin balance)
      </view> -->
      <!-- <view class="flex items-center justify-between font-size-26rpx font-500 mt-45rpx">
        <view class="color-[var(--text-inactive)]">Lockup period</view>
        <view>15D</view>
      </view> -->
      <view class="mt-30rpx font-size-26rpx font-500 color-[var(--text-inactive)]">
        {{ $t('copy.followTradingAmount') }}
      </view>
      <view
        class="flex items-center gap-20rpx h-90rpx px-30rpx mt-20rpx bg-[var(--background-gary-4)] rd-15rpx"
      >
        <input
          v-model="form.amount"
          class="flex-1 font-size-30rpx lh-90rpx"
          type="digit"
          :placeholder="$t('copy.pleaseEnter')"
        />
        <view class="font-size-26rpx font-500">USDT</view>
        <view class="font-size-26rpx font-500 color-[var(--color-primary)]" @click="onMax">
          {{ $t('common.max') }}
        </view>
      </view>
      <view class="flex items-center gap-10rpx mt-30rpx">
        <view class="flex items-center gap-10rpx font-size-22rpx">
          <view class="color-[var(--text-inactive)] underline">
            {{
              mode === 'spot'
                ? `${$t('copy.spotWalletAvailableBalance')}:`
                : `${$t('copy.futuresWalletAvailableBalance')}:`
            }}
          </view>
          <view>{{ assets.balance || 0 }} USDT</view>
        </view>
        <wd-icon
          custom-class="color-[var(--color-primary)]"
          name="add-circle"
          size="24rpx"
          @click="onRouter(`/pages/asset/deposit/index`)"
        ></wd-icon>
      </view>
      <view class="mt-40rpx font-size-26rpx font-500 color-[var(--text-inactive)]">
        {{ form.followMode === 2 ? $t('copy.followTradeRatio') : $t('copy.amountPerFollowTrade') }}
      </view>
      <view
        class="flex items-center gap-20rpx h-90rpx px-30rpx mt-20rpx bg-[var(--background-gary-4)] rd-15rpx"
      >
        <input
          v-model="form.minAmount"
          class="flex-1 font-size-30rpx lh-90rpx"
          type="number"
          :placeholder="form.followMode === 2 ? '0-100' : $t('copy.amountPerFollowTrade')"
          @input="onInput"
        />
        <view class="font-size-26rpx font-500">{{ form.followMode === 2 ? '%' : 'USDT' }}</view>
      </view>
      <!-- <view class="lh-30rpx pt-20rpx pb-40rpx font-size-22rpx color-[var(--text-inactive)] b-b">
        When the copy trader's estimated margin balance reaches -- USDT, a stop loss market order
        will be triggered to close all positions. The expected profit or loss will be -- USDT
      </view> -->
      <!-- <wd-checkbox custom-class="mt-30rpx" :modelValue="true" shape="square">
        <view class="font-size-22rpx">
          I have confirmed that the share is
          <text class="color-[var(--color-primary)]">12%</text>
        </view>
      </wd-checkbox>
      <wd-checkbox custom-class="mt-20rpx" :modelValue="true" shape="square">
        <view class="font-size-22rpx">
          I have read and agree to the
          <text class="color-[var(--color-primary)] underline">《User Service Agreement》</text>
        </view>
      </wd-checkbox> -->
      <!--  -->
      <view
        class="px-30rpx py-20rpx mx-[-30rpx] mt-30rpx bg-[var(--background-primary)] shadow-[var(--box-shadow)]"
      >
        <wd-button
          type="primary"
          size="large"
          block
          round
          :disabled="!Number(form.amount) || !form.minAmount"
          :loading="loading"
          @click="onSubmit"
        >
          {{ $t('common.confirm') }}
        </wd-button>
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'
import { inputLimitToDigit, BNumber, toFixed, toFormat } from '@/utils/number'
import { fetchSubmitOrder } from '@/service/copy'
import { fetchGetCurrencyAccount } from '@/service/assets'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  rowData: {
    type: Object,
    default: () => {},
  },
})

const emits = defineEmits(['update:modelValue', 'onCallBack'])

const mode = inject<Ref<'spot' | 'futures'>>('mode', ref('spot'))
const loading = ref(false)
const isShow = ref(false)
const assets = ref<any>({})
const tab = [
  {
    label: t('copy.fixedRatio'),
    value: 2,
  },
  {
    label: t('copy.fixedAmount'),
    value: 1,
  },
]

const form = reactive({
  amount: undefined,
  followMode: 2, // 1-定额 2-定比
  leaderId: '',
  minAmount: undefined,
})

watch(
  () => props.modelValue,
  (newVal) => {
    if (newVal) {
      assets.value = {}
      getWallet(mode.value === 'spot' ? 1 : 4)
    }
  },
)

async function onPlaceOrder() {
  loading.value = true
  try {
    await fetchSubmitOrder({
      ...form,
      leaderId: props.rowData.id,
      minAmount: form.followMode === 2 ? +toFixed(form.minAmount / 100) : form.minAmount,
    })
    uni.showToast({
      title: t('common.success'),
      icon: 'success',
      duration: 2000,
    })
    emits('onCallBack')
    onClose()
    loading.value = false
  } catch (e) {
    loading.value = false
  }
}

async function onSubmit() {
  onPlaceOrder()
}

function onInput(e) {
  let value = e.detail.value
  if (form.followMode === 2) {
    if (value > 100) {
      value = 100
    }
    if (value < 0) {
      value = 0
    }
  }
  nextTick(() => {
    form.minAmount = inputLimitToDigit(value, 0)
  })
}

function onMax() {
  form.amount = +toFixed(assets.value.balance, 2)
}

function getWallet(type) {
  return fetchGetCurrencyAccount({ type }).then((res) => {
    assets.value = res.data.find((item) => item.symbol === 'USDT') || {}
  })
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
:deep(.wd-popup) {
  overflow-y: visible !important;
}
</style>
