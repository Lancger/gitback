<template>
  <view>
    <view class="px-60rpx">
      <view class="font-size-40rpx font-600">{{ props.title }}</view>
      <view class="hint" v-if="props.hint">{{ props.hint }}</view>
      <view
        class="trade-tag"
        v-if="props.type !== 'message-verification' && currVerificationType === 'google_key'"
      >
        <view
          :class="{ 'in-active': trading === 0 }"
          class="trade-tag__item trade-tag__item-buy"
          @click="trading = 0"
        >
          <text class="trade-tag__item__text">{{ $t('safe.twoFactor.google') }}</text>
        </view>
        <view
          :class="{ 'in-active': trading === 1 }"
          class="trade-tag__item trade-tag__item-sell"
          @click="trading = 1"
        >
          <text class="trade-tag__item__text">{{ $t('safe.twoFactor.sms') }}</text>
        </view>
      </view>
      <view
        class="color-[var(--text-inactive)] mt-60rpx mb-60rpx"
        v-if="trading === 0 && props.type !== 'message-verification'"
      >
        {{ $t('safe.twoFactor.googleDesc') }}
      </view>
      <view class="color-[var(--text-inactive)] mt-60rpx mb-60rpx" v-else>
        {{ $t('safe.twoFactor.smsDesc') }} {{ account }}
      </view>
      <sms-button
        v-if="props.type === 'message-verification' || trading === 1"
        :api="smsApi"
        :api-params="smsApiParams"
      ></sms-button>
      <view>
        <!-- 密码输入框 -->
        <wd-password-input
          v-model="verificationCode"
          :mask="false"
          :gutter="10"
          :length="6"
          :focused="showKeyboard"
          @focus="showKeyboard = true"
        />
        <!-- 数字键盘 -->
        <wd-number-keyboard
          v-model="verificationCode"
          v-model:visible="showKeyboard"
          :maxlength="6"
          @close="showKeyboard = false"
        />
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { useUserStore } from '@/store'
import { fetchSendSMS, fetchSendEmail } from '@/service/base'
import {
  fetchAccountVerificationBinding,
  fetchGoogleVerificationBindingOrReset,
} from '@/service/user'

const props = defineProps({
  title: {
    type: String,
    default: '',
  },
  hint: {
    type: String,
    default: '',
  },
  type: {
    type: String,
    default: '',
  },
})
const emits = defineEmits(['hidePopup'])
const userStore = useUserStore()

const userInfo = userStore.userInfo
const showKeyboard = ref(false)
const verificationCode = ref('')
const account = userInfo.phone || userInfo.email
const currVerificationType = userInfo.google_key ? 'google_key' : userInfo.phone ? 'phone' : 'email'
const accountType = userInfo.phone ? 1 : 2
const checkType = 1
const pageType = ref('1')
const trading = ref(0)
const smsTypeMap = {
  bank: 3,
  'anti-phishing-code': 8,
  'fund-password': 7,
  'google-authenticator': 9,
  'message-verification': 10,
  '1': 4, // 绑定手机号
  '2': 6, // 绑定谷歌
  '3': 6, // 绑定邮箱
}
// 如果是谷歌验证只有手机号没有邮箱那么把trading变为1
if (userInfo.phone && !userInfo.email) {
  trading.value = 1
}
// 如果还没有进行谷歌验证先需要把trading变为1
if (!userInfo.google_key) {
  trading.value = 1
}

onLoad((options) => {
  pageType.value = options.type
})

const smsApi = computed(() => {
  return userInfo.phone ? fetchSendSMS : fetchSendEmail
})

const smsApiParams = computed(() => {
  if (userInfo.phone) {
    return {
      phone: userInfo.phone,
      type: pageType.value ? smsTypeMap[pageType.value] : smsTypeMap[props.type], // 银行卡修改页面验证码等于3
    }
  } else {
    return {
      email: userInfo.email,
      type: props.type === 'bank' ? 3 : 4, // 银行卡修改页面验证码等于3
    }
  }
})

watch(verificationCode, async (newVal) => {
  if (newVal.length === 6) {
    try {
      uni.showLoading()
      // message-verification页面解绑接口
      if (props.type === 'message-verification') {
        const res = await fetchAccountVerificationBinding({
          account,
          accountType: 1,
          checkType: 3,
          areaCode: '',
          verificationCode: verificationCode.value,
        })
        uni.hideLoading()
        uni.showToast({
          title: t('common.success'),
          icon: 'none',
          success: function () {
            if (res.code === 200) {
              userInfo.phone = ''
              uni.navigateBack()
            }
          },
        })
      } else if (props.type === 'fund-password') {
        // 资金设置页面返回验证码
        // 传phone过去判断accountType为1还是2
        emits('hidePopup', verificationCode.value, trading.value, userInfo.phone)
        uni.hideLoading()
      } else if (props.type === 'anti-phishing-code') {
        // 钓鱼码修改页面回传
        emits('hidePopup', verificationCode.value, trading.value)
        uni.hideLoading()
      } else if (props.type === 'bank') {
        // 传phone过去判断accountType为1还是2
        return emits('hidePopup', verificationCode.value, trading.value, userInfo.phone)
      } else {
        let res
        if (trading.value === 0) {
          // 未绑定前 进入绑定页面的认证 重置谷歌验证码的操作
          res = await fetchGoogleVerificationBindingOrReset({
            code: verificationCode.value,
            type: 2,
          })
        }

        if (trading.value === 1) {
          // 未绑定前 进入绑定页面的认证 短信或邮箱验证
          res = await fetchAccountVerificationBinding({
            account,
            accountType,
            checkType,
            verificationCode: verificationCode.value,
          })
        }

        uni.hideLoading()

        // 如果是google-authenticator验证直接隐藏弹框
        if (props.type === 'google-authenticator') {
          return emits('hidePopup')
        }

        if (res.code === 200 && pageType.value === '1') {
          uni.redirectTo({
            url: '/pages/user/security/message-verification',
          })
        } else if (res.code === 200 && pageType.value === '2') {
          uni.redirectTo({
            url: '/pages/user/security/google-authenticator',
          })
        } else if (res.code === 200 && pageType.value === '3') {
          uni.redirectTo({
            url: '/pages/user/security/binding-email',
          })
        }
      }
    } catch {
      uni.hideLoading()
    }
  }
})

const reset = () => {
  verificationCode.value = ''
}

defineExpose({
  reset,
})
</script>

<style lang="scss" scoped>
:deep(.wd-password-input) {
  margin: 200rpx 0 0 !important;
}
:deep(.wd-password-input__item) {
  background: var(--background-tertiary) !important;
  border: 1px solid var(--border-color);
  border-radius: 10rpx !important;
}
.trade-tag {
  display: flex;
  gap: 40rpx;
  align-items: center;
  margin-top: 30rpx;
  &__item {
    position: relative;
    flex: 1;
    height: 60rpx;
    font-size: 26rpx;
    font-weight: 500;
    line-height: 60rpx;
    text-align: center;
    background: var(--background-gary-7);
    border-radius: 100rpx;
    transition: all 0.3s;
    &__text {
      position: relative;
      z-index: 2;
    }
    &::before {
      position: absolute;
      top: 0;
      right: -10rpx;
      z-index: 1;
      width: 50%;
      height: 100%;
      content: '';
      background-color: inherit;
      transform: translate(0) rotate(0) skewX(-35deg) skewY(0) scaleX(1) scaleY(1);
    }
    + .trade-tag__item {
      &::before {
        right: auto;
        left: -10rpx;
      }
    }
  }
  &__item-buy.in-active {
    color: #fff;
    background: var(--color-green);
  }
  &__item-sell.in-active {
    color: #fff;
    background: var(--color-green);
  }
}
.hint {
  margin: 30rpx 0;
  font-size: 22rpx;
  color: var(--text-secondary);
}
</style>
