<template>
  <app-navbar custom-class="bg-transparent">
    <template #title>
      <view class="search-box flex" @click="show = true">
        {{ $t('c2c.index.c2c') }}
        <wd-icon name="caret-down-small" size="22px"></wd-icon>
      </view>
    </template>
    <template #right>
      <image
        @click="onRouter('/pages/home/ctwoc/history/index?serviceType=2')"
        class="w32rpx h32rpx"
        :src="onImageToThemeImage('/static/images/icons/records.png')"
      ></image>
    </template>
  </app-navbar>

  <view class="buysell flex-jc">
    <view class="buysell_box">
      <view :class="index === 2 ? 'buysell_buy' : 'buysell_sell'" @click="payclick(2)">
        {{ $t('c2c.buy') }}
      </view>
      <view :class="index === 1 ? 'buysell_buy' : 'buysell_sell'" @click="payclick(1)">
        {{ $t('c2c.sell') }}
      </view>
    </view>
  </view>
  <view class="pl-30rpx pr-30rpx">
    <view class="search">
      <view class="flex" @click="showcion = true">
        <image class="w-43rpx h-42rpx mr2" :src="cionobj.avatar" />
        <view class="list_cer">{{ cionobj.symbol }}</view>
        <wd-icon name="caret-down-small" size="20px" v-if="!showcion"></wd-icon>
        <wd-icon name="caret-up-small" size="20px" v-else></wd-icon>
      </view>
      <input
        type="text"
        :placeholder="$t('c2c.index.searchInput')"
        v-model="coinCou"
        @confirm="search"
      />
      <view class="search_max" @click="showCree = true">
        {{ valueCree.local_currency }}
        <wd-icon name="caret-down-small" size="20px" v-if="!showCree"></wd-icon>
        <wd-icon name="caret-up-small" size="20px" v-else></wd-icon>
      </view>
    </view>
  </view>

  <view class="pl-30rpx pr-30rpx mt-30rpx">
    <view v-for="(v, i) in tenantList" :key="i" class="list">
      <view class="flex-jc">
        <view class="flex">
          <image class="w-43rpx h-42rpx mr2 ml1" :src="v.icon" />
          <view class="list_cer">
            <text class="list_text">{{ v.name }}</text>
            <!-- <text class="list_c9">/USDT</text> -->
          </view>
        </view>

        <!-- <view class="list_cer flex">
          <view>
            {{ $t('c2c.index.vol') }} {{ v.completedOrderQuantity }} {{ $t('c2c.index.order') }}
          </view>
          <view class="list_line"></view>
          <view>{{ v.completedRate }}%</view>
        </view> -->
        <view class="list_cer flex">
          <view>
            <!-- {{ $t('c2c.index.vol') }} -->
            {{ $t('c2c.index.review') }}
          </view>
          <view class="list_line"></view>
          <view>{{ v.remarks || '99.6' }}%</view>
        </view>
      </view>
      <view class="list_usd">{{ v.rate }} {{ v.fiat_currency }}</view>
      <view class="list_sun">
        {{ $t('c2c.index.qty') }}
        <text>{{ v.coin_cou_remain }} {{ v.coin_symbol }}</text>
      </view>
      <view class="list_sun">
        {{ $t('c2c.index.transactionLimit') }}
        <text>{{ v.min_transaction }}-{{ v.max_transaction }} {{ v.coin_symbol }}</text>
      </view>
      <!-- <view class="list_sun" v-if="v.remarks">
        {{ $t('c2c.index.remarks') }}
        <text>{{ v.remarks }}</text>
      </view> -->
      <view class="list_bottom" v-if="buttonShow(v)">
        <!-- <view class="list_bottom_bank">{{ $t('c2c.index.bankCard') }}</view> -->
        <wd-button class="list_bottom_button" @click="navigator(v)" type="success" size="small">
          {{ index === 2 ? $t('c2c.buy') : $t('c2c.sell') }}
        </wd-button>
      </view>
    </view>
  </view>
  <!-- <wd-status-tip
    v-if="tenantList.length === 0"
    style="margin-top: 50%"
    image="content"
    tip="No address"
  /> -->
  <app-empty v-if="tenantList.length === 0" no-data></app-empty>
  <wd-popup v-model="show" position="bottom" custom-style="height: 200px;">
    <view class="popup">
      <view class="popup_icon" @llick="show = false">
        <wd-icon name="close" size="18px" color="#878787"></wd-icon>
      </view>

      <view
        class="popup_list"
        v-for="(v, i) in columns"
        :key="i"
        @click="(onRouter(v.url, 'redirectTo'), (show = false))"
      >
        <image class="w-43rpx h-42rpx mr2 ml1" :src="onImageToThemeImage(v.icon)" />
        <text class="popup_text">{{ v.name }}</text>
      </view>
    </view>
  </wd-popup>

  <wd-popup v-model="showCree" position="bottom" custom-style="height: 500px;">
    <view class="popup">
      <view class="popup_icon" @click="showCree = false">
        <wd-icon name="close" size="18px" color="#878787"></wd-icon>
      </view>
      <view class="popup_h">
        <template v-for="v in countryList" :key="v.id">
          <view v-if="v.currency_icon" class="popup_cree" @click="clickCree(v)">
            <image class="w-43rpx h-42rpx mr2 ml1" :src="v.currency_icon" />
            <text class="popup_text">
              {{ v.local_currency }}
            </text>
          </view>
        </template>
      </view>
    </view>
  </wd-popup>

  <wd-popup v-model="showcion" position="bottom" custom-style="height: 500px;">
    <view class="popup">
      <view class="popup_icon" @click="showcion = false">
        <wd-icon name="close" size="18px" color="#878787"></wd-icon>
      </view>
      <view class="popup_h">
        <view class="popup_cree" v-for="v in cionlist" :key="v.id" @click="clickCion(v)">
          <image class="w-43rpx h-42rpx mr2 ml1" :src="v.avatar" />
          <text class="popup_text">
            {{ v.symbol }}
          </text>
        </view>
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { ref } from 'vue'
import { fetchGetData, fetchOpenp2p, fetchGetDataCion } from '@/service/ctwoc'
import { onLoad } from '@dcloudio/uni-app'
import { useUserStore } from '@/store'
import { onImageToThemeImage, onRouter } from '@/utils'
import { useMessage } from 'wot-design-uni'
import { fetchGetPayment } from '@/service/user'

const message = useMessage()
const userInfo = useUserStore().userInfo
const myPayMethods = ref([]) // 判断有无银行卡
const columns = ref([
  {
    name: t('c2c.index.express'),
    icon: '/static/images/home/exp.png',
    url: '/pages/home/express/index',
  },
  {
    name: t('c2c.index.c2c'),
    icon: '/static/images/home/ctc.png',
    url: '/pages/home/ctwoc/index',
  },
])

const columnsCree = ref<any>([])
const tenantList = ref<any>([])
const cionlist = ref<any>()
const cionobj = ref<any>({
  symbol: '',
  avatar: '',
})

const coinCou = ref<string>('')
const index = ref<number>(2)
const valueCree = ref<any>({
  local_currency: '',
  id: '',
  icon: '',
})
const coinId = ref('')
const show = ref<boolean>(false)
const showcion = ref<boolean>(false)
const showCree = ref<boolean>(false)

onLoad(async () => {
  await getDataList()
  await dataCion()
  getopenp2p()
})

onShow(() => {
  fetchGetPaymentFun()
})

const countryList = computed(() => {
  return columnsCree.value.filter((item) =>
    index.value === 2 ? item.is_sell === '1' : item.is_buy === '1',
  )
})

const payclick = (env) => {
  index.value = env
  getopenp2p()
}

const fetchGetPaymentFun = () => {
  fetchGetPayment().then((res) => {
    console.log(res)
    myPayMethods.value = res.data
  })
}

const dataCion = () => {
  return fetchGetDataCion({
    pageSize: -521,
    column: 'sort',
    order: 'asc',
  }).then((res) => {
    cionlist.value = res.data.records
    cionobj.value = res.data.records.find((item) => item.symbol === 'USDT') || res.data.records[0]
    coinId.value = cionobj.value.id
  })
}

const clickCion = (v) => {
  cionobj.value = v
  coinId.value = v.id
  showcion.value = false
  getopenp2p()
}

const getopenp2p = () => {
  uni.showLoading()
  tenantList.value = []
  return fetchOpenp2p({
    coinId: coinId.value,
    countryId: valueCree.value.id,
    type: index.value, // 卖 1 买 2
    coinCou: coinCou.value,
    status: 1,
    current: 1,
    pageSize: -521,
  })
    .then((res) => {
      tenantList.value = res.data.records
    })
    .finally(() => {
      uni.hideLoading()
    })
}

const getDataList = () => {
  return fetchGetData({
    pageSize: -521,
    column: 'id',
    order: 'desc',
  }).then((res) => {
    columnsCree.value = res.data.records
    const list = res.data.records.filter((item) =>
      index.value === 2 ? item.is_sell === '1' : item.is_buy === '1',
    )
    valueCree.value =
      list.find((item) => item.local_currency === import.meta.env.VITE_CURRENCY) || list[0]
  })
}

const clickCree = (v) => {
  valueCree.value = v
  showCree.value = false
  getopenp2p()
}

function search() {
  getopenp2p()
}

function navigator(v) {
  // if (userInfo.real_name_status !== '2') {
  //   message
  //     .confirm({
  //       msg: t('c2c.index.message1.msg'),
  //       title: t('c2c.index.message1.title'),
  //       confirmButtonText: t('c2c.index.message1.confirmButtonText'),
  //     })
  //     .then((res) => {
  //       uni.navigateTo({
  //         url: '/pages/user/kyc/index',
  //       })
  //     })
  //   return
  // } else if (index.value === 1) {
  //   const arr = myPayMethods.value.filter((item) => item.country_id === valueCree.value.id)
  //   if (myPayMethods.value.length) {
  //     if (arr.length === 0) {
  //       // 绑卡不合适
  //       return message
  //         .confirm({
  //           msg: t('c2c.index.message2.msg'),
  //           title: t('c2c.index.message2.title'),
  //           confirmButtonText: t('c2c.index.message2.confirmButtonText'),
  //         })
  //         .then((res) => {
  //           uni.navigateTo({
  //             url: '/pages/user/bank/index',
  //           })
  //         })
  //     }
  //   } else {
  //     // 未绑卡提示
  //     return message
  //       .confirm({
  //         msg: t('c2c.index.message3.msg'),
  //         title: t('c2c.index.message3.title'),
  //         confirmButtonText: t('c2c.index.message3.confirmButtonText'),
  //       })
  //       .then((res) => {
  //         uni.navigateTo({
  //           url: '/pages/user/bank/index',
  //         })
  //       })
  //   }
  // }
  const obj = {
    index: index.value,
    id: v.id,
    receiveIcon: valueCree.value.currency_icon,
    payIcon: cionobj.value.avatar,
    itemData: v,
  }
  uni.setStorageSync('ctwoc', obj)
  uni.navigateTo({
    url: '/pages/home/ctwoc/buy-and-sell/index',
  })
}

const buttonShow = (v) => {
  return (
    userInfo.is_merchant !== '2' ||
    userInfo.is_merchant === undefined ||
    (userInfo.is_merchant === '2' && userInfo.merchant && v.service_id !== userInfo.merchant.id)
  )
}
</script>

<style lang="scss" scoped>
.popup {
  padding: 30rpx;
  &_icon {
    text-align: right;
  }
  &_list {
    display: flex;
    align-items: center;
    height: 108rpx;
    margin-top: 20rpx;
    font-size: 32rpx;
  }
  &_h {
    height: 400px;
    margin-top: 50rpx;
    overflow: auto;
  }
  &_cree {
    display: flex;
    align-items: center;
    width: 100%;
    // justify-content: center;
    height: 88rpx;
  }
}
:deep(.wd-popup--bottom) {
  border-radius: 10px 10px 0 0;
}
:deep(.uni-input-placeholder) {
  font-size: 26rpx;
  color: #ccc;
}
.search {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 70rpx;
  padding: 0 16rpx;
  background-color: var(--background-tertiary);
  border-radius: 100rpx;
  &_max {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 139rpx;
    height: 56rpx;
    margin-left: 20rpx;
    font-size: 26rpx;
    color: var(--text-inactive);
    background-color: #ffffff;
    border: 1rpx solid #ededed;
    border-radius: 100rpx;
  }
}
.buysell {
  display: flex;
  align-items: center;
  width: 690rpx;
  margin: 20rpx auto;

  &_box {
    display: flex;
    align-items: center;
    width: 308rpx;
    height: 56rpx;
    padding: 0 5rpx;
    font-size: 26rpx;
    background-color: var(--background-gary-5);
    border-radius: 27rpx;
  }
  &_buy {
    width: 150rpx;
    height: 48rpx;
    font-weight: 500;
    line-height: 48rpx;
    color: var(--text-primary);
    text-align: center;
    background-color: var(--background-primary) !important;
    border-radius: 27rpx;
  }
  &_bg {
    background-color: var(--background-primary);
  }
  &_sell {
    width: 150rpx;
    height: 48rpx;
    line-height: 48rpx;
    color: var(--text-inactive);
    text-align: center;
    border-radius: 27rpx;
  }
}
.flex {
  display: flex;
  align-items: center;
  justify-content: center;
}
.crypto {
  padding: 0 30rpx;
  margin-top: 30rpx;
  margin-bottom: 10rpx;
  font-size: 30rpx;
  font-weight: 500;
}
.list {
  padding: 30rpx 0;
  font-size: 28rpx;
  border-bottom: 1px solid #e9e9e9;
  &_text {
    font-size: 30rpx;
    font-weight: 600;
    color: var(--text-primary);
  }
  &_c9 {
    font-size: 22rpx;
    color: var(--text-inactive);
  }
  &_cer {
    font-size: 24rpx;
    color: var(--text-active);
  }
  &_line {
    width: 1rpx;
    height: 25rpx;
    margin-right: 19rpx;
    margin-left: 23rpx;
    background-color: var(--text-active);
  }
  &_usd {
    margin-top: 20rpx;
    font-size: 42rpx;
    font-weight: 600;
    color: var(--color-red);
  }
  &_sun {
    margin-top: 20rpx;
    font-size: 24rpx;
    color: var(--text-inactive);
    text {
      margin-left: 10rpx;
      font-weight: 500;
      color: var(--text-primary);
    }
  }
  &_bottom {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    &_bank {
      font-size: 22rpx;
      font-weight: 500;
      color: var(--text-inactive);
    }
    &_bank::before {
      position: relative;
      top: 4rpx;
      display: inline-block;
      width: 6rpx;
      height: 26rpx;
      margin-right: 9rpx;
      content: '';
      background-color: var(--color-primary);
      border-radius: 4rpx;
    }
    &_button {
      width: 112rpx;
      height: 41rpx;
      margin: 0 !important;
    }
  }
}

.flex-jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.search-type {
  position: relative;
  height: 30px;
  padding: 0 8px 0 16px;
  line-height: 30px;
}
.search-type::after {
  position: absolute;
  top: 5px;
  right: 0;
  bottom: 5px;
  width: 1px;
  content: '';
  background: rgba(0, 0, 0, 0.25);
}
.search-type {
  :deep(.icon-arrow) {
    display: inline-block;
    font-size: 20px;
    vertical-align: middle;
  }
}
</style>
