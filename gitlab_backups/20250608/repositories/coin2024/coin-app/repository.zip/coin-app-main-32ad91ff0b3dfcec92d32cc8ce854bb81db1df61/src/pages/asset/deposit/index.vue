<template>
  <app-navbar custom-class="bg-transparent" :title="$t('assets.deposit.title')">
    <template #right>
      <wd-icon name="view-module" size="22px" @click="navigator"></wd-icon>
    </template>
  </app-navbar>

  <view class="titleSelect">{{ $t('assets.deposit.select') }}</view>
  <view class="cell flex-jc" @click="show = true">
    <view class="flex">
      <image
        v-if="coinboj.avatar"
        class="w-60rpx h-60rpx rd-50%"
        :src="coinboj.avatar"
        mode="aspectFit"
      />
      <view>
        <text class="title">{{ coinboj.symbol }}</text>
        <!-- <text class="c9">/{{ coinboj.full_name }}</text> -->
      </view>
    </view>
    <view>
      <wd-icon name="arrow-right" size="22px"></wd-icon>
    </view>
  </view>

  <view class="titleSelect">{{ $t('assets.deposit.selectChain') }}</view>
  <view class="flex flex-wrap gap-20rpx pl-30rpx">
    <view
      :class="[networkList.chain_type == v.chain_type ? 'select select_bg' : 'select']"
      v-for="v in coinboj.networkList"
      :key="v.chain_type"
      @click="chainTypeClick(v)"
    >
      {{ v.chain_type }}
    </view>
  </view>
  <view class="img">
    <template v-if="!loading">
      <vue-qr
        v-if="address"
        class="img_qrcode"
        id="qrcode"
        ref="qrcode"
        :text="address"
        :margin="10"
        logo-src=""
      ></vue-qr>
      <text v-else>{{ $t('assets.deposit.qrError') }}</text>
    </template>
    <view v-else class="center w-100% h-100%">
      <wd-loading :size="30" />
    </view>
  </view>

  <view style="margin-bottom: 60rpx; text-align: center" v-if="address">
    <wd-button @click="saveQRCode">{{ $t('assets.deposit.saveQRCode') }}</wd-button>
  </view>
  <template v-if="hasMemo">
    <view class="px-30rpx">
      <wd-notice-bar :text="$t('assets.deposit.memoTips')" prefix="warn-bold" />
    </view>
    <view class="address">
      <view class="flex items-center justify-between">
        <view class="address_title">Tag</view>
        <image
          class="w-30rpx h-30rpx"
          src="@/static/images/assets/copys.png"
          mode="aspectFit"
          @click="copy(tag)"
        />
      </view>
      <view v-if="!loading" class="address_text">
        {{ tag }}
      </view>
      <view v-else class="center w-100% h-100rpx">
        <wd-loading :size="30" />
      </view>
    </view>
  </template>
  <view class="address">
    <view class="flex items-center justify-between">
      <view class="address_title">{{ $t('assets.deposit.walletAddress') }}</view>
      <image
        class="w-30rpx h-30rpx"
        src="@/static/images/assets/copys.png"
        mode="aspectFit"
        @click="copy(address)"
      />
    </view>
    <view v-if="!loading" class="address_text">
      {{ address }}
    </view>
    <view v-else class="center w-100% h-100rpx">
      <wd-loading :size="30" />
    </view>
  </view>

  <!-- <view class="maxsum flex-jc">
    <view class="maxsum_max">
      <text class="cor">*</text>
      Max. Amount：
    </view>
    <view class="sum">1000.00 USDT</view>
  </view>

  <view class="maxsum flex-jc">
    <view class="maxsum_max">
      <text class="cor">*</text>
      Min. Amount：
    </view>
    <view class="sum">1000.00 USDT</view>
  </view> -->
  <view class="hei"></view>

  <view class="hint">
    <view class="hint_doce">
      <text class="hint_cor">*</text>
      {{ t('assets.deposit.p1', { symbol: coinboj.symbol, network: networkList.chain_type }) }}
    </view>
    <view class="hint_doce">
      <text class="hint_cor">*</text>
      {{ t('assets.deposit.p2', { min: networkList.deposit_min, symbol: coinboj.symbol }) }}
    </view>
    <view class="hint_doce">
      <text class="hint_cor">*</text>
      {{ t('assets.deposit.p3', { min: networkList.deposit_min, symbol: coinboj.symbol }) }}
    </view>
  </view>

  <wd-popup
    v-model="show"
    position="bottom"
    custom-style="border-radius: 20rpx 20rpx 0 0; overflow: auto;"
  >
    <view class="font-size-30rpx text-center font-500 p-30rpx">{{ $t('common.select') }}</view>
    <scroll-view class="max-h-50vh" scroll-y>
      <view class="popup flex-jc" v-for="(v, i) in columns" :key="i" @click="coinClick(v)">
        <view class="flex">
          <image class="w-50rpx h-50rpx rd-50%" v-if="v.avatar" :src="v.avatar" mode="aspectFit" />
          <view class="popup_name">{{ v.symbol }}</view>
        </view>
        <view>
          <image
            class="w-32rpx h-32rpx"
            src="@/static/images/assets/xuanzhong.png"
            mode="aspectFit"
            v-if="coinboj.symbol === v.symbol"
          />
          <image
            v-else
            class="w-32rpx h-32rpx"
            src="@/static/images/assets/weixuanzhong.png"
            mode="aspectFit"
          />
        </view>
      </view>
    </scroll-view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import cryptoJS from '@/utils/crypto'
import vueQr from 'vue-qr/src/packages/vue-qr.vue'
import { fetchGetRechargeCurrency, fetchGetDepositAddress } from '@/service/assets'

const columns = ref()
const coinboj = ref({
  avatar: '',
  symbol: '',
  full_name: '',
  networkList: [],
})
const networkList = ref<any>({})
const hasMemo = ref(false)
const loading = ref(false)

const show = ref(false)

const qrcode = ref<typeof vueQr>()
const address = ref<string>('')
const tag = ref<string>('')

onMounted(() => {
  rechargeCurrency()
})

const rechargeCurrency = () => {
  return fetchGetRechargeCurrency({ type: 1 }).then((res) => {
    columns.value = res.data
    coinboj.value = res.data[0] || {}
    networkList.value = coinboj.value.networkList[0]
    hasMemo.value = coinboj.value.networkList[0].hasMemo
    if (networkList.value.chain_type) {
      depositAddress(networkList.value.chain_type)
    }
  })
}

const chainTypeClick = (chainType: any) => {
  networkList.value = chainType
  hasMemo.value = chainType.hasMemo
  depositAddress(networkList.value.chain_type)
}

const depositAddress = (value: string) => {
  loading.value = true
  address.value = ''
  fetchGetDepositAddress(value)
    .then((res) => {
      loading.value = false
      try {
        const data = cryptoJS.decrypt(res as unknown as string)
        address.value = JSON.parse(data).data.address
        tag.value = JSON.parse(data).data.memo
      } catch (error) {}
    })
    .catch(() => {
      loading.value = false
    })
}

const copy = (data) => {
  uni.setClipboardData({
    data,
    success: function () {
      uni.showToast({
        title: t('common.success'),
        icon: 'none',
        duration: 2000,
      })
    },
  })
}

const coinClick = (v) => {
  coinboj.value = v
  networkList.value = coinboj.value.networkList[0]
  hasMemo.value = coinboj.value.networkList[0].hasMemo
  depositAddress(coinboj.value.networkList[0].chain_type)
  show.value = false
}

const saveQRCode = () => {
  const picData = document.getElementById('qrcode') as HTMLImageElement // 生成二维码之后其实是个img
  if (picData) {
    const a = document.createElement('a')
    a.href = picData.src
    a.download = 'wallet'
    a.click()
    setTimeout(() => {
      a.remove()
    }, 2000)
  }
}

function navigator() {
  uni.setStorageSync('assetType', '1')
  uni.navigateTo({
    url: `/pages/asset/deposit/history/index`,
  })
}
</script>

<style lang="scss" scoped>
.popup {
  padding: 30rpx;

  &_name {
    margin-left: 20rpx;
    font-size: 30rpx;
    font-weight: 500;
    color: var(--text-primary) !important;
  }
}
.maxsum {
  width: 690rpx;
  margin: 40rpx auto 20rpx;
  &_max {
    color: var(--text-inactive) !important;
  }
  .cor {
    color: #dd0007;
  }
}
.hint {
  width: 690rpx;
  margin: 40rpx auto 20rpx;
  &_cor {
    color: #dd0007;
  }
  &_text {
    margin-top: 40rpx;
    line-height: 28rpx;
    color: var(--text-inactive) !important;
  }
  &_doce {
    margin-top: 30rpx;
    font-size: 26rpx;
    font-weight: 500;
    line-height: 30rpx;
    color: var(--text-active) !important;
  }
}
.hei {
  width: 100%;
  height: 20rpx;
  margin-top: 20rpx;
  background-color: var(--background-tertiary) !important;
}
.address {
  box-sizing: border-box;
  padding: 20rpx;
  margin: 30rpx;
  background-color: var(--background-tertiary) !important;
  border-radius: 8rpx;
  &_title {
    font-size: 30rpx;
    font-weight: 500;
  }
  &_text {
    margin-top: 10rpx;
    font-size: 28rpx;
    line-height: 40rpx;
    text-align: center;
    word-break: break-all;
  }
}
.select {
  min-width: 140rpx;
  height: 60rpx;
  padding: 0 10rpx;
  line-height: 60rpx;
  color: var(--text-primary) !important;
  text-align: center;
  background-color: var(--background-tertiary) !important;
  border-radius: 8rpx;
}
.select_bg {
  color: #00a7ed !important;
  background-color: #dff4fc !important;
}

.img {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 300rpx;
  height: 300rpx;
  margin: 60rpx auto 60rpx;
  background: url('../../../static/images/assets/scan.png') no-repeat;
  background-size: cover;
  // border: 1px solid var(--border-color);
  &_qrcode {
    width: 290rpx;
    height: 290rpx;
  }
}

.titleSelect {
  padding: 0 30rpx;
  margin: 30rpx 0;
  font-size: 24rpx;
}
.cell {
  box-sizing: border-box;
  width: 690rpx;
  padding: 20rpx;
  margin: auto;
  background-color: var(--background-primary);
  border: 1px solid #cccccc;
  border-radius: 10rpx;
  .c9 {
    color: var(--text-inactive) !important;
  }
  .title {
    margin-left: 10px;
    font-family: Asap;
    font-size: 28rpx;
    font-weight: 500;
  }
  .sum {
    margin-top: 10rpx;
    font-size: 26rpx;
    font-weight: 500;
  }
}
.flex {
  display: flex;
  align-items: center;
  min-width: 100px;
}
.flex-jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
</style>
