<template>
  <wd-overlay :show="modelValue" :z-index="99" @click="onClose">
    <view class="wrapper">
      <view class="dialog" @click.stop>
        <view class="dialog__title">{{ title }}</view>
        <view class="dialog__content">
          <slot>
            {{ content }}
          </slot>
        </view>
        <view class="dialog__foot">
          <wd-button v-if="showCancel" custom-class="flex-1" type="info" plain @click="onClose">
            {{ $t('common.cancel') }}
          </wd-button>
          <wd-button v-if="showConfirm" custom-class="flex-1" :loading="loading" @click="onConfirm">
            {{ $t('common.confirm') }}
          </wd-button>
        </view>
      </view>
    </view>
  </wd-overlay>
</template>

<script lang="ts" setup>
const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  title: {
    type: String,
    default: '',
  },
  content: {
    type: String,
    default: '',
  },
  showCancel: {
    type: Boolean,
    default: true,
  },
  showConfirm: {
    type: Boolean,
    default: true,
  },
  loading: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['update:modelValue', 'onConfirm', 'onClose', 'onCancel'])

const onConfirm = () => {
  emits('onConfirm')
}

const onClose = () => {
  emits('update:modelValue', false)
  emits('onClose')
  emits('onCancel')
}
</script>

<style lang="scss" scoped>
.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;

  .dialog {
    box-sizing: border-box;
    width: 540rpx;
    padding: 40rpx 30rpx;
    background-color: var(--background-primary);
    border-radius: 20rpx;
    &__title {
      font-size: 30rpx;
      font-weight: 500;
      text-align: center;
    }
    &__content {
      margin: 40rpx 0 60rpx;
      color: var(--text-active);
      text-align: center;
    }
    &__foot {
      display: flex;
      gap: 14rpx;
      align-items: center;
    }
  }
}
</style>
