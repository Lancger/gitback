import { http } from '@/utils/http'

// 市场
export const fetchMarketData = (params?: any) => {
  return http.get('/api/mjkj-web/coin/open/market/initData', params)
}

/** Spot List */
export const fetchGetSpot = (params?: any) => {
  return http.get('/api/mjkj-web/coin/open/getSpotGoods', params)
}

/** futures List */
export const fetchGetFutures = (params?: any) => {
  return http.get('/api/mjkj-web/coin/open/getContract', params)
}

// 热门产品
export const fetchHotProduct = () => {
  return http.get('/api/mjkj-web/coin/open/get/hotSymbol')
}

// k线历史
export const fetchKLineHistory = (params) => {
  return http.get('/api/mjkj-web/coin/open/get/kline/history', params)
}

// 添加自选
export const fetchFollow = (path) => {
  return http.get(`/api/mjkj-web/coin/quotes/${path}`)
}

// 期权列表
export const fetchGetOptions = (params?: any) => {
  return http.get('/api/mjkj-web/coin/open/getOptionsList', params)
}
