<template>
  <view v-for="item in list" :key="item" class="relative mx-30rpx py-36rpx b-b">
    <view class="font-size-30rpx font-500">{{ item.pair_name }}-{{ item.time_name }}</view>
    <view class="flex items-center justify-between gap-20rpx mt-20rpx">
      <app-tag :type="item.up_down === 1 ? 'success' : 'error'">
        {{ item.up_down === 1 ? $t('optionV2.up') : $t('optionV2.down') }}
      </app-tag>
      <app-tag type="info">
        {{ $t('optionV2.options') }}
      </app-tag>
      <view class="flex-1 font-size-22rpx color-[var(--text-inactive)]">
        {{ formatDate(item.create_time) }}
      </view>
    </view>
    <!--  -->
    <!-- <view class="absolute top-30rpx right-0 flex items-start gap-20rpx">
      <view class="w-80rpx text-right">
        <view class="font-size-22rpx">20%</view>
        <wd-progress :percent="20" hide-text />
      </view>
      <wd-button custom-class="!w-[max-content] !h-42rpx px-10rpx" type="info" size="small">
        Cancel
      </wd-button>
    </view> -->
    <!--  -->
    <view class="flex flex-col gap-y-24rpx mt-30rpx">
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('optionV2.orderNumber') }}
        </view>
        <view class="font-500">{{ item.order_no }}</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('optionV2.volume') }}({{ $t('optionV2.unit') }})
        </view>
        <view class="font-500">{{ item.bet_amount }}</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('optionV2.openPrice') }}
        </view>
        <view class="font-500">{{ item.begin_price }}</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('optionV2.closePrice') }}
        </view>
        <view class="font-500">{{ item.end_price }}</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('optionV2.deliveryRange') }}
        </view>
        <view :class="[item.delivery_up_down === 1 ? 'up-color' : 'down-color']" class="font-500">
          {{ item.delivery_range }}%({{ item.delivery_up_down === 1 ? 'Up' : 'Down' }})
        </view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">{{ $t('optionV2.deliveryAmount') }} (USDT)</view>
        <view class="font-500">
          {{ toFormat(item.delivery_amount, true) }}
        </view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('optionV2.status') }}
        </view>
        <view class="font-500">{{ $t('optionV2.filled') }}</view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { formatDate } from '@/utils/day'
import { toFormat } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
})
</script>

<style lang="scss" scoped>
//
</style>
