import mqtt from 'mqtt'

const url = import.meta.env.VITE_WS_BASEURL || `wss://${location.host}/mqtt`
let client = null
const dataList = []

export const onConnect = () => {
  const timer = setInterval(() => {
    const list = dataList.splice(0, dataList.length)
    console.log('[MQTT Data Length 500ms]', list.length)
    for (let i = 0; i < list.length; i++) {
      uni.$emit('message', list[i])
    }
  }, 500)

  client = mqtt.connect(url, {
    connectTimeout: 3 * 1000,
    username: 'admin',
    password: 'password',
    clean: true,
  })

  client
    .on('connect', () => {
      console.log('[MQTT success]')
    })
    .on('message', (topic, message) => {
      const data = message.toString()
      try {
        dataList.push([topic, JSON.parse(data), 'mqtt'])
      } catch (error) {
        dataList.push([topic, data, 'mqtt'])
      }
      // uni.$emit('message', [topic, JSON.parse(message.toString())])
    })
}

export const onSubscribe = (topic: string | string[]) => {
  if (client) {
    client.subscribe(topic, (error) => {
      if (error) {
        console.log('[Subscribe] Error:', error)
      } else {
        console.log('[Subscribe]:', topic)
      }
    })
  }
}

export const onUnsubscribe = (topic: string | string[]) => {
  if (client) {
    client.unsubscribe(topic, (error) => {
      if (error) {
        console.log('[Unsubscribe] Error:', error)
      } else {
        console.log('[Unsubscribed]:', topic)
      }
    })
  }
}
