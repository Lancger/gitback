<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    :z-index="99"
    custom-style="border-radius: 30rpx 30rpx 0 0"
    @close="onClose"
  >
    <view class="relative pt-10rpx px-30rpx">
      <view class="b-b mx-[-30rpx] py-20rpx px-30rpx">
        <view class="font-size-30rpx font-500">Orders confirmation</view>
        <view class="font-size-30rpx font-500 mt-20rpx">
          <text class="up-color">Buy</text>
          {{ data.product.symbolName }}-{{ data.current.time_name }}
          <text :class="data.mode === 1 ? 'up-color' : 'down-color'">
            {{ data.mode === 1 ? 'Up' : 'Down' }}
          </text>
          option
        </view>
      </view>
      <view class="flex flex-col gap-y-30rpx mt-30rpx">
        <view class="flex items-center justify-between">
          <view class="color-[var(--text-inactive)]">Order amount</view>
          <view class="font-500">{{ form.amount * data.current.contract_size }} USDT</view>
        </view>
        <view class="flex items-center justify-between">
          <view class="color-[var(--text-inactive)]">Volume</view>
          <view class="font-500">{{ form.amount }}</view>
        </view>
        <view class="flex items-center justify-between">
          <view class="color-[var(--text-inactive)]">Fee</view>
          <view class="font-500">{{ toFormat(data.fee) }} USDT</view>
        </view>
        <view class="flex items-center justify-between">
          <view class="color-[var(--text-inactive)]">Unit price</view>
          <view class="font-500">{{ data.current.contract_size }} USDT</view>
        </view>
      </view>
      <!-- <view class="flex items-center gap-10rpx mt-30rpx">
        <view class="color-[var(--text-inactive)]">Available</view>
        <view class="font-500">342,432.32 USDT</view>
      </view> -->
      <!--  -->
      <view
        class="px-30rpx py-20rpx mx-[-30rpx] mt-30rpx bg-[var(--background-primary)] shadow-[var(--box-shadow)]"
      >
        <wd-button type="primary" size="large" block round :loading="loading" @click="onSubmit">
          {{ $t('common.confirm') }}
        </wd-button>
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'
import { inputLimitToDigit, BNumber, toFixed, toFormat } from '@/utils/number'
import { fetchOptionsV2PlaceOrder } from '@/service/options'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  form: {
    type: Object,
    default: () => {},
  },
  data: {
    type: Object,
    default: () => {},
  },
})

const emits = defineEmits(['update:modelValue'])

const loading = ref(false)

const onSubmit = async () => {
  loading.value = true
  try {
    await fetchOptionsV2PlaceOrder(props.form)
    onRouter(
      `/pages/optionV2/result?mode=${props.data.mode}&title=${props.data.product.symbolName}-${props.data.current.time_name}&date=${props.data.time[1]}`,
      'redirectTo',
    )
  } catch (error) {
    loading.value = false
  }
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
:deep(.wd-popup) {
  overflow-y: visible !important;
}
</style>
