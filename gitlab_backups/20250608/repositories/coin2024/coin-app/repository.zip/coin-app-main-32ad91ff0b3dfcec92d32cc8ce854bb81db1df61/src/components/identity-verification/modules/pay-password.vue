<template>
  <view class="p-30rpx mt-30rpx min-h-70vh">
    <view class="font-size-40rpx font-600">
      {{ $t('components.identityVerification.payPassword.title') }}
    </view>
    <view class="mt-30rpx font-size-24rpx color-[var(--text-inactive)]">
      {{ $t('components.identityVerification.payPassword.desc') }}
    </view>
    <view class="mt-100rpx font-size-24rpx font-500 color-[var(--text-inactive)]">
      {{ $t('components.identityVerification.payPassword.verificationCode') }}
    </view>
    <view
      class="flex items-center h-90rpx px-30rpx mt-20rpx font-size-30rpx font-500 bg-[var(--background-gary-4)] rd-15rpx"
    >
      <input v-model="code" class="flex-1 h-100% lh-90rpx" :password="isPassword" type="text" />
      <wd-icon
        :name="isPassword ? 'eye-close' : 'view'"
        size="30rpx"
        @click="isPassword = !isPassword"
      ></wd-icon>
    </view>
    <wd-button
      custom-class="mt-40rpx !w-100%"
      size="large"
      :loading="loading"
      :disabled="!code.length"
      @click="onSubmit"
    >
      {{ $t('common.submit') }}
    </wd-button>
  </view>
</template>

<script lang="ts" setup>
import md5 from 'md5'
import { fetchPayPasswordCheck } from '@/service/user'

const emits = defineEmits(['onCallback'])

const code = ref('')
const loading = ref(false)
const isPassword = ref(true)

const onSubmit = async () => {
  loading.value = true
  try {
    await fetchPayPasswordCheck(code.value)
    emits('onCallback', code.value)
    code.value = ''
    loading.value = false
  } catch (error) {
    loading.value = false
  }
}
</script>

<style lang="scss" scoped></style>
