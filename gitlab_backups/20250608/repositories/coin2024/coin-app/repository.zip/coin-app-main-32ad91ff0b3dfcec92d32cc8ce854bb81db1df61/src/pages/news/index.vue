<template>
  <app-navbar title="news" left-arrow custom-class="!bg-transparent"></app-navbar>
  <wd-tabs
    @click="handleClick"
    custom-class="app-tabs news-tab"
    v-model="tab"
    swipeable
    animated
    :map-num="100"
  >
    <wd-tab title="News">
      <news-list :list="newsData"></news-list>
      <wd-loadmore :state="loadMoreState" />
    </wd-tab>
    <wd-tab title="Academy">
      <news-list :list="newsData"></news-list>
      <wd-loadmore :state="loadMoreState" />
    </wd-tab>
  </wd-tabs>
</template>
<script lang="ts" setup>
import { fetchFormData } from '@/service/base'
import usePagination from '@/hooks/usePagination'

const newsParams = reactive({
  article_type: '1530429800596701185',
  article_issue: 1,
  pageSize: 12,
  pageNo: 1,
  article_lang: 'en',
  column: 'id',
  order: 'desc',
})

const {
  data: newsData,
  loadMoreState,
  onInit,
} = usePagination({
  api: getNews,
  params: newsParams,
  onLoadMoreFn: onReachBottom,
})

const tab = ref<number>(0)

watchEffect(() => {
  newsData.value = newsData.value.sort(
    (a, b) => new Date(b.article_time).getTime() - new Date(a.article_time).getTime(),
  )
})

const handleClick = (e) => {
  newsData.value = []
  if (e.index === 0) {
    newsParams.article_type = '1530429800596701185'
  } else {
    newsParams.article_type = '1530476503358046209'
  }
  onInit()
}

function getNews(params) {
  return fetchFormData('1530431184536666113', params)
}
</script>
<style lang="scss" scoped>
.page {
  background: var(--background-secondary) var(--background-linear-gradient-1) no-repeat;
  background-size: 100% 744rpx;
}
.news-tab {
  :deep(.wd-tabs__nav-item) {
    flex: none !important;
    padding: 0 30rpx !important;
  }
}
</style>
