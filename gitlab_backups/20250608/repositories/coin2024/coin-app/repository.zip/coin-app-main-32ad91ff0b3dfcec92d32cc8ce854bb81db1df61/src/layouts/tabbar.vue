<template>
  <wd-config-provider :class="['page', themeStore.theme]">
    <slot />
    <wd-toast />
    <wd-message-box />
    <wd-notify />
    <wd-tabbar
      :model-value="pagePath"
      fixed
      :bordered="false"
      placeholder
      safeAreaInsetBottom
      :zIndex="90"
      @change="handleTabbarChange"
    >
      <wd-tabbar-item
        v-for="item in tabBar.list"
        :key="item.pagePath"
        :title="$t(item.text)"
        :name="item.pagePath"
      >
        <template #icon="{ active }">
          <wd-img
            height="40rpx"
            width="40rpx"
            :src="
              active
                ? onImageToThemeImage(item.selectedIconPath)
                : onImageToThemeImage(item.iconPath)
            "
          ></wd-img>
        </template>
      </wd-tabbar-item>
    </wd-tabbar>
  </wd-config-provider>
</template>

<script lang="ts" setup>
import { useThemeStore } from '@/store'
import { tabBar } from '@/pages.json'
import { currRoute, onImageToThemeImage } from '@/utils'

const themeStore = useThemeStore()
const pagePath = currRoute().path.substr(1)

const handleTabbarChange = (params) => {
  uni.switchTab({
    url: `/${params.value}`,
  })
}
</script>

<style lang="scss">
:deep(.wd-tabbar) {
  background: var(--wot-tabbar-bg) !important;
  box-shadow: var(--wot-tabbar-shadow, '') !important;
}
:deep(.wd-tabbar-item__body) {
  .wd-tabbar-item__body-title {
    margin-top: 5px !important;
    font-weight: 500;
  }
  .is-active {
    font-weight: 600;
  }
}
</style>
