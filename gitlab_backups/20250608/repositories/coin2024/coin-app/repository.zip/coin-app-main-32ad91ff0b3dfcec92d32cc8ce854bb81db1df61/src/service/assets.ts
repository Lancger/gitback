import { http } from '@/utils/http'

export const fetchGetCurrencyAccount = (data: { type: any }) => {
  return http.post('/api/mjkj-web/coin/assets/getCurrencyAccount', data)
}

export const fetchGetWalletAccount = () => {
  return http.get('/api/mjkj-web/coin/assets/getWalletAccount')
}

export const fetchGetDictItems = (data) => {
  return http.get(`/api/mjkj-web/sys/sys/dict/getDictItems/${data}`)
}

export const fetchGetData = (param: { pageSize: number; order: string }) => {
  return http.get('/api/mjkj-web/cgform-api/getData/1531180815470080002', param)
}

export const fetchGetMyBill = (data) => {
  return http.post('/api/mjkj-web/coin/assets/getMyBill', data)
}

export const fetchGetRechargeCurrency = (params) => {
  return http.get('/api/mjkj-web/coin/assets/getRechargeCurrency', params)
}

export const fetchGetDepositAddress = (param: any) => {
  return http.get('/api/mjkj-web/coin/assets/getDepositAddress/' + param)
}

export const fetchGetRechargeLog = (data) => {
  return http.post('/api/mjkj-web/coin/assets/getRechargeLog', data)
}

export const fetchGetWithdrawalLog = (data) => {
  return http.post('/api/mjkj-web/coin/assets/getWithdrawalLog', data)
}

export const fetchWithdrawal = (data) => {
  return http.post('/api/mjkj-web/coin/assets/withdrawal', data)
}

// 获取资产类型
export const fetchWalletTransAccount = (data) => {
  return http.get('/api/mjkj-web/sys/sys/dict/getDictItems/wallet_trans_account', data)
}

// 获取资产类型下面的币种余额
export const fetchGetMyBalance = (param: any) => {
  return http.get('/api/mjkj-web/coin/assets/getMyBalance', param)
}

// 划转接口
export const fetchWalletTrans = (param: any) => {
  return http.get('/api/mjkj-web/coin/wallet/trans', param)
}

// 取消出金
export const fetchWithdrawalCancel = (id: any) => {
  return http.post(`/api/mjkj-web/coin/assets/withdrawal/cancel/${id}`)
}

// 获取钱包币种余额
export const fetchWalletToken = (token) => {
  return http.get(`/api/mjkj-web/coin/wallet/get/wealth/${token}`)
}
