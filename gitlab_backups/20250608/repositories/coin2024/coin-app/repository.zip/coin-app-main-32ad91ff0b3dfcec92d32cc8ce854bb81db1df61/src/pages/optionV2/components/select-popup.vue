<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    :z-index="99"
    custom-style="border-radius: 30rpx 30rpx 0 0"
    @close="onClose"
  >
    <view class="relative pt-40rpx">
      <view class="font-size-30rpx font-500 px-30rpx pb-20rpx">Select</view>
      <!--  -->
      <tabs-box v-model="tabIndex" />
      <!--  -->
      <wd-tabs
        custom-class="app-tabs--tag app-tabs--tag-info app-tabs--no-flex-1 mt-20rpx"
        :model-value="1"
        swipeable
        animated
        :map-num="100"
      >
        <block
          v-for="(item, index) in ['15 min', '30 min', '60 min', '90 min', '120 min']"
          :key="index"
        >
          <wd-tab :title="item"></wd-tab>
        </block>
      </wd-tabs>
      <view
        class="flex items-center justify-between px-30rpx mt-30rpx font-size-22rpx color-[var(--text-inactive)]"
      >
        <view>Index price: 3860.7</view>
        <view>Expiration time: 23:21:12</view>
      </view>
      <!-- product list -->
      <scroll-view class="h-60vh" scroll-y>
        <product-list />
      </scroll-view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import TabsBox from './tabs-box.vue'
import ProductList from './product-list.vue'
import { t } from '@/locale'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'
import { inputLimitToDigit, BNumber, toFixed, toFormat } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
})

const emits = defineEmits(['update:modelValue'])

const tabIndex = ref(0)

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
:deep(.wd-popup) {
  overflow-y: visible !important;
}
</style>
