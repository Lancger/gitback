<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    :z-index="99"
    closable
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="ico-popup">
      <view class="ico-popup__title">
        {{ mode === 'pay' ? $t('ico.payment') : $t('ico.detail') }}
      </view>
      <view class="ico-popup__top">
        <view class="coin-info">
          <image class="coin-info__logo" :src="rowData.avatar" mode="scaleToFill" />
          <view class="coin-info__name">{{ rowData.symbol }}</view>
          <!-- <view class="coin-info__desc">{{ rowData.symbol }}</view> -->
        </view>
        <view v-if="mode !== 'pay'" class="progress">
          <view class="progress__title">{{ $t('ico.schedule') }}</view>
          <view class="progress__main">
            <view class="progress__main__line">
              <wd-progress :percentage="rowData.progress" color="''" />
            </view>
          </view>
        </view>
      </view>
      <block v-if="mode !== 'pay'">
        <view class="detail-list">
          <view class="detail-list__item">
            <view class="detail-list__item__label">{{ $t('ico.offeringPrice') }}</view>
            <view class="detail-list__item__value">{{ toFormat(rowData.price, true) }} USDT</view>
          </view>
          <view class="detail-list__item">
            <view class="detail-list__item__label">{{ $t('ico.issueQuantity') }}</view>
            <view class="detail-list__item__value">{{ toFormat(rowData.circulation, 0) }}</view>
          </view>
          <view class="detail-list__item">
            <view class="detail-list__item__label">{{ $t('ico.startTime') }}</view>
            <view class="detail-list__item__value">{{ formatDate(rowData.start_time) }}</view>
          </view>
          <view class="detail-list__item">
            <view class="detail-list__item__label">{{ $t('ico.closingTime') }}</view>
            <view class="detail-list__item__value">{{ formatDate(rowData.stop_time) }}</view>
          </view>
        </view>
        <view class="input-box">
          <view class="input-box__left">
            <view class="input-box__title">{{ $t('ico.subscribe') }}</view>
            <input
              v-model="form.purchaseQuantity"
              class="input-box__input"
              type="number"
              :placeholder="`${$t('ico.min')} ${rowData.person_quota_min}`"
              @input="onInput"
            />
          </view>
          <view class="input-box__unit">
            <!-- <text>{{ rowData.symbol }}</text> -->
            <text class="input-box__unit__btn" @click="onMax">{{ $t('ico.max') }}</text>
          </view>
        </view>
      </block>
      <view v-else class="detail-list">
        <view class="detail-list__item">
          <view class="detail-list__item__label">{{ $t('ico.unitPrice') }}</view>
          <view class="detail-list__item__value">{{ rowData.subscribed_price }} USDT</view>
        </view>
        <view class="detail-list__item">
          <view class="detail-list__item__label">{{ $t('ico.subscribeQuantity') }}</view>
          <view class="detail-list__item__value">{{ rowData.allotment_quantity }}</view>
        </view>
        <view class="detail-list__item">
          <view class="detail-list__item__label">{{ $t('ico.listingTime') }}</view>
          <view class="detail-list__item__value">{{ formatDate(rowData.ipo_time) }}</view>
        </view>
      </view>
      <view class="input-box input-box--disabled">
        <view class="input-box__left">
          <view class="input-box__title">
            {{ mode !== 'pay' ? $t('ico.total') : $t('ico.willFreeze') }}
          </view>
          <input class="input-box__input" type="text" disabled :value="totalPrice" />
        </view>
        <view class="input-box__unit">USDT</view>
      </view>
      <view v-if="mode !== 'pay'" class="asset">
        <text class="asset__title">{{ $t('ico.available') }}</text>
        {{ assets.balance }} USDT
        <text class="asset__btn" @click="onRouter('/pages/asset/deposit/index')">
          {{ $t('ico.topUp') }}
        </text>
      </view>
      <view class="ico-popup__btn">
        <wd-button size="large" block :loading="loading" @click="onSubmit">
          {{ mode === 'pay' ? $t('common.confirm') : $t('common.submit') }}
        </wd-button>
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchIcoSubscribe, fetchIcoSubscribePay } from '@/service/ico'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'
import { inputLimitToDigit, BNumber, toFixed, toFormat } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  rowData: {
    type: Object,
    default: () => {},
  },
  assets: {
    type: Object,
    default: () => {},
  },
  mode: {
    type: String,
    default: 'placeOrder', // placeOrder / pay
  },
})

const emits = defineEmits(['update:modelValue', 'onCallBack'])

const loading = ref(false)
const form = reactive({
  purchaseQuantity: '',
  projectId: '',
})

const totalPrice = computed(() => {
  if (props.mode !== 'pay') {
    return toFixed(BNumber(form.purchaseQuantity || 0).times(props.rowData.price || 0))
  }

  return Number(BNumber(props.rowData.subscribed_price).times(props.rowData.allotment_quantity))
})

const funMap = {
  placeOrder: onPlaceOrder,
  pay: onPay,
}

async function onPay() {
  loading.value = true
  try {
    await fetchIcoSubscribePay({
      recordId: props.rowData.id,
    })
    uni.showToast({
      title: t('common.success'),
      icon: 'success',
      duration: 2000,
    })
    emits('onCallBack', props.mode)
    onClose()
    loading.value = false
  } catch (e) {
    loading.value = false
  }
}

async function onPlaceOrder() {
  if (+form.purchaseQuantity < props.rowData.person_quota_min) {
    uni.showToast({
      title: `${t('ico.min')} ${props.rowData.person_quota_min}`,
      icon: 'none',
    })
    return
  }
  loading.value = true
  form.projectId = props.rowData.id
  try {
    await fetchIcoSubscribe(form)
    emits('onCallBack', props.mode)
    onClose()
    loading.value = false
  } catch (e) {
    loading.value = false
  }
}

async function onSubmit() {
  funMap[props.mode]()
}
function onInput(e) {
  nextTick(() => {
    form.purchaseQuantity = inputLimitToDigit(e.detail.value)
  })
}

function onMax() {
  form.purchaseQuantity = props.rowData.person_quota_max
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.ico-popup {
  padding: 0 30rpx;
  &__title {
    height: 90rpx;
    font-size: 30rpx;
    font-weight: 500;
    line-height: 90rpx;
    text-align: center;
  }
  &__top {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  &__btn {
    padding: 30rpx;
    margin: 30rpx -30rpx 0;
    box-shadow: var(--box-shadow);
  }
  .coin-info {
    display: flex;
    align-items: center;
    &__logo {
      width: 46rpx;
      height: 46rpx;
      margin-right: 20rpx;
      border-radius: 50%;
    }
    &__name {
      font-size: 30rpx;
      font-weight: 500;
    }
    &__desc {
      font-size: 22rpx;
      color: var(--text-inactive);
    }
  }
  .progress {
    &__title {
      font-size: 22rpx;
      color: var(--text-inactive);
      text-align: right;
    }
    &__main {
      display: flex;
      align-items: center;
      width: 320rpx;
      margin-top: 10rpx;
      &__line {
        flex: 1;
      }
      &__text {
        font-size: 24rpx;
      }
    }
  }
  .detail-list {
    padding: 30rpx 0;
    &__item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 24rpx;
      + .detail-list__item {
        margin-top: 30rpx;
      }
      &__label {
        color: var(--text-inactive);
      }
    }
  }
  .input-box {
    box-sizing: border-box;
    display: flex;
    align-items: center;
    padding: 20rpx 30rpx;
    margin-bottom: 30rpx;
    border: 1px solid var(--border-color);
    border-radius: 10rpx;
    &--disabled {
      background: var(--background-gary-4);
    }
    &__left {
      flex: 1;
    }
    &__title {
      font-size: 18rpx;
      color: var(--text-inactive);
    }
    &__input {
      margin-top: 10rpx;
      font-size: 30rpx;
    }
    &__unit {
      font-size: 30rpx;
      &__btn {
        position: relative;
        padding-left: 60rpx;
        color: var(--color-primary);
        &::after {
          position: absolute;
          top: 50%;
          left: 30rpx;
          width: 1px;
          height: 30rpx;
          content: '';
          background: #000;
          transform: translateY(-50%);
        }
      }
    }
  }
  .asset {
    font-size: 22rpx;
    &__title {
      color: var(--text-inactive);
    }
    &__btn {
      padding-left: 10rpx;
      text-decoration: underline;
    }
  }
}
</style>
