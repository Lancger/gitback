<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar :title="$t('message.notice.title')" left-arrow></app-navbar>
  <app-empty :no-data="data.length === 0">
    <view
      v-for="(item, index) in data"
      :key="index"
      class="px-30rpx py-30rpx b-b"
      @click="onRouter(`/pages/news/details?id=${item.id}`)"
    >
      <view class="flex items-center justify-between">
        <view class="font-size-28rpx font-500 ellipsis">{{ item.article_title }}</view>
      </view>
      <view
        class="mt-20rpx line-height-30rpx font-size-22rpx color-[var(--text-active)] ellipsis-2"
      >
        {{ toText(item.article_content) }}
      </view>
      <view class="mt-20rpx font-size-22rpx color-[var(--text-inactive)]">
        {{ formatDate(item.release_time) }}
      </view>
    </view>
    <wd-loadmore :state="loadMoreState" />
  </app-empty>
</template>

<script lang="ts" setup>
import usePagination from '@/hooks/usePagination'
import { fetchNotice } from '@/service/home'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'

const { data, loadMoreState } = usePagination({
  api: fetchNotice,
  params: {
    current: 1,
    size: 12,
  },
  onLoadMoreFn: onReachBottom,
  pageNoKey: 'current',
  pageSizeKey: 'size',
})

const toText = (HTML) => {
  const input = HTML
  return input
    .replace(/<(style|script|iframe)[^>]*?>[\s\S]+?<\/\1\s*>/gi, '')
    .replace(/<[^>]+?>/g, '')
    .replace(/\s+/g, ' ')
    .replace(/ /g, ' ')
    .replace(/&ldquo;/g, ' ')
    .replace(/&rdquo;/g, ' ')
    .replace(/&nbsp;/gi, '')
    .replace(/>/g, ' ')
}
</script>

<style lang="scss" scoped></style>
