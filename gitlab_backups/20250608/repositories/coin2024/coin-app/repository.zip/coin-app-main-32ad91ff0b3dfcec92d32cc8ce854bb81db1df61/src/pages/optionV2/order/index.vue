<template>
  <app-navbar>
    <template #title>
      <view class="h-100% flex flex-col justify-center">
        <view class="font-size-34rpx font-600 lh-none">
          {{ $t('optionV2.order') }}
        </view>
        <view class="font-size-22rpx font-400 color-[var(--text-inactive)] lh-none">
          {{ $t('optionV2.options') }}
        </view>
      </view>
    </template>
  </app-navbar>
  <!--  -->
  <wd-tabs
    custom-class="app-tabs--no-flex-1"
    v-model="tabIndex"
    swipeable
    animated
    :map-num="100"
    @change="onTabChange"
  >
    <block v-for="(item, index) in tab" :key="index">
      <wd-tab :title="item.label"></wd-tab>
    </block>
  </wd-tabs>
  <!-- <view @click="closeOutside">
    <wd-drop-menu>
      <wd-drop-menu-item v-model="optionsValue" :options="options" />
    </wd-drop-menu>
  </view> -->
  <!--  -->
  <app-empty :no-data="list.length === 0">
    <position-list v-if="tabIndex === 0" :list="list" @onCountDownEnd="getList" />
    <order-list v-else :list="list" />
    <wd-loadmore :state="loadMoreState" />
  </app-empty>

  <close-position-popup v-model="showClosePositionPopup" />
</template>

<script lang="ts" setup>
import { useQueue } from 'wot-design-uni'
import PositionList from '../components/position-list.vue'
import ClosePositionPopup from '../components/close-position-popup.vue'
import OrderList from '../components/order-list.vue'
import { fetchOptionsOrder } from '@/service/options'
import { t } from '@/locale'

const { closeOutside } = useQueue()
const tab = [
  { label: t('optionV2.position'), value: 0 },
  // { label: 'Orders', value: 'orders' },
  { label: t('optionV2.orderHistory'), value: 1 },
]
const tabIndex = ref(0)
const options = [
  {
    label: t('optionV2.cancel'),
    value: 'cancel',
  },
]
const optionsValue = ref('cancel')
const showClosePositionPopup = ref(false)

const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
} = usePagination({
  api: (params) => {
    return fetchOptionsOrder({
      pageNo: params.pageNo,
      pageSize: params.pageSize,
      order_status: tab[tabIndex.value].value,
    })
  },
  params: {},
  onLoadMoreFn: onReachBottom,
})

const onTabChange = ({ index }) => {
  tabIndex.value = index
  list.value = []
  getList()
}
</script>

<style lang="scss" scoped>
:deep(.wd-drop-menu__item) {
  flex: none;
  height: 70rpx;
  line-height: 70rpx;
}
</style>
