<template>
  <wd-navbar
    :title="title"
    :customClass="customClass"
    :customStyle="'z-index: 5;' + customStyle"
    :bordered="false"
    fixed
    :placeholder="placeholder"
    safeAreaInsetTop
    :left-arrow="leftArrow"
    @click-left="handleClickLeft"
  >
    <template v-if="$slots.capsule" #capsule>
      <slot name="capsule"></slot>
    </template>
    <template v-if="$slots.left" #left>
      <slot name="left"></slot>
    </template>
    <template v-if="$slots.title" #title>
      <slot name="title"></slot>
    </template>
    <template v-if="$slots.right" #right>
      <slot name="right"></slot>
    </template>
  </wd-navbar>
</template>

<script lang="ts" setup>
const props = defineProps({
  title: {
    type: String,
    default: '',
  },
  customClass: {
    type: String,
    default: '',
  },
  customStyle: {
    type: String,
    default: '',
  },
  leftArrow: {
    type: Boolean,
    default: true,
  },
  placeholder: {
    type: Boolean,
    default: true,
  },
})
const pages = getCurrentPages()

function handleClickLeft() {
  if (pages.length > 1) {
    uni.navigateBack()
  } else {
    uni.reLaunch({
      url: '/pages/home/index',
    })
  }
}
</script>

<style lang="scss" scoped>
//
</style>
