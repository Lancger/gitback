import { http } from '@/utils/http'

// 申请贷款
export const fetchApplyLoan = (data: any) => {
  return http.post('/api/mjkj-web/coin/pledge/apply', data)
}

// 获取贷款记录
export const fetchLoanRecords = (params: any) => {
  return http.get('/api/mjkj-web/coin/pledge/getPledgeRecordList', params)
}

// 获取贷款项目列表
export const fetchLoanProjectList = (params: any) => {
  return http.get('/api/mjkj-web/coin/pledge/getPledgeProjectList', params)
}

// 获取贷款历史记录
export const fetchLoanHistory = (params: any) => {
  return http.get('/api/mjkj-web/coin/pledge/getRepaymentList', params)
}

// 还款
export const fetchLoanRepayment = (data: any) => {
  return http.post('/api/mjkj-web/coin/pledge/repayment', data)
}
