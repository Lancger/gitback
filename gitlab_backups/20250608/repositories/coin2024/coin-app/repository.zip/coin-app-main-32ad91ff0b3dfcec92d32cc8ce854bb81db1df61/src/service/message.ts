import { http } from '@/utils/http'

// 获取通知列表
export const fetchMessageList = (data?: any) => {
  return http.post('/api/mjkj-web/coin/member/getMessageList', data)
}

// 已读
export const fetchReadMessage = (msgIds: (string | number)[]) => {
  return http.post(`/api/mjkj-web/coin/member/markMessageRead`, { msgIds })
}

// 获取未读数
export const fetchUnreadMessageCount = (userId: string) => {
  return http.post('/api/mjkj-web/coin/member/getUnreadMessageCount', { userId })
}
