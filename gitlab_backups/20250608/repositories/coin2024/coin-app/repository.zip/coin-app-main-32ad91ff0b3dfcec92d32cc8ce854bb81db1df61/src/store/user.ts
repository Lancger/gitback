import { defineStore } from 'pinia'
import md5 from 'md5'
import { BNumber, toFormat } from '@/utils/number'
import { fetchAuth } from '@/service/auth'
import { fetchGetUserInfo } from '@/service/user'
import { fetchFormData } from '@/service/base'
import { onSubscribe } from '@/utils/subscribe'
import config from '@/config'

const initState = { nickname: '', avatar: '' }

export const useUserStore = defineStore(
  'user',
  () => {
    const userInfo = ref<IUserInfo>({ ...initState })
    const token = ref('')
    const authForm = ref<{ [key: string]: any }>({}) // 登录、注册表单
    const exchangeRateList = ref<any>([])
    const exchangeRateCurrent = ref<any>({
      quote_currency: import.meta.env.VITE_CURRENCY,
    })
    const noticePopupIdMap = ref<any>({}) // 公告弹窗 ID Map
    const earnHistoryItemData = ref<any>({}) // 理财历史数据

    const onSetExchangeRateCurrent = (val) => {
      exchangeRateCurrent.value = val
    }

    const getExchangeRateCurrent = (quote) => {
      return exchangeRateList.value.find(
        (item) => item.base_currency === 'USDT' && item.quote_currency === quote,
      )
    }

    const onGetExchangeRate = (first?) => {
      return fetchFormData('1531553843420971009', {
        pageSize: '-521',
        country_flag: 1,
        column: 'id',
        order: 'desc',
      }).then((res) => {
        exchangeRateList.value = res.data.records
        if (first) {
          exchangeRateCurrent.value = getExchangeRateCurrent(
            exchangeRateCurrent.value.quote_currency,
          )
        }
      })
    }

    const onExchangeRateConversion = (
      amount: string | number,
      decimal: number | boolean = true,
    ) => {
      amount = amount || 0
      if (typeof decimal === 'boolean' && decimal) {
        decimal = BNumber(amount).dp()
      }
      return `${exchangeRateCurrent.value.exchange_code}${toFormat(BNumber(amount).times(exchangeRateCurrent.value.rate || 0), decimal)}`
    }

    const onAuth = (form) => {
      authForm.value = form
      return fetchAuth({
        ...form,
        password: md5(form.password),
        remark: form.loginType === 'register' ? form.password : null,
      }).then(async (res: any) => {
        if (res.error_description !== '步骤1登录成功') {
          token.value = `${res.token_type} ${res.access_token}`
          await getUserInfo()
          config.c2cChat && onSubscribe(`refresh_${userInfo.value?.blade_user_id}`)
          onSubscribe(`notify_new_message_${userInfo.value?.blade_user_id}`)
          onSubscribe(`notify_new_message_all`)
        }
        return res
      })
    }

    const getUserInfo = () => {
      return fetchGetUserInfo().then((res) => {
        userInfo.value = res.data
      })
    }

    const setUserInfo = (val: IUserInfo) => {
      userInfo.value = val
    }

    const clearUserInfo = () => {
      userInfo.value = {}
    }
    // 一般没有reset需求，不需要的可以删除
    const reset = () => {
      userInfo.value = { ...initState }
    }

    const isLogined = computed(() => !!token.value)

    const onLogout = () => {
      token.value = ''
      authForm.value = {}
      clearUserInfo()
    }

    return {
      token,
      userInfo,
      authForm,
      exchangeRateList,
      exchangeRateCurrent,
      noticePopupIdMap,
      earnHistoryItemData,
      isLogined,
      onSetExchangeRateCurrent,
      onExchangeRateConversion,
      onGetExchangeRate,
      getUserInfo,
      onAuth,
      reset,
      onLogout,
    }
  },
  {
    persist: true,
  },
)
