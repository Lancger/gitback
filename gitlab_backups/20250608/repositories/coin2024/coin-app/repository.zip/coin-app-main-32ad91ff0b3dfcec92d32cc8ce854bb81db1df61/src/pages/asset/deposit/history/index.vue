<template>
  <app-navbar custom-class="bg-transparent" :title="$t('assets.deposit.history')"></app-navbar>

  <view class="menu">
    <wd-drop-menu custom-class="h-100rpx">
      <wd-drop-menu-item
        :title="typetitle"
        @open="norecordFlag = false"
        @close="norecordFlag = true"
        ref="dropMenu"
      >
        <view class="product-list" v-if="coinList.records">
          <view class="product-list__item">
            <view class="product-list__item__coin-info">
              <!-- <image class="w-60rpx h-60rpx img" src="@img/avatar.png" mode="aspectFit" />
              <image class="product-list__item__coin-info__logo" src="item.bzicon" mode="aspectFit" /> -->
              <view class="product-list__item__coin-info__content">
                <view class="product-list__item__coin-info__name" @click="coinIdClick">
                  {{ $t('common.all') }}
                </view>
              </view>
            </view>
          </view>
          <view
            class="product-list__item"
            v-for="(v, i) in coinList.records"
            :key="i"
            @click="coinIdClick(v)"
          >
            <view class="product-list__item__coin-info flex">
              <image class="w-60rpx h-60rpx img" :src="v.avatar" mode="aspectFit" />
              <view class="product-list__item__coin-info__content">
                <view class="product-list__item__coin-info__name">
                  {{ v.symbol }}
                  <text class="font-400 font-size-22rpx color-[var(--text-active)]">
                    /{{ v.full_name }}
                  </text>
                </view>
              </view>
            </view>
          </view>
        </view>
      </wd-drop-menu-item>
    </wd-drop-menu>
  </view>
  <view class="mt-120rpx" v-if="newsData.length > 0">
    <view
      class="cell"
      v-for="(v, i) in newsData"
      :key="i"
      @click="onRouter(`/pages/asset/deposit/history/details?id=${v.id}&type=${type}`)"
    >
      <view class="flex-jc">
        <view class="flex">
          <view class="title">{{ v.coin_symbol }}</view>
          <view class="">{{ v.chain_type }}</view>
        </view>
        <view class="coin">{{ type === '2' ? '-' : '+' }}{{ toFormat(v.amount, true) }}</view>
      </view>

      <view class="flex-jc mt4">
        <view class="time">{{ formatDate(v.create_time) }}</view>
        <view class="time">
          <!-- <span class="fee">{{ v.fee_amount }}</span> -->
          <span>
            <!-- Balance 0  -->
            {{
              {
                '-1': $t('assets.deposit.fail'),
                '0': $t('assets.deposit.pending'),
                '1': $t('assets.deposit.success'),
                '2': $t('assets.deposit.pending'),
                '3': $t('assets.deposit.success'),
                '4': $t('assets.deposit.fail'),
              }[v.log_status]
            }}
          </span>
        </view>
      </view>
    </view>
  </view>

  <!-- <view class="norecord" v-if="newsData.length === 0 && norecordFlag">
    <image class="w300rpx h177rpx" src="@/static/images/assets/norecord.png" mode="aspectFit" />
    <view class="norecord_text">No record</view>
  </view> -->
  <app-empty v-if="newsData.length === 0 && norecordFlag" :no-data="true"></app-empty>
</template>

<script lang="ts" setup>
import { onLoad } from '@dcloudio/uni-app'
import { ref } from 'vue'
import { toFormat } from '@/utils/number'
import { onRouter } from '@/utils'
import { fetchGetRechargeLog, fetchGetData, fetchGetWithdrawalLog } from '@/service/assets'
import usePagination from '@/hooks/usePagination'
import { formatDate } from '@/utils/day'

const type = ref<any>('')
const norecordFlag = ref(true)
const coinList = ref<any>({
  records: [],
})
const rechargeList = ref([])

const value = ref<number>(Date.now())
const newsParams = reactive({
  coinId: '',
  current: 1,
  size: 12,
  type: '',
})

const {
  data: newsData,
  loadMoreState,
  onInit,
} = usePagination({
  api: getNews,
  params: newsParams,
  pageNoKey: 'current',
  pageSizeKey: 'sizi',
  onLoadMoreFn: onReachBottom,
})

onLoad(() => {
  type.value = uni.getStorageSync('assetType')
  coinData()
})

const typetitle = ref<string>('All')

const dropMenu = ref()
const coinIdClick = (data) => {
  newsParams.coinId = data.id ? data.id : ''
  typetitle.value = data.name ? data.name : 'All'
  onInit()
  dropMenu.value.close()
}

const coinData = () => {
  return fetchGetData({
    pageSize: -521,
    order: 'asc',
  }).then((res) => {
    coinList.value = res.data
  })
}
function getNews(params) {
  if (uni.getStorageSync('assetType') === '1') {
    return fetchGetRechargeLog(params)
  } else {
    return fetchGetWithdrawalLog(params)
  }
}
</script>

<style lang="scss" scoped>
.page {
  background: var(--background-secondary);
}
:deep(.wd-drop-item) {
  z-index: 9999;
}
.menu {
  position: fixed;
  top: 44px;
  right: 0;
  left: 0;
  background-color: var(--background-primary);
}
:deep(.wd-drop-menu) {
  display: flex;
  justify-content: space-between;
}
:deep(.wd-drop-menu__list) {
  display: flex;
  justify-content: space-between;
  padding-right: 20rpx;
  //   background-color: var(--background-secondary);
}
:deep(.wd-drop-menu__item-title-text) {
  margin-right: 10rpx !important;
}
:deep(.wd-drop-menu__arrow) {
  font-size: 30px !important;
}
:deep(.wd-drop-menu__item) {
  flex: none;
  justify-content: space-between;
}
.norecord {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  &_text {
    margin-top: 30rpx;
    color: var(--text-inactive) !important;
    text-align: center;
  }
}
.cell {
  box-sizing: border-box;
  width: 690rpx;
  padding: 20rpx;
  margin: 20rpx auto;
  background-color: var(--background-primary);
  border-radius: 20rpx;
  .market {
    padding: 5rpx 10rpx;
    margin-left: 20rpx;
    font-size: 20rpx;
    border-radius: 5rpx;
  }

  .title {
    margin-right: 20rpx;
    font-family: Asap;
    font-size: 28rpx;
    font-weight: 500;
  }
  .coin {
    font-family: Asap;
    font-size: 26rpx;
    color: #07ba83;
    // color: #FF4E43;
  }
  .cost {
    margin-top: 10rpx;
    color: var(--text-inactive);
    text-align: right;
  }
  .time {
    font-size: 22rpx;
    color: var(--text-inactive);
  }

  .fee {
    margin-right: 20rpx;
  }
}
.flex {
  align-items: center;
}
//
.flex-jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.product-list {
  margin: 0 30rpx;
  &__item {
    display: flex;
    align-items: center;
    padding: 30rpx;
    background: var(--background-primary);
    border-radius: 20rpx;
    &__coin-info {
      display: flex;
      align-items: center;
      width: 40%;
      &__logo {
        width: 50rpx;
        height: 50rpx;
        border-radius: 50%;
      }
      &__content {
        flex: 1;
        padding-left: 20rpx;
      }
      &__name {
        font-size: 30rpx;
        font-weight: 500;
      }
    }
  }
}
</style>
