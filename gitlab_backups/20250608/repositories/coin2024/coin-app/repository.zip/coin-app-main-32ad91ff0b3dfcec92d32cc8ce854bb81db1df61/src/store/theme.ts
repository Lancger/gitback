import { defineStore } from 'pinia'

export const useThemeStore = defineStore(
  'theme',
  () => {
    const theme = ref('light')

    const isDark = computed(() => theme.value === 'dark')

    const switchTheme = (themeName) => {
      theme.value = themeName
    }

    return {
      theme,
      isDark,
      switchTheme,
    }
  },
  {
    persist: true,
  },
)
