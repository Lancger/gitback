<template>
  <app-navbar :title="$t('safe.emailPage.title')" left-arrow></app-navbar>

  <view class="p-30rpx">
    <wd-form custom-class="auth-form mt-30rpx" ref="form" :model="model">
      <wd-input
        prop="email"
        no-border
        use-prefix-slot
        use-suffix-slot
        v-model="model.email"
        :placeholder="$t('safe.emailPage.input')"
        :rules="[{ required: true, message: $t('safe.emailPage.rules') }]"
      >
        <template #suffix>
          <view class="countDown" @click="countDown">
            {{ timeout ? t('safe.emailPage.sendTime', { time }) : $t('safe.emailPage.sendCode') }}
          </view>
        </template>
      </wd-input>
    </wd-form>
    <wd-password-input
      v-model="verificationCode"
      :mask="false"
      :gutter="10"
      :length="6"
      :focused="showKeyboard"
      @focus="showKeyboard = true"
    />
    <wd-number-keyboard
      v-model="verificationCode"
      v-model:visible="showKeyboard"
      :maxlength="6"
      @close="showKeyboard = false"
    />
    <wd-button class="mt-160rpx" size="large" block :disabled="disabled" @click="confirm">
      {{ $t('common.confirm') }}
    </wd-button>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchSendEmail } from '@/service/base'
import { fetchAccountVerificationBinding } from '@/service/user'
import { useUserStore } from '@/store'
const userStore = useUserStore()
const time = ref(60)
const timeout = ref(null)
const model = reactive({
  email: '',
  type: 4,
})
const show = ref(false)
const emailTest =
  /^(([^<>()\\[\]\\.,;:\s@"]+(\.[^<>()\\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
const verificationCode = ref('')
const showKeyboard = ref(false)
const disabled = computed(() => {
  return !model.email || !verificationCode.value
})

const countDown = () => {
  if (!emailTest.test(model.email)) {
    return uni.showToast({
      title: t('safe.emailPage.toast'),
      icon: 'none',
    })
  }
  if (timeout.value) return
  uni.showLoading()
  fetchSendEmail(model)
    .then((res) => {
      timeout.value = setInterval(() => {
        time.value -= 1
        if (time.value === 0) {
          clearInterval(timeout.value)
          timeout.value = null
          time.value = 60
        }
      }, 1000)
    })
    .finally(() => {
      uni.hideLoading()
    })
}

const confirm = () => {
  if (!emailTest.test(model.email)) {
    return uni.showToast({
      title: t('safe.emailPage.toast'),
      icon: 'none',
    })
  }
  uni.showLoading()
  fetchAccountVerificationBinding({
    account: model.email,
    accountType: 2,
    checkType: 2,
    verificationCode: verificationCode.value,
  })
    .then((res) => {
      userStore
        .getUserInfo()
        .then(() => {
          uni.showToast({
            title: t('common.success'),
            icon: 'none',
            success: function () {
              uni.navigateBack()
            },
          })
        })
        .finally(() => {
          uni.hideLoading()
        })
    })
    .finally(() => {
      uni.hideLoading()
    })
}
</script>

<style lang="scss" scoped>
.countDown {
  font-size: 30rpx;
  font-weight: 500;
  color: var(--color-primary);
}
:deep(.wd-password-input) {
  margin: 200rpx 0 0 !important;
}
:deep(.wd-password-input__item) {
  background: var(--background-tertiary) !important;
  border: 1px solid var(--border-color);
  border-radius: 10rpx !important;
}
.unbind {
  .head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    text:nth-child(1) {
      font-size: 30rpx;
      font-weight: 500;
      color: var(--text-primary);
    }
    text:nth-child(2) {
      color: var(--text-inactive);
    }
  }
  .hint {
    margin-top: 40rpx;
    font-size: 26rpx;
    line-height: 30rpx;
    color: var(--text-primary);
  }
  .po-fixed {
    position: fixed;
    right: 30rpx;
    bottom: 30rpx;
    left: 30rpx;
  }
}
</style>
