import { http } from '@/utils/http'

/** 期权列表 */
export const fetchOptionsList = (params?: any) => {
  return http.get(`/api/mjkj-web/coin/options/list`, params)
}

/** 期权下单 */
export const fetchOptionsPlaceOrder = (data?: any) => {
  return http.post(`/api/mjkj-web/coin/options/betOrder`, data)
}

/** 期权订单 */
export const fetchOptionsOrder = (data?: any) => {
  return http.post(`/api/mjkj-web/coin/options/getOrderList`, data)
}

/** 期权记录详情 */
export const fetchOptionsOrderDetail = (data?: any) => {
  return http.post(`/api/mjkj-web/coin/options/getOrderInfo`, data)
}

// v2 下单
export const fetchOptionsV2PlaceOrder = (data?: any) => {
  return http.post(`/api/mjkj-web/coin/options/new/betOrder`, data)
}
