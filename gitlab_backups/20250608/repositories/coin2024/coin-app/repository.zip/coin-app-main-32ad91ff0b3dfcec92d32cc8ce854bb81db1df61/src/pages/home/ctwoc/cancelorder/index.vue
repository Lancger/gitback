<template>
  <app-navbar custom-class="bg-transparent" title="">
    <template #right>
      <!-- @click="navigator" -->
      <view @click="cancel">{{ $t('c2c.cancelOrder.cancelOrder') }}</view>
    </template>
  </app-navbar>
  <view class="title">{{ $t('c2c.cancelOrder.orderCreated') }}</view>
  <view class="text" v-if="listObj.type === '1'">
    {{ $t('c2c.cancelOrder.payWithin') }}
    <wd-count-down
      ref="countDown"
      custom-class="count-down"
      :time="time"
      format="mm:ss"
      @finish="finish"
    />
  </view>

  <view class="user">
    <view class="flex">
      <image v-if="listObj.icon" class="w-70rpx h-70rpx mr2 ml1" :src="listObj.icon" />
      <image v-else class="w-70rpx h-70rpx mr2 ml1" src="@img/avatar.png" />
      <view>
        <view class="user_name">{{ $t('c2c.cancelOrder.bankTransfer') }}</view>
        <view class="user_text">
          {{ $t('c2c.cancelOrder.unitPrice') }} {{ listObj.unit_price }} {{ listObj.fiat_currency }}
        </view>
      </view>
    </view>
    <view class="flex">
      <view class="user_chat" @click="navigator">{{ $t('c2c.cancelOrder.appeal') }}</view>
      <view
        class="user_chat ml-20rpx"
        @click="onRouter(`/pages/home/ctwoc/contact-merchant/index?orderId=${listObj.id}`)"
      >
        {{ $t('c2c.cancelOrder.chat') }}
      </view>
    </view>
  </view>

  <view class="flex list">
    <view class="flex">
      <!-- <image class="w-43rpx h-42rpx mr2" src="@/static/images/home/btc.png" /> -->
      <view class="list_cer" mr1>{{ listObj.type === '1' ? $t('c2c.buy') : $t('c2c.sell') }}</view>
      <view class="list_cer">{{ listObj.coin_symbol }}</view>
    </view>
  </view>

  <view class="flex_jc">
    <view>{{ $t('c2c.cancelOrder.orderID') }}</view>
    <view class="flex">
      <view>{{ listObj.id }}</view>
      <image class="w-30rpx h-30rpx ml2" @click="copy" src="@/static/images/assets/copy.png" />
    </view>
  </view>

  <view class="flex_jc">
    <view>{{ $t('c2c.cancelOrder.unitPrice') }}</view>
    <view>{{ listObj.exchange_code }} {{ listObj.unit_price }} {{ listObj.fiat_currency }}</view>
  </view>

  <view class="flex_jc">
    <view>{{ $t('c2c.cancelOrder.amount') }}</view>
    <view>{{ listObj.fiat_currency_amount }} {{ listObj.fiat_currency }}</view>
  </view>

  <view class="flex_jc">
    <view>{{ $t('c2c.cancelOrder.qty') }}</view>
    <view>{{ listObj.coin_cou }} {{ listObj.coin_symbol }}</view>
  </view>

  <view class="flex_jc">
    <view>{{ $t('c2c.cancelOrder.orderTime') }}</view>
    <view>{{ shijianc(listObj.order_time) }}</view>
  </view>

  <view class="flex_jc">
    <view>{{ $t('c2c.cancelOrder.paymentMethod') }}</view>
    <view>{{ $t('c2c.cancelOrder.bankTransfer') }}</view>
  </view>

  <view class="btn">
    <!-- <view class="btn_subscribe">Get payment details</view> -->
    <view
      class="btn_subscribewhine"
      @click="onRouter(`/pages/home/ctwoc/paid/index?id=${listObj.id}`, 'redirectTo')"
    >
      {{ $t('c2c.cancelOrder.getPaymentDetails') }}
    </view>
  </view>
</template>

<script lang="ts" setup>
import { useMessage } from 'wot-design-uni'
import { t } from '@/locale'
import { fetchGetServicePayment, fetchCancel } from '@/service/ctwoc'
import { onRouter } from '@/utils'

const message = useMessage()
const data = ref({
  value: '',
  sum: '',
  valueCree: {
    local_currency: '',
  },
  valueCoin: {
    symbol: '',
  },
})
const orderId = ref()
const listObj = ref<any>({})
const time = ref<number>()
onLoad((options) => {
  const buypreviewObj = uni.getStorageSync('buypreview')
  data.value = buypreviewObj.data
  orderId.value = buypreviewObj.res
  fetchGetServicePayment({
    orderId: orderId.value,
  }).then((res) => {
    // 15分钟超时
    const startTime = new Date(res.data.order_time).getTime()
    const endTime = startTime + 15 * 60 * 1000
    const currTime = new Date().getTime()
    time.value = endTime - currTime
    listObj.value = res.data
  })
})

const finish = () => {
  fetchCancelFun()
}

const copy = () => {
  uni.setClipboardData({
    data: listObj.value.id,
    success: function () {
      uni.showToast({
        title: t('common.success'),
        icon: 'none',
        duration: 2000,
      })
    },
  })
}
const fetchCancelFun = () => {
  fetchCancel(listObj.value.id).then((res) => {
    uni.showToast({
      icon: 'none',
      title: t('c2c.cancelOrder.canceled'),
      success: function () {
        uni.navigateTo({
          url: '/pages/home/ctwoc/index',
        })
      },
    })
  })
}
const cancel = () => {
  message
    .confirm({
      msg: t('c2c.cancelOrder.msg'),
      title: t('c2c.cancelOrder.tips'),
    })
    .then((res) => {
      fetchCancelFun()
    })
}
function navigator(url: string) {
  if (listObj.value.appeal_status === 1 || listObj.value.appeal_status === 2) {
    onRouter(`/pages/home/ctwoc/appeal-details/index?orderId=${listObj.value.id}`)
  } else {
    onRouter(
      `/pages/home/ctwoc/appeal/index?bSType=${listObj.value.type}&orderId=${listObj.value.id}`,
    )
  }
}

function shijianc(time) {
  const date = new Date(time)
  const Y = date.getFullYear() + '-'
  const M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-'
  const D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ' '
  const h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':'
  const m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':'
  const s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds()
  return Y + M + D + h + m + s
}
</script>

<style lang="scss" scoped>
.user {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 690rpx;
  height: 130rpx;
  padding: 30rpx;
  margin: 40rpx auto;
  background-color: var(--background-gary-4);
  border-radius: 20rpx;
  &_chat {
    width: 100rpx;
    height: 46rpx;
    font-size: 22rpx;
    line-height: 46rpx;
    color: var(--wot-color-white);
    text-align: center;
    background-color: var(--color-primary);
    border-radius: 100rpx;
  }
  &_bor {
    padding: 5rpx 15rpx;
    border: 2rpx solid var(--border-color);
    border-radius: 100rpx;
  }
  &_name {
    padding-left: 20rpx;
    font-family: Asap;
    font-size: 28rpx;
    font-weight: 500;
    color: var(--text-primary);
  }
  &_text {
    padding-left: 20rpx;
    margin-top: 10rpx;
  }
}
.list {
  height: 88rpx;
  padding: 0 30rpx;
  margin-top: 30rpx;
  font-size: 28rpx;
  &_cer {
    color: var(--text-primary) !important;
  }
}
.flex {
  display: flex;
  align-items: center;
}

.btn {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 130rpx;
  box-shadow: 0px -5px 21.7px 0px #c6c6c640;
  &_subscribe {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--text-inactive) !important;
    text-align: center;
    background-color: var(--border-color-inactive);
    border-radius: 100rpx;
  }

  &_subscribewhine {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--wot-color-white) !important;
    text-align: center;
    background-color: #00a7ed;
    border-radius: 100rpx;
  }
}
.title {
  padding-left: 30rpx;
  margin: 40rpx 0 40rpx 0;
  font-family: Asap;
  font-size: 34rpx;
  font-weight: 500;
  color: var(--text-primary);
}
.text {
  display: flex;
  align-items: center;
  padding-left: 30rpx;
  margin-bottom: 20rpx;
  color: var(--text-inactive);
  .count-down {
    margin-left: 6rpx;
    color: var(--text-primary) !important;
  }
}
.flex_jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 48rpx;
  padding: 0 30rpx;
  color: var(--text-inactive);
}
</style>
