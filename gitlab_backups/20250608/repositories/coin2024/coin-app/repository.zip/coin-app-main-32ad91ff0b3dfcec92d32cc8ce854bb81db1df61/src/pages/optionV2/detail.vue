<template>
  <app-navbar>
    <template #title>
      <view class="flex items-center gap-10rpx">
        <view class="font-size-32rpx font-600">
          {{ productData.product.symbol }} {{ $t('optionV2.option') }}
        </view>
        <!-- <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ toFormat(productData.token.close, productData.token.base_coin_scale) }}
        </view> -->
        <!-- <wd-icon custom-class="!font-700" name="caret-down-small" size="30rpx"></wd-icon> -->
      </view>
    </template>
    <template #right>
      <text
        class="i-carbon-align-box-top-right font-size-30rpx"
        @click="onRouter('/pages/optionV2/order/index')"
      ></text>
    </template>
  </app-navbar>
  <view class="p-30rpx py-40rpx">
    <view class="flex items-center justify-between font-size-30rpx font-600">
      <view>
        {{ $t('optionV2.buy') }} {{ productData.product.symbol }}
        {{ productData.mode === 1 ? $t('optionV2.up') : $t('optionV2.down') }}
        {{ $t('optionV2.option') }}.
      </view>
      <view>
        {{
          productData.mode === 1
            ? productData.current.up_odds.odds
            : productData.current.down_odds.odds
        }}
      </view>
    </view>
    <view class="flex items-center justify-between mt-40rpx font-size-22rpx">
      <view class="color-[var(--text-inactive)]">{{ $t('optionV2.available') }}</view>
      <view class="flex items-center gap-10rpx">
        <view>{{ walletData.balance }} {{ walletData.symbol }}</view>
        <wd-icon
          custom-class="color-[var(--color-primary)]"
          name="translate-bold"
          size="24rpx"
          @click="onRouter('/pages/asset/transfer/index')"
        ></wd-icon>
      </view>
    </view>
    <!--  -->
    <view
      class="flex items-center justify-between gap-20rpx px-30rpx mt-30rpx h-90rpx bg-[var(--background-gary-4)] rd-10rpx"
    >
      <wd-icon name="decrease" size="24rpx" @click="onChangeAmount(-1)"></wd-icon>
      <input
        v-model="form.amount"
        type="number"
        class="flex-1 h-100% lh-90rpx font-size-28rpx font-500 text-center"
        :placeholder="$t('optionV2.volume') + '(' + $t('optionV2.unit') + ')'"
        @input="onInput"
      />
      <wd-icon name="add" size="24rpx" @click="onChangeAmount(1)"></wd-icon>
    </view>
    <!--  -->
    <view class="flex items-center gap-10rpx mt-20rpx">
      <view
        v-for="item in options"
        :key="item.value"
        :class="{ 'bg-[var(--color-primary)] color-#fff': item.value === optionsValue }"
        class="flex-1 h-46rpx lh-46rpx text-center font-size-22rpx text-center bg-[var(--background-gary-4)] rd-10rpx transition-all-300"
        @click="onChangeOptions(item.value)"
      >
        {{ item.label }}
      </view>
    </view>
    <!--  -->
    <view class="flex items-center justify-between mt-20rpx font-size-22rpx">
      <view class="color-[var(--text-inactive)]">{{ $t('common.max') }}</view>
      <view class="font-500">{{ maxOpen }}</view>
    </view>
    <!-- <view class="flex items-center justify-between mt-20rpx font-size-22rpx">
      <view class="color-[var(--text-inactive)]">Max Vol</view>
      <view class="font-500">6.0</view>
    </view> -->
    <!--  -->
    <!-- <view class="flex items-center justify-between gap-20rpx mt-20rpx">
      <view
        class="flex-1 h-90rpx lh-90rpx text-center font-size-28rpx font-500 bg-#EDEDED rd-10rpx"
      >
        Best offer
      </view>
      <wd-button class="!w-[max-content] !px-30rpx !rd-10rpx" size="large" type="info" plain>
        Best price
      </wd-button>
    </view> -->
    <!--  -->
    <view class="flex flex-col gap-20rpx py-30rpx b-b">
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">{{ $t('optionV2.fee') }}</view>
        <view class="font-500">{{ toFormat(fee) }} USDT</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">{{ $t('optionV2.unitPrice') }}</view>
        <view class="font-500">{{ productData.current.contract_size }} USDT</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">{{ $t('optionV2.expectedRevenue') }}</view>
        <view class="font-500">{{ toFormat(pl) }} USDT</view>
      </view>
    </view>
    <!--  -->
    <!-- <view class="flex items-center justify-between mt-20rpx">
      <view class="color-[var(--text-inactive)]">Total cost</view>
      <view class="font-500">1.450/9.8</view>
    </view> -->
  </view>

  <!--  -->
  <app-footer background="var(--background-primary)" shadow>
    <view class="px-30rpx py-20rpx">
      <wd-button
        custom-class="!w-100%"
        size="large"
        :disabled="Number(form.amount) <= 0"
        @click="showConfirmOrderPopup = true"
      >
        {{ $t('optionV2.buy') }}
      </wd-button>
    </view>
  </app-footer>

  <confirm-order-popup
    v-model="showConfirmOrderPopup"
    :form="form"
    :data="{
      ...productData,
      fee,
    }"
  ></confirm-order-popup>
  <!-- <select-popup v-model="showSelectPopup" /> -->
</template>

<script lang="ts" setup>
import { onRouter } from '@/utils'
import ConfirmOrderPopup from './components/confirm-order-popup.vue'
import SelectPopup from './components/select-popup.vue'
import { fetchGetCurrencyAccount } from '@/service/assets'
import { inputLimitToDigit, toFormat, toFixed } from '@/utils/number'

const showConfirmOrderPopup = ref(false)
const showSelectPopup = ref(false)
const options = [
  { label: '25%', value: 0.25 },
  { label: '50%', value: 0.5 },
  { label: '75%', value: 0.75 },
  { label: '100%', value: 1 },
]
const optionsValue = ref(0)
const walletData = ref<any>({})
const productData = ref<any>(uni.getStorageSync('optionsV2Data') || {})
const form = reactive({
  amount: null,
  endTime: '',
  optionsCurrencyId: '',
  optionsTimeId: '',
  price: '',
  startTime: '',
  upDown: 1,
})
const maxOpen = computed(() => {
  // return Math.floor(walletData.value.balance / productData.value.current.contract_size)
  return calculateMaxCards(
    walletData.value.balance,
    productData.value.current.fee,
    productData.value.current.contract_size,
    1,
  )
})
const pl = computed(() => {
  const rate =
    productData.value.mode === 1
      ? productData.value.current.up_odds.odds
      : productData.value.current.down_odds.odds
  return form.amount * productData.value.current.contract_size * rate
})
const fee = computed(() => {
  return form.amount * productData.value.current.contract_size * productData.value.current.fee
})

onLoad(() => {
  console.log(productData.value)
  productData.value.product.symbolName = productData.value.product.symbolName.replace('/', '')
  form.optionsCurrencyId = productData.value.product.id
  form.optionsTimeId = productData.value.current.id
  form.startTime = productData.value.time[0]
  form.endTime = productData.value.time[1]
  form.upDown = productData.value.mode
})

onShow(() => {
  getWallet()
})

const onInput = (e) => {
  const value = inputLimitToDigit(e.detail.value, 0)
  if (Number(value) > maxOpen.value) {
    nextTick(() => {
      form.amount = maxOpen.value
    })
  }
  if (Number(value) < 1) {
    nextTick(() => {
      form.amount = null
    })
  }
  nextTick(() => {
    form.amount = value
  })
}

const onChangeAmount = (value) => {
  switch (value) {
    case 1:
      form.amount = +form.amount + 1
      if (form.amount > maxOpen.value) {
        form.amount = maxOpen.value
      }
      break
    case -1:
      form.amount = +form.amount - 1
      if (form.amount < 1) {
        form.amount = 1
      }
      break
  }
}

const onChangeOptions = (value) => {
  optionsValue.value = value
  form.amount = Math.floor(maxOpen.value * value)
}

function getWallet() {
  return fetchGetCurrencyAccount({ type: 1 }).then((res) => {
    walletData.value = res.data.find((item) => item.symbol === 'USDT') || {}
  })
}

// 计算最大可开张数
function calculateMaxCards(balance, feeRate, cardValue, leverage) {
  if (!balance || !feeRate || !cardValue || !leverage) return 0
  // 初始最大张数为0
  let maxCards = 0

  // 当余额足够支付一定数量的卡和手续费时，增加张数
  while (true) {
    // 尝试购买下一个张数的总成本
    const potentialCost = ((maxCards + 1) * cardValue) / leverage
    const totalCostWithFee = potentialCost + (maxCards + 1) * cardValue * feeRate
    // 如果余额足够支付这笔交易，继续增加张数，否则退出循环
    if (totalCostWithFee <= balance) {
      maxCards += 1
    } else {
      break
    }
  }

  return maxCards
}
</script>

<style lang="scss" scoped>
:deep(.wd-navbar__title) {
  max-width: 70% !important;
}
</style>
