import { makeApiRequest, generateSymbol, parseFullSymbol } from './helpers.js'
import { ws, onConnect, onSubscribe, onUnsubscribe, emitter } from './streaming.js'

// DatafeedConfiguration implementation
const configurationData = {
  // Represents the resolutions for bars supported by your datafeed
  supported_resolutions: ['1', '5', '15', '30', '60', '1D', '1W', '1M'],
  // // The `exchanges` arguments are used for the `searchSymbols` method if a user selects the exchange
  // exchanges: [
  //   { value: 'Bitfinex', name: 'Bitfinex', desc: 'Bitfinex' },
  //   { value: 'Kraken', name: 'Kraken', desc: 'Kraken bitcoin exchange' },
  // ],
  // // The `symbols_types` arguments are used for the `searchSymbols` method if a user selects this symbol type
  symbols_types: [{ name: 'crypto', value: 'crypto' }],
}

// Use it to keep a record of the most recent bar on the chart
const lastBarsCache = new Map()

// Obtains all symbols for all exchanges supported by CryptoCompare API
async function getAllSymbols() {
  const data = await makeApiRequest('data/v3/all/exchanges')
  let allSymbols = []

  for (const exchange of configurationData.exchanges) {
    const pairs = data.Data[exchange.value].pairs

    for (const leftPairPart of Object.keys(pairs)) {
      const symbols = pairs[leftPairPart].map((rightPairPart) => {
        const symbol = generateSymbol(exchange.value, leftPairPart, rightPairPart)
        return {
          symbol: symbol.short,
          full_name: symbol.full,
          description: symbol.short,
          exchange: exchange.value,
          type: 'crypto',
        }
      })
      allSymbols = [...allSymbols, ...symbols]
    }
  }
  return allSymbols
}

let mqttClient

export default {
  onReady: (callback) => {
    console.log('[onReady]: Method call')
    setTimeout(() => callback(configurationData))
  },

  searchSymbols: async (userInput, exchange, symbolType, onResultReadyCallback) => {
    console.log('[searchSymbols]: Method call')
    // const symbols = await getAllSymbols()
    // const newSymbols = symbols.filter((symbol) => {
    //   const isExchangeValid = exchange === '' || symbol.exchange === exchange
    //   const isFullSymbolContainsInput =
    //     symbol.full_name.toLowerCase().indexOf(userInput.toLowerCase()) !== -1
    //   return isExchangeValid && isFullSymbolContainsInput
    // })
    // onResultReadyCallback(newSymbols)
  },

  resolveSymbol: async (
    symbolName,
    onSymbolResolvedCallback,
    onResolveErrorCallback,
    extension,
  ) => {
    console.log('[resolveSymbol]: Method call', symbolName)
    // const symbols = await getAllSymbols()
    // const symbolItem = symbols.find(({ full_name }) => full_name === symbolName)
    const symbolItem = {}
    if (!symbolItem) {
      console.log('[resolveSymbol]: Cannot resolve symbol', symbolName)
      onResolveErrorCallback('Cannot resolve symbol')
      return
    }
    // Symbol information object
    const symbolInfo = {
      ticker: tvQuery.s,
      name: tvQuery.s,
      description: tvQuery.s,
      type: 'crypto',
      session: '24x7',
      exchange: 'Exchange',
      minmov: (Math.pow(10, tvQuery.p) / Math.pow(100, tvQuery.p)) * Math.pow(10, tvQuery.p),
      pricescale: Math.pow(10, +tvQuery.p || 2),
      has_intraday: true,
      visible_plots_set: 'ohlc',
      has_weekly_and_monthly: false,
      supported_resolutions: configurationData.supported_resolutions,
      volume_precision: 2,
      // timezone: tvTimezone,
      data_status: 'streaming',
    }
    console.log('[resolveSymbol]: Symbol resolved', symbolName)
    setTimeout(() => {
      onSymbolResolvedCallback({ ...symbolInfo })
    }, 0)
  },

  getBars: async (symbolInfo, resolution, periodParams, onHistoryCallback, onErrorCallback) => {
    const { from, to, firstDataRequest } = periodParams
    console.log('[getBars]: Method call', symbolInfo, resolution, from, to)
    // const parsedSymbol = parseFullSymbol(`${symbolInfo.exchange}:${symbolInfo.name}`)
    // const urlParameters = {
    //   e: parsedSymbol.exchange,
    //   fsym: parsedSymbol.fromSymbol,
    //   tsym: parsedSymbol.toSymbol,
    //   toTs: to,
    //   limit: 2000,
    // }
    const urlParameters = {
      type: tvQuery.t,
      symbol: tvQuery.s,
      from: from * 1000,
      to: to * 1000,
      resolution: tvQuery.i,
    }
    const query = Object.keys(urlParameters)
      .map((name) => `${name}=${encodeURIComponent(urlParameters[name])}`)
      .join('&')
    try {
      const data = await makeApiRequest(`/api/mjkj-web/coin/open/get/kline/history?${query}`)
      if ((data.Response && data.Response === 'Error') || data.data.length === 0) {
        // "noData" should be set if there is no data in the requested period
        onHistoryCallback([], { noData: true })
        return
      }
      let bars = []
      data.data.forEach((bar) => {
        if (bar.time >= from && bar.time < to) {
          bars = [
            ...bars,
            {
              time: bar.time * 1000,
              low: +bar.lowestPrice,
              high: +bar.highestPrice,
              open: +bar.openPrice,
              close: +bar.closePrice,
              volume: +bar.volume,
            },
          ]
        }
      })
      if (firstDataRequest) {
        lastBarsCache.set(`${symbolInfo.exchange}:${symbolInfo.name}`, { ...bars[bars.length - 1] })
      }
      console.log(`[getBars]: returned ${bars.length} bar(s)`)
      onHistoryCallback(bars, { noData: false })
    } catch (error) {
      console.log('[getBars]: Get error', error)
      onErrorCallback(error)
    }
  },

  subscribeBars: (
    symbolInfo,
    resolution,
    onRealtimeCallback,
    subscriberUID,
    onResetCacheNeededCallback,
  ) => {
    console.log('[subscribeBars]: Method call with subscriberUID:', subscriberUID)
    // subscribeOnStream(
    //   symbolInfo,
    //   resolution,
    //   onRealtimeCallback,
    //   subscriberUID,
    //   onResetCacheNeededCallback,
    //   lastBarsCache.get(`${symbolInfo.exchange}:${symbolInfo.name}`),
    // )
    if (tvQuery.mode === 'mqtt') {
      mqttClient = mqtt.connect(WSS_URL, {
        connectTimeout: 2 * 1000,
        username: 'admin',
        password: 'password',
        clean: true,
      })

      mqttClient.on('connect', () => {
        mqttClient.subscribe(`${tvQuery.t}_kline_${tvQuery.s}`, (err) => {
          console.log(err)
        })
      })

      mqttClient.on('message', (topic, message) => {
        // console.log(topic, JSON.parse(message.toString()))
        const { kline } = JSON.parse(message.toString())
        if (tvQuery.i == '1' && kline.period != '1min') return
        if (tvQuery.i == '5' && kline.period != '5min') return
        if (tvQuery.i == '15' && kline.period != '15min') return
        if (tvQuery.i == '30' && kline.period != '30min') return
        if (tvQuery.i == '60' && kline.period != '60min') return
        if (tvQuery.i == '240' && kline.period != '4hour') return
        if (tvQuery.i == '1D' && kline.period != '1day') return
        if (tvQuery.i == '1W' && kline.period != '1week') return
        if (tvQuery.i == '1M' && kline.period != '1mon') return

        onRealtimeCallback({
          time: kline.time * 1000,
          open: kline.openPrice,
          high: kline.highestPrice,
          low: kline.lowestPrice,
          close: kline.closePrice,
          volume: kline.volume,
        })
      })
    }

    if (tvQuery.mode === 'ws') {
      onConnect()
      onSubscribe(subTopic)
      emitter.on('message', (msgData) => {
        const [topic, data] = msgData
        const { kline } = data
        onRealtimeCallback({
          time: kline.time * 1000,
          open: kline.openPrice,
          high: kline.highestPrice,
          low: kline.lowestPrice,
          close: kline.closePrice,
          volume: kline.volume,
        })
      })
    }

    window.addEventListener('hashchange', function (event) {
      console.log('URL 通过 popstate 变动')
      // 处理逻辑
    })
  },

  unsubscribeBars: (subscriberUID) => {
    console.log('[unsubscribeBars]: Method call with subscriberUID:', subscriberUID)
    console.log(mqttClient)
    if (tvQuery.mode === 'mqtt') {
      mqttClient.end(true)
    }

    if (tvQuery.mode === 'ws') {
      onUnsubscribe(subTopic)
      ws.close()
    }
  },
}
