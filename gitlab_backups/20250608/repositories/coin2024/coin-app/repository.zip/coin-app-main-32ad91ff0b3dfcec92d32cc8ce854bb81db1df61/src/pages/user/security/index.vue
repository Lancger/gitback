<template>
  <view>
    <app-navbar :title="$t('safe.title')" left-arrow></app-navbar>
    <view class="main">
      <view class="main__hint1">{{ $t('safe.h1') }}</view>
      <view class="main__hint2">{{ $t('safe.desc') }}</view>
      <view
        class="main__list"
        v-for="(item, index) in listArr"
        :key="index"
        @click="navigator(item, index)"
      >
        <view class="main__list__name">{{ $t(item.name) }}</view>
        <view :class="item.class">
          <text v-if="item.value">{{ $t(item.value) }}</text>
          <wd-icon v-if="index !== 0" name="arrow-right" size="30rpx" class="icon"></wd-icon>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { useUserStore } from '@/store'

const userStore = useUserStore()

const userInfo = computed(() => {
  return userStore.userInfo
})

const listArr = computed(() => {
  return [
    {
      name: 'safe.email',
      value: userInfo.value.email ? 'safe.bind' : 'safe.unverified',
      class: userInfo.value.email ? 'main__list__binded' : 'main__list__notBinded',
      url: '/pages/user/security/binding-email',
      disabled: Boolean(userInfo.value.email),
    },
    {
      name: 'safe.sms',
      value: userInfo.value.phone ? 'safe.bind' : 'safe.unverified',
      class: userInfo.value.phone ? 'main__list__binded' : 'main__list__notBinded',
      url: '/pages/user/security/message-verification',
      disabled: Boolean(userInfo.value.phone),
    },
    {
      name: 'safe.google',
      value: userInfo.value.google_key ? 'safe.opened' : 'safe.notOpen',
      class: userInfo.value.google_key ? 'main__list__binded' : 'main__list__notBinded',
      url: '/pages/user/security/google-authenticator',
      disabled: false,
    },
    {
      name: 'safe.password',
      class: 'main__list__binded',
      url: '/pages/user/security/login-password',
      disabled: false,
    },
    // {
    //   name: 'safe.payPassword',
    //   value: userInfo.value.pay_pwd ? null : 'safe.notSet',
    //   class: 'main__list__binded',
    //   url: '/pages/user/security/fund-password',
    // },
    {
      name: 'safe.code',
      class: 'main__list__binded',
      url: '/pages/user/security/anti-phishing-code',
      disabled: false,
    },
  ]
})

onShow(() => {
  userStore.getUserInfo()
})

function navigator(item, index) {
  // if (index === 0 && !userInfo.value.email) {
  //   return uni.navigateTo({
  //     url: '/pages/user/security/two-factor?type=3',
  //   })
  // }
  // if (index === 1 && userInfo.value.phone) {
  //   return uni.navigateTo({
  //     url: '/pages/user/security/message-verification',
  //   })
  // }

  // if (index === 2 && userInfo.value.google_key) {
  //   return uni.navigateTo({
  //     url: '/pages/user/security/google-authenticator',
  //   })
  // }
  // if (index === 2) {
  //   return uni.navigateTo({
  //     url: '/pages/user/security/google-authenticator',
  //   })
  // }

  // if (index === 4 && userInfo.value.pay_pwd) {
  //   return uni.navigateTo({
  //     url: '/pages/user/security/change-fund-password',
  //   })
  // }

  if (!item.url || item.disabled) return

  uni.navigateTo({
    url: item.url,
  })
}
</script>

<style lang="scss" scoped>
.page {
  background-color: var(--background-tertiary);
}
.main {
  padding: 30rpx;
  &__hint1 {
    margin-top: 40rpx;
    font-size: 40rpx;
    font-weight: 600;
    color: var(--text-primary);
  }
  &__hint2 {
    margin-top: 20rpx;
    margin-bottom: 80rpx;
    font-size: 24rpx;
    font-weight: 400;
    color: var(--text-inactive);
  }
  &__list {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 90rpx;
    padding: 0 30rpx;
    margin-bottom: 20rpx;
    background-color: var(--background-primary);
    border-radius: 20rpx;
    .icon {
      color: var(--text-inactive);
    }
    &__name {
      font-size: 30rpx;
      font-weight: 500;
      color: var(--text-primary);
    }
    &__binded {
      display: flex;
      align-items: center;
      color: var(--text-inactive);
    }
    &__notBinded {
      position: relative;
      display: flex;
      align-items: center;
      font-size: 24rpx;
      color: var(--color-red);
    }
    &__notBinded::after {
      position: absolute;
      top: calc(50% - 4rpx);
      left: -20rpx;
      display: block;
      width: 8rpx;
      height: 8rpx;
      content: '';
      background-color: var(--color-red);
      border-radius: 50%;
    }
  }
}
</style>
