<template>
  <view class="title">{{ $t('c2c.orderSuccess.orderIsComplete') }}</view>

  <view class="text" v-if="props.listObj.type === '1'">
    {{ $t('c2c.orderSuccess.p1') }}
    <text>{{ $t('c2c.orderSuccess.yourTradingAccount') }}</text>
  </view>
  <view class="text" v-else>{{ $t('c2c.orderSuccess.p2') }}</view>
  <view class="succ">
    <image class="w-100rpx h-100rpx" src="@/static/images/assets/succ.png" />
  </view>
  <view class="sun" v-if="props.listObj.type === '1'">
    {{ props.listObj.coin_cou }} {{ props.listObj.coin_symbol }}
  </view>
  <view class="sun" v-if="props.listObj.type === '2'">
    -{{ props.listObj.coin_cou }} {{ props.listObj.coin_symbol }}
  </view>

  <!-- <view class="time">{{ $t('c2c.orderSuccess.fullFillTime') }} 03/21/2024 12:23:35</view> -->

  <view class="assets">{{ $t('c2c.orderSuccess.viewYourAssets') }}</view>

  <view class="account" @click="onRouter('pages/asset/index', 'switchTab')">
    <view class="flex">
      <image class="w-50rpx h-50rpx mr1" src="@/static/images/assets/ass.png" />
      <view>{{ $t('c2c.orderSuccess.assetAccount') }}</view>
    </view>

    <view class="account_view" @click="onRouter('/pages/asset/index', 'switchTab')">
      {{ $t('c2c.orderSuccess.view') }}
    </view>
  </view>
</template>
<script lang="ts" setup>
import { onRouter } from '@/utils'
const props = defineProps({
  listObj: {
    type: Object,
    default: () => {
      return {}
    },
  },
})
// props.listObj.type 1是买 2是卖
</script>
<style lang="scss" scoped>
.title {
  padding-left: 30rpx;
  margin-top: 60rpx;
  font-family: Asap;
  font-size: 34rpx;
  font-weight: 500;
  color: var(--text-primary);
}
.flex {
  display: flex;
  align-items: center;
}
.account {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 600rpx;
  height: 120rpx;
  padding: 0 30rpx;
  margin: 60rpx auto;
  color: var(--text-primary);
  border: 1px solid #333333;
  border-radius: 20rpx;
  &_view {
    width: 130rpx;
    height: 55rpx;
    font-size: 22rpx;
    line-height: 55rpx;
    color: var(--wot-color-white);
    text-align: center;
    background-color: var(--color-primary);
    border-radius: 100rpx;
  }
}
.sun {
  font-family: Asap;
  font-size: 50rpx;
  font-weight: 600;
  color: var(--text-primary);
  text-align: center;
}
.assets {
  margin-top: 200rpx;
  font-family: Asap;
  font-size: 36rpx;
  font-weight: 600;
  color: var(--text-primary);
  text-align: center;
}
.succ {
  width: 100rpx;
  height: 100rpx;
  margin: auto;
  margin-top: 100rpx;
  margin-bottom: 40rpx;
}
.time {
  margin-top: 25rpx;
  color: var(--text-inactive);
  text-align: center;
}
.text {
  padding: 30rpx;
  font-family: Asap;
  font-size: 22rpx;
  font-weight: 400;
  color: var(--text-inactive);
  text-align: left;
  text {
    color: var(--text-primary);
    text-decoration: underline;
  }
}
.schedule {
  width: 690rpx;
  margin-top: 40rpx;
  view {
    width: 216rpx;
    height: 4rpx;
    margin-left: 30rpx;
    background-color: var(--background-gary-4);
  }
  &_black {
    background-color: var(--text-primary) !important;
  }
}
</style>
