import { http } from '@/utils/http'

/** 获取币种配置信息 */
export const fetchTokenConfig = (typeAndSymbol, params?: any) => {
  return http.get(`/api/mjkj-web/coin/open/transaction/${typeAndSymbol}`, params)
}

/** 获取币种数据 */
export const fetchTokenData = (data?: any) => {
  return http.post(`/api/mjkj-web/coin/open/get/contractDetail`, data)
}

/** 获取现货钱包 */
export const fetchSpotWallet = (symbol, params?: any) => {
  return http.get(`/api/mjkj-web/coin/wallet/get/spot/${symbol}`, params)
}

// 下单
export type tradeMode = 'zyzs' | 'xjwt' | 'sjwt'
export const fetchPlaceOrder = (mode: tradeMode, data?: any) => {
  return http.post(`/api/mjkj-web/coin/entrust/exchange/${mode}`, data)
}

// 订单
export type tradeOrderMode = 'zyzs' | 'sjwt' | 'ptwt'
export const fetchOrderList = (mode: tradeOrderMode, params?: any) => {
  return http.get(`/api/mjkj-web/coin/entrust/entrustlog/now/${mode}/all`, params)
}

// 订单取消
export const fetchOrderCancel = (data?: any) => {
  return http.post(`/api/mjkj-web/coin/entrust/cancel/entrust`, data)
}

// 交易记录
export const fetchOrderRecords = (data?: any) => {
  return http.post(`/api/mjkj-web/coin/entrust/getEntrustLogCurrency`, data)
}

// 交易记录详情
export const fetchOrderDetail = (no: string) => {
  return http.post(`/api/mjkj-web/coin/entrust/transaction/details/${no}`)
}
