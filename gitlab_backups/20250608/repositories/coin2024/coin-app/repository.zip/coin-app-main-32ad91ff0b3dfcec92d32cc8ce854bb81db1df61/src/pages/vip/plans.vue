<template>
  <app-navbar title="VIP Plans"></app-navbar>
  <view class="!bg-[var(--background-primary)]">
    <wd-tabs custom-class="app-tabs app-tabs--no-flex-1 ">
      <wd-tab title="Trader plan"></wd-tab>
      <wd-tab title="Position plan"></wd-tab>
    </wd-tabs>
    <wd-tabs custom-class="app-tabs--tag app-tabs--no-flex-1">
      <wd-tab title="Spot"></wd-tab>
      <wd-tab title="Futures"></wd-tab>
    </wd-tabs>
  </view>

  <view class="mt-20rpx bg-[var(--background-primary)]">
    <view v-for="(item, index) in 10" :key="index" class="p-30rpx b-b">
      <view class="font-size-30rpx font-500">VIP1</view>
      <view class="flex flex-col gap-26rpx mt-30rpx">
        <view class="flex justify-between items-center">
          <view class="color-[var(--text-inactive)]">30D vol(USD*)</view>
          <view>≥ 1,000,000.00 USD</view>
        </view>
        <view class="flex justify-between items-center">
          <view class="color-[var(--text-inactive)]">And/Or</view>
          <view>And</view>
        </view>
        <view class="flex justify-between items-center">
          <view class="color-[var(--text-inactive)]">XXX-balance</view>
          <view>≥ 20 XXX</view>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
//
</script>

<style lang="scss" scoped>
.page {
  background: var(--background-secondary);
}
</style>
