<template>
  <app-navbar :title="title" custom-class="!bg-transparent"></app-navbar>
  <view class="p-30rpx">
    <view class="hint">
      {{ $t('safe.codePage.title') }}
    </view>
    <wd-form custom-class="auth-form mt-30rpx" ref="form" :model="model">
      <wd-input
        prop="antiCode"
        no-border
        clearable
        use-prefix-slot
        v-model="model.antiCode"
        :placeholder="$t('safe.codePage.input')"
        :rules="[{ required: true, message: $t('safe.codePage.rules') }]"
      ></wd-input>
    </wd-form>
    <view class="hint2">
      {{ $t('safe.codePage.p1') }}
    </view>
    <wd-button class="mt-77rpx" size="large" block :disabled="!disabled" @click="confirm">
      {{ $t('common.confirm') }}
    </wd-button>
    <wd-popup
      v-model="show"
      position="bottom"
      custom-style="height:70vh;paddingTop: 30rpx;"
      @close="show = false"
    >
      <verification
        :title="$t('safe.codePage.twoFactorTitle')"
        type="anti-phishing-code"
        @hidePopup="hidePopup"
      ></verification>
    </wd-popup>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { useUserStore } from '@/store'
import { fetchAantiCode } from '@/service/user'
import { fetchSendSMS, fetchSendEmail } from '@/service/base'
import verification from './components/verification.vue'

const model = reactive({
  antiCode: '',
})
const userStore = useUserStore()
const userInfo = userStore.userInfo
const show = ref(false)
const verificationCode = ref('')
const title = ref('')
const showKeyboard = ref(false)
const account = userInfo.phone || userInfo.email
const obj = computed(() => {
  if (userInfo.google_key) {
    return {
      googleCode: verificationCode.value,
    }
  } else if (userInfo.phone) {
    return {
      phoneCode: verificationCode.value,
    }
  } else {
    return {
      emailCode: verificationCode.value,
    }
  }
})
const smsApiParams = computed(() => {
  if (userInfo.phone) {
    return {
      phone: userInfo.phone,
      type: 4,
    }
  } else {
    return {
      email: userInfo.email,
      type: 4,
    }
  }
})
onLoad(() => {
  console.log(userInfo)

  if (userInfo.anti_code) {
    model.antiCode = userInfo.anti_code
    title.value = t('safe.codePage.change')
  } else {
    title.value = t('safe.codePage.set')
  }
})
const smsApi = computed(() => {
  return userInfo.phone ? fetchSendSMS : fetchSendEmail
})
const disabled = computed(() => {
  return /^[0-9A-Za-z\\u4e00-\\u9fa5]{4,20}$/.test(model.antiCode)
})

const hidePopup = (code, trading) => {
  console.log(trading)
  let obj
  if (trading === 0) {
    obj = {
      googleCode: code,
    }
  } else {
    if (userInfo.phone) {
      obj = {
        phoneCode: code,
      }
    } else {
      obj = {
        emailCode: code,
      }
    }
  }

  verificationCode.value = code
  fetchAantiCode({
    antiCode: model.antiCode,
    ...obj,
  }).then((res) => {
    userInfo.anti_code = model.antiCode
    uni.navigateBack()
  })
}
const confirm = () => {
  show.value = true
}
</script>

<style lang="scss" scoped>
.hint {
  margin-top: 20rpx;
  font-size: 22rpx;
  line-height: 30rpx;
  color: var(--text-inactive);
}
.hint2 {
  font-size: 22rpx;
  line-height: 30rpx;
  color: var(--text-active);
}
:deep(.wd-password-input) {
  margin: 100rpx 0 0 !important;
}
:deep(.wd-password-input__item) {
  background: var(--background-tertiary) !important;
  border: 1px solid var(--border-color);
  border-radius: 10rpx !important;
}
</style>
