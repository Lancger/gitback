import { defineStore } from 'pinia'
import { useUserStore } from './user'
import { fetchFormData, fetchServerTime } from '@/service/base'
import { onRouter } from '@/utils'

export const useSystemStore = defineStore(
  'system',
  () => {
    const serviceUrl = ref('')
    const serverTime = ref<any>({})
    const systemConfig = reactive({
      lightLogo: '',
      darkLogo: '',
      appReview: 0, // 应用审核状态 1: 审核中 0: 审核通过
      appName: '', // 应用名称
    })

    const onSetFavicon = () => {
      const favicon = document.querySelector('link[rel="shortcut icon"]')
      if (favicon instanceof HTMLLinkElement) {
        favicon.href = systemConfig.lightLogo
      }
    }

    function getSystemLogo() {
      return fetchFormData('1530464853989064705', {
        config_code: 'h5_logo',
        column: 'id',
        order: 'desc',
      }).then((res) => {
        const [data] = res.data.records
        if (data) {
          systemConfig.lightLogo = data.config_img_daytime
          systemConfig.darkLogo = data.config_img_night
          onSetFavicon()
        }
      })
    }

    function onService(customUrl?, title?) {
      const { isLogined, userInfo } = useUserStore()
      let url = customUrl || userInfo.customerServiceUrl || serviceUrl.value

      // tg | whatsApp
      if (/wa.me|whatsapp|t.me/.test(url)) {
        window.location.href = url
        return
      }

      if (isLogined) {
        // 美恰
        if (/(chatlink|meiqia)/.test(url)) {
          url += `&metadata={"email": "${userInfo.email}","tel": "${userInfo.phone}","name": "uid: ${userInfo.uid}"}`
        }
        if (/insms.chat/.test(url)) {
          url += `&uid=${userInfo.uid}&nickname=${userInfo.uid}&nickName=${userInfo.uid}`
        }

        const params = {
          '[email]': userInfo.email,
          '[phone]': userInfo.phone,
          '[uid]': userInfo.uid,
          '[name]': userInfo.name,
        }
        Object.keys(params).forEach((key) => {
          url = url.replace(key, params[key])
        })
      }

      // 内嵌
      const query = [`url=${encodeURIComponent(url)}`]
      if (title) query.push(`title=${title}`)
      onRouter(`/pages/webview/index?${query.join('&')}`)
    }

    function onLooseJsonParse(obj) {
      // eslint-disable-next-line no-new-func
      return Function('"use strict";return (' + obj + ')')()
    }

    function getService() {
      return fetchFormData('1530464853989064705', {
        config_code: 'customer_service_url',
      }).then((res) => {
        const [data] = res.data.records
        if (data.config_data) {
          serviceUrl.value = onLooseJsonParse(data.config_data.substring(7)).url
        }
      })
    }

    function getServerTime() {
      return fetchServerTime().then((res) => {
        serverTime.value = res.data
      })
    }

    function getSystemConfig() {
      fetchFormData('1530464853989064705', {
        column: 'id',
        order: 'desc',
        pageSize: '-521',
      }).then((res) => {
        try {
          res.data.records.forEach((item) => {
            switch (item.config_code) {
              case 'app_review': {
                systemConfig.appReview = Number(item.config_data)
                break
              }
              case 'web_title': {
                // 固定网站标题
                const fixedTitle = onLooseJsonParse(item.config_data.substring(7)).en
                document.title = fixedTitle
                systemConfig.appName = fixedTitle
                setInterval(() => {
                  document.title = fixedTitle
                }, 500)
                break
              }
              case 'h5_logo': {
                systemConfig.lightLogo = item.config_img_daytime
                systemConfig.darkLogo = item.config_img_night
                onSetFavicon()
                break
              }
              case 'customer_service_url': {
                serviceUrl.value = onLooseJsonParse(item.config_data.substring(7)).url
                break
              }
              default:
            }
          })
        } catch (error) {
          // error
        }
      })
    }

    return {
      serverTime,
      systemConfig,
      onService,
      getServerTime,
      getSystemConfig,
    }
  },
  {
    persist: true,
  },
)
