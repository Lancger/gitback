<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar>
    <template #left>
      <wd-icon name="arrow-left" size="24px"></wd-icon>
      <view class="h-100% ml-20rpx" @click.stop="showProduct = true">
        <wd-icon name="menu-fold" size="24px"></wd-icon>
      </view>
    </template>
    <template #title>
      <view v-if="productItem.contract" class="mt-8rpx font-size-30rpx font-700 lh-none">
        {{ productName }}
      </view>
      <view class="!mt-10rpx !font-size-22rpx color-[var(--text-inactive)] lh-none">
        {{ $t('options.title') }}
      </view>
    </template>
  </app-navbar>
  <!--  -->
  <view class="wrap">
    <view class="w-100% h-500rpx">
      <k-line-chart
        v-if="tokenItem.base_coin_scale"
        :symbol="tokenItem.symbol_name"
        :precision="tokenItem.base_coin_scale"
        :topicSymbol="tokenItem.subText"
        k-type="ubw"
        :chart-style="10"
        :showVol="false"
        :showMA="false"
        showLine
        :key="productItem.contract"
      ></k-line-chart>
      <view v-else class="center w-100% h-100%">
        <wd-loading :size="30" />
      </view>
    </view>
    <view class="form">
      <view class="form-item">
        <input
          v-model="form.amount"
          class="form-item__input"
          type="text"
          :placeholder="$t('options.amount')"
          @input="onInput"
        />
        <view class="form-item__right">USDT</view>
      </view>
      <view class="flex justify-between items-center mt-40rpx">
        <view>
          <text class="color-[var(--text-inactive)]">{{ $t('options.available') }}</text>
          {{ toFormat(walletData.balance, walletData.base_coin_scale) }} USDT
        </view>
        <view>
          <text class="color-[var(--text-inactive)]">{{ $t('options.expectedReturn') }}</text>
          {{ toFormat(income, true) }} USDT
        </view>
      </view>
      <view class="flex gap-20rpx mt-30rpx">
        <wd-button custom-class="m-0 flex-1" type="success" block @click="onShowPlaceOrder(1)">
          {{ $t('options.up') }}
        </wd-button>
        <wd-button custom-class="m-0 flex-1" type="error" block @click="onShowPlaceOrder(-1)">
          {{ $t('options.down') }}
        </wd-button>
      </view>
    </view>
  </view>
  <view class="h-20rpx bg-[var(--background-secondary)]"></view>
  <!-- 订单 -->
  <view class="order-wrap">
    <view class="order-wrap__tab">
      <wd-tabs
        custom-class="app-tabs app-tabs--no-flex-1"
        :model-value="0"
        swipeable
        animated
        :map-num="100"
      >
        <block v-for="(item, index) in [$t('options.position')]" :key="index">
          <wd-tab :title="item">
            <!-- 持仓 -->
            <view v-if="index === 0" class="position-wrap">
              <app-empty custom-class="h-700rpx" :no-data="positionList.length === 0">
                <option-position-list
                  :list="positionList"
                  @onCountDownEnd="onCountDownEnd"
                ></option-position-list>
              </app-empty>
            </view>
          </wd-tab>
        </block>
      </wd-tabs>
      <image
        class="absolute top-26rpx right-30rpx w-36rpx h-36rpx"
        :src="onImageToThemeImage('/static/images/icons/records02.png')"
        @click="onRouter('/pages/option/history/index')"
      />
    </view>
  </view>
  <!-- 选择交易对 -->
  <option-product-popup
    v-model:show="showProduct"
    :list="productList"
    @onChange="onProductChange"
  ></option-product-popup>
  <!-- 下单 -->
  <option-place-order
    v-model:show="showPlaceOrder"
    :loading="submitLoading"
    :data="placeOrderData"
    :balance="toFormat(walletData.balance, walletData.base_coin_scale)"
    @onConfirm="onSubmit"
  ></option-place-order>
</template>

<script lang="ts" setup>
import optionPositionList from './components/option-position-list.vue'
import optionProductPopup from './components/option-product-popup.vue'
import optionPlaceOrder from './components/option-place-order.vue'
import { t } from '@/locale'
import { fetchOptionsList, fetchOptionsOrder, fetchOptionsPlaceOrder } from '@/service/options'
import { fetchGetCurrencyAccount } from '@/service/assets'
import { fetchTokenConfig } from '@/service/trade'
import { toFormat, BNumber, inputLimitToDigit } from '@/utils/number'
import { onImageToThemeImage, onRouter } from '@/utils'

const showProduct = ref(false)
const showPlaceOrder = ref(false)
const productList = ref([])
const positionParams = reactive({
  pageNo: 1,
  pageSize: 10,
  order_status: 0,
})
const itemId = ref('')
const productItem = ref<any>({})
const tradingPair = ref<any>({})
const walletData = ref<any>({})
const form = reactive({
  optionsCurrencyId: '',
  optionsTimeId: '',
  upDown: null,
  amount: null,
})
const submitLoading = ref(false)
const tokenItem = ref<any>({})

const income = computed(() =>
  BNumber(form.amount || 0).times(
    (tradingPair.value.up_odds && tradingPair.value.up_odds.odds) || 0,
  ),
)
const productName = computed(
  () =>
    `${productItem.value.contract && productItem.value.contract.replace('/', '')}-${tradingPair.value.time_name}`,
)

const placeOrderData = computed(() => {
  return {
    amount: form.amount,
    rate: tradingPair.value && tradingPair.value.up_odds && tradingPair.value.up_odds.odds,
    productName: productName.value,
    isUp: form.upDown === 1,
  }
})

const {
  data: positionList,
  loadMoreState,
  onInit,
} = usePagination({
  api: fetchOptionsOrder,
  params: positionParams,
  onLoadMoreFn: onReachBottom,
})

onLoad(async (options) => {
  itemId.value = options.id
  getWallet()
  getList()
})

const onCountDownEnd = () => {
  onInit()
  getWallet()
}

const onSubmit = () => {
  submitLoading.value = true
  return fetchOptionsPlaceOrder(form)
    .then((res) => {
      showPlaceOrder.value = false
      submitLoading.value = false
      form.amount = ''
      uni.showToast({
        title: 'Success',
        icon: 'none',
      })
      getWallet()
      onInit()
    })
    .catch(() => {
      submitLoading.value = false
    })
}

const onShowPlaceOrder = (mode) => {
  if (+form.amount <= 0) {
    return uni.showToast({
      title: t('options.amount'),
      icon: 'none',
    })
  }
  form.upDown = mode
  showPlaceOrder.value = true
}

const onProductChange = async (arr) => {
  const [product, pair] = arr

  productItem.value = product
  tradingPair.value = pair

  form.optionsCurrencyId = productItem.value.id
  form.optionsTimeId = tradingPair.value.id

  try {
    tokenItem.value = {}
    const res = await getTokenConfig(product.contract)
    tokenItem.value = res.data
  } catch (error) {}
}

const onInput = (e) => {
  const value = inputLimitToDigit(e.detail.value) || ''
  nextTick(() => {
    form.amount = value
  })
}

function getList() {
  return fetchOptionsList().then((res) => {
    productList.value = res.data.map((item) => {
      if (itemId.value === item.id) {
        onProductChange([item, item.scenePairList[0]])
      }
      return {
        ...item,
        scenePairList: item.scenePairList.map((e) => {
          return {
            ...e,
            time: onGetTime(e.time_name),
          }
        }),
      }
    })
  })
}

function getTokenConfig(symbol) {
  return fetchTokenConfig(`ubw/${symbol.replace('/', '_')}`)
}

function getWallet() {
  return fetchGetCurrencyAccount({ type: 1 }).then((res) => {
    walletData.value = res.data.find((item) => item.symbol === 'USDT') || {}
  })
}

function onGetTime(time) {
  if (time.indexOf('S') !== -1) {
    // 秒
    return parseInt(time) * 1000
  }

  if (time.indexOf('M') !== -1) {
    // 分钟
    return parseInt(time) * 60 * 1000
  }

  if (time.indexOf('H') !== -1) {
    // 小时
    return parseInt(time) * 60 * 60 * 1000
  }

  if (time.indexOf('D') !== -1) {
    // 天
    return parseInt(time) * 60 * 60 * 24 * 1000
  }

  return 0
}
</script>

<style lang="scss" scoped>
.order-wrap {
  &__tab {
    position: relative;
    display: flex;
    align-items: center;
    border-bottom: 1px solid var(--background-gary-4);
    :deep(.wd-tabs__line) {
      display: none;
    }
  }
}
.form {
  padding: 30rpx;
  margin-top: 1px;
  border-top: 1px solid var(--border-color-inactive);
  &-item {
    display: flex;
    align-items: center;
    padding: 0 20rpx;
    border: 1px solid var(--border-color-inactive);
    border-radius: 5rpx;
    &__input {
      flex: 1;
      height: 72rpx;
      font-size: 26rpx;
      line-height: 72rpx;
    }
    &__right {
      font-size: 26rpx;
      color: var(--text-inactive);
    }
  }
}
</style>
