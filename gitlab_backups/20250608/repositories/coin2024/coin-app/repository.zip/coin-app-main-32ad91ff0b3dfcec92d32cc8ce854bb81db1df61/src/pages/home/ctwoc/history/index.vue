<template>
  <app-navbar custom-class="bg-transparent" :title="$t('c2c.history.title')"></app-navbar>
  <view>
    <wd-tabs
      custom-class="app-tabs--no-flex-1 b-b"
      :model-value="0"
      swipeable
      animated
      :map-num="100"
      :slidable-num="4"
      @click="change"
      l
    >
      <block v-for="(item, index) in tab" :key="index">
        <wd-tab :title="$t(item)"></wd-tab>
      </block>
    </wd-tabs>
    <view class="p-30rpx">
      <app-empty :no-data="historyArr.length === 0">
        <view
          class="list"
          v-for="item in historyArr"
          :key="item.id"
          @click="
            onRouter(
              `/pages/home/ctwoc/paid/index?id=${item.id}&coin_icon=${encodeURIComponent(item.coin_icon)}`,
            )
          "
        >
          <view class="list__head">
            <view class="list__head__left">
              <image :src="item.coin_icon"></image>
              <text>
                {{ item.type === '1' ? $t('c2c.history.buy') : $t('c2c.history.sell') }}
                {{ item.coin_symbol }}
              </text>
            </view>
            <view>{{ orderStatus(item) }}</view>
          </view>
          <view class="list__item">
            <view class="list__item__left">{{ $t('c2c.history.qty') }}</view>
            <view class="list__item__right">
              {{ item.type === '1' ? '+' : '-' }}{{ toFormat(item.coin_cou) }}
              {{ item.coin_symbol }}
            </view>
          </view>
          <view class="list__item mt-30rpx mb-30rpx">
            <view class="list__item__left">{{ $t('c2c.history.orderAmount') }}</view>
            <view class="list__item__right">${{ toFormat(item.fiat_currency_amount) }}</view>
          </view>
          <view class="list__item">
            <view class="list__item__left">{{ $t('c2c.history.orderTime') }}</view>
            <view class="list__item__right">{{ formatDate(item.order_time) }}</view>
          </view>
        </view>
      </app-empty>
    </view>
  </view>
</template>
<script lang="ts" setup>
import { t } from '@/locale'
import { fetchBuyList } from '@/service/ctwoc'
import { toFormat } from '@/utils/number'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'

const tab = ref([
  'c2c.history.tabs.1',
  'c2c.history.tabs.2',
  'c2c.history.tabs.3',
  'c2c.history.tabs.4',
  'c2c.history.tabs.5',
])
const params = ref<any>({
  current: 1,
  serviceType: 2,
  size: 10,
  status: '',
})
const historyArr = ref([])
onLoad((e) => {
  params.value.serviceType = e.serviceType
  fetchBuyListFun()
})
onReachBottom(() => {
  params.value.current += 1
  fetchBuyListFun()
})
const fetchBuyListFun = () => {
  uni.showLoading()
  fetchBuyList(params.value)
    .then((res) => {
      // if (res.data.total === historyArr.value.length) {
      //   uni.showToast({
      //     icon: 'none',
      //     title: 'No more',
      //   })
      //   return
      // }
      historyArr.value = historyArr.value.concat(res.data.records)
    })
    .finally(() => {
      uni.hideLoading()
    })
}

const orderStatus = (item) => {
  if (item.order_status === '1') {
    return item.type === '1' ? t('c2c.history.toBePaid') : t('c2c.history.toBeCollected')
  } else if (item.order_status === '2') {
    return t('c2c.history.pending')
  } else if (item.order_status === '3') {
    return t('c2c.history.completed')
  } else if (item.order_status === '4') {
    return t('c2c.history.canceled')
  }
}

const change = (e) => {
  params.value.status = e.index === 0 ? '' : e.index
  historyArr.value = []
  params.value.current = 1
  fetchBuyListFun()
}
</script>
<style lang="scss" scoped>
.list {
  padding: 30rpx;
  margin-bottom: 30rpx;
  border: 1rpx solid var(--border-color-inactive);
  border-radius: 10rpx;
  &__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 30rpx;
    font-size: 26rpx;
    font-weight: 500;
    color: var(--text-primary);
    &__left {
      image {
        width: 36rpx;
        height: 36rpx;
        margin-right: 20rpx;
      }
    }
  }
  &__item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 24rpx;
    &__left {
      color: var(--text-inactive);
    }
    &__right {
      color: var(--text-primary);
    }
  }
}
</style>
