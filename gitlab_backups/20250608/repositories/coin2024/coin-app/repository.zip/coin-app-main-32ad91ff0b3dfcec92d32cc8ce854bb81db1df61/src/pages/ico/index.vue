<template>
  <app-navbar :title="$t('ico.title')">
    <template #right>
      <image
        class="w-36rpx h-36rpx"
        :src="onImageToThemeImage('/static/images/icons/records02.png')"
        @click="onRouter('/pages/ico/history')"
      />
    </template>
  </app-navbar>
  <wd-tabs
    custom-class="app-tabs--no-flex-1 b-b classify-tab"
    :model-value="listParams.projectType"
    swipeable
    animated
    :map-num="100"
    @change="onTabChange"
  >
    <block v-for="(item, index) in tab" :key="index">
      <wd-tab :title="$t(item.label)" :name="item.value"></wd-tab>
    </block>
  </wd-tabs>
  <wd-tabs
    custom-class="app-tabs--no-flex-1 type-tabs"
    v-model="statusTabIndex"
    swipeable
    animated
    :map-num="100"
    :slidable-num="3"
    @change="onStatusTabChange"
  >
    <block v-for="(item, index) in statusTab" :key="index">
      <wd-tab :title="$t(item.label)"></wd-tab>
    </block>
  </wd-tabs>
  <wd-skeleton
    :loading="loading"
    animation="flashed"
    :row-col="[
      { margin: '30rpx 30rpx 0', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
      { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
    ]"
  >
    <view class="wrap">
      <view v-if="statusTabIndex > 1" class="wrap__head">
        <view class="wrap__head__item">{{ $t('ico.name') }}</view>
        <view class="wrap__head__item">
          {{ isWin ? $t('ico.amount') : $t('ico.subscribeQuantity') }}
        </view>
        <view class="wrap__head__item">
          {{
            isWin
              ? (listParams.projectType === 'purchase' && subscriptionMode === 'base') ||
                (listParams.projectType === 'allot' && placementMode === 'base')
                ? $t('ico.offeringQuantity')
                : ''
              : $t('ico.subscriptionTime')
          }}
        </view>
      </view>
      <app-empty :no-data="list.length === 0">
        <ico-list
          v-if="statusTabIndex > 1"
          :isWin="isWin"
          :list="list"
          @click="onListClick"
        ></ico-list>
        <ico-card-list
          v-else
          :isSub="statusTabIndex === 1"
          :list="list"
          @click="onListClick"
        ></ico-card-list>
        <wd-loadmore :state="loadMoreState" />
      </app-empty>
    </view>
  </wd-skeleton>

  <!-- 申请 -->
  <ico-apply-popup v-model="showApply"></ico-apply-popup>
  <!-- 弹窗 -->
  <ico-popup
    v-model="showPopup"
    :row-data="rowData"
    :assets="walletData"
    :mode="isWin ? 'pay' : 'placeOrder'"
    @onCallBack="onPopupCallBack"
  ></ico-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import icoPopup from './components/ico-popup.vue'
import icoList from './components/ico-list.vue'
import icoCardList from './components/ico-card-list.vue'
import icoApplyPopup from './components/ico-apply-popup.vue'
import { onRouter, onImageToThemeImage } from '@/utils'
import { toFixed } from '@/utils/number'
import {
  fetchIcoProductList,
  fetchIcoSubscribeRecords,
  fetchIcoPlacingRecords,
  fetchIcoCheckPlacingPermission,
} from '@/service/ico'
import { fetchGetCurrencyAccount } from '@/service/assets'

type modeType = 'base' | 'selfPay' // base 基础模式 selfPay 手动认缴模式
const subscriptionMode = 'base' as modeType
const placementMode = 'base' as modeType

const tab = ref([
  {
    label: 'ico.subscription',
    value: 'purchase',
  },
  {
    label: 'ico.placement',
    value: 'allot',
  },
])
const statusTab = ref([
  {
    label: 'ico.upcoming',
    value: 1,
  },
  {
    label: 'ico.offering',
    value: 2,
  },
  {
    label: 'ico.pending',
    value: 3,
  },
  {
    label: 'ico.winnings',
    value: 4,
  },
])
const statusTabIndex = ref(0)
const listParams = reactive({
  projectType: 'purchase',
  stage: 1,
  pageNo: 1,
  pageSize: 20,
})
const showPopup = ref(false)
const rowData = ref({})
const walletData = ref({})
const showApply = ref(false)

const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
} = usePagination({
  api: (params) => {
    if (isWin.value || statusTabIndex.value === 2) {
      const form = {
        state: statusTabIndex.value === 2 ? 'purchased' : 'pending_subscription',
        pay_state: 0,
        pageNo: params.pageNo,
        pageSize: params.pageSize,
      }

      if (listParams.projectType === 'purchase') {
        return fetchIcoSubscribeRecords(form).then((res) => {
          res.data.records = res.data.records.map((item) => {
            return {
              ...item,
              isPay: subscriptionMode === 'selfPay',
            }
          })
          return res
        })
      } else {
        return fetchIcoPlacingRecords(form).then((res) => {
          res.data.records = res.data.records.map((item) => {
            return {
              ...item,
              isPay: placementMode === 'selfPay',
            }
          })
          return res
        })
      }
    } else {
      return fetchIcoProductList(params).then((res) => {
        res.data.records = res.data.records.map((item) => {
          return {
            ...item,
            progress: Number(toFixed((item.total * 100) / item.circulation)),
          }
        })

        return res
      })
    }
  },
  params: listParams,
  onLoadMoreFn: onReachBottom,
})

const isWin = computed(() => statusTab.value[statusTabIndex.value].value === 4)

onLoad(() => {
  getWallet()
})

const onPopupCallBack = () => {
  getWallet()
  getList()
}

const onListClick = async (row) => {
  const status = statusTab.value[statusTabIndex.value].value
  if (status !== 2 && status !== 4) return
  rowData.value = row
  // (listParams.projectType === 'allot' && statusTabIndex.value === 0)
  // if (listParams.projectType === 'allot' && statusTabIndex.value === 1) {
  //   const res = await fetchIcoCheckPlacingPermission()
  //   switch (res.data) {
  //     case '-1':
  //       uni.showToast({
  //         title: t('ico.assetVerificationFailure'),
  //         icon: 'none',
  //         duration: 2000,
  //       })
  //       break
  //     case '0':
  //       uni.showToast({
  //         title: t('ico.toBeReviewed'),
  //         icon: 'none',
  //         duration: 2000,
  //       })
  //       break
  //     case '1':
  //       showPopup.value = true
  //       break
  //     case '2': // 未提交
  //       showApply.value = true
  //       break
  //     default:
  //   }
  // } else {
  if (placementMode === 'selfPay' || subscriptionMode === 'selfPay') {
    showPopup.value = !(isWin.value && +row.pay_state === 1)
  } else {
    showPopup.value = !isWin.value
  }
  // showPopup.value = !isWin.value
  // }
}

const onTabChange = (event) => {
  listParams.projectType = event.name
  getList()
}

const onStatusTabChange = (event) => {
  statusTabIndex.value = event.index
  listParams.stage = statusTab.value[event.index].value
  getList()
}

function getWallet() {
  return fetchGetCurrencyAccount({ type: 1 }).then((res) => {
    walletData.value = res.data.find((item) => item.symbol === 'USDT') || {}
  })
}
</script>

<style lang="scss" scoped>
.classify-tab {
  :deep(.wd-tabs__line) {
    bottom: 0 !important;
  }
}

.type-tabs {
  :deep(.wd-tabs__nav) {
    background: var(--background-secondary) !important;
  }
  :deep(.wd-tabs__line) {
    display: none;
  }
}

.wrap {
  &__head {
    display: flex;
    padding: 0 15rpx;
    &__item {
      height: 80rpx;
      padding: 0 15rpx;
      font-size: 22rpx;
      line-height: 80rpx;
      color: var(--text-inactive);
      &:nth-of-type(1) {
        width: 30%;
      }
      &:nth-of-type(2) {
        width: 40%;
        text-align: right;
      }
      &:nth-of-type(3) {
        width: 30%;
        text-align: right;
      }
    }
  }
}

.page.dark {
  .type-tabs {
    :deep(.wd-tabs__nav-item.is-active) {
      color: var(--color-primary);
    }
  }
}
</style>
