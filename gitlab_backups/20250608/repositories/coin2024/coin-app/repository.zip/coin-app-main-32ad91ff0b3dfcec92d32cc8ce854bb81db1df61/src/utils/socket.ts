declare global {
  interface Window {
    pako: any
  }
}

const url = import.meta.env.VITE_WS_BASEURL || `wss://${location.host}/ws`
let ws = null
let lockReconnect = false // 是否真正建立连接
let reconnectTimer = null // 断开重连倒计时
let sendFixHeartTimer = null // 固定发送心跳定时器
const dataList = []
const subMap = new Map() // 订阅地址
let timer = null

// subMap.set('ws.market.CSPOT.BTCUSDT_TEST.1', true)
// subMap.set('ws.market.CSPOT.ETHUSDT_TEST.1', true)

export function onConnect() {
  ws = uni.connectSocket({
    url,
    complete: () => {},
  })

  // ws连接成功
  ws.onOpen(() => {
    console.log('[WS SUCCESS]')
    // 全局推送数据
    if (!timer) {
      timer = setInterval(() => {
        const list = dataList.splice(0, dataList.length)
        console.log('[WS Data Length 500ms]', list.length)
        for (let i = 0; i < list.length; i++) {
          // console.log(list[i])
          const [topic, data] = list[i]
          let dataObj = {}
          // 行情
          if (topic.indexOf('market') !== -1) {
            dataObj = {
              close: data.lastPrice,
              zdf: data.chg,
              hight: data.high,
              low: data.low,
              vol: data.amount,
              amount: data.quantity,
            }
          }
          // 最新成交
          // if (data.symbol.indexOf('tick') !== -1) {
          // }
          // 盘口
          if (topic.indexOf('depth') !== -1) {
            dataObj = {
              buyItems: data.buy.map((item) => {
                return {
                  price: item.price,
                  amount: item.quantity,
                }
              }),
              sellItems: data.sell.map((item) => {
                return {
                  price: item.price,
                  amount: item.quantity,
                }
              }),
            }
          }
          // K 线
          if (topic.indexOf('kline') !== -1) {
            dataObj = {
              kline: {
                time: data.time,
                openPrice: data.open,
                closePrice: data.close,
                highestPrice: data.high,
                lowestPrice: data.low,
                volume: data.volume,
                turnover: data.turnover,
              },
            }
          }
          uni.$emit('message', [
            topic,
            {
              ...data,
              ...dataObj,
            },
          ])
        }
      }, 500)
    }

    // 开启心跳
    onSendFixHeart()

    // 自动订阅之前的
    onAutoSubscribe()
  })

  // ws收到服务器消息
  ws.onMessage((e) => {
    if (typeof e.data === 'string' && /pong/.test(e.data)) return

    try {
      const res = window.pako.ungzip(new Uint8Array(e.data), { to: 'string' })
      const wsData = JSON.parse(res)
      wsData.data = typeof wsData.data === 'object' ? wsData.data : JSON.parse(wsData.data)

      dataList.push([wsData.topic, wsData.data, 'ws'])
    } catch (err) {
      console.log(err)
    }
  })

  // 错误
  ws.onError((e) => {
    // 重连
    onReconnect()
  })

  // 关闭
  ws.onClose((res) => {
    if (res.code !== 1000) {
      // 重连
      onReconnect()
    }
  })
}

// 发送消息
function onSend(data) {
  ws.send({ data })
}

// 重连
function onReconnect() {
  // 设置lockReconnect变量避免重复连接
  if (lockReconnect) return
  lockReconnect = true
  reconnectTimer && clearTimeout(reconnectTimer)
  reconnectTimer = setTimeout(
    () => {
      onConnect()
      lockReconnect = false
    },
    Math.floor(Math.random() * 2000 + 3000),
  )
}

// 固定发送心跳
function onSendFixHeart() {
  clearInterval(sendFixHeartTimer)
  sendFixHeartTimer = setInterval(() => {
    onSend(
      JSON.stringify({
        ping: Date.now(),
      }),
    )
  }, 15 * 1000)
}

// 订阅
export function onSubscribe(topic: string | string[]) {
  console.log('[Subscribe:]', topic)
  if (typeof topic === 'string') {
    subMap.set(topic, true)
    onSend(
      JSON.stringify({
        cmd: 'sub',
        topic,
      }),
    )
    return
  }

  topic.forEach((topic) => {
    subMap.set(topic, true)
    onSend(
      JSON.stringify({
        cmd: 'sub',
        topic,
      }),
    )
  })
}

// 取消订阅
export function onUnsubscribe(topic: string | string[]) {
  console.log('[Unsubscribe:]', topic)
  if (typeof topic === 'string') {
    onSend(
      JSON.stringify({
        cmd: 'unsub',
        topic,
      }),
    )
    subMap.delete(topic)
    return
  }

  topic.forEach((topic) => {
    onSend(
      JSON.stringify({
        cmd: 'unsub',
        topic,
      }),
    )
    subMap.delete(topic)
  })
}

// 自动订阅
function onAutoSubscribe() {
  if (subMap.size > 0) {
    onSubscribe(Array.from(subMap.keys()))
  }
}
