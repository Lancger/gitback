<route lang="json5" type="page">
{
  layout: 'tabbar',
}
</route>

<template>
  <view class="header">
    <wd-tabs
      custom-class="app-tabs app-tabs--large app-tabs--no-flex-1"
      v-model="tabIndex"
      swipeable
      animated
      :map-num="100"
    >
      <block v-for="(item, index) in tab" :key="index">
        <wd-tab :title="$t(item)"></wd-tab>
      </block>
    </wd-tabs>
    <wd-icon name="search" size="35rpx" @click="onRouter('/pages/search/index')"></wd-icon>
  </view>
  <view class="h-88rpx"></view>
  <!-- custom-class="app-tabs app-tabs--no-flex-1" -->
  <wd-tabs
    v-if="tabIndex === 2"
    v-model="cIndex"
    custom-class="options-tabs"
    swipeable
    animated
    :slidable-num="1"
    :map-num="100"
  >
    <block v-for="(item, index) in classify" :key="index">
      <wd-tab :title="$t(item)"></wd-tab>
    </block>
  </wd-tabs>
  <view>
    <view class="list-head">
      <view class="list-head__item">{{ $t('market.listHead.token') }}</view>
      <view class="list-head__item">
        <wd-sort-button
          v-model="priceSortValue"
          :line="false"
          allow-reset
          :title="$t('market.listHead.lastPrice')"
          @change="onPriceSortChange"
        />
      </view>
      <view class="list-head__item">
        <wd-sort-button
          v-model="rateSortValue"
          :line="false"
          allow-reset
          :title="$t('market.listHead.change')"
          @change="onRateSortChange"
        />
      </view>
    </view>
    <wd-skeleton
      :loading="dataLoading"
      animation="flashed"
      :row-col="[
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
        { margin: '0 30rpx', height: '120rpx', borderRadius: '20rpx' },
      ]"
    >
      <app-empty :no-data="list.length === 0">
        <product-list :hideCurrency="tabIndex === 0" :list="list" @click="onTrade"></product-list>
      </app-empty>
    </wd-skeleton>
  </view>
</template>

<script lang="ts" setup>
import _ from 'lodash'
import { useTradeStore, useUserStore } from '@/store'
import { onRouter } from '@/utils'
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'
import { fetchWatchList } from '@/service/home'
import { fetchGetFutures, fetchGetSpot } from '@/service/market'

const tab = ref(['market.tabs.spot', 'market.tabs.futures', 'market.tabs.watch'])
const tabIndex = ref(0)
const priceSortValue = ref(0)
const rateSortValue = ref(0)
const spotList = ref([])
const futuresList = ref([])
const watchList = ref([])
const dataLoading = ref(true)
const classify = ['market.tabs.spot', 'market.tabs.futures']
const cIndex = ref(0)

const list = computed(() => {
  let arr = []
  switch (tabIndex.value) {
    case 0:
      arr = spotList.value
      break
    case 1:
      arr = futuresList.value
      break
    default:
      arr = watchList.value.filter((item) =>
        cIndex.value === 0 ? item.optional === 'xh' : item.optional === 'hy',
      )
  }

  // 价格排序
  if (priceSortValue.value !== 0) {
    return [...arr].sort((a, b) => {
      if (priceSortValue.value === -1) {
        return a.close - b.close
      }
      return b.close - a.close
    })
  }

  // 涨跌幅排序
  if (rateSortValue.value !== 0) {
    return [...arr].sort((a, b) => {
      if (rateSortValue.value === -1) {
        return a.zdf - b.zdf
      }
      return b.zdf - a.zdf
    })
  }

  return arr
})

onLoad(async () => {
  await getSpot()
  await getFutures()
  dataLoading.value = false
  onSubscribe(getSubTopic())
})

onShow(async () => {
  onSubscribe(getSubTopic())
  getWatchList()
  uni.$on('message', onMsgFn)
})

// onHide(() => {
//   onUnsubscribe('all_symbol_detail')
//   uni.$off('message', onMsgFn)
// })

onUnload(() => {
  onUnsubscribe(getSubTopic())
  uni.$off('message', onMsgFn)
})

function getSubTopic() {
  if (subscribeMode === 'mqtt') {
    return 'all_symbol_detail'
  } else {
    const spotSymbol = spotList.value
      .filter((item) => Boolean(item.subText))
      .map((item) => `ws.market.CSPOT.${item.subText}.1`)
    const futuresSymbol = futuresList.value
      .filter((item) => Boolean(item.subText))
      .map((item) => `ws.market.CSPOT.${item.subText}.1`)
    const watchSymbol = watchList.value
      .filter((item) => Boolean(item.subText))
      .map((item) => `ws.market.CSPOT.${item.subText}.1`)
    return [...spotSymbol, ...futuresSymbol, ...watchSymbol]
  }
}

const onPriceSortChange = () => {
  if (priceSortValue.value !== 0) {
    rateSortValue.value = 0
  }
}

const onRateSortChange = () => {
  if (rateSortValue.value !== 0) {
    priceSortValue.value = 0
  }
}

function onTrade(e) {
  switch (tabIndex.value) {
    case 0:
      onRouter(`/pages/market/detail?symbol=${e.symbolName}&type=xh`)
      return
    case 1:
      onRouter(`/pages/market/detail?symbol=${e.symbolName}&type=ubw`)
      return
    default:
      onRouter(
        `/pages/market/detail?symbol=${e.symbolName}&type=${e.optional === 'xh' ? 'xh' : 'ubw'}`,
      )
  }
}
const onMsgFn = onMessage
function onMessage(msgData) {
  const [topic, data] = msgData
  if (topic !== 'all_symbol_detail' && subscribeMode === 'mqtt') return
  onUpdate(data)
}

function onUpdate(data) {
  let findFun
  if (subscribeMode === 'ws') {
    findFun = (item) => data.symbol === item.subText
  } else {
    findFun = (item) => data.symbolName === item.symbolName
  }
  // 自选
  const watchIndex = watchList.value.findIndex(findFun)
  if (watchIndex !== -1) {
    watchList.value.splice(watchIndex, 1, {
      ...watchList.value[watchIndex],
      ...data,
    })
  }
  // 现货
  if (data.type === 'xh' || subscribeMode === 'ws') {
    const sIndex = spotList.value.findIndex(findFun)
    if (sIndex !== -1) {
      spotList.value.splice(sIndex, 1, {
        ...spotList.value[sIndex],
        ...data,
      })
    }
  }
  // 合约
  if (data.type === 'ubw' || subscribeMode === 'ws') {
    const fIndex = futuresList.value.findIndex(findFun)
    if (fIndex !== -1) {
      futuresList.value.splice(fIndex, 1, {
        ...futuresList.value[fIndex],
        ...data,
      })
    }
  }
}

function getSpot() {
  return fetchGetSpot().then((res) => {
    spotList.value = res.data.map((item) => {
      return {
        ...item,
        isShowVol: true,
      }
    })
  })
}

function getFutures() {
  return fetchGetFutures().then((res) => {
    futuresList.value = res.data
      .filter((item) => item.contract_type === '1')
      .map((item) => {
        return {
          ...item,
          isShowVol: true,
        }
      })
  })
}

function getWatchList() {
  return fetchWatchList().then((res) => {
    watchList.value = res.data.map((item) => {
      return {
        ...item,
        isShowVol: true,
      }
    })
  })
}
</script>

<style lang="scss" scoped>
.options-tabs {
  --wot-tabs-nav-height: 68rpx;
  --wot-tabs-nav-color: var(--text-inactive);
  :deep(.wd-tabs__line) {
    display: none;
  }
  :deep(.wd-tabs__nav-item.is-active) {
    color: var(--color-primary);
  }
}
.header {
  position: fixed;
  top: 0;
  z-index: 10;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  width: 100%;
  padding: 0 30rpx 0 15rpx;
  background: var(--background-primary);
  :deep(.wd-tabs__nav-item) {
    padding: 0 15rpx !important;
  }
}
.list-head {
  --wot-sort-button-color: var(--text-inactive);
  box-sizing: border-box;

  display: flex;
  align-items: center;
  padding: 0 60rpx;
  color: var(--text-inactive) !important;
  &__item {
    &:nth-of-type(1) {
      width: 40%;
    }
    &:nth-of-type(2) {
      width: 30%;
      text-align: right;
    }
    &:nth-of-type(3) {
      width: 30%;
      text-align: right;
    }
  }
}
.page {
  background: var(--background-secondary);
}
.page.blue {
  .header {
    background: var(--color-primary);
    :deep(.wd-tabs__line) {
      display: none;
    }
    :deep(.wd-tabs__nav-item) {
      color: var(--text-primary) !important;
    }
    :deep(.wd-tabs__nav-item.is-active) {
      color: var(--color-white) !important;
    }
  }
}
</style>
