<template>
  <app-navbar left-arrow custom-class="!bg-transparent"></app-navbar>
  <view class="p-30rpx">
    <view class="box">
      <view>{{ ssTitle }}</view>
      <view class="flex">
        {{ requirementTime }}
        <wd-count-down
          v-if="pageStatus === 0 || pageStatus === 1 || pageStatus === 3"
          ref="countDown"
          custom-class="count-down"
          :time="time"
          format="mm:ss"
          @finish="finish"
        />
      </view>
    </view>
    <view class="box__hint">
      <view v-if="boxFlag">
        <!-- 等待申诉处理说明 -->
        <view v-if="ddssclTips">
          <p class="mb-10rpx">
            {{ $t('c2c.appealDetails.p1.1') }}
          </p>
          <p class="mb-10rpx">
            {{ $t('c2c.appealDetails.p1.2') }}
          </p>
          <p class="mb-10rpx">
            {{ $t('c2c.appealDetails.p1.3') }}
          </p>
        </view>
        <!-- 等待客服处理说明 -->
        <view v-if="ddkfclsmTips">
          <p class="mb-10rpx">
            {{ $t('c2c.appealDetails.p2.1') }}
          </p>
          <p class="mb-10rpx">
            {{ $t('c2c.appealDetails.p2.2') }}
          </p>
        </view>
        <!-- 处理申诉中说明 -->
        <view v-if="clsszsmTips">
          <p class="mb-10rpx">
            {{ $t('c2c.appealDetails.p3.1') }}
          </p>
          <p class="mb-10rpx">
            {{ $t('c2c.appealDetails.p3.2') }}
          </p>
          <p class="mb-10rpx">
            {{ $t('c2c.appealDetails.p3.3') }}
          </p>
          <p class="mb-10rpx">
            {{ $t('c2c.appealDetails.p3.4') }}
          </p>
        </view>
        <view class="box__hint__button mt-20rpx">
          <wd-button
            @click="
              onRouter(
                `/pages/home/ctwoc/appeal/index?bSType=${listObj.type}&orderId=${listObj.id}&type=4`,
              )
            "
            class="flex-1"
          >
            {{ $t('c2c.appealDetails.additionalDescription') }}
          </wd-button>
          <wd-button class="flex-1" v-if="currentRole === 'initiator'" @click="undoAppeal">
            {{ $t('c2c.appealDetails.undoTheAppeal') }}
          </wd-button>
        </view>
        <view class="box__hint__button mt-20rpx" v-if="consultWith">
          <wd-button class="flex-1" @click="negotiationFailed">
            {{ $t('c2c.appealDetails.negotiationFailed') }}
          </wd-button>
          <wd-button class="flex-1" @click="consensus">
            {{ $t('c2c.appealDetails.consensus') }}
          </wd-button>
        </view>
      </view>

      <view class="box__hint__button" v-if="pageStatus === 4">
        <wd-button
          @click="
            onRouter(`/pages/home/ctwoc/appeal/index?bSType=${listObj.type}&orderId=${listObj.id}`)
          "
          class="flex-1"
        >
          {{ $t('c2c.appealDetails.appealAgain') }}
        </wd-button>
      </view>
    </view>
    <view class="consultWith-hint" v-if="consultWithHint">
      {{ $t('c2c.appealDetails.p4') }}
    </view>
    <view
      class="box__update"
      @click="onRouter(`/pages/home/ctwoc/appeal-progress/index?orderId=${listObj.id}`)"
    >
      <text>{{ $t('c2c.appealDetails.appealProgressUpdate') }}</text>
      <wd-icon name="arrow-right" size="22px"></wd-icon>
    </view>

    <view class="box__list">
      <view class="box__list__item">
        <view>
          {{ $t('c2c.buy') }}
          <text>USDT</text>
        </view>
      </view>
      <view class="box__list__item">
        <view>{{ $t('c2c.appealDetails.unitPrice') }}</view>
        <view>{{ listObj.exchange_code }} {{ listObj.unit_price }}</view>
      </view>
      <view class="box__list__item">
        <view>{{ $t('c2c.appealDetails.amount') }}</view>
        <view>{{ listObj.exchange_code }} {{ listObj.fiat_currency_amount }}</view>
      </view>
      <view class="box__list__item">
        <view>{{ $t('c2c.appealDetails.qty') }}</view>
        <view>{{ listObj.coin_cou }} {{ listObj.coin_symbol }}</view>
      </view>
      <view class="box__list__item">
        <view>{{ $t('c2c.appealDetails.orderNo') }}</view>
        <view>{{ listObj.order_code }}</view>
      </view>
      <view class="box__list__item">
        <view>{{ $t('c2c.appealDetails.createTime') }}</view>
        <view>{{ formatDate(listObj.order_time) }}</view>
      </view>
      <view class="box__list__item">
        <view>{{ $t('c2c.appealDetails.recipient') }}</view>
        <view>{{ listObj.name }}</view>
      </view>
    </view>
    <wd-message-box selector="wd-message-box-slot">
      <view class="text-align-left">
        {{ $t('c2c.appealDetails.p5') }}
      </view>
      <view class="text-align-left">
        {{ $t('c2c.appealDetails.p6.1') }}
      </view>
      <view class="text-align-left">
        {{ $t('c2c.appealDetails.p6.2') }}
      </view>
      <view class="text-align-left">{{ $t('c2c.appealDetails.p6.3') }}</view>
    </wd-message-box>
    <wd-message-box selector="wd-message-box-slot-consultWith"></wd-message-box>
  </view>
</template>
<script lang="ts" setup>
import { t } from '@/locale'
import {
  fetchGetAppealOrder,
  fetchGetServicePayment,
  fetchAppealCancel,
  fetchAppeal,
} from '@/service/ctwoc'
import { useUserStore } from '@/store'
import { useMessage } from 'wot-design-uni'
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'

const message = useMessage('wd-message-box-slot')
const consultWithMessage = useMessage('wd-message-box-slot-consultWith')
const userStore = useUserStore()
const ssTitle = ref(t('c2c.appealDetails.appealInProgress'))
const requirementTime = ref(t('c2c.appealDetails.desc.2'))
const orderId = ref('')
const listObj = ref<any>({})
const appealData = ref<any>({})
const pageStatus = ref<any>('')
const currentRole = ref('associate')
const time = ref<number>(0)
const ddssclTips = ref(false)
const ddkfclsmTips = ref(false)
const clsszsmTips = ref(false)
const boxFlag = ref(true)
const consultWith = ref(false)
const consultWithHint = ref(false)

onLoad((e) => {
  orderId.value = e.orderId
  initialize()
})

const initialize = () => {
  fetchGetAppealOrder({
    orderId: orderId.value,
  }).then((res) => {
    appealData.value = res.data[0]
    pageStatus.value = appealData.value.status
    const startTime = new Date(appealData.value.create_time).getTime()
    const endTime = startTime + 30 * 60 * 1000
    const currTime = new Date().getTime()
    time.value = endTime - currTime
    const id = userStore.userInfo.merchant
      ? userStore.userInfo.merchant.member_id
      : userStore.userInfo.id
    if (appealData.value.associate_id === id) {
      currentRole.value = 'associate' // associate 被申诉人
    }
    if (appealData.value.initiator_id === id) {
      currentRole.value = 'initiator' // associate 申诉人
    }

    console.log(appealData.value.associate_id === id)
    console.log(appealData.value.initiator_id === id)

    console.log(currentRole.value, 'currentRole')

    console.log(pageStatus.value, 'pageStatus')
    pageInitFun()
  })

  fetchGetServicePayment({
    orderId: orderId.value,
  }).then((res) => {
    // 30分钟客服介入
    listObj.value = res.data
  })
}

const pageInitFun = () => {
  // 申诉人页面处理
  if (currentRole.value === 'initiator') {
    if (pageStatus.value === 0) {
      ddssclTips.value = true
      ssTitle.value = t('c2c.appealDetails.appealInProgress')
      requirementTime.value = t('c2c.appealDetails.desc.1')
    } else if (pageStatus.value === 1) {
      ddssclTips.value = true
      ssTitle.value = t('c2c.appealDetails.appealInProgress')
      requirementTime.value = t('c2c.appealDetails.desc.1')
    } else if (pageStatus.value === 2) {
      ddkfclsmTips.value = true
      ssTitle.value = t('c2c.appealDetails.appealInProgress')
      requirementTime.value = t('c2c.appealDetails.desc.2')
    } else if (pageStatus.value === 3) {
      clsszsmTips.value = true
      consultWith.value = true
      ssTitle.value = t('c2c.appealDetails.appealInProgress')
      requirementTime.value = t('c2c.appealDetails.desc.3')
    } else if (pageStatus.value === 4) {
      boxFlag.value = false
      ssTitle.value = t('c2c.appealDetails.appealClosed')
      requirementTime.value = t('c2c.appealDetails.desc.4')
    }
  } else if (currentRole.value === 'associate') {
    // 被申诉人页面处理
    if (pageStatus.value === 0) {
      clsszsmTips.value = true
      // 被申诉方0状态有协商按钮
      consultWith.value = true
      ssTitle.value = t('c2c.appealDetails.appealInProgress')
      requirementTime.value = t('c2c.appealDetails.desc.3')
    } else if (pageStatus.value === 1) {
      clsszsmTips.value = true
      // 被申诉方1状态有协商按钮
      consultWith.value = true
      ssTitle.value = t('c2c.appealDetails.appealInProgress')
      requirementTime.value = t('c2c.appealDetails.desc.3')
    } else if (pageStatus.value === 2) {
      console.log(pageStatus.value)

      ddkfclsmTips.value = true
      ssTitle.value = t('c2c.appealDetails.appealInProgress')
      requirementTime.value = t('c2c.appealDetails.desc.2')
    } else if (pageStatus.value === 3) {
      clsszsmTips.value = true
      consultWithHint.value = true
      consultWith.value = false
      ssTitle.value = t('c2c.appealDetails.appealInProgress')
      requirementTime.value = t('c2c.appealDetails.desc.5')
    } else if (pageStatus.value === 4) {
      clsszsmTips.value = true
      boxFlag.value = false
      ssTitle.value = t('c2c.appealDetails.appealClosed')
      requirementTime.value = t('c2c.appealDetails.desc.4')
    }
    // 被申诉人没有撤销权限
  }
}

const finish = () => {
  if (pageStatus.value === 0 || pageStatus.value === 1 || pageStatus.value === 3) {
    pageStatus.value = 2
    pageStatus.value = 2
    pageInitFun()
  }
}

const undoAppeal = () => {
  message
    .confirm({
      title: t('c2c.appealDetails.message1.title'),
      cancelButtonText: t('c2c.appealDetails.message1.cancelButtonText'),
      confirmButtonText: t('c2c.appealDetails.message1.confirmButtonText'),
    })
    .then(() => {
      uni.showLoading()
      fetchAppealCancel(orderId.value)
        .then((res) => {
          initialize()
        })
        .finally(() => {
          uni.hideLoading()
        })
      // console.log('点击了确定按钮')
    })
    .catch(() => {
      // console.log('点击了取消按钮')
    })
}

const negotiationFailed = () => {
  consultWithMessage
    .confirm({
      title: t('c2c.appealDetails.message2.title'),
      msg: t('c2c.appealDetails.message2.msg'),
    })
    .then(() => {
      uni.showLoading()
      fetchAppeal({
        orderId: orderId.value,
        type: 3,
      })
        .then((res) => {
          initialize()
        })
        .finally(() => {
          uni.hideLoading()
        })
    })
    .catch(() => {})
}

const consensus = () => {
  consultWithMessage
    .confirm({
      title: t('c2c.appealDetails.message3.title'),
      msg: t('c2c.appealDetails.message3.msg'),
    })
    .then(() => {
      if (currentRole.value === 'initiator') {
        // 申诉人直接撤销申诉就行
        fetchAppealCancel(orderId.value).then((res) => {
          initialize()
        })
      } else {
        uni.showLoading()
        fetchAppeal({
          orderId: orderId.value,
          type: 2,
        })
          .then((res) => {
            initialize()
          })
          .finally(() => {
            uni.hideLoading()
          })
      }
    })
    .catch(() => {})
}
//
</script>
<style lang="scss" scoped>
.page {
  background-color: var(--background-tertiary);
}
.box {
  padding: 30rpx;
  background-color: var(--background-primary);
  view:nth-child(1) {
    font-size: 30rpx;
    font-weight: 500;
  }
  view:nth-child(2) {
    margin-top: 20rpx;
    font-size: 26rpx;
  }
  &__hint {
    padding: 30rpx;
    margin-top: 20rpx;
    font-size: 26rpx;
    background-color: var(--background-primary);
    &__button {
      display: flex;
      gap: 20rpx;
      align-items: center;
    }
  }

  &__update {
    display: flex;
    justify-content: space-between;
    padding: 30rpx;
    margin-top: 20rpx;
    font-size: 30rpx;
    background-color: var(--background-primary);
  }
}

.box__list {
  padding: 30rpx;
  margin-top: 20rpx;
  background-color: var(--background-primary);
  &__item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20rpx;
  }
}
.flex {
  display: flex;
  gap: 20rpx;
  align-items: center;
}
.text-align-left {
  margin-bottom: 10rpx;
  text-align: left;
}

.consultWith-hint {
  padding: 30rpx;
  margin-top: 20rpx;
  font-weight: 500;
  text-align: center;
  background-color: var(--background-primary);
}
//
</style>
