<template>
  <app-navbar custom-class="bg-transparent" :title="title"></app-navbar>

  <view class="sum">{{ data.sum }} {{ data.valueCoin.name }}</view>

  <view class="flex_jc">
    <view>{{ $t('c2c.buyPreview.unitPrice') }}</view>
    <view>
      {{ data.rate || BNumber(data.value).div(data.sum) }} {{ data.valueCree.local_currency }}
    </view>
  </view>

  <view class="flex_jc">
    <view>{{ $t('c2c.buyPreview.amount') }}</view>
    <view>{{ data.value }} {{ data.valueCree.local_currency }}</view>
  </view>

  <view class="flex_jc">
    <view>{{ $t('c2c.buyPreview.qty') }}</view>
    <view>{{ data.sum }} {{ data.valueCoin.name }}</view>
  </view>
  <view class="flex_jc">
    <view>{{ $t('c2c.buyPreview.channel') }}</view>
    <view>{{ $t('c2c.buyPreview.c2c') }}</view>
  </view>

  <view class="flex_jc">
    <view>{{ $t('c2c.buyPreview.paymentMethod') }}</view>
    <view>{{ $t('c2c.buyPreview.bankTransfer') }}</view>
  </view>
  <!-- <view class="flex_jc">
    <view>Refresh</view>
    <view>
      <wd-count-down
        ref="countDown"
        custom-class="count-down"
        :time="time"
        format="mm:ss"
        @finish="finish"
      />
    </view>
  </view> -->
  <view class="btn">
    <!-- <view class="btn_subscribe">Buy USDT</view> -->
    <view class="btn_subscribewhine" @click="navigator">
      {{ data.index === 2 ? $t('c2c.buy') : $t('c2c.sell') }} {{ data.valueCoin.name }}
    </view>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchSubmitOrder } from '@/service/ctwoc'
import { BNumber } from '@/utils/number'

const data = ref()
const flag = ref(true)
const title = ref('')
const time = ref<number>(30 * 1000)
const countDown = ref<any>(null)
const typeFlag = ref('')
onLoad((e) => {
  data.value = uni.getStorageSync('payment')
  typeFlag.value = e.type
  if (data.value.index === 2) {
    title.value = t('c2c.buyPreview.buyPreview')
  } else {
    title.value = t('c2c.buyPreview.sellPreview')
  }
})
const finish = () => {
  countDown.value.reset()
}
function navigator(url: string) {
  if (!flag.value) return
  flag.value = false
  uni.showLoading()
  let obj = null
  // 如果有值代表是从快捷买币进来的
  if (typeFlag.value) {
    // 获取快捷买币保存的值
    obj = uni.getStorageSync('express')
  } else {
    obj = {
      advertiseId: data.value.id,
      coinCou: data.value.sum,
      fiatCurrencyAmount: data.value.value,
      serviceType: '2',
      type: data.value.index === 1 ? '2' : '1',
    }
  }
  return fetchSubmitOrder(obj)
    .then((res) => {
      uni.setStorageSync('buypreview', {
        res: res.data,
        data: data.value,
      })
      uni.redirectTo({
        url: `/pages/home/ctwoc/cancelorder/index`,
      })
    })
    .finally(() => {
      uni.hideLoading()
      flag.value = true
    })
}
</script>

<style lang="scss" scoped>
.btn {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 130rpx;
  box-shadow: 0px -5px 21.7px 0px #c6c6c640;
  &_subscribe {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--text-inactive) !important;
    text-align: center;
    background-color: var(--border-color-inactive);
    border-radius: 100rpx;
  }

  &_subscribewhine {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--wot-color-white) !important;
    text-align: center;
    background-color: #00a7ed;
    border-radius: 100rpx;
  }
}
.sum {
  margin: 120rpx 0 40rpx 0;
  font-family: Asap;
  font-size: 50rpx;
  font-weight: 500;
  color: var(--text-primary);
  text-align: center;
}
.flex_jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 48rpx;
  padding: 0 30rpx;
  color: var(--text-inactive);
}
.count-down {
  color: var(--text-inactive);
}
</style>
