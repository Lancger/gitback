import { http } from '@/utils/http'

/** banner */
export const fetchBanner = (params?: any) => {
  return http.get('/api/mjkj-web/coin/open/coinBanners/1', params)
}

// 自选
export const fetchWatchList = (params?: any) => {
  return http.get('/api/mjkj-web/coin/quotes/getOptional', params)
}

// 获取公告
export const fetchNotice = (data?: any) => {
  return http.post('/api/mjkj-web/coin/member/getSysNotice', data)
}

// 获取
export const fetchNews = (data) => {
  return http.post('/api/mjkj-web/coin/member/getNewsList', data)
}
