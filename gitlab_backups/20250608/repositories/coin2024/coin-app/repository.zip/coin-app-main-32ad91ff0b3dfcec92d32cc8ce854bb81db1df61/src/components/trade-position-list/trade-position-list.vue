<template>
  <view class="trade-order-list">
    <view v-for="(item, index) in list" :key="index" class="trade-order-list__item">
      <view class="flex items-center">
        <view class="token-info">
          <image class="token-info__logo" :src="item.avatar" />
          <view class="token-info__name">{{ item.symbol_name }}</view>
        </view>
        <!-- <view :class="[item.direction === 1 ? 'up-color' : 'down-color']" class="position-lever">
          Cross/combined {{ item.leverage }}
        </view> -->
        <view class="tag-list">
          <view class="tag-list__item">{{ $t('components.tradePositionList.futures') }}</view>
          <view :class="[item.direction === 1 ? 'buy' : 'sell']" class="tag-list__item">
            {{
              item.direction === 1
                ? $t('components.tradePositionList.long')
                : $t('components.tradePositionList.short')
            }}
          </view>
          <view class="tag-list__item brand">{{ item.leverage }}</view>
        </view>
      </view>
      <view class="order-date">{{ formatDate(item.create_time) }}</view>
      <view class="order-detail">
        <!-- <view :class="[item.pl >= 0 ? 'up-color' : 'down-color']" class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('components.tradePositionList.pl') }} (USDT)
          </view>
          <view class="order-detail__item__content">
            {{ item.pl > 0 ? '+' : null }}{{ onEmptyText(item.pl) }}
          </view>
        </view>
        <view class="order-detail__item">
          <view class="order-detail__item__title"></view>
          <view class="order-detail__item__content"></view>
        </view>
        <view :class="[item.pl > 0 ? 'up-color' : 'down-color']" class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('components.tradePositionList.pl') }}%
          </view>
          <view class="order-detail__item__content">
            {{ item.pl >= 0 ? '+' : null }}{{ onEmptyText(item.plRatio) }}
          </view>
        </view> -->
        <view class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('components.tradePositionList.volume') }} ({{
              futuresConfig.unit === 'u' ? item.balance_symbol : futuresConfig.unitLabel
            }})
          </view>
          <view class="order-detail__item__content">
            {{
              onEmptyText(
                futuresConfig.unit === 'u'
                  ? toFormat(BNumber(item.balance).plus(item.frozen_balance), true)
                  : item.balance,
              )
            }}
          </view>
        </view>
        <view class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('components.tradePositionList.margin') }} (USDT)
          </view>
          <view class="order-detail__item__content">
            {{ onEmptyText(toFormat(item.principal_amount, true)) }}
          </view>
        </view>
        <view :class="[item.pl >= 0 ? 'up-color' : 'down-color']" class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('components.tradePositionList.pl') }} (USDT)
          </view>
          <view class="order-detail__item__content">
            <text>{{ item.pl > 0 ? '+' : null }}{{ onEmptyText(item.pl) }}</text>
            /
            <text class="font-size-22rpx">
              {{ item.pl >= 0 ? '+' : null }}{{ onEmptyText(item.plRatio) }}
            </text>
          </view>
        </view>
        <view class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('components.tradePositionList.entryPrice') }} (USDT)
          </view>
          <view class="order-detail__item__content">
            {{ onEmptyText(toFormat(item.avg_price, item.base_coin_scale)) }}
          </view>
        </view>
        <view class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('components.tradePositionList.markPrice') }} (USDT)
          </view>
          <view class="order-detail__item__content">
            {{ onEmptyText(toFormat(item.closePrice, item.base_coin_scale)) }}
          </view>
        </view>
        <view class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('components.tradePositionList.riskRate') }}
          </view>
          <view class="order-detail__item__content">{{ toFormatPercent(BNumber(riskRate)) }}</view>
        </view>
        <!-- <view class="order-detail__item">
          <view class="order-detail__item__title">
            {{ $t('components.tradePositionList.liqPrice') }} (USDT)
          </view>
          <view class="order-detail__item__content">
            {{ onEmptyText(toFormat(item.forcePrice, item.base_coin_scale)) }}
          </view>
        </view> -->
      </view>
      <view v-if="false" class="mt-30rpx">
        <text class="color-[var(--text-inactive)] pr-10rpx">TP/SL</text>
        <text class="up-color">68,092</text>
        /
        <text class="down-color">67,610</text>
      </view>
      <view class="order-btn-list">
        <wd-button
          v-if="showReverse"
          custom-class="order-btn-list__item"
          type="info"
          block
          @click="onEvent('reverse', item)"
        >
          {{ $t('components.tradePositionList.reverse') }}
        </wd-button>
        <wd-button
          v-if="showStopLimit"
          custom-class="order-btn-list__item"
          type="info"
          block
          @click="onEvent('stopLimit', item)"
        >
          {{ $t('components.tradePositionList.tp/sl') }}
        </wd-button>
        <!-- <wd-button
          custom-class="order-btn-list__item"
          type="info"
          block
          @click="onEvent('fastClose', item)"
        >
          Quick Close
        </wd-button> -->
        <wd-button
          v-if="showClose"
          custom-class="order-btn-list__item"
          type="info"
          block
          @click="onEvent('close', item)"
        >
          {{ $t('components.tradePositionList.close') }}
        </wd-button>
        <wd-button
          v-if="showShare"
          custom-class="order-btn-list__item"
          icon="share"
          block
          @click="onEvent('share', item)"
        >
          {{ $t('common.share') }}
        </wd-button>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { useTradeStore } from '@/store'
import { onEmptyText } from '@/utils'
import { formatDate } from '@/utils/day'
import { BNumber, toFormat, toFormatPercent } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  riskRate: {
    type: [Number, String],
    default: 0,
  },
  showClose: {
    type: Boolean,
    default: true,
  },
  showShare: {
    type: Boolean,
    default: true,
  },
  showReverse: {
    type: Boolean,
    default: true,
  },
  showStopLimit: {
    type: Boolean,
    default: true,
  },
})

const emits = defineEmits(['onEvent'])

const { futuresConfig } = useTradeStore()

const onEvent = (event: string, row: any) => {
  emits('onEvent', [event, row])
}
</script>

<style lang="scss" scoped>
.trade-order-list {
  &__item {
    position: relative;
    padding: 30rpx;
    border-bottom: 1px solid var(--background-gary-4);
    .order-btn {
      position: absolute;
      top: 30rpx;
      right: 30rpx;
      height: 40rpx;
      font-size: 20rpx;
    }
    .token-info {
      display: flex;
      align-items: center;
      &__logo {
        width: 40rpx;
        height: 40rpx;
        margin-right: 10rpx;
        border-radius: 50%;
      }
      &__name {
        font-size: 30rpx;
        font-weight: 500;
      }
    }
    .tag-list {
      position: relative;
      display: flex;
      gap: 10rpx;
      align-items: center;
      padding-left: 10rpx;
      margin-left: 10rpx;
      &::after {
        position: absolute;
        top: 50%;
        left: 0;
        width: 1px;
        height: 24rpx;
        content: '';
        background: var(--border-color);
        transform: translateY(-50%);
      }
      &__item {
        height: 30rpx;
        padding: 0 14rpx;
        font-size: 20rpx;
        line-height: 30rpx;
        background: var(--background-gary-4);
        border-radius: 5rpx;
      }
      &__item.buy {
        color: var(--color-green);
        background: #07ba831a;
      }
      &__item.sell {
        color: var(--color-red);
        background: #ff4e431a;
      }
      &__item.brand {
        color: var(--color-primary);
        background: rgba(0, 167, 237, 0.1);
      }
    }
    .order-date {
      flex: 1;
      // margin-left: 20rpx;
      margin-top: 20rpx;
      font-size: 22rpx;
      color: var(--text-inactive);
      // text-align: right;
    }
    .order-detail {
      display: flex;
      flex-wrap: wrap;
      gap: 20rpx 0;
      margin-top: 20rpx;
      &__item {
        box-sizing: border-box;
        width: 33.33%;
        &:nth-of-type(3n - 1) {
          text-align: center;
        }
        &:nth-of-type(3n) {
          text-align: right;
        }
        &__title {
          font-size: 22rpx;
          color: var(--text-inactive);
        }
        &__content {
          margin-top: 20rpx;
          font-size: 26rpx;
          font-weight: 500;
        }
      }
    }
    .position-lever {
      position: relative;
      padding-left: 10rpx;
      margin-left: 10rpx;
      font-size: 25rpx;
      font-weight: 500;
      &::after {
        position: absolute;
        top: 50%;
        left: 0;
        width: 1px;
        height: 24rpx;
        content: '';
        background: var(--border-color);
        transform: translateY(-50%);
      }
    }
    .order-btn-list {
      display: flex;
      // flex-wrap: wrap;
      gap: 20rpx;
      align-items: center;
      margin-top: 30rpx;
      &__item {
        flex: 1;
        // width: calc(50% - 20rpx);
        min-width: auto !important;
        height: 60rpx !important;
        font-size: 26rpx;
        font-weight: 500;
      }
    }
  }
}
</style>
