<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar></app-navbar>
  <view class="px-60rpx mt-65rpx">
    <view class="font-size-40rpx font-600">{{ $t('auth.twoFactor.title') }}</view>
    <view class="color-[var(--text-inactive)] mt-20rpx mb-60rpx">
      {{ $t('auth.twoFactor.desc') }} {{ account }}
    </view>
    <sms-button ref="smsRef" :api="smsApi" :api-params="smsApiParams"></sms-button>
    <view>
      <!-- 密码输入框 -->
      <wd-password-input
        v-model="verificationCode"
        :mask="false"
        :gutter="10"
        :length="6"
        :focused="showKeyboard"
        @focus="showKeyboard = true"
      />
      <!-- 数字键盘 -->
      <wd-number-keyboard
        v-model="verificationCode"
        v-model:visible="showKeyboard"
        :maxlength="6"
        @close="showKeyboard = false"
      />
    </view>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { useUserStore } from '@/store'
import { fetchForgetPassword } from '@/service/auth'
import { fetchSendEmail, fetchSendSMS } from '@/service/base'

const userStore = useUserStore()
const verificationCode = ref('')
const showKeyboard = ref(false)
const pageModel = ref('')
const smsRef = ref(null)

const submitMap = {
  auth: onAuthSubmit,
  forgetPassword: onForgetPasswordSubmit,
}

const smsApi = computed(() => {
  if (pageModel.value === 'forgetPassword') {
    return userStore.authForm.type === 1 ? fetchSendSMS : fetchSendEmail
  }

  return userStore.authForm.phone ? fetchSendSMS : fetchSendEmail
})

const smsApiParams = computed(() => {
  const type =
    pageModel.value === 'forgetPassword' ? 5 : userStore.authForm.loginType === 'register' ? 1 : 2
  if (userStore.authForm.email || userStore.authForm.type === 2) {
    return {
      email: userStore.authForm.email || userStore.authForm.account,
      type,
    }
  }

  return {
    phone: userStore.authForm.phone || userStore.authForm.account,
    areaCode: userStore.authForm.areaCode,
    type,
  }
})

const account = computed(() => {
  if (pageModel.value === 'forgetPassword') {
    return userStore.authForm.account
  }

  return userStore.authForm.phone ? userStore.authForm.phone : userStore.authForm.email
})

watch(verificationCode, async (newVal) => {
  if (newVal.length === 6) {
    try {
      uni.showLoading({
        title: t('common.loading'),
        mask: true,
      })
      showKeyboard.value = false
      await submitMap[pageModel.value]()
      uni.hideLoading()
    } catch {
      uni.hideLoading()
    }
  }
})

onLoad((options) => {
  pageModel.value = options.t
})

onReady(() => {
  if (smsRef.value) {
    smsRef.value.onSend()
  }
})

function onForgetPasswordSubmit() {
  userStore.authForm.code = verificationCode.value
  const form = { ...userStore.authForm }
  delete form.areaCode
  return fetchForgetPassword(form).then((res) => {
    uni.showToast({
      title: t('common.success'),
    })
    uni.navigateBack({ delta: 2 })
  })
}

function onAuthSubmit() {
  if (userStore.authForm.loginType === 'login') {
    userStore.authForm.step = 2
  }

  if (userStore.authForm.phone) {
    userStore.authForm.phoneCode = verificationCode.value
    userStore.authForm.emailCode = ''
  } else if (userStore.authForm.email) {
    userStore.authForm.emailCode = verificationCode.value
    userStore.authForm.phoneCode = ''
  }

  return userStore.onAuth(userStore.authForm).then((res) => {
    uni.showToast({
      title: t('common.success'),
    })
    uni.reLaunch({
      url: '/pages/home/index',
    })
  })
}
</script>

<style lang="scss" scoped>
:deep(.wd-password-input) {
  margin: 200rpx 0 0 !important;
}
:deep(.wd-password-input__item) {
  background: var(--background-tertiary) !important;
  border: 1px solid var(--border-color);
  border-radius: 10rpx !important;
}
</style>
