<template>
  <wd-select-picker
    v-model="value"
    :title="$t('common.select')"
    use-default-slot
    :columns="columns"
    filterable
    :filter-placeholder="$t('common.search')"
    type="radio"
    :show-confirm="false"
    @confirm="onConfirm"
  >
    <slot></slot>
  </wd-select-picker>
</template>

<script lang="ts" setup>
import { fetchFormData, fetchArea } from '@/service/base'

const props = withDefaults(
  defineProps<{
    selectMode: 'area' | 'country'
  }>(),
  {
    selectMode: 'area',
  },
)

const emits = defineEmits(['onConfirm'])

const value = ref('')

const columns = ref<Record<string, any>>([])

if (props.selectMode === 'area') {
  getArea()
} else {
  getCountry()
}

const onConfirm = (event) => {
  emits('onConfirm', event.selectedItems)
}

// 国家
function getCountry() {
  return fetchFormData('1531578936708677634', {
    pageSize: -521,
    column: 'sort',
    order: 'asc',
    is_auth: 1,
    pageNo: 1,
  }).then((res) => {
    columns.value = res.data.records.map((item) => {
      return {
        ...item,
        label: item.zh_name,
        value: item.id,
      }
    })
  })
}

// 区号
function getArea() {
  return fetchArea({
    pageNo: 1,
    pageSize: -521,
  }).then((res) => {
    columns.value = res.data.map((item) => {
      return {
        ...item,
        label: `+${item.code} (${item.title})`,
        value: item.code,
      }
    })
  })
}
</script>

<style lang="scss" scoped>
:deep(.wd-action-sheet__header) {
  height: 90rpx;
  font-size: 36rpx;
  font-weight: 700;
  line-height: 90rpx;
}
:deep(.wd-action-sheet__close) {
  top: 30rpx;
  right: 30rpx;
  font-size: 30rpx;
}
:deep(.wd-select-picker__wrapper.is-filterable) {
  height: 60vh;
  max-height: 60vh;
  padding: 0;
}
:deep(.wd-radio__label) {
  font-size: 30rpx;
  font-weight: 500;
}
:deep(.wd-radio.is-cell-radio) {
  padding: 20rpx 30rpx;
}
</style>
