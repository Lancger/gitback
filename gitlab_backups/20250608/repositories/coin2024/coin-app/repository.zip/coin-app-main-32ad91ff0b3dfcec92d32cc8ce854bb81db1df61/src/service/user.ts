import { http } from '@/utils/http'

/** 获取用户信息 */
export const fetchGetUserInfo = () => {
  return http.get('/api/mjkj-web/coin/member/getMemberInfo')
}

/** 获取国家列表 */
export const fetchGetNationList = (params: any) => {
  return http.get('/api/mjkj-web/cgform-api/getData/1531578936708677634', params)
}

/** 获取客服列表 */
export const fetchGetServiceList = (params: any) => {
  return http.get('/api/mjkj-web/cgform-api/getData/1530464853989064705', params)
}

/** 获取身份证件列表 */
export const fetchGetCertificatesType = (params: any) => {
  return http.get('/api/mjkj-web/sys/sys/dict/getDictItems/certificates_type', params)
}

/** 身份认证 */
export const fetchVerified = (data: any) => {
  return http.post('/api/mjkj-web/coin/member/verified', data)
}

// 实名认证状态查询
export const fetchGetKYCStatus = () => {
  return http.get('/api/mjkj-web/coin/member/getMemberOtherData/yhrzxx')
}
/** 账户验证绑定 */
export const fetchAccountVerificationBinding = (data: any) => {
  return http.post('/api/mjkj-web/coin/member/accountVerificationBinding', data)
}

/** 修改钓鱼码 */
export const fetchAantiCode = (data: any) => {
  return http.post('/api/mjkj-web/coin/member/antiCode', data)
}

/** 获取绑定二维码 */
export const fetchGetGoogleVerification = (data: any) => {
  return http.get('/api/mjkj-web/coin/member/getGoogleVerification/0', data)
}

/** 绑定谷歌验证码 */
export const fetchGoogleVerificationBindingOrReset = (params: any) => {
  return http.get(
    `/api/mjkj-web/coin/member/googleVerificationBindingOrReset/${params.code}/${params.type}`,
  )
}

/** 设置资金密码 */
export const fetchTradePwd = (data: any) => {
  return http.post(`/api/mjkj-web/coin/member/tradePwd`, data)
}

/** 查询银行卡列表 */
export const fetchGetPayment = () => {
  return http.get(`/api/mjkj-web/coin/member/getPayment`)
}

/** 获取账户类型 */
export const fetchGetData = () => {
  return http.get(
    `/api/mjkj-web/cgform-api/getData/1541709245688348673?pageSize=-521&enable=1&column=id&order=desc`,
  )
}

/** 新增或修改银行账户 */
export const fetchPayment = (data: any) => {
  return http.post(`/api/mjkj-web/coin/member/payment`, data)
}

/** 修改登录密码 */
export const fetchUpdatePassword = (data: any) => {
  return http.post(`/api/mjkj-web/coin/member/updatePassword`, data)
}

/** 修改用户资料 */
export const fetchUserProfileEdit = (data) => {
  return http.post(`/api/mjkj-web/coin/member/updateMemberInfo`, data)
}

/** 设置语言 */
export const fetchSetLanguage = (language) => {
  return http.get(`/api/mjkj-web/coin/open/lang/${language}`)
}

// 谷歌身份校验
export const fetchGoogleAuthCheck = (code) => {
  return http.get(`/api/mjkj-web/coin/open/verifyGoogleCode`, {
    googleCode: code,
  })
}

// 资金密码校验
export const fetchPayPasswordCheck = (password) => {
  return http.post(`/api/mjkj-web/coin/member/tradePwd/validated`, {
    tradePwd: password,
  })
}

// 注销账号
export const fetchDeleteAccount = () => {
  return http.get(`/api/mjkj-web/coin/member/logout`)
}
