export default {
  futuresUnit: 'cont',
  dateFormat: {
    YMDHMS: 'MM/DD/YYYY HH:mm:ss',
    YMDHM: 'MM/DD/YYYY HH:mm',
    YMD: 'MM/DD/YYYY',
    YM: 'MM/YYYY',
    HM: 'HH:mm',
    HMS: 'HH:mm:ss',
  },
  futuresLeverageMode: 'free', // free: 自由杠杆, fixed: 固定杠杆
  isDeleteAccount: false,
  c2cChat: false,
  spotPnL: false, // 现货收益显示
  authRememberPassword: true, // 记住密码
  isVip: false, // 是否开启VIP
  decimalSeparator: '.', // 小数点
  groupingSeparator: ',', // 千分位
}
