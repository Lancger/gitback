<template>
  <app-navbar :title="$t('earnNew.title')"></app-navbar>
  <view class="header">
    <wd-search
      v-model="keyword"
      @search="getList"
      @change="getList"
      @clear="getList"
      :placeholder="$t('earnNew.placeholder')"
      placeholder-left
    >
      <template #suffix>
        <image
          class="w-36rpx h-36rpx ml-30rpx mr-30rpx"
          :src="onImageToThemeImage('/static/images/icons/records.png')"
          @click="onRouter(`/pages/earn/history/index?t=${tab[tabIndex].value}`)"
        />
      </template>
    </wd-search>
  </view>
  <wd-tabs
    v-model="tabIndex"
    swipeable
    animated
    sticky
    :offset-top="44 - 44"
    custom-class="app-tabs--no-flex-1"
    @change="onTabsChange"
  >
    <block v-for="(item, index) in tab" :key="index">
      <wd-tab :title="$t(item.label)">
        <view>
          <view
            class="flex items-center justify-between h-80rpx px-30rpx b-t font-size-22rpx color-[var(--text-inactive)]"
          >
            <view class="w-33.33%">{{ $t('earnNew.crypto') }}</view>
            <view v-if="item.value === 1" class="w-33.33% text-center">
              {{ $t('earnNew.term') }}
            </view>
            <view class="w-33.33% text-right">{{ $t('earnNew.apr') }}</view>
          </view>
          <app-empty custom-class="h-30vh" :no-data="list.length === 0">
            <template v-if="item.value === 0">
              <view
                v-for="(v, i) in list"
                :key="i"
                class="flex items-center justify-between px-30rpx py-25rpx font-size-28rpx font-500"
                @click="onRouter(`/pages/earn/detail?id=${v.coin_id}&t=0`)"
              >
                <view class="flex items-center gap-20rpx">
                  <image class="w-42rpx h-42rpx" :src="v.coin_avatar" />
                  <view class="font-size-30rpx">{{ v.coin_name }}</view>
                </view>
                <view class="flex items-center gap-15rpx">
                  <view>{{ toFormatPercent(v.rate_year * 100) }}</view>
                  <text
                    v-if="showInterestRateChart === 'true'"
                    class="i-carbon-chart-line-smooth"
                    @click.stop="onShowChart(v)"
                  ></text>
                </view>
              </view>
            </template>
            <template v-if="item.value === 1">
              <view
                v-for="(v, i) in list"
                :key="i"
                class="flex items-center justify-between px-30rpx py-25rpx font-size-28rpx font-500"
                @click="onRouter(`/pages/earn/detail?id=${v.id}&t=1`)"
              >
                <view class="w-33.33% flex items-center gap-20rpx">
                  <image class="w-42rpx h-42rpx" :src="v.coin_avatar" />
                  <view class="font-size-30rpx">{{ v.coin_name }}</view>
                </view>
                <view class="w-33.33% text-center">{{ v.day }} {{ $t('earnNew.day') }}</view>
                <view class="w-33.33% text-right">{{ toFormatPercent(v.rate_year * 100) }}</view>
              </view>
            </template>
          </app-empty>
        </view>
        <view class="h-20rpx bg-[var(--background-tertiary)]"></view>
        <view class="px-30rpx">
          <view class="flex items-center gap-20rpx h-80rpx">
            <view class="font-size-30rpx">{{ $t('earnNew.holdings') }}</view>
            <view class="w-1px h-24rpx bg-[var(--border-color)]"></view>
            <view
              class="h-30rpx line-height-30rpx px-8rpx font-size-20rpx bg-[var(--background-gary-4)] rd-5rpx"
            >
              {{ $t(item.label) }}
            </view>
          </view>
          <view :class="{ 'banner--two': item.value === 1 }" class="banner">
            <view class="banner__title">
              {{ item.value === 0 ? $t('earnNew.ad1.title') : $t('earnNew.ad2.title') }}
            </view>
            <view class="banner__desc">
              {{ item.value === 0 ? $t('earnNew.ad1.desc') : $t('earnNew.ad2.desc') }}
            </view>
          </view>
          <app-empty custom-class="h-30vh" :no-data="positionList.length === 0">
            <template v-if="item.value === 0">
              <view
                v-for="(v, i) in positionList"
                :key="i"
                class="py-30rpx b-b"
                @click="onRouter(`/pages/earn/history/detail?id=${v.coinId}&t=0`)"
              >
                <view class="flex items-center justify-between">
                  <view class="flex items-center gap-10rpx">
                    <image class="w-42rpx h-42rpx" :src="v.coinAvatar"></image>
                    <view class="font-size-30rpx font-500">{{ v.coinName }}</view>
                  </view>
                  <!-- <view class="font-size-22rpx color-[var(--text-inactive)]">05/21 02:55:44</view> -->
                </view>
                <view class="flex items-center mt-30rpx">
                  <view class="flex-1">
                    <view class="font-size-22rpx color-[var(--text-inactive)]">
                      {{ $t('earnNew.totalAmount') }}
                    </view>
                    <view class="mt-20rpx font-size-24rpx font-500">
                      {{ toFormat(v.holdNum, true) }}
                    </view>
                  </view>
                  <view class="flex-1 text-center">
                    <view class="font-size-22rpx color-[var(--text-inactive)]">
                      {{ $t('earnNew.earnings') }}
                    </view>
                    <view class="mt-20rpx font-size-24rpx font-500 color-[var(--color-green)]">
                      {{ toFormat(v.holdProfit, true) }}
                    </view>
                  </view>
                  <view class="flex-1 text-right">
                    <view class="font-size-22rpx color-[var(--text-inactive)]">
                      {{ $t('earnNew.apr') }}
                    </view>
                    <view class="mt-20rpx font-size-24rpx font-500">
                      {{ toFormatPercent(v.rateYear * 100) }}
                    </view>
                  </view>
                </view>
              </view>
            </template>
            <template v-if="item.value === 1">
              <view
                v-for="(v, i) in positionList"
                :key="i"
                class="py-30rpx b-b"
                @click="onFixedToDetail(v)"
              >
                <view class="flex items-center justify-between">
                  <view class="flex items-center gap-10rpx">
                    <image class="w-42rpx h-42rpx" :src="v.coin_avatar"></image>
                    <view class="font-size-30rpx font-500">
                      {{ v.coin_name }} /
                      <text class="font-size-24rpx">{{ v.day }} {{ $t('earnNew.day') }}</text>
                    </view>
                  </view>
                  <view class="font-size-22rpx color-[var(--text-inactive)]">
                    {{ formatDate(v.create_time) }}
                  </view>
                </view>
                <view class="flex items-center mt-30rpx">
                  <view class="flex-1">
                    <view class="font-size-22rpx color-[var(--text-inactive)]">
                      {{ $t('earnNew.totalAmount') }}
                    </view>
                    <view class="mt-20rpx font-size-24rpx font-500">
                      {{ toFormat(v.buy_cou, true) }}
                    </view>
                  </view>
                  <view class="flex-1 text-center">
                    <view class="font-size-22rpx color-[var(--text-inactive)]">
                      {{ $t('earnNew.dailyEarnings') }}
                    </view>
                    <view class="mt-20rpx font-size-24rpx font-500 color-[var(--color-green)]">
                      {{ toFormat(v.dailyExpectedProfit, true) }}
                    </view>
                  </view>
                  <view class="flex-1 text-center">
                    <view class="font-size-22rpx color-[var(--text-inactive)]">
                      {{ $t('earnNew.totalRevenue') }}
                    </view>
                    <view class="mt-20rpx font-size-24rpx font-500 color-[var(--color-green)]">
                      {{
                        v.cumulativeEarnings
                          ? toFormat(v.cumulativeEarnings, BNumber(v.cumulativeEarnings).dp())
                          : toFormat(
                              v.dailyExpectedProfit * v.day,
                              BNumber(v.dailyExpectedProfit).dp(),
                            )
                      }}
                    </view>
                  </view>
                  <view class="flex-1 text-right">
                    <view class="font-size-22rpx color-[var(--text-inactive)]">
                      {{ $t('earnNew.apr') }}
                    </view>
                    <view class="mt-20rpx font-size-24rpx font-500">
                      {{ toFormatPercent(v.rate_year * 100) }}
                    </view>
                  </view>
                  <!-- <view class="flex-1 text-right">
                    <view class="font-size-22rpx color-[var(--text-inactive)]">
                      {{ $t('earnNew.term') }}
                    </view>
                    <view class="mt-20rpx font-size-24rpx font-500">
                      {{ v.day }} {{ $t('earnNew.day') }}
                    </view>
                  </view> -->
                </view>
              </view>
            </template>
          </app-empty>
        </view>
      </wd-tab>
    </block>
  </wd-tabs>

  <!-- 图表 -->
  <wd-popup
    v-model="showChart"
    position="bottom"
    :z-index="99"
    closable
    custom-style="border-radius: 40rpx 40rpx 0 0"
  >
    <view class="p-30rpx">
      <view class="font-size-30rpx font-500 text-center">Real-Time APR</view>
      <view class="mt-30rpx">
        <interest-rate-chart :id="productItem.id" />
      </view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import interestRateChart from './components/interest-rate-chart.vue'
import { t } from '@/locale'
import { useUserStore } from '@/store'
import { onImageToThemeImage, onRouter } from '@/utils'
import { toFormat, BNumber, toFormatPercent } from '@/utils/number'
import {
  fetchFlexibleList,
  fetchFixedList,
  fetchFlexiblePositionList,
  fetchFixedHistory,
} from '@/service/earn'
import { formatDate } from '@/utils/day'

const showInterestRateChart = import.meta.env.VITE_SHOW_INTEREST_RATE_CHART
const userStore = useUserStore()
const tab = ref([
  {
    label: 'earnNew.fixed',
    value: 1,
  },
  {
    label: 'earnNew.flexible',
    value: 0,
  },
  {
    label: 'quantitative.title',
    value: 3,
  },
])
const tabIndex = ref(0)
const keyword = ref('')
const list = ref([])
const positionList = ref([])
const showChart = ref(false)
const productItem = ref<any>({})

onShow(() => {
  getList()
  getPosition()
})

function onShowChart(data) {
  productItem.value = data
  showChart.value = true
}

function onFixedToDetail(data) {
  userStore.earnHistoryItemData = data
  onRouter('/pages/earn/history/detail?t=1')
}

function onTabsChange({ index }) {
  if (index === 2) {
    onRouter('/pages/quantitative/index')
    nextTick(() => {
      tabIndex.value = 0
    })
    return
  }
  tabIndex.value = index
  list.value = []
  positionList.value = []
  getList()
  getPosition()
}

function getList() {
  if (tab.value[tabIndex.value].value === 0) {
    return fetchFlexibleList({
      coinName: keyword.value,
      pageNum: 1,
      pageSize: -521,
    }).then((res) => {
      list.value = res.data.records
    })
  } else {
    return fetchFixedList({
      coinName: keyword.value,
    }).then((res) => {
      list.value = res.data
    })
  }
}

function getPosition() {
  if (tab.value[tabIndex.value].value === 0) {
    return fetchFlexiblePositionList().then((res) => {
      positionList.value = res.data
    })
  } else {
    return fetchFixedHistory({
      orderStatus: 0,
      current: 1,
      size: 9999,
    }).then((res) => {
      positionList.value = res.data.records
    })
  }
}
</script>

<style lang="scss" scoped>
.header {
  --wot-search-input-radius: 100rpx;
  --wot-search-input-height: 70rpx;
  --wot-search-icon-color: var(--text-primary);
  --wot-search-input-fs: 26rpx;
}

.banner {
  box-sizing: border-box;
  width: 100%;
  height: 116rpx;
  padding: 24rpx 30rpx 0;
  margin: 15rpx 0;
  color: #fff;
  background: url('../../static/images/earn/banner01.png') no-repeat;
  background-size: cover;
  &__title {
    font-size: 26rpx;
    font-weight: 500;
  }
  &__desc {
    margin-top: 10rpx;
    font-size: 22rpx;
  }
  &--two {
    background: url('../../static/images/earn/banner02.png') no-repeat;
    background-size: cover;
  }
}
</style>
