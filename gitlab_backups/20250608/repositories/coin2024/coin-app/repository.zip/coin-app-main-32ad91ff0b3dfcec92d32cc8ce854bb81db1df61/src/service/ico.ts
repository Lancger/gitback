import { http } from '@/utils/http'

// 列表
export function fetchIcoProductList(data) {
  return http.post('/api/mjkj-web/coin/purchase/list', data)
}

// 配售记录
export function fetchIcoPlacingRecords(data) {
  return http.post('/api/mjkj-web/coin/purchase/purchaseAllotRecord/list', data)
}

// 申购记录
export function fetchIcoSubscribeRecords(data) {
  return http.post('/api/mjkj-web/coin/purchase/purchaseRecord/list', data)
}

// 申购
export function fetchIcoSubscribe(data) {
  return http.post('/api/mjkj-web/coin/purchase/applyPurchase', data)
}

// 认缴
export function fetchIcoSubscribePay(data) {
  return http.post('/api/mjkj-web/coin/purchase/pay', data)
}

// 申请配售权限
export function fetchIcoPlacingApply(data?) {
  return http.post('/api/mjkj-web/coin/purchase/purchaseAccessRequest', data)
}

// 查询配售审核状态
export function fetchIcoCheckPlacingPermission(data?) {
  return http.post('/api/mjkj-web/coin/purchase/queryPurchaseAccess', data)
}
