// Datafeed implementation that you will add later
import Datafeed from './datafeed.js'

// window.BASE_URL = 'https://h5.x-coinx.com'
// 获取域名
if (location.port) {
  // dev
  window.BASE_URL = 'http://localhost:9000'
  // window.BASE_URL = 'http://192.168.101.16:9000'
  window.WSS_URL = 'wss://h5.devxxl.top/ws'
  // window.WSS_URL = 'wss://h5.financedev.xyz/ws'
} else {
  // prod
  // const index = location.host.indexOf('.')
  // const host = location.host.substring(index)
  window.BASE_URL = `https://${location.host}` //location.origin.replace(/(h5|view)/, 'gateway')
  window.WSS_URL = `wss://${location.host}/ws` //location.origin.replace(/h5/, 'ws').replace(/https/, 'wss') + '/mqtt'
}

window.tvQuery = {}

decodeURIComponent(location.search)
  .substring(1)
  .split('&')
  .forEach((item) => {
    const [key, value] = item.split('=')
    window.tvQuery[key] = value
  })

if (tvQuery.ymd) {
  const [ymd, hm] = tvQuery.ymd.split('|')
  window.tvQuery.YMD = ymd
  window.tvQuery.HM = hm
}

if (tvQuery.mode === 'ws') {
  const topicTimeMap = {
    1: '1m',
    5: '5m',
    15: '15m',
    30: '30m',
    60: '1h',
    '1D': '1d',
    '1W': '1wk',
    '1M': '1mo',
  }
  window.subTopic = `ws.kline.CSPOT.${tvQuery.ts}.1.${topicTimeMap[tvQuery.i]}`
}

// 获取当前时区
window.tvTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone

// 初始化图表
window.tvWidget = new TradingView.widget({
  datafeed: Datafeed,
  library_path: './charting_library/',
  // library_path: "https://charting-library.tradingview-widget.com/charting_library/",
  debug: false, // uncomment this line to see Library errors and warnings in the console
  fullscreen: true,
  symbol: tvQuery.s,
  interval: tvQuery.i,
  container: 'tv_chart_container',
  locale: 'en',
  theme: tvQuery.theme,
  // timezone: tvTimezone,
  load_last_chart: false,
  disabled_features: [
    'left_toolbar',
    'timeframes_toolbar',
    'header_compare',
    'header_resolutions',
    'header_fullscreen_button',
    'header_compare',
    'header_screenshot',
    'header_settings',
    'header_undo_redo',
    'header_quick_search',
    'header_symbol_search',
    'vert_touch_drag_scroll',
    'use_localstorage_for_settings',
    'save_chart_properties_to_local_storage',
  ],
  enabled_features: [],
  overrides: {
    'mainSeriesProperties.style': Number(tvQuery.style),
    'scalesProperties.showStudyLastValue': false,
  },
  custom_formatters: {
    timeFormatter: {
      format: (date) => {
        return dayjs(date).format(tvQuery.HM)
      },
    },
    dateFormatter: {
      format: (date) => {
        return dayjs(date).format(tvQuery.YMD)
      },
    },
  },
  numeric_formatting: { decimal_sign: tvQuery.d, grouping_separator: tvQuery.g },
})

// 图表初始化成功
window.tvWidget.onChartReady(function () {
  // 指标
  if (Boolean(Number(tvQuery.v))) {
    tvWidget.activeChart().createStudy('Volume', false, false)
  }

  if (Boolean(Number(tvQuery.ma))) {
    tvWidget.activeChart().createStudy('Moving Average', false, false, { length: 7 })
    tvWidget.activeChart().createStudy('Moving Average', false, false, { length: 25 })
    tvWidget.activeChart().createStudy('Moving Average', false, false, { length: 99 })
  }
})
