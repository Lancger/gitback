<template>
  <wd-popup
    :model-value="show"
    position="bottom"
    :z-index="99"
    closable
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="popup-head b-b">
      <view class="popup-head-title">{{ $t('components.tradeLeverage.title') }}</view>
      <view class="popup-head-desc">{{ data.symbol_name }}</view>
    </view>
    <view class="px-30rpx pt-40rpx">
      <view class="text-center">
        <text class="color-[var(--text-active)]">
          {{ $t('components.tradeLeverage.current') }}
        </text>
        {{ modelValue }}X
      </view>
      <view class="leverage-value">
        <view
          v-if="config.futuresLeverageMode === 'free'"
          class="center w-36rpx h-36rpx bg-[var(--background-gary-4)]"
          @click="onTap('minus')"
          @longtap="onTap('minus')"
        >
          <wd-icon custom-class="color-[var(--text-inactive)]" name="remove" size="24rpx"></wd-icon>
        </view>
        <view class="flex items-center px-40rpx">
          <input
            :value="inputValue"
            class="leverage-value__input"
            type="number"
            :disabled="config.futuresLeverageMode === 'fixed'"
            @input="onInput"
            @blur="onBlur"
          />
          <view class="font-size-34rpx font-500 ml-10rpx">X</view>
        </view>
        <view
          v-if="config.futuresLeverageMode === 'free'"
          class="center w-36rpx h-36rpx bg-[var(--background-gary-4)]"
          @click="onTap('plus')"
          @longtap="onTap('plus')"
        >
          <wd-icon custom-class="color-[var(--text-active)]" name="add1" size="24rpx"></wd-icon>
        </view>
      </view>
      <view v-if="config.futuresLeverageMode === 'free'" class="px-40rpx mt-30rpx">
        <app-slider
          v-model="inputValue"
          :options="sliderOptions"
          :min="min"
          :max="max"
        ></app-slider>
      </view>
      <view v-if="config.futuresLeverageMode === 'fixed'" class="leverage-list">
        <scroll-view class="leverage-list-scroll" scroll-x>
          <view
            v-for="(item, index) in sliderOptions"
            :key="index"
            :class="{ inactive: inputValue === item.value }"
            class="leverage-list-item"
            @click="onSelect(item.value)"
          >
            {{ item.label }}
          </view>
        </scroll-view>
      </view>
    </view>
    <view class="tip">
      <view>
        <text class="color-[var(--text-inactive)]">
          {{ $t('components.tradeLeverage.borrowingLimit') }}
        </text>
        {{ maxOpen }} {{ data.unitLabel }}
      </view>
      <view class="mt-10rpx">
        <text class="color-[var(--text-inactive)]">
          {{ $t('components.tradeLeverage.marginRequired') }}
        </text>
        0.0 USDT
      </view>
    </view>
    <wd-button custom-class="m-20rpx" size="large" :loading="loading" block @click="onSubmit">
      {{ $t('common.confirm') }}
    </wd-button>
  </wd-popup>
</template>

<script lang="ts" setup>
import { fetchChangeLever } from '@/service/futures'
import { inputLimitToDigit, toFixed, BNumber } from '@/utils/number'
import config from '@/config'

const props = defineProps({
  modelValue: {
    type: Number,
    default: 1,
  },
  show: {
    type: Boolean,
    default: false,
  },
  max: {
    type: Number,
    default: 200,
  },
  min: {
    type: Number,
    default: 1,
  },
  data: {
    type: Object,
    default: () => ({}),
  },
})

const emits = defineEmits(['update:modelValue', 'update:show', 'onCallback'])

const loading = ref(false)
const inputValue = ref<number>(props.modelValue)

const sliderOptions = ref([])

// 最大手续费
const maxFee = computed(() => {
  return toFixed(
    BNumber(props.data.hyBaseBalance).times(inputValue.value).times(props.data.open_fee),
    +props.data.base_coin_scale,
  )
})

// // 最大开仓数量
const maxOpen = computed(() => {
  if (props.data.unit === 'u') {
    return Number(
      toFixed(BNumber(props.data.hyBaseBalance).minus(maxFee.value), +props.data.base_coin_scale),
    )
  } else {
    // return Math.floor(
    //   BNumber(props.data.hyBaseBalance)
    //     .minus(maxFee.value)
    //     .div(props.data.contract_size / inputValue.value),
    // )
    return calculateMaxCards(
      +props.data.hyBaseBalance,
      +props.data.open_fee,
      +props.data.contract_size,
      +inputValue.value,
    )
  }
})

watch(
  () => props.show,
  (newVal) => {
    if (newVal) {
      inputValue.value = props.modelValue
      onInitSliderOptions()
    }
  },
)

const onInitSliderOptions = () => {
  sliderOptions.value = []
  sliderOptions.value.push({
    label: '1X',
    value: 1,
  })
  const stepVal = Math.floor(props.max / 4)
  const len = Math.floor(props.max / stepVal)
  for (let i = 1; i <= len; i++) {
    const val = stepVal * i
    sliderOptions.value.push({
      label: `${val}X`,
      value: val,
    })
  }

  if (props.max % stepVal !== 0) {
    sliderOptions.value.push({
      label: `${props.max}X`,
      value: props.max,
    })
  }
}

const onSubmit = async () => {
  loading.value = true
  try {
    await fetchChangeLever({
      cou: inputValue.value,
      pattern: 2,
      patternType: 1,
      symbol: props.data.coin_symbol,
      type: 'ubw',
    })
    onClose()
    emits('onCallback')
    loading.value = false
  } catch (e) {
    loading.value = false
  }
}

const onClose = () => {
  emits('update:show', false)
}

const onSelect = (val) => {
  inputValue.value = val
}

const onTap = (type) => {
  if (type === 'minus' && +inputValue.value !== props.min) {
    inputValue.value--
  }

  if (type === 'plus' && +inputValue.value !== props.max) {
    inputValue.value++
  }
}

const onInput = (e) => {
  let value = Number(inputLimitToDigit(e.detail.value, 0)) || null
  inputValue.value = value
  if (value > props.max) {
    value = props.max
  }
  nextTick(() => {
    inputValue.value = value
  })
}

const onBlur = (e) => {
  let value = Number(inputLimitToDigit(e.detail.value, 0)) || null
  if (value > props.max) {
    value = props.max
  }
  if (value < props.min) {
    value = props.min
  }
  nextTick(() => {
    inputValue.value = value
  })
}

// 计算最大可开张数
function calculateMaxCards(balance, feeRate, cardValue, leverage) {
  if (!balance || !feeRate || !cardValue || !leverage) return 0
  // 初始最大张数为0
  let maxCards = 0
  // 当余额足够支付一定数量的卡和手续费时，增加张数
  while (true) {
    // 尝试购买下一个张数的总成本
    const potentialCost = ((maxCards + 1) * cardValue) / leverage
    const totalCostWithFee = potentialCost + (maxCards + 1) * cardValue * feeRate
    // 如果余额足够支付这笔交易，继续增加张数，否则退出循环
    if (totalCostWithFee <= balance) {
      maxCards += 1
    } else {
      break
    }
  }

  return maxCards
}
</script>

<style lang="scss" scoped>
.tip {
  padding: 20rpx 30rpx;
  margin: 30rpx;
  font-size: 22rpx;
  background: var(--background-gary-4);
  border-radius: 10rpx;
}
.popup-head {
  box-sizing: border-box;
  padding: 56rpx 30rpx 20rpx;
  &-title {
    font-size: 30rpx;
    font-weight: 500;
  }
  &-desc {
    margin-top: 20rpx;
    font-size: 22rpx;
    color: var(--text-inactive);
  }
}
.leverage-value {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 30rpx;
  &__input {
    width: 120rpx;
    font-size: 56rpx;
    font-weight: 500;
    line-height: 1;
    text-align: center;
    border-bottom: 1px solid var(--border-color);
  }
}
.leverage-list {
  box-sizing: border-box;
  height: 72rpx;
  margin: 30rpx;
  overflow: hidden;
  border: 1px solid var(--border-color);
  border-radius: 100rpx;
  &-scroll {
    width: 100%;
    font-size: 0;
    white-space: nowrap;
  }
  &-item {
    display: inline-block;
    width: 135rpx;
    height: 50rpx;
    margin-top: 10rpx;
    font-size: 26rpx;
    font-weight: 500;
    line-height: 50rpx;
    text-align: center;
    border-radius: 100rpx;
    transition: all 0.3s;
    &:first-child {
      margin-left: 10rpx;
    }
    &:last-child {
      margin-right: 10rpx;
    }
  }
  &-item.inactive {
    color: #fff;
    background: var(--color-primary);
  }
}
</style>
