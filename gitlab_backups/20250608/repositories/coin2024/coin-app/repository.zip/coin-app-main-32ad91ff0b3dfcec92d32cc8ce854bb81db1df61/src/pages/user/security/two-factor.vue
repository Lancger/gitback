<template>
  <app-navbar></app-navbar>
  <verification :title="$t('safe.twoFactor.title')"></verification>
</template>

<script lang="ts" setup>
import verification from './components/verification.vue'
</script>

<style lang="scss" scoped></style>
