<template>
  <wd-overlay :show="modelValue" :z-index="99" @click="onClose">
    <view class="wrapper">
      <view class="dialog" @click.stop>
        <view class="dialog__title">{{ $t('futures.index.confirmOrderDialog.title') }}</view>
        <view class="flex items-center font-500 mt-40rpx gap-10rpx">
          <text :class="[data.direction === 1 ? 'up-color' : 'down-color']">
            {{ data.direction === 1 ? $t('futures.index.long') : $t('futures.index.short') }}
          </text>
          <view>
            {{ data.exchangeCoinStr }}
          </view>
          <view class="tag">{{ data.leverage }}X</view>
        </view>
        <view class="order-list">
          <view class="order-list-item">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.confirmOrderDialog.orderPrice') }}
            </view>
            <view>
              {{
                data.orderType !== 'ptwt'
                  ? $t('futures.index.confirmOrderDialog.market')
                  : `${toFormat(data.price)} USDT`
              }}
            </view>
          </view>
          <view v-if="data.unit === 'cont'" class="order-list-item">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.confirmOrderDialog.volume') }}
            </view>
            <view>{{ data.amount }} {{ data.unitLabel }}</view>
          </view>
          <view class="order-list-item">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.confirmOrderDialog.margin') }}
            </view>
            <view>{{ data.unit === 'cont' ? data.margin : data.amount }} USDT</view>
          </view>
          <!-- <view class="order-list-item">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.confirmOrderDialog.marginRatio') }}
            </view>
            <view>--%</view>
          </view> -->
          <view v-if="data.takeProfitPrice || data.stopLossPrice" class="order-list-item">
            <view class="color-[var(--text-inactive)]">
              {{ $t('futures.index.confirmOrderDialog.tp/sl') }}
            </view>
            <view>
              <text class="up-color">{{ toFormat(data.takeProfitPrice, true) }}</text>
              /
              <text class="down-color">{{ toFormat(data.stopLossPrice, true) }}</text>
            </view>
          </view>
        </view>
        <view class="dialog__foot">
          <wd-button custom-class="flex-1" type="info" plain @click="onClose">
            {{ $t('common.cancel') }}
          </wd-button>
          <wd-button custom-class="flex-1" :loading="loading" @click="onConfirm">
            {{ $t('common.confirm') }}
          </wd-button>
        </view>
      </view>
    </view>
  </wd-overlay>
</template>

<script lang="ts" setup>
import { toFormat } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  data: {
    type: Object,
    default: () => ({}),
  },
  loading: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['update:modelValue', 'onConfirm'])

const onConfirm = () => {
  emits('onConfirm')
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  .tag {
    height: 24rpx;
    padding: 0 6rpx;
    font-size: 20rpx;
    line-height: 24rpx;
    color: var(--color-primary);
    background: #00a7ed1a;
    border-radius: 5rpx;
  }
  .dialog {
    box-sizing: border-box;
    width: 540rpx;
    padding: 30rpx;
    background-color: var(--background-primary);
    border-radius: 20rpx;
    &__title {
      font-size: 30rpx;
      font-weight: 500;
      text-align: center;
    }
    .order-list {
      padding: 25rpx 0;
      &-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 15rpx 0;
      }
    }
    &__foot {
      display: flex;
      gap: 14rpx;
      align-items: center;
    }
  }
}
</style>
