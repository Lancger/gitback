<template>
  <app-navbar custom-class="bg-transparent" :title="$t('assets.transfer.title')">
    <!-- <template #right>
      <wd-icon
        name="view-module"
        size="22px"
        @click="navigator('/pages/asset/deposit/history/index')"
      ></wd-icon>
    </template> -->
  </app-navbar>
  <view class="drop-menu mt-30rpx">
    <wd-drop-menu>
      <wd-drop-menu-item :title="from.text" ref="fromDropMenu">
        <view
          class="product-list"
          v-for="(item, index) in fromAccount"
          :key="index"
          @click="fromChange(item)"
        >
          <view class="product-list__left">{{ item.text }}</view>
          <view class="product-list__right" v-if="item.text === from.text">
            <image
              class="w-30rpx h-30rpx"
              src="@/static/images/assets/xuanzhong.png"
              mode="aspectFit"
            />
          </view>
        </view>
      </wd-drop-menu-item>
      <view class="drop-menu_icon" @click="transfer">
        <image
          class="w-40rpx h-40rpx img"
          src="@/static/images/assets/zhuanhuan.png"
          mode="aspectFit"
        />
      </view>

      <wd-drop-menu-item :title="to.text" ref="toDropMenu">
        <view
          class="product-list"
          v-for="(item, index) in toAccount"
          :key="index"
          @click="toChange(item)"
        >
          <view class="product-list__left">{{ item.text }}</view>
          <view class="product-list__right" v-if="item.text === to.text">
            <image
              class="w-30rpx h-30rpx"
              src="@/static/images/assets/xuanzhong.png"
              mode="aspectFit"
            />
          </view>
        </view>
      </wd-drop-menu-item>
    </wd-drop-menu>
  </view>

  <view class="drop-menu flex-jc">
    <view class="drop-menu_type">
      <view @click="closeOutside">
        <input
          @input="currencyNameChange"
          :placeholder="$t('assets.transfer.crypto')"
          type="text"
          disabled
          v-model="currencyName"
        />
      </view>
    </view>
    <wd-drop-menu>
      <wd-drop-menu-item :title="balanceObj.name" ref="balanceDropMenu">
        <template v-for="(item, index) in fromBalance" :key="index">
          <view v-if="item.name === 'USDT'" class="product-list" @click="balanceChange(item)">
            <view class="product-list__left">
              <image class="w-50rpx h-50rpx" :src="item.avatar"></image>
              {{ item.name }}
            </view>
            <view class="product-list__right">{{ toFormat(item.balance, true) }}</view>
          </view>
        </template>
      </wd-drop-menu-item>
    </wd-drop-menu>
  </view>

  <view class="drop-menu flex-jc">
    <view class="drop-menu_type">{{ $t('assets.transfer.amount') }}</view>
    <view class="drop-menu_type flex-jc">
      <view class="drop-menu_Amount w50">
        <wd-input
          type="number"
          custom-class="!text-right"
          no-border
          v-model="sum"
          :placeholder="''"
        />
      </view>
      <view class="drop-menu_max" @click="sum = balanceObj.balance">
        {{ $t('assets.transfer.max') }}
      </view>
    </view>
  </view>

  <view class="available">
    {{ $t('assets.transfer.available') }} {{ toFormat(balanceObj.balance, true) }}
    {{ balanceObj.name }}
  </view>
  <view class="button">
    <wd-button :disabled="disabled" size="large" block @click="confirm">
      {{ $t('assets.transfer.submit') }}
    </wd-button>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchWalletTransAccount, fetchGetMyBalance, fetchWalletTrans } from '@/service/assets'
import { useUserStore } from '@/store'
import { toFormat, BNumber } from '@/utils/number'
import { useQueue } from 'wot-design-uni'

const { closeOutside } = useQueue()

const fromDropMenu = ref()
const toDropMenu = ref()
const balanceDropMenu = ref()
const sum = ref('')
const userInfo = useUserStore().userInfo
const accountList = ref([]) // 账户信息数字
const from = ref<any>({}) // 划转的户头
const to = ref<any>({}) // 将要划转的户头
const balance = ref({}) // 所有户头下面币种余额的集合
const currencyName = ref() // 币种模糊搜索的数据
const balanceObj = ref<any>({}) // 当前选中币种的余额数据

onLoad(() => {
  fetchWalletTransAccountFun()
})

const disabled = computed(() => {
  if (!sum.value || parseFloat(sum.value) < 1) {
    return true
  } else {
    return false
  }
})

const currencyNameChange = () => {
  currencyName.value = currencyName.value.toUpperCase()
  // balanceDropMenu.value.open()
}
// 保存from展示的账户数据
const fromAccount = computed(() => {
  return accountList.value.filter((item) => {
    return item.id !== to.value.id
  })
})

// 保存to展示的账户数据
const toAccount = computed(() => {
  return accountList.value.filter((item) => {
    return item.id !== from.value.id
  })
})

// 当前划转户头下面的币种余额
const fromBalance = computed(() => {
  return balance.value[from.value.id].filter((item) =>
    currencyName.value ? item.name.includes(currencyName.value) : item,
  )
})
async function fetchWalletTransAccountFun() {
  const walletDataRes = await fetchWalletTransAccount({})
  walletDataRes.data = walletDataRes.data.filter((item) => {
    if (userInfo.is_merchant !== '2' && item.id === 'service') {
      return false
    }
    // fix: 去掉杠杆和市值
    if (item.id === 'marginFixed' || item.id === 'marginAll' || item.id === 'market') {
      return false
    }
    return true
  })
  accountList.value = walletDataRes.data.map((item, index) => {
    if (item.value === 'wallet') {
      item.type = '1'
    } else if (item.value === 'spot') {
      item.type = '2'
    } else if (item.value === 'marginFixed') {
      item.type = '3'
    } else if (item.value === 'marginAll') {
      item.type = '4'
    } else if (item.value === 'contract') {
      item.type = '5'
    } else if (item.value === 'market') {
      item.type = '6'
    } else if (item.value === 'wealth') {
      item.type = '7'
    } else if (item.value === 'service') {
      item.type = '8'
    } else if (item.value === 'options') {
      item.type = '9'
    }
    return item
  })
  getBalance()
  from.value = accountList.value[0]
  to.value = accountList.value[1]
}

const getBalance = () => {
  accountList.value.forEach((item, index) => {
    fetchGetMyBalance({
      type: item.type,
    }).then((res) => {
      if (index === 0) {
        balanceObj.value = res.data.find((item) => item.symbol === 'USDT')
      }
      balance.value[item.id] = res.data
    })
  })
}
const fromChange = (item) => {
  from.value = item
  fromDropMenu.value.close()
  balanceObj.value = balance.value[from.value.id].find((item) => item.symbol === 'USDT')
}

const toChange = (item) => {
  to.value = item
  toDropMenu.value.close()
}

const transfer = () => {
  const copyFrom = Object.assign({}, from.value)
  const copyTo = Object.assign({}, to.value)

  from.value = copyTo
  to.value = copyFrom
  fromBalance.value.forEach((item) => {
    if (item.name === balanceObj.value.name) {
      balanceObj.value = item
    }
  })
}

const balanceChange = (item) => {
  balanceObj.value = item
  balanceDropMenu.value.close()
}

const confirm = () => {
  uni.showLoading()
  fetchWalletTrans({
    amount: sum.value,
    coinSymbol: balanceObj.value.name,
    from: from.value.id,
    to: to.value.id,
  })
    .then((res) => {
      uni.showToast({
        icon: 'none',
        title: t('common.success'),
      })

      refresh()
      uni.navigateBack()
    })
    .finally(() => {
      uni.hideLoading()
    })
}

const refresh = () => {
  fetchGetMyBalance({
    type: from.value.type,
  }).then((res) => {
    balance.value[from.value.id] = res.data
    res.data.forEach((item) => {
      if (item.name === balanceObj.value.name) {
        balanceObj.value.balance = item.balance
      }
    })
  })
  fetchGetMyBalance({
    type: to.value.type,
  }).then((res) => {
    balance.value[to.value.id] = res.data
  })
}
</script>

<style lang="scss" scoped>
:deep(.wd-drop-menu__list) {
  display: flex;
  justify-content: space-between;
  padding-right: 20rpx;
  //   background-color: var(--background-secondary);
}
:deep(.wd-drop-menu__item) {
  flex: none;
  justify-content: space-between;
}
:deep(.wd-drop-menu__item-title-text) {
  margin-right: 10rpx !important;
}
:deep(.wd-drop-menu__arrow) {
  font-size: 30px !important;
}
:deep(.uni-input-placeholder) {
  font-size: 28rpx;
  color: var(--text-inactive);
}
.button {
  padding: 0 30rpx;
  margin-top: 128rpx;
}
.available {
  padding-right: 30rpx;
  line-height: 88rpx;
  color: var(--text-inactive) !important;
  text-align: right;
}
.flex-jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
  //   padding: 0 30rpx;
}
.drop-menu {
  position: relative;
  min-height: 96rpx;
  border-bottom: 1px solid var(--border-color-inactive);
  &_type {
    padding: 0 30rpx;
    color: var(--text-inactive) !important;
  }
  &_max {
    margin-left: 30rpx;
    color: var(--text-primary);
  }
  &_icon {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
}

.product-list {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 30rpx 30rpx;
  font-weight: 500;
  color: var(--text-primary);
}
</style>
