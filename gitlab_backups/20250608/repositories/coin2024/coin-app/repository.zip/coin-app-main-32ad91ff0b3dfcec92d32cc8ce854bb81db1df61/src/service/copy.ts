import { http } from '@/utils/http'

// 获取产品列表
export const fetchGetProductList = (data: any) => {
  return http.post('/api/mjkj-web/copy/trade/queryList', data)
}

// 参与跟单
export const fetchSubmitOrder = (data: any) => {
  return http.post('/api/mjkj-web/copy/trade/submitOrder', data)
}

// 获取跟单列表
export const fetchGetMyOrderList = (data: any) => {
  return http.post('/api/mjkj-web/copy/trade/myOrderList', data)
}

// 结束跟单
export const fetchCloseOrder = (data: any) => {
  return http.post('/api/mjkj-web/copy/trade/closeOrder', data)
}
