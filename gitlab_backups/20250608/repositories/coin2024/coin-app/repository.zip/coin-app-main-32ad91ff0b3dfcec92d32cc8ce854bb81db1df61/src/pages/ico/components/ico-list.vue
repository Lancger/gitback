<template>
  <view class="ico-list">
    <view
      v-for="(item, index) in list"
      :key="index"
      class="ico-list__item"
      @click="emits('click', item)"
    >
      <view class="ico-list__item-col">
        <view class="token-info">
          <image class="token-info__logo" :src="item.avatar" mode="aspectFit" />
          <view class="token-info__name">
            {{ item.symbol }}
            <!-- <text class="font-size-22rpx color-[var(--text-inactive)]">/USDT</text> -->
          </view>
        </view>
      </view>
      <view class="ico-list__item-col">
        <view class="ico-date">
          {{
            isWin
              ? `${toFormat(item.subscribed_price * item.allotment_quantity)} USDT`
              : item.purchase_quantity
          }}
        </view>
      </view>
      <view class="ico-list__item-col">
        <block v-if="isWin">
          <block v-if="item.isPay">
            <wd-button v-show="item.pay_state == 0" custom-class="pay-btn">
              {{ $t('ico.pay') }}
            </wd-button>
          </block>
          <view v-else class="ico-date">{{ item.allotment_quantity }}</view>
        </block>
        <view v-else class="ico-date">{{ formatDate(item.create_time) }}</view>
        <!-- <wd-progress v-else :percentage="item.progress" color="''" /> -->
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { formatDate } from '@/utils/day'
import { BNumber, toFormat } from '@/utils/number'
const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  isWin: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['click'])
</script>

<style lang="scss" scoped>
.ico-list {
  padding: 10rpx 15rpx;
  &__item {
    display: flex;
    align-items: center;
    padding: 30rpx 0;
    &-col {
      padding: 0 15rpx;
      &:nth-of-type(1) {
        width: 30%;
      }
      &:nth-of-type(2) {
        width: 40%;
        text-align: right;
      }
      &:nth-of-type(3) {
        width: 30%;
        text-align: right;
      }
    }
    .token-info {
      display: flex;
      align-items: center;
      &__logo {
        width: 46rpx;
        height: 46rpx;
        margin-right: 20rpx;
        border-radius: 50%;
      }
      &__name {
        font-size: 30rpx;
        font-weight: 500;
      }
    }

    .ico-date {
      font-size: 26rpx;
      font-weight: 500;
    }
    :deep(.wd-button.pay-btn) {
      width: 100rpx !important;
      min-width: auto;
      height: 40rpx !important;
    }
  }
}
</style>
