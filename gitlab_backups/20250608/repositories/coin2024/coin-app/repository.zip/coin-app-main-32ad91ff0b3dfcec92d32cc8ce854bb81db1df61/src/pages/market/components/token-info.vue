<template>
  <view class="token-info">
    <view class="token-info__head">
      <image class="token-logo" :src="data.avatar" />
      <view class="token-info__head__content">
        <view class="token-name">{{ data.symbol }}</view>
        <!-- <view class="token-desc">{{ data.name }}</view> -->
      </view>
    </view>
    <view class="token-info__desc">
      <view class="token-info__desc-item">
        <view class="token-info__desc-item__label">
          {{ $t('market.detail.tokenInfo.grossVolume') }}
        </view>
        <view class="token-info__desc-item__value">{{ data.total_cou }}</view>
      </view>
      <view class="token-info__desc-item">
        <view class="token-info__desc-item__label">
          {{ $t('market.detail.tokenInfo.circulation') }}
        </view>
        <view class="token-info__desc-item__value">
          {{ data.circulate_cou }}
        </view>
      </view>
      <view class="token-info__desc-item">
        <view class="token-info__desc-item__label">{{ $t('market.detail.tokenInfo.time') }}</view>
        <view class="token-info__desc-item__value">{{ formatDate(data.publish_time) }}</view>
      </view>
      <view class="token-info__desc-item flex-col !items-start">
        <view class="token-info__desc-item__label">{{ $t('market.detail.tokenInfo.intro') }}</view>
        <view class="token-info__desc-item__value mt-20rpx line-height-35rpx">
          <!-- {{ info }} -->
          <!-- <mp-html :content="info" /> -->
          <div v-html="info"></div>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
// @ts-expect-error 没有声明文件
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'
import { toFormat } from '@/utils/number'
import { formatDate } from '@/utils/day'
const props = defineProps({
  data: {
    type: Object,
    default: () => {},
  },
})

const info = computed(() => {
  try {
    const infoObj = JSON.parse(props.data.information)
    return infoObj[uni.getLocale() === 'zh-Hant' ? 'zh_tw' : uni.getLocale()] || infoObj.en
  } catch (error) {
    return props.data.information
  }
})
</script>

<style lang="scss" scoped>
.token-info {
  min-height: 60vh;
  &__head {
    box-sizing: border-box;
    display: flex;
    align-items: center;
    padding: 25rpx 30rpx;
    border-bottom: 1px solid var(--background-gary-4);
    &__content {
      flex: 1;
      padding-left: 30rpx;
    }
    .token-logo {
      width: 90rpx;
      height: 90rpx;
      border-radius: 50%;
    }
    .token-name {
      font-size: 48rpx;
      font-weight: 500;
    }
    .token-desc {
      margin-top: 10rpx;
      font-size: 28rpx;
      color: var(--text-active);
    }
  }
  &__desc {
    padding: 20rpx 30rpx;
    &-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 20rpx 0;
      &__label {
        font-size: 22rpx;
        color: var(--text-inactive);
      }
      &__value {
        font-size: 22rpx;
      }
    }
  }
}
</style>
