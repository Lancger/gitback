<template>
  <view class="p-40rpx pb-0">
    <view
      v-for="(item, index) in list"
      :key="index"
      class="product-list p-40rpx py-30rpx mb-30rpx rd-20rpx"
    >
      <view class="flex items-center gap-20rpx">
        <view
          class="flex items-center justify-center w-160rpx h-80rpx box-border bg-#333333 rd-10rpx"
        >
          <image class="w-70rpx h-70rpx rd-50%" :src="item.avatar" />
        </view>
        <view class="flex-1">
          <view class="flex items-center flex-wrap gap-10rpx">
            <view class="font-size-30rpx font-500">{{ item.pname }}</view>
            <view class="flex-1 flex items-center justify-between gap-10rpx">
              <app-tag v-if="isAll" size="small">
                {{
                  item.project_type === 'purchase'
                    ? $t('icoV2.subscription')
                    : $t('icoV2.placement')
                }}
              </app-tag>
              <view
                v-if="mode !== 'win'"
                class="flex-1 font-size-22rpx color-[var(--text-inactive)] text-right"
              >
                {{ $t('icoV2.schedule') }}
              </view>
            </view>
          </view>
          <view class="flex items-center justify-between gap-10rpx mt-5rpx">
            <view class="font-size-22rpx color-[var(--text-inactive)]">{{ item.symbol }}</view>
            <view v-if="mode !== 'win'" class="w-60%">
              <wd-progress :percentage="item.progress" color="''" />
            </view>
          </view>
        </view>
      </view>
      <!--  -->
      <view
        v-if="item.description"
        class="mt-20rpx font-size-22rpx color-[var(--text-inactive)] ellipsis"
      >
        {{ onHtmlToText(item.description) }}
      </view>
      <!--  -->
      <view
        class="flex flex-col gap-20rpx p-30rpx mt-20rpx bg-[var(--background-primary)] rd-16rpx"
      >
        <template v-if="isAll">
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.totalAllocation') }}</view>
            <view>{{ toFormat(item.circulation, 0) }}</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.endTime') }}</view>
            <view>{{ formatDate(item.stop_time) }}</view>
          </view>
        </template>
        <template v-if="mode === 'subscribed' && !isAll">
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.issuePrice') }}</view>
            <view>{{ toFormat(item.price, true) }} USDT</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.issueQuantity') }}</view>
            <view>{{ toFormat(item.circulation, 0) }}</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.expirationTime') }}</view>
            <view>{{ formatDate(item.stop_time) }}</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.announcementTime') }}</view>
            <view>{{ formatDate(item.win_time) }}</view>
          </view>
        </template>
        <template v-if="mode === 'pending'">
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.issuePrice') }}</view>
            <view>{{ toFormat(item.subscribed_price, true) }} USDT</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.subscribeQuantity') }}</view>
            <view>{{ toFormat(item.purchase_quantity, 0) }}</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.expirationTime') }}</view>
            <view>{{ formatDate(item.stop_time) }}</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.announcementTime') }}</view>
            <view>{{ formatDate(item.win_time) }}</view>
          </view>
        </template>
        <template v-if="mode === 'win'">
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.winningPrice') }}</view>
            <view>{{ toFormat(item.subscribed_price, true) }} USDT</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.winningQuantity') }}</view>
            <view>{{ toFormat(item.allotment_quantity, 0) }}</view>
          </view>
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.winningTime') }}</view>
            <view>{{ formatDate(item.win_time) }}</view>
          </view>
          <!-- <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-inactive)]">{{ $t('icoV2.announcementTime') }}</view>
            <view>{{ formatDate(item.win_time) }}</view>
          </view> -->
        </template>
      </view>
      <!--  -->
      <view
        v-if="item.isSubscribed || item.isEnd || item.isPay"
        class="flex items-center gap-20rpx mt-30rpx"
      >
        <wd-button
          v-if="item.isSubscribed"
          custom-class="flex-1"
          type="primary"
          round
          size="large"
          @click="emits('click', item)"
        >
          {{ $t('icoV2.subscribe') }}
        </wd-button>
        <wd-button
          v-if="+item.pay_state === 0"
          custom-class="flex-1"
          type="primary"
          round
          size="large"
          @click="emits('click', item)"
        >
          {{ $t('icoV2.pay') }}
        </wd-button>
        <wd-button v-if="item.isEnd" custom-class="flex-1" type="info" round size="large" disabled>
          {{ $t('icoV2.ended') }}
        </wd-button>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { onHtmlToText } from '@/utils'
import { formatDate } from '@/utils/day'
import { toFormat, toFixed } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  mode: {
    type: String,
    default: 'subscribed', // subscribed, pending, win
  },
  isAll: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['click'])
</script>

<style lang="scss" scoped>
.product-list {
  background: linear-gradient(180deg, #fafdff 0%, #d8efff 100%);
}

.page.dark {
  .product-list {
    background: linear-gradient(359.07deg, #2d2d2d 63.38%, #27444f 102.27%);
  }
}
</style>
