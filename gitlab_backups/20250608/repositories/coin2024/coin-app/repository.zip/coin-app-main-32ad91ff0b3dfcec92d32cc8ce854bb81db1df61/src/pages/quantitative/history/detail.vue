<template>
  <app-navbar :title="$t('quantitative.historyDetails')" />
  <app-empty :no-data="list.length === 0">
    <view
      v-for="(item, index) in list"
      :key="index"
      class="p-30rpx m-30rpx bg-[var(--background-primary)] rd-20rpx"
    >
      <view class="flex items-center justify-between gap-10rpx">
        <view class="font-size-28rpx font-500">{{ item.symbol }}</view>
        <!-- <wd-icon custom-class="color-[var(--text-inactive)]" name="arrow-right" size="28rpx" /> -->
      </view>
      <view class="flex items-center gap-10rpx mt-16rpx">
        <view
          :class="item.direction === 0 ? 'bg-[var(--color-green)]' : 'bg-[var(--color-red)]'"
          class="h-30rpx px-6rpx lh-30rpx font-size-20rpx rd-5rpx color-#fff"
        >
          {{ item.direction === 0 ? $t('quantitative.long') : $t('quantitative.short') }}
        </view>
        <view
          class="h-30rpx px-6rpx lh-30rpx font-size-20rpx bg-[var(--background-gary-4)] rd-5rpx"
        >
          {{ item.lever }}X
        </view>
      </view>
      <!--  -->
      <view class="flex flex-col gap-30rpx mt-20rpx">
        <view class="flex items-center justify-between font-size-24rpx">
          <view class="color-[var(--text-inactive)]">
            {{ $t('quantitative.openPrice') }}
          </view>
          <view>{{ item.openPrice }}</view>
        </view>
        <view class="flex items-center justify-between font-size-24rpx">
          <view class="color-[var(--text-inactive)]">
            {{ $t('quantitative.closePrice') }}
          </view>
          <view>{{ item.closePrice }}</view>
        </view>
        <view class="flex items-center justify-between font-size-24rpx">
          <view class="color-[var(--text-inactive)]">
            {{ $t('quantitative.settledAmount') }}
          </view>
          <view>{{ item.amount }}</view>
        </view>
        <view class="flex items-center justify-between font-size-24rpx">
          <view class="color-[var(--text-inactive)]">
            {{ $t('quantitative.profit') }}
          </view>
          <view :class="item.profit >= 0 ? 'up-color' : 'down-color'">
            {{ item.profit }}({{ toFormatPercent(item.profitRate * 100) }})
          </view>
        </view>
        <!-- <view class="flex items-center justify-between font-size-24rpx">
          <view class="color-[var(--text-inactive)]">
            {{ $t('quantitative.settledTime') }}
          </view>
          <view>{{ formatDate(item.closeTime) }}</view>
        </view> -->
      </view>
    </view>
    <wd-loadmore :state="loadMoreState" />
  </app-empty>
</template>

<script lang="ts" setup>
import { fetchHistoryOrderDetail } from '@/service/quantitative'
import { formatDate } from '@/utils/day'
import { toFixed, toFormatPercent } from '@/utils/number'

const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
} = usePagination({
  api: (params) => {
    return fetchHistoryOrderDetail({
      size: params.pageSize,
      current: params.pageNo,
      projectRecordId: productId.value,
    })
  },
  params: {},
  onLoadMoreFn: onReachBottom,
  isInit: false,
})
const productId = ref('')

onLoad((options) => {
  productId.value = options.id
  getList()
})
</script>

<style lang="scss" scoped>
.page {
  background-color: var(--background-secondary);
}
</style>
