<template>
  <app-navbar :title="$t('safe.payPasswordPage.title')" left-arrow></app-navbar>
  <view class="p-30rpx">
    <wd-form custom-class="auth-form mt-30rpx" ref="form" :model="model">
      <view>
        <view class="name">
          {{ $t('safe.payPasswordPage.newPassword') }}
        </view>
        <wd-input
          prop="tradePwd"
          no-border
          clearable
          v-model="model.tradePwd"
          showPassword
          :placeholder="$t('safe.payPasswordPage.input.newPassword')"
          :rules="[
            {
              required: false,
              validator: validatorTradePwd,
              message: $t('safe.payPasswordPage.rules.newPassword'),
            },
          ]"
        ></wd-input>
      </view>
      <view>
        <view class="name">{{ $t('safe.payPasswordPage.confirmPassword') }}</view>
        <wd-input
          prop="tradePwd1"
          no-border
          clearable
          v-model="model.tradePwd1"
          showPassword
          :placeholder="$t('safe.payPasswordPage.input.confirmPassword')"
          :rules="[
            {
              required: false,
              validator: validatorTradePwd1,
              message: $t('safe.payPasswordPage.rule.confirmPassword'),
            },
          ]"
        ></wd-input>
      </view>
    </wd-form>
    <wd-button size="large" block @click="confirm">{{ $t('common.confirm') }}</wd-button>
    <wd-popup
      v-model="show"
      position="right"
      custom-style="width: 100vw;paddingTop: 30rpx;"
      @close="show = false"
      closable
    >
      <view class="popup">
        <view class="font-size-40rpx font-600">
          {{ $t('safe.payPasswordPage.securityVerification') }}
        </view>
        <view class="hint">
          {{ $t('safe.payPasswordPage.tips') }}
        </view>
        <wd-form custom-class="auth-form mt-30rpx" ref="form" :model="model">
          <view>
            <view class="popup__name">{{ $t('safe.payPasswordPage.loginPassword') }}</view>
            <wd-input
              prop="tradePwd"
              no-border
              clearable
              v-model="model.loginPwd"
              showPassword
            ></wd-input>
          </view>
        </wd-form>
        <view>
          <view class="popup__name flex">
            {{ $t('safe.payPasswordPage.emailVerification') }}

            <view class="countDown" @click="countDown">
              {{
                timeout
                  ? t('safe.payPasswordPage.sendTime', { time })
                  : $t('safe.payPasswordPage.sendCode')
              }}
            </view>
          </view>
          <!-- 密码输入框 -->
          <wd-password-input
            v-model="model.emailCode"
            :mask="false"
            :gutter="10"
            :length="6"
            :focused="showEmailCode"
            @focus="showEmailCode = true"
          />
          <!-- 数字键盘 -->
          <wd-number-keyboard
            v-model="model.emailCode"
            v-model:visible="showEmailCode"
            :maxlength="6"
            @close="showEmailCode = false"
          />
        </view>
        <view class="mt-30rpx">
          <view class="popup__name">{{ $t('safe.payPasswordPage.google') }}</view>
          <!-- 密码输入框 -->
          <wd-password-input
            v-model="model.totpCode"
            :mask="false"
            :gutter="10"
            :length="6"
            :focused="showTotpCode"
            @focus="showTotpCode = true"
          />
          <!-- 数字键盘 -->
          <wd-number-keyboard
            v-model="model.totpCode"
            v-model:visible="showTotpCode"
            :maxlength="6"
            @close="showTotpCode = false"
          />
        </view>
        <wd-button class="mt-60rpx" size="large" block :disabled="disabled" @click="affirm">
          {{ $t('common.confirm') }}
        </wd-button>
      </view>
    </wd-popup>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchSendEmail } from '@/service/base'
import { fetchTradePwd } from '@/service/user'
import { useUserStore } from '@/store'
const userStore = useUserStore()
const model = reactive({
  tradePwd: '',
  tradePwd1: '',
  loginPwd: '',
  emailCode: '',
  totpCode: '',
})
const show = ref(false)
const form = ref()
const showEmailCode = ref(false)
const showTotpCode = ref(false)
const time = ref(60)
const timeout = ref(null)
const validatorTradePwd = (val) => {
  return /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,18}$/.test(val)
}

const validatorTradePwd1 = (val) => {
  if (val !== model.tradePwd) {
    return Promise.reject(new Error('The two entered passwords do not match!'))
  } else {
    return Promise.resolve()
  }
}
const disabled = computed(() => {
  return !model.loginPwd || model.emailCode.length !== 6 || model.totpCode.length !== 6
})
const confirm = () => {
  form.value.validate().then(({ valid, errors }) => {
    if (valid) {
      show.value = true
    }
  })
}
const affirm = () => {
  fetchTradePwd(model).then((res) => {
    console.log(res)
    uni.showToast({
      title: t('common.success'),
      icon: 'none',
      success: function () {
        uni.navigateBack()
      },
    })
  })
}

const countDown = () => {
  if (timeout.value) return
  uni.showLoading()
  fetchSendEmail({
    type: 4,
    email: userStore.userInfo.email,
  })
    .then((res) => {
      timeout.value = setInterval(() => {
        time.value -= 1
        if (time.value === 0) {
          clearInterval(timeout.value)
          timeout.value = null
          time.value = 60
        }
      }, 1000)
    })
    .finally(() => {
      uni.hideLoading()
    })
}
</script>

<style lang="scss" scoped>
:deep(.wd-password-input__item) {
  background: var(--background-tertiary) !important;
  border: 1px solid var(--border-color);
  border-radius: 10rpx !important;
}
.name {
  margin-bottom: 30rpx;
  font-size: 24rpx;
  color: var(--text-primary);
}
.popup {
  padding: 60rpx;
  .hint {
    margin: 30rpx 0;
    font-size: 22rpx;
    color: var(--text-secondary);
  }
  &__name {
    margin-bottom: 30rpx;
    font-size: 24rpx;
    color: var(--text-primary);
  }
}
.flex {
  display: flex;
  justify-content: space-between;
  .countDown {
    font-weight: 500;
    color: var(--color-primary);
  }
}
</style>
