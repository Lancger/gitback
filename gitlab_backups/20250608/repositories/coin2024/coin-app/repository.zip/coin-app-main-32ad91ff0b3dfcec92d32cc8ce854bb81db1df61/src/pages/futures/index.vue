<route lang="json5" type="page">
{
  layout: 'tabbar',
}
</route>

<template>
  <view class="header">
    <wd-tabs
      custom-class="app-tabs app-tabs--no-flex-1 app-tabs--large"
      v-model="tabIndex"
      swipeable
      animated
      :map-num="100"
      @click="onTabChange"
    >
      <block v-for="(item, index) in tab" :key="index">
        <wd-tab :title="$t(item)"></wd-tab>
      </block>
    </wd-tabs>
  </view>
  <view class="h-88rpx"></view>
  <KeepAlive>
    <component :is="tabIndex === 0 ? tradeFutures : tradeOption"></component>
  </KeepAlive>
</template>

<script lang="ts" setup>
import tradeFutures from './components/trade-futures.vue'
import tradeOption from './components/trade-option.vue'
import { onRouter } from '@/utils'

const tab = ref(['futures.tabs.futures', 'futures.tabs.options', 'Copy', 'OptionsV2'])
const tabIndex = ref(0)

function onTabChange({ index }) {
  console.log(index)
  // tabIndex.value = index
  if (index === 3) {
    onRouter('/pages/optionV2/index')
    nextTick(() => {
      tabIndex.value = 0
    })
  }
  if (index === 2) {
    onRouter('/pages/copy/index')
    nextTick(() => {
      tabIndex.value = 0
    })
  }
}
</script>

<style lang="scss" scoped>
.header {
  position: fixed;
  top: 0;
  z-index: 50;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  width: 100%;
  padding: 0 30rpx 0 0;
  background: var(--background-secondary);
}
.page {
  background: var(--background-secondary);
}
.page.blue {
  .header {
    background: var(--color-primary);
    :deep(.wd-tabs__line) {
      display: none;
    }
    :deep(.wd-tabs__nav-item) {
      color: var(--text-primary) !important;
    }
    :deep(.wd-tabs__nav-item.is-active) {
      color: var(--color-white) !important;
    }
  }
}
</style>
