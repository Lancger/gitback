import { http } from '@/utils/http'

// 活期币种列表
export const fetchFlexibleList = (data) => {
  return http.post('/api/mjkj-web/coin/wealth/wealth/cbsx/hlist', data)
}

// 活期持仓列表
export const fetchFlexiblePositionList = (data = {}) => {
  return http.post('/api/mjkj-web/coin/wealth/wealth/cbsx/holdlist', data)
}

// 活期币种详情
export const fetchFlexibleItemDetail = (coinId) => {
  return http.post('/api/mjkj-web/coin/wealth/wealth/cbsx/hInfo', { coinId })
}

// 活期申购
export const fetchFlexibleSubmit = (data) => {
  return http.post('/api/mjkj-web/coin/wealth/wealth/cbsx/cbuy', data)
}

// 活期申购历史
export const fetchFlexibleHistory = (data) => {
  return http.post('/api/mjkj-web/coin/wealth/wealth/cbsx/histlist', data)
}

// 活期持仓详情
export const fetchFlexiblePositionDetail = (coinId) => {
  return http.post('/api/mjkj-web/coin/wealth/wealth/cbsx/hRedeem', { coinId })
}

// 活期持仓赎回
export const fetchFlexibleRedeem = (data) => {
  return http.post('/api/mjkj-web/coin/wealth/wealth/cbsx/cunlock', data)
}

// 定期币种列表
export const fetchFixedList = (params) => {
  return http.get('/api/mjkj-web/coin/open/wealth/cbsx/now', params)
}

// 定期币种详情
export const fetchFixedItemDetail = (goodsId) => {
  return http.get('/api/mjkj-web/coin/open/wealth/cbsx/goodsInfo', { goodsId })
}

// 定期申购历史
export const fetchFixedHistory = (data) => {
  return http.post('/api/mjkj-web/coin/wealth/getWealthCbjlList', data)
}

// 定期币种项目历史
export const fetchFixedPastHistory = () => {
  return http.get('/api/mjkj-web/coin/open/wealth/cbsx/history')
}

// 定期申购
export const fetchFixedSubmit = (data: any) => {
  return http.post('/api/mjkj-web/coin/wealth/wealth/cbsx/buy', data)
}

// 获取钱包余额
export const fetchWallet = (token) => {
  return http.get(`/api/mjkj-web/coin/wallet/get/wealth/${token}`)
}

// 获取活期利率图表
export const fetchFlexibleRateChart = (params) => {
  return http.get('/api/mjkj-web/coin/wealth/wealth/getYieldChart', params)
}
