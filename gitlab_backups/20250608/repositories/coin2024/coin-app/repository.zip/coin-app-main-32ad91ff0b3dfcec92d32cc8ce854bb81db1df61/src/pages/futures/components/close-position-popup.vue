<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    closable
    :zIndex="999"
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="px-30rpx pt-30rpx">
      <view class="font-size-32rpx font-500 text-center">
        {{ $t('futures.index.closePositionPopup.title') }}
      </view>
      <view class="pt-50rpx pb-30rpx b-b">
        <view class="flex items-center">
          <view class="font-size-30rpx font-500">{{ rowData.symbol_name }}</view>
          <view class="tag-list">
            <view class="tag-list__item">
              {{ $t('futures.index.closePositionPopup.futures') }}
            </view>
            <view :class="[rowData.direction === 1 ? 'buy' : 'sell']" class="tag-list__item">
              {{ rowData.direction === 1 ? $t('futures.index.long') : $t('futures.index.short') }}
            </view>
            <view class="tag-list__item brand">{{ rowData.leverage }}</view>
          </view>
        </view>
        <view class="flex items-end justify-between mt-20rpx">
          <view class="flex gap-10rpx font-size-22rpx">
            <view class="color-[var(--text-active)]">
              {{ $t('futures.index.closePositionPopup.lastPrice') }}
            </view>
            <view>{{ toFormat(rowData.closePrice) }} USDT</view>
          </view>
          <view class="flex items-end gap-10rpx font-size-22rpx">
            <view class="color-[var(--text-active)]">
              {{ $t('futures.index.closePositionPopup.pl') }}
            </view>
            <view
              :class="[rowData.pl > 0 ? 'up-color' : 'down-color']"
              class="font-size-30rpx font-500"
            >
              {{ rowData.pl > 0 ? '+' : null }}{{ rowData.pl }}
            </view>
            <view :class="[rowData.pl > 0 ? 'up-color' : 'down-color']" class="font-size-20rpx">
              {{ rowData.plRatio }}
            </view>
          </view>
        </view>
      </view>
      <view class="flex flex-col gap-20rpx py-40rpx">
        <view class="flex items-center">
          <view class="w-130rpx font-size-28rpx color-[var(--text-active)]">
            {{ $t('futures.index.closePositionPopup.type') }}
          </view>
          <view class="flex-1 flex items-center gap-30rpx">
            <wd-button
              v-for="(item, index) in modeList"
              :key="index"
              :type="modeIndex === index ? 'primary' : 'info'"
              :plain="false"
              hairline
              :round="false"
              custom-class="flex-1"
              @click="modeIndex = index"
            >
              {{ $t(item.label) }}
            </wd-button>
          </view>
        </view>
        <view class="flex items-center">
          <view class="w-130rpx font-size-28rpx color-[var(--text-active)]">
            {{ $t('futures.index.closePositionPopup.price') }}
          </view>
          <view
            v-if="modeIndex === 0"
            class="flex-1 h-72rpx font-size-26rpx font-500 line-height-72rpx text-center color-[var(--text-inactive)] rounded-10rpx bg-[var(--background-gary-4)]"
          >
            {{ $t('futures.index.closePositionPopup.marketPrice') }}
          </view>
          <app-input
            v-else
            v-model="limitPrice"
            :placeholder="$t('futures.index.closePositionPopup.limitPrice')"
            :isPlaceholderTop="false"
            :formatter="(value) => inputLimitToDigit(value, BNumber(rowData.closePrice).dp())"
            custom-class="flex-1"
          ></app-input>
        </view>
        <view class="flex items-center">
          <view class="w-130rpx font-size-28rpx color-[var(--text-active)]">
            {{ $t('futures.index.closePositionPopup.volume') }}
          </view>
          <app-input
            v-model="amount"
            :placeholder="$t('futures.index.closePositionPopup.volume')"
            :isPlaceholderTop="false"
            :formatter="(value) => inputLimitToDigit(value, BNumber(rowData.balance).dp())"
            custom-class="flex-1"
            @update:model-value="onInput"
          ></app-input>
        </view>
        <view class="pl-130rpx">
          <view class="flex items-center justify-between font-size-22rpx">
            <view class="color-[var(--text-active)]">
              {{ $t('futures.index.closePositionPopup.volume') }}
            </view>
            <view>
              {{ toFormat(rowData.balance) }}
              {{ futuresConfig.unit === 'u' ? rowData.balance_symbol : futuresConfig.unitLabel }}
            </view>
          </view>
          <view class="flex items-center justify-between mt-10rpx font-size-22rpx">
            <view class="color-[var(--text-active)]">
              {{ $t('futures.index.closePositionPopup.margin') }}
            </view>
            <view>{{ toFormat(rowData.principal_amount) }} USDT</view>
          </view>
          <view class="px-10rpx mt-20rpx">
            <app-slider v-model="sliderVal" @update:model-value="onSlider"></app-slider>
          </view>
        </view>
      </view>
    </view>
    <view class="footer">
      <wd-button size="large" block :loading="loading" @click="onSubmit">
        {{ $t('common.confirm') }}
      </wd-button>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { useUserStore, useTradeStore } from '@/store'
import { BNumber, inputLimitToDigit, toFormat } from '@/utils/number'
import { fetchPlaceOrder } from '@/service/futures'

const { onExchangeRateConversion } = useUserStore()
const { futuresConfig } = useTradeStore()

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  rowData: {
    type: Object,
    default: () => ({}),
  },
})

const emits = defineEmits(['update:modelValue', 'onCallback'])

const modeList = [
  {
    label: 'futures.index.closePositionPopup.marketPrice',
    value: 0,
  },
  {
    label: 'futures.index.closePositionPopup.limitPrice',
    value: 1,
  },
]
const modeIndex = ref(0)
const limitPrice = ref(null)
const amount = ref(null)
const sliderVal = ref(100)

watch(
  () => props.modelValue,
  (newValue, oldValue) => {
    sliderVal.value = 100
    limitPrice.value = props.rowData.closePrice
    amount.value = Number(BNumber(props.rowData.balance).times(sliderVal.value / 100))
  },
)

const onSlider = (val) => {
  amount.value =
    futuresConfig.unit === 'u'
      ? Number(BNumber(props.rowData.balance).times(val / 100))
      : Math.floor(Number(BNumber(props.rowData.balance).times(val / 100)))
}

const onInput = (val = 0) => {
  if (+val > +props.rowData.balance) {
    nextTick(() => {
      amount.value = props.rowData.balance
      sliderVal.value = 100
    })
    return
  }
  sliderVal.value = Number(BNumber(+val).div(props.rowData.balance).times(100))
}

const loading = ref(false)
async function onSubmit() {
  loading.value = true
  try {
    await fetchPlaceOrder(`close/${modeIndex.value === 0 ? 'quick' : 'ptwt'}`, {
      exchangeCoinStr: props.rowData.symbol_name,
      price: modeIndex.value === 0 ? props.rowData.avg_price : limitPrice.value, // 委托价
      amount: amount.value, // 数量
      // 3=平仓-平多 4=平仓-平空
      direction: props.rowData.direction === 1 ? 3 : 4, // 方向
      pattern: props.rowData.pattern, // 逐仓=1，全仓=2
      patternType: props.rowData.pattern_type, // 并仓=1，分仓=2
      contractType: props.rowData.contract_type, // 合约类型
      closeLogContractOrderCode: props.rowData.order_code, // 合约code
    })
    onClose()
    emits('onCallback')
    loading.value = false
  } catch (e) {
    onClose()
    loading.value = false
  }
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.tag-list {
  position: relative;
  display: flex;
  gap: 10rpx;
  align-items: center;
  padding-left: 10rpx;
  margin-left: 10rpx;
  &::after {
    position: absolute;
    top: 50%;
    left: 0;
    width: 1px;
    height: 24rpx;
    content: '';
    background: var(--border-color);
    transform: translateY(-50%);
  }
  &__item {
    height: 30rpx;
    padding: 0 14rpx;
    font-size: 20rpx;
    line-height: 30rpx;
    background: var(--background-gary-4);
    border-radius: 5rpx;
  }
  &__item.buy {
    color: var(--color-green);
    background: #07ba831a;
  }
  &__item.sell {
    color: var(--color-red);
    background: #ff4e431a;
  }
  &__item.brand {
    color: var(--color-primary);
    background: rgba(0, 167, 237, 0.1);
  }
}
.footer {
  padding: 20rpx 30rpx;
  box-shadow: var(--box-shadow);
}
</style>
