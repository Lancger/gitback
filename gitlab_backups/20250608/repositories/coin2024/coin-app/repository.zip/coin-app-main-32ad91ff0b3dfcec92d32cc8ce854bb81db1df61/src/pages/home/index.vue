<route lang="json5" type="home">
{
  layout: 'tabbar',
}
</route>

<template>
  <view class="header flex items-center flex-justify-between px-30rpx py-20rpx">
    <image
      v-if="userStore.userInfo.avatar"
      class="w-68rpx h-68rpx rd-50%"
      :src="userStore.userInfo.avatar"
      mode="scaleToFill"
      @click="onRouter('/pages/user/index')"
    />
    <image
      v-else
      class="w-68rpx h-68rpx rd-50%"
      src="@img/avatar.png"
      mode="scaleToFill"
      @click="onRouter('/pages/user/index')"
    />
    <view class="flex items-center gap-20rpx">
      <image
        class="w-45rpx h-45rpx"
        :src="onImageToThemeImage('/static/images/icons/search.png')"
        @click="onRouter('/pages/search/index')"
      />
      <wd-badge :is-dot="unreadMessageCount > 0">
        <image
          class="w-45rpx h-45rpx"
          :src="onImageToThemeImage('/static/images/icons/notify.png')"
          @click="onRouter('/pages/message/notify')"
        />
      </wd-badge>
      <image
        class="w-45rpx h-45rpx"
        :src="onImageToThemeImage('/static/images/icons/service.png')"
        @click="onService()"
      />
    </view>
  </view>
  <view class="flex flex-items-center flex-justify-between px-30rpx mt-110rpx">
    <image
      class="w-335rpx h-306rpx block"
      :src="onImageToThemeImage('/static/images/home/deposit.png')"
      @click="onRouter('/pages/asset/deposit/index')"
    />
    <view class="w-334rpx">
      <image
        class="w-334rpx h-143rpx"
        :src="onImageToThemeImage('/static/images/home/bank-card.png')"
        @click="onRouter('/pages/home/express/index')"
      />
      <image
        class="w-334rpx h-143rpx mt-20rpx"
        @click="onRouter('/pages/home/ctwoc/index')"
        :src="onImageToThemeImage('/static/images/home/c2c.png')"
      />
    </view>
  </view>
  <!-- Notice -->
  <view v-if="noticeData.length > 0" class="notice-box" @click="onRouter('/pages/message/notice')">
    <image class="w-32rpx h-32rpx" :src="onImageToThemeImage('/static/images/icons/notice.png')" />
    <swiper class="notice-box__content" autoplay circular vertical :interval="3000">
      <swiper-item v-for="(item, index) in noticeData" :key="index">
        <!-- @click="onRouter(`/pages/news/details?id=${item.id}`)" -->
        <view class="notice-text">
          {{ item.article_title }}
        </view>
      </swiper-item>
    </swiper>
    <wd-icon custom-class="color-[var(--arrow-color)]" name="arrow-right" size="32rpx"></wd-icon>
  </view>
  <!-- banner -->
  <wd-skeleton
    v-if="swiperList.length > 0"
    :loading="swiperList.length === 0"
    animation="flashed"
    :row-col="[{ height: '260rpx', borderRadius: '20rpx' }]"
    class="m-30rpx"
  >
    <wd-swiper
      custom-image-class="!h-260rpx"
      value-key="img"
      :list="swiperList"
      :indicator="false"
      autoplay
    ></wd-swiper>
  </wd-skeleton>
  <!-- NavList -->
  <wd-grid custom-class="mx-30rpx my-20rpx rd-20rpx" :column="4">
    <wd-grid-item
      v-for="(item, index) in navList"
      :key="index"
      custom-class="font-500"
      icon-size="82rpx"
      :text="t(item.title)"
      use-icon-slot
      @click="onNavEvent(item)"
    >
      <template #icon>
        <image class="w-82rpx h-82rpx" :src="onImageToThemeImage(item.icon)" />
      </template>
    </wd-grid-item>
  </wd-grid>
  <!-- swiper -->
  <wd-skeleton
    :loading="recommendList.length === 0"
    animation="flashed"
    :row-col="[
      [
        {
          width: '30%',
          height: '280rpx',
          borderRadius: '20rpx',
          margin: '20rpx 0 0 30rpx',
        },
        { width: '30%', height: '280rpx', borderRadius: '20rpx', margin: '20rpx 0 0 20rpx' },
        { width: '30%', height: '280rpx', borderRadius: '20rpx', margin: '20rpx 0 0 20rpx' },
      ],
    ]"
  >
    <view class="product-swiper">
      <swiper class="product-swiper__main" circular>
        <swiper-item v-for="(arr, i) in recommendList" :key="i">
          <view class="flex gap-20rpx px-30rpx">
            <view
              v-for="(item, index) in arr"
              :key="index"
              class="product-swiper__item"
              @click="onRouter(`/pages/market/detail?symbol=${item.symbolName}&type=xh`)"
            >
              <image class="product-swiper__item__cover" :src="item.bzicon" mode="scaleToFill" />
              <view class="product-swiper__item__name">{{ item.symbolName.split('/')[0] }}</view>
              <view class="product-swiper__item__price">
                {{ toFormat(item.close, item.baseCoinScale) }}
              </view>
              <view
                :class="[item.zdf >= 0 ? 'up-color' : 'down-color']"
                class="product-swiper__item__rate"
              >
                {{ item.zdf > 0 ? '+' : '' }}{{ toFormatPercent(item.zdf) }}
              </view>
            </view>
          </view>
        </swiper-item>
      </swiper>
    </view>
  </wd-skeleton>
  <!-- product -->
  <wd-tabs
    custom-class="app-tabs"
    :model-value="1"
    swipeable
    animated
    :map-num="100"
    :offset-top="-44"
    :sticky="false"
  >
    <block v-for="(item, index) in productData" :key="index">
      <wd-tab :title="t(item.name)">
        <product-list
          :hideCurrency="index !== 0"
          :list="item.list"
          @click="onRouter(`/pages/market/detail?symbol=${$event.symbolName}&type=xh`)"
        ></product-list>
        <view class="center py-20rpx" @click="onRouter('/pages/market/index', 'switchTab')">
          <view class="mr-10rpx font-size-22rpx color-[var(--text-inactive)]">
            {{ t('home.more') }}
          </view>
          <wd-icon
            custom-class="color-[var(--text-inactive)]"
            name="arrow-down"
            size="22rpx"
          ></wd-icon>
        </view>
      </wd-tab>
    </block>
  </wd-tabs>
  <!-- News -->
  <wd-tabs custom-class="app-tabs news-tab" v-model="tab" swipeable animated :map-num="100">
    <wd-tab :title="t('home.news')">
      <news-list :list="newsData"></news-list>
      <view
        class="flex items-center justify-center gap-10rpx p-20rpx m-30rpx border-solid border-[var(--border-color)] bg-[var(--background-primary)] rd-10rpx"
        @click="onLoadMoreNews"
      >
        <view class="font-size-26rpx font-500 color-[var(--color-primary)]">
          {{ $t('home.more') }}
        </view>
        <wd-loading v-if="newsLoading" size="32rpx" />
        <wd-icon
          v-else
          custom-class="mt-8rpx color-[var(--color-primary)]"
          name="arrow-down"
          size="32rpx"
        ></wd-icon>
      </view>
      <!-- <wd-loadmore :state="loadMoreState" /> -->
    </wd-tab>
  </wd-tabs>

  <!-- notice popup -->
  <notice-popup
    v-model="showNotice"
    :data="noticePopupData"
    @onClose="userStore.noticePopupIdMap[noticePopupData.article_lang] = noticePopupData.id"
  ></notice-popup>
</template>

<script lang="ts" setup>
import _ from 'lodash'
import { t } from '@/locale'
import { useSystemStore, useUserStore } from '@/store'
import usePagination from '@/hooks/usePagination'
import { onImageToThemeImage, onRouter } from '@/utils'
import { toFixed, toFormat, toFormatPercent } from '@/utils/number'
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'
import { fetchBanner, fetchWatchList, fetchNotice, fetchNews } from '@/service/home'
import { fetchMarketData } from '@/service/market'
import { fetchFormData } from '@/service/base'
import { fetchUnreadMessageCount } from '@/service/message'
import config from '@/config'

const newsParams = reactive({
  article_type: '1530429800596701185',
  article_issue: 1,
  pageSize: 12,
  pageNo: 1,
  article_lang: uni.getLocale() === 'zh-Hant' ? 'zh_tW' : uni.getLocale(),
  column: 'id',
  order: 'desc',
})
const {
  data: newsData,
  loadMoreState,
  loading: newsLoading,
  onInit: getNewsList,
  onLoadMore: onNewsLoad,
} = usePagination({
  api: (params) => {
    return fetchNews({
      pageSize: params.pageSize,
      pageNo: params.pageNo,
    })
  },
  params: newsParams,
})

const { onService, serverTime, getServerTime } = useSystemStore()
const userStore = useUserStore()

const swiperList = ref<any>([])
const navList = ref([
  {
    title: 'home.grid.ico',
    icon: '/static/images/home/ico_icon.png',
    url: '/pages/ico/index',
    type: 1,
  },
  {
    title: 'home.grid.spot',
    icon: '/static/images/home/spot_icon.png',
    url: '/pages/trade/index',
    type: 2,
  },
  {
    title: 'home.grid.futures',
    icon: '/static/images/home/futures_icon.png',
    url: '/pages/futures/index',
    type: 2,
  },
  {
    title: 'home.grid.express',
    icon: '/static/images/home/express_icon.png',
    url: '/pages/home/express/index',
    type: 1,
  },
  {
    title: 'home.grid.withdrawal',
    icon: '/static/images/home/withdrawal_icon.png',
    url: '/pages/asset/withdraw/index',
    type: 1,
  },
  {
    title: 'home.grid.deposit',
    icon: '/static/images/home/deposit_icon.png',
    url: '/pages/asset/deposit/index',
    type: 1,
  },
  {
    title: 'home.grid.earn',
    icon: '/static/images/home/earn_icon.png',
    url: '/pages/earn/index',
    type: 1,
  },
  {
    title: 'home.grid.safe',
    icon: '/static/images/home/security_icon.png',
    url: '/pages/user/security/index',
    type: 1,
  },
])
const tab = ref<number>(0)
const productData = reactive<any>([
  {
    name: 'home.tabs.watch',
    key: 'watch',
    list: [],
  },
  {
    name: 'home.tabs.hot',
    key: 'hot',
    list: [],
  },
  {
    name: 'home.tabs.gainers',
    key: 'zfb',
    list: [],
  },
  {
    name: 'home.tabs.top',
    key: 'zlb',
    list: [],
  },
  {
    name: 'home.tabs.turnover',
    key: 'cjeb',
    list: [],
  },
  {
    name: 'home.tabs.new',
    key: 'xbb',
    list: [],
  },
  {
    name: 'home.tabs.deFi',
    key: 'defi',
    list: [],
  },
  {
    name: 'home.tabs.gameFi',
    key: 'gamefi',
    list: [],
  },
])
const recommendList = ref([])
const noticeData = ref<any>([])

const subMap = {
  all_symbol_detail: onSubAllFun,
}
const showNotice = ref(false)
const noticePopupData = ref<any>({})

uni.onLocaleChange((res) => {
  getNewsList()
  getBanner()
})

getBanner()
uni.$on('message', onMessage)

onShow(async () => {
  // 获取服务器时间
  getServerTime()
  await getMarket()
  getNotice()
  if (userStore.isLogined) {
    getWatchList()
    getUnreadMessageCount()
  }
  onSubscribe(getSubTopic())
})

// onHide(() => {
//   onUnsubscribe(Object.keys(subMap))
//   uni.$off('message', onMessage)
// })

onUnload(() => {
  onUnsubscribe(getSubTopic())
  uni.$off('message', onMessage)
})

const unreadMessageCount = ref(0)
function getUnreadMessageCount() {
  return fetchUnreadMessageCount(userStore.userInfo.id).then((res) => {
    unreadMessageCount.value = +res.data.count
  })
}

function getSubTopic() {
  if (subscribeMode === 'mqtt') {
    return Object.keys(subMap)
  } else {
    return productData
      .map((item) => item.list)
      .flat(Infinity)
      .filter((item) => Boolean(item.subText))
      .map((item) => `ws.market.CSPOT.${item.subText}.1`)
  }
}

function onMessage(msgData) {
  const [topic, data] = msgData
  if (subMap[topic] && subscribeMode === 'mqtt') {
    subMap[topic](data)
    return
  }

  if (topic.indexOf('market') !== -1) {
    onUpdate(data)
  }
}

function onLoadMoreNews() {
  if (newsLoading.value) return
  onNewsLoad()
}

function onSubAllFun(data) {
  if (data.type !== 'xh') return
  onUpdate(data)
}

function onUpdate(data) {
  productData.forEach((item) => {
    item.list.forEach((v) => {
      if (v.symbolName === data.symbolName) {
        v.close = data.close
        v.zdf = data.zdf
        return
      }

      if (v.subText === data.symbol && subscribeMode === 'ws') {
        v.close = data.close
        v.zdf = data.zdf
      }
    })
  })
}

const onNavEvent = (e) => {
  switch (e.type) {
    case 2:
      onRouter(e.url, 'switchTab')
      break
    default:
      onRouter(e.url)
  }
}

function getBanner() {
  return fetchBanner({
    clientType: 1,
    type: 1,
  }).then((res) => {
    swiperList.value = res.data.map((item) => item.img)
  })
}

function getNotice() {
  // return fetchFormData('1530431184536666113', {
  //   article_type: '1530429499214987266',
  //   // article_recommend: 1,
  //   article_issue: 1,
  //   pageNo: 1,
  //   pageSize: 5,
  //   article_lang: 'en',
  // }).then((res) => {
  //   noticeData.value = res.data.records
  // })
  return fetchNotice({
    current: 1,
    size: 20,
  }).then((res) => {
    noticeData.value = res.data.records.filter((item) => item.type === 1 || item.type === 2)
    // 弹窗公告
    const [noticeFirst] = res.data.records.filter((item) => item.type === 0 || item.type === 2)
    if (noticeFirst && noticeFirst.id !== userStore.noticePopupIdMap[noticeFirst.article_lang]) {
      noticePopupData.value = {
        ...noticeFirst,
        title: noticeFirst.article_title,
        content: noticeFirst.article_content,
        date: noticeFirst.release_time,
      }
      showNotice.value = true
    }
  })
}

function getMarket() {
  return fetchMarketData({
    type: 'index',
  }).then((res) => {
    productData.forEach((item, index) => {
      productData[index].list = res.data[item.key] || []
    })
    recommendList.value = _.chunk(res.data.zlb, 3)
  })
}

function getWatchList() {
  return fetchWatchList().then((res) => {
    productData[0].list = res.data.filter((item) => item.optional === 'xh')
  })
}
</script>

<style lang="scss" scoped>
.header {
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 10;
  box-sizing: border-box;
  background: var(--background-secondary) var(--background-linear-gradient-1) no-repeat;
  background-size: 100% 744rpx;
}
.wd-swiper {
  height: 260rpx;
  // margin: 20rpx 30rpx;
  background: var(--background-primary);
  border-radius: 30rpx;
}
:deep(.wd-swiper__track) {
  height: 100% !important;
}
.news-tab {
  :deep(.wd-tabs__nav-item) {
    flex: none !important;
    padding: 0 30rpx !important;
  }
}
.product-swiper {
  height: 256rpx;
  margin: 20rpx 0;
  /* stylelint-disable-next-line selector-type-no-unknown */
  // :deep(uni-swiper-item) {
  //   width: 220rpx !important;
  // }
  &__item {
    box-sizing: border-box;
    width: calc(33.33% - 10rpx);
    height: 256rpx;
    padding: 30rpx 10rpx 0;
    text-align: center;
    background: var(--background-primary);
    border-radius: 16rpx;
    &__cover {
      display: block;
      width: 50rpx;
      height: 50rpx;
      margin: auto;
      border-radius: 50%;
    }
    &__name {
      margin-top: 16rpx;
      color: var(--text-inactive);
    }
    &__price {
      margin-top: 20rpx;
      font-size: 30rpx;
      font-weight: 500;
    }
    &__rate {
      margin-top: 20rpx;
      font-size: 28rpx;
      font-weight: 500;
    }
  }
}
.notice-box {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  padding: 0 16rpx;
  margin: 20rpx 30rpx;
  font-size: 22rpx;
  font-weight: 500;
  color: var(--text-active) !important;
  background: var(--background-primary) !important;
  border: 1px solid var(--border-color);
  border-radius: 16rpx;
  &__content {
    flex: 1;
    height: 70rpx;
    padding: 0 16rpx;
    .notice-text {
      overflow: hidden;
      font-size: 22rpx;
      line-height: 68rpx;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
}
.page {
  background: var(--background-secondary) var(--background-linear-gradient-1) no-repeat;
  background-size: 100% 744rpx;
}

.page.dark {
  background: var(--background-primary) var(--background-linear-gradient-3) no-repeat;
  background-size: 100% 744rpx;

  .header {
    background: var(--background-primary) var(--background-linear-gradient-1) no-repeat;
    background-size: 100% 744rpx;
  }

  .notice-box {
    background: var(--background-secondary) !important;
  }

  .product-swiper__item {
    background: var(--background-secondary);
  }

  :deep(.news-list__item) {
    background: var(--background-secondary);
  }

  :deep(.product-list__item) {
    background: var(--background-secondary);
  }
}
</style>
