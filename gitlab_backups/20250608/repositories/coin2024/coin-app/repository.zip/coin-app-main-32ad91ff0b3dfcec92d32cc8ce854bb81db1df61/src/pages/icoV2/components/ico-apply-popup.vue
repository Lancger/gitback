<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    closable
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="px-30rpx pt-76rpx pb-100rpx">
      <view class="font-size-30rpx font-500">{{ $t('icoV2.apply.title') }}</view>
      <image class="w-316rpx h-90rpx block mx-auto my-60rpx" src="@img/ico/apply_icon.png" />
      <view class="text-center font-500">{{ $t('icoV2.apply.p1') }}</view>
      <view class="text-center mt-30rpx">{{ $t('icoV2.apply.p2') }}</view>
    </view>

    <view class="footer">
      <wd-button size="large" block :loading="loading" @click="onSubmit">
        {{ $t('common.submit') }}
      </wd-button>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchIcoPlacingApply } from '@/service/ico'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['update:modelValue'])

const loading = ref(false)

async function onSubmit() {
  loading.value = true
  try {
    await fetchIcoPlacingApply()
    uni.showToast({
      title: t('icoV2.apply.applicationSubmitted'),
      icon: 'none',
    })
    onClose()
    loading.value = false
  } catch (e) {
    onClose()
    loading.value = false
  }
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.footer {
  padding: 20rpx 30rpx;
  box-shadow: var(--box-shadow);
}
</style>
