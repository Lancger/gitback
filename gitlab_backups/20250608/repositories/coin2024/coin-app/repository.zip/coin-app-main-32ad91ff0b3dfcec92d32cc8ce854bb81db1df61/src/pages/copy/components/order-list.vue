<template>
  <view
    v-for="(item, index) in list"
    :key="index"
    :class="{ 'b-b': index !== 0 }"
    class="mx-30rpx py-30rpx"
  >
    <view class="flex items-center justify-between" @click="handleClick(item)">
      <view class="flex items-center gap-20rpx">
        <image
          class="w-70rpx h-70rpx rd-50%"
          :src="item.project.avatar || '/static/images/avatar.png'"
          mode="scaleToFill"
        />
        <view>
          <view class="font-size-28rpx font-500">{{ item.project.nickname }}</view>
          <view
            v-if="item.state === 0"
            class="mt-10rpx font-size-20rpx color-[var(--text-inactive)]"
          >
            {{ $t('copy.followTime') }}: {{ formatDate(item.create_time) }}
          </view>
          <view v-else class="mt-10rpx font-size-20rpx color-[var(--text-inactive)]">
            {{ formatDate(item.create_time) }} - {{ formatDate(item.close_time) }}
          </view>
        </view>
      </view>
      <wd-icon
        v-if="isTap"
        custom-class="color-[var(--text-inactive)]"
        name="arrow-right"
        size="30rpx"
      ></wd-icon>
    </view>
    <!--  -->
    <view v-if="item.state === 0" class="flex flex-wrap gap-y-26rpx mt-40rpx">
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.netFollowTradeAmount') }}
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(item.amount, true) }}</view>
      </view>
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.margin') }} (USDT)
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(item.amount, true) }}</view>
      </view>
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.realizedPnl') }} (USDT)
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(item.profit, true) }}</view>
      </view>
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.unrealizedPnl') }} (USDT)
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(item.profit, true) }}</view>
      </view>
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.profitShareAmount') }} (USDT)
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(0, true) }}</view>
      </view>
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.netProfit') }} (USDT)
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(item.profit, true) }}</view>
      </view>
      <!-- <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">Profit share ratio</view>
        <view class="font-500 mt-20rpx">12%</view>
      </view> -->
    </view>
    <view v-if="item.state === 2" class="flex flex-wrap gap-y-26rpx mt-40rpx">
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.netFollowTradeAmount') }}
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(item.amount, true) }}</view>
      </view>
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.pnl') }} (USDT)
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(item.profit, true) }}</view>
      </view>
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.profitShareAmount') }} (USDT)
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(0, true) }}</view>
      </view>
      <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.netProfit') }} (USDT)
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(item.profit, true) }}</view>
      </view>
      <!-- <view class="w-50%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">Profit share ratio</view>
        <view class="font-500 mt-20rpx">12%</view>
      </view> -->
    </view>
    <view v-if="item.state === 2" class="font-size-20rpx color-[var(--text-inactive)] mt-30rpx">
      {{ $t('copy.closureReason') }}
    </view>
    <view v-if="showBtns && item.state === 0" class="flex items-center gap-20rpx mt-30rpx">
      <wd-button custom-class="flex-1 !rd-10rpx" block @click="handleClose(item)">
        {{ $t('copy.endFollow') }}
      </wd-button>
    </view>
  </view>

  <app-dialog
    v-model="showDialog"
    :title="$t('copy.endFollow')"
    :content="$t('copy.endFollowContent')"
    :loading="loading"
    @onConfirm="onSubmit"
  ></app-dialog>
</template>

<script lang="ts" setup>
import { toFormat } from '@/utils/number'
import { fetchCloseOrder } from '@/service/copy'
import { formatDate } from '@/utils/day'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  showBtns: {
    type: Boolean,
    default: false,
  },
  isTap: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['click', 'onEnd'])

const showDialog = ref(false)
const loading = ref(false)
const rowData = ref<any>({})

const onSubmit = async () => {
  loading.value = true
  try {
    await fetchCloseOrder({
      id: rowData.value.id,
    })
    loading.value = false
    emits('onEnd')
  } catch (error) {
    loading.value = false
  }
}

const handleClose = (item) => {
  showDialog.value = true
  rowData.value = item
}

const handleClick = (item) => {
  if (props.isTap) {
    emits('click', item)
  }
}
</script>

<style lang="scss" scoped>
//
</style>
