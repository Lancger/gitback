<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    closable
    :zIndex="999"
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="px-30rpx pt-30rpx">
      <view class="font-size-30rpx font-500 text-center">Quick Close</view>
      <view class="flex items-center justify-between mt-50rpx">
        <view>
          <view class="font-size-22rpx color-[var(--text-active)]">Liquidation Information</view>
          <view class="mt-10rpx font-size-30rpx font-500">{{ rowData.symbol_name }}</view>
        </view>
        <view class="text-right">
          <view class="font-size-22rpx color-[var(--text-active)]">Yield</view>
          <view
            :class="[rowData.pl >= 0 ? 'up-color' : 'down-color']"
            class="mt-10rpx font-size-30rpx font-500"
          >
            {{ rowData.plRatio }}
          </view>
        </view>
      </view>
      <view
        :class="[rowData.direction === 1 ? 'up-color' : 'down-color']"
        class="mt-20rpx font-size-30rpx font-500"
      >
        Cross / combined {{ rowData.leverage }} {{ rowData.direction === 1 ? 'Long' : 'Short' }}
      </view>
      <view class="p-30rpx mx-[-30rpx] mt-30rpx b-t flex justify-between items-center">
        <view class="font-size-32rpx color-[var(--text-active)]">Available close</view>
        <view class="font-size-32rpx font-500">
          {{ rowData.balance }} {{ rowData.balance_symbol }}
        </view>
      </view>
    </view>
    <view class="footer">
      <wd-button size="large" block :loading="loading" @click="onSubmit">Confirm</wd-button>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { fetchPlaceOrder } from '@/service/futures'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  rowData: {
    type: Object,
    default: () => ({}),
  },
})

const emits = defineEmits(['update:modelValue', 'onCallback'])

const loading = ref(false)

async function onSubmit() {
  loading.value = true
  try {
    await fetchPlaceOrder(`close/quick`, {
      exchangeCoinStr: props.rowData.symbol_name,
      price: props.rowData.avg_price, // 委托价
      amount: props.rowData.balance, // 数量
      // 3=平仓-平多 4=平仓-平空
      direction: props.rowData.direction === 1 ? 3 : 4, // 方向
      pattern: props.rowData.pattern, // 逐仓=1，全仓=2
      patternType: props.rowData.pattern_type, // 并仓=1，分仓=2
      contractType: props.rowData.contract_type, // 合约类型
      closeLogContractOrderCode: props.rowData.order_code, // 订单号
    })
    onClose()
    emits('onCallback')
    loading.value = false
  } catch (e) {
    onClose()
    loading.value = false
  }
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.footer {
  padding: 20rpx 30rpx;
  box-shadow: var(--box-shadow);
}
</style>
