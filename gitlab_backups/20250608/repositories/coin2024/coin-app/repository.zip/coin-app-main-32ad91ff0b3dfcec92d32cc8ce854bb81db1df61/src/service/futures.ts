import { http } from '@/utils/http'

/** 获取合约钱包 */
export const fetchFuturesWallet = (symbol, params?: any) => {
  return http.get(`/api/mjkj-web/coin/wallet/get/contract/${symbol}`, params)
}

/** 获取当前持仓 */
export const fetchFuturesPosition = (mode: 'ubw' | 'bbw' = 'ubw', params?: any) => {
  return http.get(`/api/mjkj-web/coin/entrust/get/myPosition/${mode}`, params)
}

// 订单
export const fetchOrderList = (tradeOrderMode: any, params?: any) => {
  return http.get(`/api/mjkj-web/coin/entrust/entrustlogContract/${tradeOrderMode}/all`, params)
}

// 切换杠杆
export const fetchChangeLever = (data?: any) => {
  return http.post(`/api/mjkj-web/coin/wallet/contract/updateLeverageRadio`, data)
}

// 下单
export const fetchPlaceOrder = (tradeOrderMode: any, data?: any) => {
  return http.post(`/api/mjkj-web/coin/entrust/contract/${tradeOrderMode}`, data)
}

// 一键平仓
export const fetchCloseAll = (data) => {
  return http.post(`/api/mjkj-web/coin/entrust/contract/close/onekey`, data)
}

// 获取资金费率
export const fetchGetFundingRate = (symbolName) => {
  return http.get(`/api/mjkj-web/coin/open/getFundingRate`, { symbolName })
}

// 资金费记录列表
export const fetchFundingRateRecords = (data) => {
  return http.post(`/api/mjkj-web/coin/night/list`, data)
}

// 获取持仓风险率
export const fetchGetPositionRisk = () => {
  return http.get(`/api/mjkj-web/coin/entrust/get/riskRate`)
}
