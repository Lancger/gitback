import { http } from '@/utils/http'

// 获取会员等级
export const fetchMemberLevelInfo = () => {
  return http.get('/api/mjkj-web/coin/memberLevel/getMemberLevelInfo')
}
