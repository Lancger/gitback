<template>
  <view class="flex items-center justify-center flex-col h-100vh px-30rpx">
    <image class="w-160rpx h-160rpx" src="/static/images/result/success.png" mode="scaleToFill" />
    <view class="font-size-36rpx font-500 text-center mt-40rpx">
      {{ $t('quantitative.success') }}
    </view>

    <wd-button custom-class="mt-500rpx !w-100%" size="large" block @click="onBack">
      {{ $t('quantitative.ok') }}
    </wd-button>
    <wd-button
      custom-class="mt-30rpx !w-100%"
      type="info"
      size="large"
      block
      plain
      @click="onRouter('/pages/quantitative/history/index', 'redirectTo')"
    >
      {{ $t('quantitative.viewOrders') }}
    </wd-button>
  </view>
</template>

<script lang="ts" setup>
import { onRouter } from '@/utils'
const onBack = () => {
  uni.navigateBack()
}
</script>

<style lang="scss" scoped>
//
</style>
