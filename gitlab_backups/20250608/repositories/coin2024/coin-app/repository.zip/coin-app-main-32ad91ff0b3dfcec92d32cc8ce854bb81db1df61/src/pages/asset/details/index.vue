<template>
  <app-navbar custom-class="bg-transparent" :title="$t('assets.bills.title')"></app-navbar>
  <view class="tabs">
    <wd-tabs
      custom-class="app-tabs"
      swipeable
      animated
      :slidable-num="5"
      :map-num="100"
      @click="navigatortype"
      v-model="tab"
    >
      <block v-for="(item, index) in walletList" :key="index">
        <wd-tab :title="item.name" :name="item.type"></wd-tab>
      </block>
    </wd-tabs>
    <wd-drop-menu style="height: 48px">
      <wd-drop-menu-item :title="typetitle" icon-size="24px" ref="dropMenu">
        <view class="product-list">
          <view class="product-list__item">
            <view class="product-list__item__coin-info flex">
              <view class="product-list__item__coin-info__content">
                <view class="product-list__item__coin-info__name" @click="coinIdClick">
                  {{ $t('common.all') }}
                </view>
              </view>
            </view>
          </view>
          <view
            class="product-list__item"
            v-for="(v, i) in coinList.records"
            :key="i"
            @click="coinIdClick(v)"
          >
            <view class="product-list__item__coin-info flex">
              <image class="w-60rpx h-60rpx img" :src="v.avatar" mode="aspectFit" />
              <view class="product-list__item__coin-info__content">
                <view class="product-list__item__coin-info__name">
                  {{ v.symbol }}
                  <text class="font-400 font-size-22rpx color-[var(--text-active)]">
                    /{{ v.full_name }}
                  </text>
                </view>
              </view>
            </view>
          </view>
        </view>
      </wd-drop-menu-item>
      <wd-drop-menu-item :title="typetitleRight" icon-size="22px" ref="dropMenuRight">
        <view class="product-list">
          <view class="product-list__item">
            <view class="product-list__item__coin-info">
              <view class="product-list__item__coin-info__name" @click="typeclick">
                {{ $t('common.all') }}
              </view>
              <view
                class="product-list__item__coin-info__name"
                v-for="(v, i) in typeList"
                :key="i"
                @click="typeclick(v)"
              >
                {{ v.title }}
              </view>
            </view>
          </view>
        </view>
      </wd-drop-menu-item>
    </wd-drop-menu>
  </view>
  <view
    :style="{
      marginTop: `${tabsHeight + 10 + 'px'}`,
    }"
  >
    <template v-for="(item, index) in walletList">
      <asset-details-list
        v-if="item.type === tab"
        :key="index"
        :myBillDataList="walletAccountData[item.type]"
      ></asset-details-list>
    </template>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import {
  fetchGetDictItems,
  fetchGetData,
  fetchGetMyBill,
  fetchGetWalletAccount,
} from '@/service/assets'
import assetDetailsList from './components/asset-details-list.vue'

const walletList = ref<any>([])

const typeList = ref<any>()
const coinList = ref<any>()
const typetitle = ref<string>(t('common.all'))
const walletAccountData = ref({}) // 全部账户数据
const walletAccountParams = ref({}) // 各个账户数据对应的请求参数
const walletAccountType = ref({}) // 各个账户数据对应的搜索类型请求参数
const tab = ref<any>(0)
const tabsHeight = ref(0)

onReachBottom(() => {
  walletAccountParams.value[tab.value].current++
  myBillData()
})
onLoad((options: any) => {
  tab.value = options.billsType
  coinData()
  walletAccount()
})

onReady(() => {
  // 获取元素高度
  uni
    .createSelectorQuery()
    .select('.tabs')
    .boundingClientRect(function (rect: any) {
      console.log('元素高度：', rect.height)
      tabsHeight.value = rect.height
    })
    .exec()
})
const dictItems = () => {
  return fetchGetDictItems(walletAccountType.value[tab.value]).then((res) => {
    typeList.value = res.data
  })
}

const walletAccount = () => {
  return fetchGetWalletAccount().then((res) => {
    walletList.value = res.data
    walletList.value.splice(-1, 1)
    walletList.value.forEach((item) => {
      if (item.type === '1') {
        walletAccountType.value[item.type] = 'assets_mybill_wallet_type'
      } else if (item.type === '2') {
        walletAccountType.value[item.type] = 'assets_mybill_spot_type'
      } else if (item.type === '4') {
        walletAccountType.value[item.type] = 'assets_mybill_contract_type'
      } else if (item.type === '7') {
        walletAccountType.value[item.type] = 'assets_mybill_wealth_type'
      } else if (item.type === '9') {
        walletAccountType.value[item.type] = 'assets_mybill_options_type'
      } else if (item.type === '8') {
        walletAccountType.value[item.type] = 'assets_mybill_service_type'
      }
      walletAccountParams.value[item.type] = {
        billsType: item.type,
        current: 1,
        size: 10,
        type: type.value,
        coinId,
      }
      console.log(walletAccountType.value)

      fetchGetMyBill(walletAccountParams.value[item.type]).then((res) => {
        walletAccountData.value[item.type] = res.data.records
      })
    })
    if (tab.value === 0 || tab.value === '0') {
      tab.value = walletList.value[0].type
    }
    dictItems()
  })
}

const navigatortype = (e) => {
  tab.value = e.name
  type.value = '0'
  typetitleRight.value = t('assets.bills.type')
  dictItems()
}
const coinData = () => {
  return fetchGetData({
    pageSize: -521,
    order: 'asc',
  }).then((res) => {
    coinList.value = res.data
  })
}

const typetitleRight = ref<string>(t('assets.bills.type'))

const type = ref('0')
const dropMenuRight = ref()

const typeclick = (data) => {
  type.value = data.value ? data.value : '0'
  typetitleRight.value = data.title ? data.title : t('assets.bills.type')
  dropMenuRight.value.close()
  walletAccountParams.value[tab.value].current = 1
  walletAccountData.value[tab.value] = []
  myBillData()
}

let coinId = ''
const dropMenu = ref()
const coinIdClick = (data) => {
  coinId = data.id ? data.id : ''
  typetitle.value = data.name ? data.name : t('common.all')
  dropMenu.value.close()
  walletAccountParams.value[tab.value].current = 1
  walletAccountData.value[tab.value] = []
  myBillData()
}

const myBillData = () => {
  uni.showLoading()
  return fetchGetMyBill({
    billsType: walletAccountParams.value[tab.value].billsType,
    current: walletAccountParams.value[tab.value].current,
    size: 10,
    type: type.value,
    coinId,
  })
    .then((res) => {
      walletAccountData.value[tab.value] = walletAccountData.value[tab.value].concat(
        res.data.records,
      )
    })
    .finally(() => {
      uni.hideLoading()
    })
}
</script>

<style lang="scss" scoped>
.page {
  background: var(--background-secondary);
}
.tabs {
  position: fixed;
  top: 44px;
  right: 0;
  left: 0;
  z-index: 99;
  background-color: var(--background-primary) !important;
}
:deep(.wd-drop-menu__arrow) {
  font-size: 24px !important;
}

:deep(.wd-drop-menu__list) {
  display: flex;
  justify-content: space-between;
  padding-right: 30rpx;
  background-color: var(--background-secondary);
}
:deep(.wd-drop-menu__item) {
  flex: none;
  justify-content: space-between;
}

.flex {
  display: flex;
  align-items: center;
}

.product-list {
  max-height: 60vh;
  margin: 0 30rpx;
  overflow: auto;
  &__item {
    display: flex;
    align-items: center;
    padding: 30rpx;
    background: var(--background-primary);
    border-radius: 20rpx;
    &__coin-info {
      width: 100%;
      &__logo {
        width: 50rpx;
        height: 50rpx;
        border-radius: 50%;
      }
      &__content {
        flex: 1;
        padding-left: 20rpx;
      }
      &__name {
        height: 68rpx;
        font-size: 30rpx;
        font-weight: 500;
        line-height: 68rpx;
      }
    }
  }
}
</style>
