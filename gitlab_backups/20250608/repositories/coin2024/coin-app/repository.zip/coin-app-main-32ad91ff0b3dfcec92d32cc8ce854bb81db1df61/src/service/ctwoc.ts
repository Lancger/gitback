import { http } from '@/utils/http'

export const fetchGetData = (params: any) => {
  return http.get('/api/mjkj-web/cgform-api/getData/1531578936708677634', params)
}

export const fetchOneclick = () => {
  return http.get('/api/mjkj-web/coin/open/one-click')
}

export const fetchGetDataRete = (params: { pageSize: number; column: string; order: string }) => {
  return http.get('/api/mjkj-web/cgform-api/getData/1531553843420971009', params)
}

export const fetchOpenp2p = (params: any) => {
  return http.get('/api/mjkj-web/coin/open/p2p', params)
}

export const fetchGetDataCion = (params: { pageSize: number; column: string; order: string }) => {
  return http.get('/api/mjkj-web/cgform-api/getData/1531180815470080002', params)
}

export const fetchSubmitOrder = (data: any) => {
  return http.post('/api/mjkj-web/coin/buy/submit_order', data)
}

// 获取c2c订单详情
export const fetchGetServicePayment = (params: any) => {
  return http.get('/api/mjkj-web/coin/buy/getServicePayment', params)
}

// c2c订单取消
export const fetchCancel = (id: any) => {
  return http.post(`/api/mjkj-web/coin/buy/cancel/${id}`)
}

// c2c买入订单确认付款
export const fetchPay = (id: any) => {
  return http.post(`/api/mjkj-web/coin/buy/pay/${id}`)
}

// c2c卖出订单确认收款
export const fetchComplete = (id: any) => {
  return http.post(`/api/mjkj-web/coin/buy/complete/${id}`)
}

// c2c历史订单列表
export const fetchBuyList = (data: any) => {
  return http.post('/api/mjkj-web/coin/buy/list', data)
}

// 申诉理由列表
export const fetchGetDictItems = (params: any) => {
  return http.get(`/api/mjkj-web/sys/sys/dict/getDictItems/${params}`)
}

// 申诉接口
export const fetchAppeal = (data: any) => {
  return http.post('/api/mjkj-web/coin/buy/appeal', data)
}

// 判断是申诉人还是被申诉人
export const fetchGetAppealOrder = (params: any) => {
  return http.get('/api/mjkj-web/coin/buy/getAppealOrder', params)
}

// 撤销申诉
export const fetchAppealCancel = (params: any) => {
  return http.get(`/api/mjkj-web/coin/buy/appeal/cancel/${params}`)
}

// 申诉进度详情
export const fetchAppealOrder = (params: any) => {
  return http.get(`/api/mjkj-web/coin/buy/appeal/order/${params}`)
}

// 获取聊天记录
export const fetchGetOrderChatRecord = (params: any) => {
  return http.get(`/api/mjkj-web/coin/buy/getOrderChatRecord/${params}`)
}

// 发送聊天消息
export const fetchSendOrderChatRecord = (data: any) => {
  return http.post('/api/mjkj-web/coin/buy/sendOrderChatRecord', data)
}
