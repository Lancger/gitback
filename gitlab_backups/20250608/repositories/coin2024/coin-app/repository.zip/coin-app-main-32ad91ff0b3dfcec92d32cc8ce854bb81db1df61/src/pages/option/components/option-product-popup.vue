<template>
  <wd-popup :model-value="show" position="left" :z-index="99" @close="onClose">
    <view class="popup-wrap">
      <view class="popup-wrap__head">
        <view class="popup-wrap__head-title">{{ $t('options.optionProductPopup.title') }}</view>
        <view class="popup-wrap__head-list">
          <view class="popup-wrap__head-list-item">
            {{ $t('options.optionProductPopup.title') }}
          </view>
          <view class="popup-wrap__head-list-item">
            {{ $t('options.optionProductPopup.price') }}
          </view>
          <view class="popup-wrap__head-list-item">
            {{ $t('options.optionProductPopup.time') }}
          </view>
        </view>
      </view>
      <scroll-view class="popup-wrap__scroll" scroll-y>
        <view class="product-list">
          <view v-for="(item, index) in list" :key="index" class="product-list-item">
            <view class="product-list-item__title">{{ item.contract }}</view>
            <view
              v-for="(v, i) in item.scenePairList"
              :key="i"
              class="product-list-item__row"
              @click="onTap(item, v)"
            >
              <view class="product-list-item__row__name">
                {{ item.contract.split('/')[0] }}·{{ v.time_name }}
              </view>
              <view class="product-list-item__row__date">
                <wd-count-down
                  :ref="(el) => countDownRef(el, `c_${index}_${i}`)"
                  :time="v.time"
                  millisecond
                  @finish="onFinish(`c_${index}_${i}`)"
                />
              </view>
            </view>
          </view>
        </view>
      </scroll-view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { inputLimitToDigit } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Number,
    default: 1,
  },
  show: {
    type: Boolean,
    default: false,
  },
  list: {
    type: Array<any>,
    default: () => [],
  },
})

const emits = defineEmits(['update:modelValue', 'update:show', 'onChange'])

const countDownRefMap = {}

const onTap = (item, pair) => {
  emits('onChange', [item, pair])
  onClose()
}

const onClose = () => {
  emits('update:show', false)
}

const onFinish = (refsKey) => {
  countDownRefMap[refsKey].reset()
}

const countDownRef = (el, key) => {
  countDownRefMap[key] = el
}
</script>

<style lang="scss" scoped>
.popup-wrap {
  display: flex;
  flex-direction: column;
  width: 526rpx;
  height: 100%;
  &__scroll {
    flex: 1;
  }
  &__head {
    padding: 30rpx 30rpx 0;
    &-title {
      font-size: 40rpx;
      font-weight: 500;
    }
    &-list {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-top: 30rpx;
      font-size: 20rpx;
      color: var(--text-active);
    }
  }
  .product-list {
    padding: 40rpx 30rpx;
    &-item {
      padding-bottom: 25rpx;
      &__row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding-bottom: 15rpx;
        font-size: 26rpx;
      }
      &__title {
        position: relative;
        padding-left: 14rpx;
        margin-bottom: 40rpx;
        font-size: 26rpx;
        font-weight: 500;
        &::after {
          position: absolute;
          top: 50%;
          left: 0;
          width: 6rpx;
          height: 100%;
          content: '';
          background: var(--color-primary);
          border-radius: 100rpx;
          transform: translateY(-50%);
        }
      }
    }
  }
}
</style>
