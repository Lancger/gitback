<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar :title="$t('options.history.detail')"></app-navbar>
  <view class="wrap">
    <view class="font-size-30rpx font-700">{{ data.pair_name }}-{{ data.time_name }}</view>
    <view class="tag-list">
      <view :class="[data.up_down === 1 ? 'buy' : 'sell']" class="tag-list__item">
        {{ data.up_down === 1 ? $t('options.up') : $t('options.down') }}
      </view>
      <view class="tag-list__item">{{ $t('options.title') }}</view>
    </view>
    <view class="detail-list">
      <view class="detail-list__item">
        <view class="detail-list__item__label">{{ $t('options.history.orderNumber') }}</view>
        <view class="detail-list__item__value">{{ data.order_no }}</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">{{ $t('options.history.openingPrice') }}</view>
        <view class="detail-list__item__value">{{ data.begin_price }}</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">{{ $t('options.history.closingPrice') }}</view>
        <view class="detail-list__item__value">{{ data.end_price }}</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">{{ $t('options.history.orderTime') }}</view>
        <view class="detail-list__item__value">{{ formatDate(data.create_time) }}</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">{{ $t('options.history.orderAmount') }}</view>
        <view class="detail-list__item__value">{{ data.bet_amount }} USDT</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">{{ $t('options.history.yieldRate') }}</view>
        <view class="detail-list__item__value">{{ data.odds }}</view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">{{ $t('options.history.status') }}</view>
        <view class="detail-list__item__value">
          {{ data.order_status === 1 ? $t('options.history.delivered') : '' }}
        </view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">
          {{ $t('options.history.settlementResult') }}
        </view>
        <view
          :class="[data.delivery_up_down === 1 ? 'up-color' : 'down-color']"
          class="detail-list__item__value"
        >
          {{ data.delivery_range }}%({{
            data.delivery_up_down === 1 ? $t('options.up') : $t('options.down')
          }})
        </view>
      </view>
      <view class="detail-list__item">
        <view class="detail-list__item__label">{{ $t('options.history.settlementAmount') }}</view>
        <view class="detail-list__item__value">{{ data.delivery_amount }} USDT</view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { fetchOptionsOrderDetail } from '@/service/options'
import { formatDate } from '@/utils/day'

const data = ref<any>({})

onLoad((options) => {
  fetchOptionsOrderDetail({ id: options.id }).then((res) => {
    data.value = res.data
  })
})
</script>

<style lang="scss" scoped>
.wrap {
  padding: 30rpx;
  .tag-list {
    display: flex;
    gap: 10rpx;
    align-items: center;
    margin: 20rpx 0 30rpx;
    &__item {
      height: 30rpx;
      padding: 0 14rpx;
      font-size: 20rpx;
      line-height: 30rpx;
      background: var(--background-gary-4);
      border-radius: 5rpx;
    }
    &__item.buy {
      color: var(--color-green);
      background: #07ba831a;
    }
    &__item.sell {
      color: var(--color-red);
      background: #ff4e431a;
    }
  }
  .detail-list {
    padding: 15rpx 0;
    border-top: 1px solid var(--background-gary-4);
    &__item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 15rpx 0;

      &__label {
        color: var(--text-inactive);
      }
    }
  }
}
</style>
