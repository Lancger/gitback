<template>
  <app-navbar :title="$t('kyc.results.title')" left-arrow></app-navbar>
  <view class="main">
    <image
      v-if="realNameStatus == 0"
      class="main__img"
      src="@/static/images/user/applying.png"
    ></image>
    <image
      v-if="realNameStatus == 1"
      class="main__img"
      src="@/static/images/user/success.png"
    ></image>
    <image
      v-if="realNameStatus == -1"
      class="main__img"
      src="@/static/images/user/error.png"
    ></image>

    <template v-if="realNameStatus == 0">
      <view class="main__name">
        {{ $t('kyc.results.applying') }}
      </view>
      <view class="main__hint">
        {{ $t('kyc.results.tips') }}
      </view>
    </template>
    <template v-if="realNameStatus == 1">
      <view class="main__name">
        {{ $t('kyc.results.successful') }}
      </view>
      <view class="main__hint">
        {{ $t('kyc.results.successfulDesc') }}
      </view>
    </template>
    <template v-if="realNameStatus == -1">
      <view class="main__name">
        {{ $t('kyc.results.verificationFailure') }}
      </view>
      <view class="main__hint">
        {{ $t('kyc.results.reason') + data.reason || '' }}
      </view>
    </template>

    <template v-if="realNameStatus == -1">
      <wd-button
        type="error"
        size="large"
        class="!w-400rpx mt-168rpx"
        @click="onRouter('/pages/user/kyc/index?edit=1', 'redirectTo')"
      >
        {{ $t('kyc.results.edit') }}
      </wd-button>
      <wd-button type="info" plain size="large" class="!w-400rpx mt-40rpx" @click="onService()">
        {{ $t('common.customerService') }}
      </wd-button>
    </template>

    <view v-if="realNameStatus == 0 || realNameStatus == 1" class="position-fixed">
      <wd-button type="primary" size="large" block @click="onBack">
        {{ $t('kyc.results.viewMarket') }}
      </wd-button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { useUserStore, useSystemStore } from '@/store'
import { fetchGetKYCStatus } from '@/service/user'
import { onRouter } from '@/utils'

const { onService } = useSystemStore()
const data = ref<any>({})
const realNameStatus = computed(() => +data.value.card_status)
let timer = null
let isMounted = true

getInfo()

onUnload(() => {
  isMounted = false
  clearTimeout(timer)
})

function getInfo() {
  return fetchGetKYCStatus()
    .then((res) => {
      data.value = res.data
      if (isMounted && +res.data.card_status === 0) {
        // 1 通过 0 审核中 -1 驳回
        timer = setTimeout(getInfo, 1000)
      }
    })
    .catch((_) => {
      if (isMounted) {
        timer = setTimeout(getInfo, 3000)
      }
    })
}

function onBack(url) {
  onRouter('/pages/market/index', 'switchTab')
}
</script>

<style lang="scss" scoped>
.main {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 181rpx;
  padding-right: 30rpx;
  padding-left: 30rpx;
  &__img {
    width: 160rpx;
    height: 160rpx;
  }
  &__name {
    margin-top: 80rpx;
    font-size: 36rpx;
    font-weight: 500;
    color: var(--text-primary);
  }
  &__hint {
    padding: 0 30rpx;
    margin-top: 23rpx;
    font-size: 22rpx;
    color: var(--text-inactive);
    text-align: center;
  }
}
.position-fixed {
  position: fixed;
  right: 30rpx;
  bottom: 128rpx;
  left: 30rpx;
}
</style>
