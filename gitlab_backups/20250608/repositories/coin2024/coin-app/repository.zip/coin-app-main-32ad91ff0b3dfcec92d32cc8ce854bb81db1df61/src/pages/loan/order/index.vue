<template>
  <app-navbar :title="$t('loan.loanOrders')"></app-navbar>
  <wd-tabs
    v-model="tabValue"
    custom-class="app-tabs--no-flex-1"
    swipeable
    animated
    :map-num="100"
    @change="onTabChange"
  >
    <block v-for="(item, index) in tab" :key="index">
      <wd-tab :title="item.label" :name="item.value"></wd-tab>
    </block>
  </wd-tabs>
  <!--  -->
  <app-empty :no-data="list.length === 0">
    <view
      v-for="(v, i) in list"
      :key="i"
      class="p-30rpx py-40rpx m-30rpx rd-20rpx border-1 border-[#E5E5E5] border-solid"
    >
      <view class="flex flex-col gap-30rpx">
        <view class="flex items-center justify-between font-siz-24rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.loan') }}</view>
          <view>{{ toFormat(v.amount) }} {{ v.loan_symbol }}</view>
        </view>
        <view class="flex items-center justify-between font-siz-24rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.collateral') }}</view>
          <view>{{ toFormat(v.pledge_amount) }} {{ v.pledge_symbol }}</view>
        </view>
        <view class="flex items-center justify-between font-siz-24rpx">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.loanTime') }}</view>
          <view>{{ formatDate(v.create_time) }}</view>
        </view>
      </view>
      <wd-button v-if="v.status !== 1" custom-class="mt-40rpx w-100% !bg-#000" @click="onDetail(v)">
        {{ $t('loan.viewDetails') }}
      </wd-button>
      <wd-button v-else custom-class="mt-40rpx w-100%" @click="onShowPopup(v)">
        {{ $t('loan.repayment') }}
      </wd-button>
    </view>
    <wd-loadmore :state="loadMoreState" />
  </app-empty>

  <!--  -->
  <repayment-popup v-model="showPopup" :row-data="rowData" @onCallBack="getList" />
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import repaymentPopup from '../components/repayment-popup.vue'
import { fetchLoanRecords } from '@/service/loan'
import { formatDate } from '@/utils/day'
import { toFormat } from '@/utils/number'
import { onRouter } from '@/utils'

const showPopup = ref(false)
const rowData = ref<any>({})
const tabValue = ref('0')
const tab = [
  {
    label: t('loan.pendingReview'),
    value: '0',
  },
  {
    label: t('loan.reject'),
    value: '-1',
  },
  {
    label: t('loan.ongoing'),
    value: '1',
  },
]

const {
  data: list,
  loadMoreState,
  onInit: getList,
} = usePagination({
  api: (params) => {
    return fetchLoanRecords({
      pageNo: params.pageNo,
      pageSize: params.pageSize,
      status: tabValue.value,
    })
  },
  params: {},
  onLoadMoreFn: onReachBottom,
})

const onShowPopup = (item) => {
  rowData.value = item
  showPopup.value = true
}

const onDetail = (item) => {
  uni.setStorageSync('loanOrderItem', item)
  onRouter(`/pages/loan/order/detail`)
}

function onTabChange({ name }) {
  tabValue.value = name
  list.value = []
  getList()
}
</script>

<style lang="scss" scoped></style>
