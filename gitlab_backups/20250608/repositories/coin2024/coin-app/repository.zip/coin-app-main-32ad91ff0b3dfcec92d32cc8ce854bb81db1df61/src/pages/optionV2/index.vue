<template>
  <app-navbar :title="$t('optionV2.title')"></app-navbar>
  <!--  -->
  <view class="p-30rpx">
    <view class="flex items-center justify-between">
      <view class="flex items-center" @click="showSelectToken = true">
        <view class="font-size-30rpx font-600">
          {{ optionsTokenItem.symbolName }} {{ $t('optionV2.option') }}
        </view>
        <wd-icon custom-class="!font-700" name="caret-down-small" size="30rpx"></wd-icon>
      </view>
      <text
        class="i-carbon-align-box-top-right font-size-30rpx"
        @click="onRouter('/pages/optionV2/order/index')"
      ></text>
    </view>
    <view
      :class="optionsTokenItem.zdf >= 0 ? 'up-color' : 'down-color'"
      class="font-size-30rpx font-600 mt-20rpx"
    >
      {{
        optionsTokenItem && optionsTokenItem.close
          ? toFormat(optionsTokenItem.close, optionsTokenItem.base_coin_scale)
          : '--'
      }}
      <text class="font-size-22rpx font-400 ml-10rpx">
        {{ optionsTokenItem && optionsTokenItem.zdf >= 0 ? '+' : null
        }}{{
          optionsTokenItem && optionsTokenItem.zdf ? toFormatPercent(optionsTokenItem.zdf) : '--'
        }}
      </text>
    </view>
  </view>
  <!--  -->
  <tabs-box v-model="tabIndex" />
  <!--  -->
  <wd-tabs
    custom-class="app-tabs--tag app-tabs--tag-info app-tabs--no-flex-1 mt-20rpx"
    v-model="dateIndex"
    swipeable
    animated
    :map-num="100"
    @change="onChangeDate"
  >
    <block v-for="(item, index) in dateTab" :key="index">
      <wd-tab :title="item.label"></wd-tab>
    </block>
  </wd-tabs>
  <!--  -->
  <view
    class="flex items-center justify-between px-30rpx mt-30rpx font-size-22rpx color-[var(--text-inactive)]"
  >
    <view>
      {{ $t('optionV2.indexPrice') }}:
      {{ toFormat(optionsTokenItem.close, optionsTokenItem.base_coin_scale) }}
    </view>
    <view class="flex items-center gap-10rpx">
      <view>{{ $t('optionV2.expirationTime') }}:</view>
      <wd-count-down
        v-if="dateTab[dateIndex]"
        custom-class="!font-size-22rpx !color-[var(--text-inactive)]"
        ref="countDownRef"
        :time="dateTab[dateIndex].value"
        millisecond
        @finish="onFinish"
      />
    </view>
  </view>
  <!-- product list -->
  <app-empty :no-data="!currentData.cycles || currentData.cycles.length === 0">
    <product-list
      :list="currentData.cycles || []"
      :options-data="{ ...currentData, mode: tabIndex }"
      @click="onProductClick"
    />
  </app-empty>

  <!-- 选择币种 -->
  <select-token-popup
    v-model="showSelectToken"
    :list="optionsProductList"
    select
    :select-value="optionsProductItem.symbolName"
    select-key="symbolName"
    @onSelect="onSelectToken"
  ></select-token-popup>
</template>

<script lang="ts" setup>
import TabsBox from './components/tabs-box.vue'
import ProductList from './components/product-list.vue'
import { fetchOptionsList } from '@/service/options'
import { fetchGetOptions } from '@/service/market'
import { toFixed, toFormat, toFormatPercent } from '@/utils/number'
import { onRouter } from '@/utils'
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'

const tabIndex = ref(0)
const showSelectToken = ref(false)
const optionsTokenData = ref([])
const optionsProductList = ref([])
const optionsProductItem = ref<any>({})
const optionsTokenItem = ref<any>({})
const dateTab = ref([])
const dateIndex = ref(0)
const countDownRef = ref(null)

const currentData = computed<any>(() => {
  if (!optionsProductItem.value.scenePairList) return {}
  return optionsProductItem.value.scenePairList[dateIndex.value]
})

onLoad(() => {
  uni.$on('message', onMessage)
})

onShow(() => {
  getOptions()
  getList()
  onSubscribe('all_symbol_detail')
})

onUnload(() => {
  onUnsubscribe('all_symbol_detail')
  uni.$off('message', onMessage)
})

function onMessage(msgData) {
  const [topic, data] = msgData
  if (data.type !== 'ubw' && subscribeMode === 'mqtt') return
  if (optionsTokenItem.value && data.symbolName === optionsTokenItem.value.symbolName) {
    Object.assign(optionsTokenItem.value, data)
  }
}

const onProductClick = (item) => {
  uni.setStorageSync('optionsV2Data', {
    time: item,
    token: optionsTokenItem.value,
    product: {
      ...optionsProductItem.value,
      symbol: optionsProductItem.value.symbolName.split('/')[0],
    },
    current: currentData.value,
    mode: tabIndex.value === 0 ? 1 : -1,
  })
  onRouter(`/pages/optionV2/detail`)
}

const onChangeDate = () => {
  getList()
}

const onFinish = () => {
  if (countDownRef.value) {
    getList()
    countDownRef.value.reset()
  }
}

const onSelectToken = (e) => {
  optionsProductItem.value = e
  optionsTokenItem.value = optionsTokenData.value.find((item) => item.symbolName === e.symbolName)
}

function getOptions() {
  return fetchGetOptions().then((res) => {
    optionsTokenData.value = res.data
  })
}

function getList() {
  return fetchOptionsList().then((res) => {
    optionsProductList.value = res.data.map((item) => {
      return {
        ...item,
        symbolName: item.currency_name,
      }
    })
    onSelectToken(
      optionsProductItem.value.symbolName
        ? optionsProductList.value.find(
            (item) => item.symbolName === optionsProductItem.value.symbolName,
          )
        : optionsProductList.value.find((item) => item.symbolName === 'BTC/USDT'),
    )
    getDateTab()
  })
}

function getDateTab() {
  dateTab.value = optionsProductItem.value.scenePairList.map((item) => {
    return {
      label: item.time_name,
      value: getTime(item.time_name),
    }
  })
}

function getTime(time) {
  if (time.indexOf('S') !== -1) {
    // 秒
    return parseInt(time) * 1000
  }

  if (time.indexOf('M') !== -1) {
    // 分钟
    return parseInt(time) * 60 * 1000
  }

  if (time.indexOf('H') !== -1) {
    // 小时
    return parseInt(time) * 60 * 60 * 1000
  }

  if (time.indexOf('D') !== -1) {
    // 天
    return parseInt(time) * 60 * 60 * 24 * 1000
  }

  return 0
}
</script>

<style lang="scss" scoped></style>
