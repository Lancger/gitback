<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar>
    <template #title>
      <view class="mt-8rpx font-size-34rpx font-700 lh-none">
        {{ $t('options.history.title') }}
      </view>
      <view class="!mt-5rpx !font-size-22rpx font-400 color-[var(--text-inactive)] lh-none">
        {{ $t('options.title') }}
      </view>
    </template>
  </app-navbar>
  <view>
    <app-empty :no-data="list.length === 0">
      <option-history-list :list="list"></option-history-list>
      <wd-loadmore :state="loadMoreState" />
    </app-empty>
  </view>
</template>

<script lang="ts" setup>
import usePagination from '@/hooks/usePagination'
import optionHistoryList from '../components/option-history-list.vue'
import { fetchOptionsList, fetchOptionsOrder, fetchOptionsPlaceOrder } from '@/service/options'

const positionParams = reactive({
  pageNo: 1,
  pageSize: 10,
  order_status: 1,
})

const {
  data: list,
  loadMoreState,
  onInit,
} = usePagination({
  api: fetchOptionsOrder,
  params: positionParams,
  onLoadMoreFn: onReachBottom,
})
</script>

<style lang="scss" scoped></style>
