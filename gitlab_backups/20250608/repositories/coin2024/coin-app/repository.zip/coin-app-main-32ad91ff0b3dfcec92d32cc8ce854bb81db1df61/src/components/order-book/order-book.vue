<template>
  <view class="order-book">
    <view class="order-book__head">
      <view class="order-book__head__item">
        <view>{{ $t('components.orderBook.price') }}</view>
        <view>(USDT)</view>
      </view>
      <view class="order-book__head__item text-right">
        <view>{{ $t('components.orderBook.volume') }}</view>
        <view>({{ tokenConfig.coin_symbol }})</view>
      </view>
    </view>
    <view class="order-book__list">
      <view
        v-for="(item, index) in sellList"
        :key="index"
        class="order-book__list__item sell"
        @click="onTapPrice(item.price)"
      >
        <view class="order-book__list__item-content">
          <text class="down-color">
            {{ toFormat(item.price, tokenConfig.base_coin_scale) || '--' }}
          </text>
          <text>
            {{
              toFormatUnit(item.amount, tokenConfig.coin_coin_scale || tokenConfig.coin_scale) ||
              '--'
            }}
          </text>
        </view>
        <view
          :style="{ transform: `translateX(-${item.ratio || 100}%) `, left: '100%' }"
          class="order-book__list__item-bg"
        ></view>
      </view>
    </view>
    <view class="mt-20rpx" @click="onTapPrice(tokenData.close)">
      <view :class="[isUp ? 'up-color' : 'down-color']" class="font-size-30rpx font-600">
        {{ toFormat(tokenData.close, tokenConfig.base_coin_scale) || '--' }}
      </view>
      <view class="mt-10rpx font-size-22rpx color-[var(--text-inactive)]">
        ≈{{ onExchangeRateConversion(tokenData.close, tokenConfig.base_coin_scale) || '--' }}
      </view>
    </view>
    <view class="order-book__list">
      <view
        v-for="(item, index) in buyList"
        :key="index"
        class="order-book__list__item buy"
        @click="onTapPrice(item.price)"
      >
        <view class="order-book__list__item-content">
          <text class="up-color">
            {{ toFormat(item.price, tokenConfig.base_coin_scale) || '--' }}
          </text>
          <text>
            {{
              toFormatUnit(item.amount, tokenConfig.coin_coin_scale || tokenConfig.coin_scale) ||
              '--'
            }}
          </text>
        </view>
        <view
          :style="{ transform: `translateX(-${item.ratio || 100}%) `, left: '100%' }"
          class="order-book__list__item-bg"
        ></view>
      </view>
    </view>
    <view class="flex justify-between mt-20rpx">
      <!--  v-if="showType === -1" -->
      <image
        class="w-42rpx h-42rpx"
        src="@img/icons/order-book_1.png"
        mode="scaleToFill"
        @click="onSwitch(0)"
      />
      <image
        class="w-42rpx h-42rpx"
        src="@img/icons/order-book_2.png"
        mode="scaleToFill"
        @click="onSwitch(1)"
      />
      <image
        class="w-42rpx h-42rpx"
        src="@img/icons/order-book_0.png"
        mode="scaleToFill"
        @click="onSwitch(-1)"
      />
    </view>
  </view>
</template>

<script lang="ts" setup>
import { BNumber, toFixed, toFormat, toFormatUnit } from '@/utils/number'
import { useUserStore } from '@/store'

const props = defineProps({
  orderBookData: {
    type: Object,
    default: () => ({}),
  },
  tokenData: {
    type: Object,
    default: () => ({}),
  },
  tokenConfig: {
    type: Object,
    default: () => ({}),
  },
  max: {
    type: Number,
    default: 10,
  },
  min: {
    type: Number,
    default: 5,
  },
})
const emits = defineEmits(['onSelect'])
const { onExchangeRateConversion } = useUserStore()

const buyList = ref<any>([])
const sellList = ref<any>([])
const showType = ref(-1)
const isUp = ref(true)
const lastPrice = ref(0)

watchEffect(() => {
  isUp.value = props.tokenData.close >= lastPrice.value
  lastPrice.value = props.tokenData.close
  // if (props.orderBookData.buyItems && props.orderBookData.sellItems) {
  //   onInit()
  // }
  if (props.orderBookData) {
    onInit()
  }
})

const onTapPrice = (price) => {
  emits('onSelect', price)
}

const onSwitch = (type) => {
  showType.value = type
  onInit()
}

function onInit() {
  const max = showType.value === -1 ? props.min : props.max
  if (props.orderBookData.buyItems) {
    const buyData = [...props.orderBookData.buyItems]
    buyList.value = buyData.slice(0, max)
    buyList.value.sort((a, b) => {
      return b.price - a.price
    })
    const buyMax = buyList.value.map((item) => Number(item.amount))
    buyList.value = buyList.value.map((item) => {
      return {
        ...item,
        ratio: (item.amount / Math.max(...buyMax)) * 100,
      }
    })
  } else {
    buyList.value = new Array(max).fill({})
  }

  if (props.orderBookData.sellItems) {
    const sellData = [...props.orderBookData.sellItems]
    sellList.value = sellData.slice(0, max)
    sellList.value.sort((a, b) => {
      return b.price - a.price
    })
    const sellMax = sellList.value.map((item) => Number(item.amount))
    sellList.value = sellList.value.map((item) => {
      return {
        ...item,
        ratio: (item.amount / Math.max(...sellMax)) * 100,
      }
    })
  } else {
    sellList.value = new Array(max).fill({})
  }

  if (showType.value === 0) {
    sellList.value = []
  }

  if (showType.value === 1) {
    buyList.value = []
  }
}
</script>

<style lang="scss" scoped>
.order-book {
  &__head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 20rpx;
    color: var(--text-inactive);
  }
  &__list {
    margin-top: 20rpx;
    &__item {
      position: relative;
      width: 100%;
      height: 42rpx;
      overflow: hidden;
      &-content {
        position: relative;
        z-index: 2;
        display: flex;
        align-items: center;
        justify-content: space-between;
        height: 100%;
        padding: 0 8rpx;
      }
      &-bg {
        position: absolute;
        top: 0;
        right: 0;
        z-index: 1;
        width: 100%;
        height: 100%;
        opacity: 0.1;
        transition: all 0.3s;
        transform: tran3lateX(100%);
      }
    }
    &__item.buy {
      .order-book__list__item-bg {
        background: var(--color-green);
      }
    }
    &__item.sell {
      .order-book__list__item-bg {
        background: var(--color-red);
      }
    }
  }
}
</style>
