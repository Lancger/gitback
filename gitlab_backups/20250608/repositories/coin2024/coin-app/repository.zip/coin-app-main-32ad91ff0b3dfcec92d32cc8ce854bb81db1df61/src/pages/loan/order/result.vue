<template>
  <app-navbar></app-navbar>
  <!--  -->
  <view class="text-center pt-200rpx">
    <image
      class="block w-100rpx h-100rpx m-auto"
      src="/static/images/result/success02.png"
      mode="scaleToFill"
    />
    <view class="font-size-30rpx font-600 mt-30rpx">Repaid</view>
    <view class="font-size-50rpx font-600 mt-20rpx">1110 USDT</view>
    <view class="flex flex-col gap-40rpx p-30rpx py-50rpx mt-40rpx">
      <view class="flex items-center justify-between font-siz-26rpx font-500">
        <view class="color-[var(--text-inactive)]">Principal</view>
        <view>1100 USDT</view>
      </view>
      <view class="flex items-center justify-between font-siz-26rpx font-500">
        <view class="color-[var(--text-inactive)]">Interest</view>
        <view>35,344235 BGB</view>
      </view>
      <view class="flex items-center justify-between font-siz-26rpx font-500">
        <view class="color-[var(--text-inactive)]">Collateral released</view>
        <view>{{ formatDate(new Date()) }}</view>
      </view>
    </view>
    <wd-button custom-class="mt-164rpx w-300rpx" type="info" size="large" @click="onBack">
      OK
    </wd-button>
  </view>
</template>

<script lang="ts" setup>
import { formatDate } from '@/utils/day'

const data = ref<any>({})

onLoad((options) => {
  data.value = options
})

const onBack = () => {
  uni.navigateBack()
}
</script>

<style lang="scss" scoped>
//
</style>
