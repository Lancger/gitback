<template>
  <app-navbar custom-class="bg-transparent" title="">
    <template #right>
      <!-- @click="navigator" -->
      <view @click="cancel" v-if="listObj.order_status === '1'">
        {{ $t('c2c.paid.cancelOrder') }}
      </view>
    </template>
  </app-navbar>
  <view class="title" v-if="listObj.order_status === '4'">{{ $t('c2c.paid.orderCancelled') }}</view>
  <view v-else>
    <view class="schedule flex mt-40rpx">
      <view class="schedule_black"></view>
      <view
        :class="{
          schedule_black: listObj.order_status === '2' || listObj.order_status === '3',
        }"
      ></view>
      <view
        :class="{
          schedule_black: listObj.order_status === '3',
        }"
      ></view>
    </view>

    <view class="title">{{ orderStatus() }}</view>
  </view>
  <view v-if="listObj.order_status !== '3'">
    <!-- 取消倒计时只有状态为1和卖出操作时才展示 -->
    <view class="text" v-if="listObj.order_status === '1' && listObj.type === '1'">
      {{ $t('c2c.paid.payWithin') }}
      <text class="text_time">
        <wd-count-down
          ref="countDown"
          custom-class="count-down"
          :time="time"
          format="mm:ss"
          @finish="finish"
        />
      </text>
    </view>

    <view class="user">
      <view class="flex">
        <image v-if="listObj.icon" class="w-70rpx h-70rpx mr2 ml1" :src="listObj.icon" />
        <image v-else class="w-70rpx h-70rpx mr2 ml1" src="@img/avatar.png" />
        <view>
          <!-- <view class="user_name">{{ $t('c2c.paid.bankTransfer') }}</view> -->
          <view class="user_name">{{ listObj.name }}</view>
          <view class="user_text">
            {{ $t('c2c.paid.unitPrice') }} {{ listObj.unit_price }} {{ listObj.fiat_currency }}
          </view>
        </view>
      </view>
      <view v-if="config.c2cChat" class="flex">
        <!-- <view class="user_chat" @click="navigator">{{ $t('c2c.paid.appeal') }}</view> -->
        <wd-badge :modelValue="listObj.unReadCount">
          <view
            class="user_chat ml-20rpx"
            @click="onRouter(`/pages/home/ctwoc/contact-merchant/index?orderId=${listObj.id}`)"
          >
            {{ $t('c2c.paid.chat') }}
          </view>
        </wd-badge>
      </view>
      <view
        v-if="listObj.customerServiceLink && !config.c2cChat"
        class="user_chat"
        @click="onService(listObj.customerServiceLink, listObj.name)"
      >
        {{ $t('c2c.paid.customerService') }}
      </view>
    </view>

    <view class="information flex justify-between">
      <view
        v-if="listObj.whatsapp"
        class="information-item"
        :class="{ disabled: !listObj.whatsapp }"
        @click="onService(listObj.whatsapp)"
      >
        <image class="w-50rpx h-50rpx mr-36rpx" src="@/static/images/assets/whatsapp.png" />
        <view class="flex-1 text-left">WhatsApp</view>
        <wd-icon name="arrow-right" class="color-#999" size="20px"></wd-icon>
      </view>
      <view
        v-if="listObj.tg"
        class="information-item"
        :class="{ disabled: !listObj.tg }"
        @click="onService(listObj.tg)"
      >
        <image class="w-50rpx h-50rpx mr-36rpx" src="@/static/images/assets/telegram.png" />
        <view class="flex-1 text-left">Telegram</view>
        <wd-icon name="arrow-right" class="color-#999" size="20px"></wd-icon>
      </view>
    </view>

    <view class="flex list">
      <!-- <image class="w-43rpx h-42rpx mr2" :src="coinIcon" /> -->
      <view class="list_cer mr1">
        {{ listObj.type === '1' ? $t('c2c.buy') : $t('c2c.sell') }}
      </view>
      <view class="list_cer">{{ listObj.coin_symbol }}</view>
    </view>

    <view class="flex_jc">
      <view>{{ $t('c2c.paid.youPay') }}</view>
      <view>
        {{ listObj.exchange_code }}{{ toFormat(listObj.fiat_currency_amount)
        }}{{ listObj.fiat_currency }}
      </view>
    </view>

    <view class="flex_jc">
      <view>{{ $t('c2c.paid.qty') }}</view>
      <view class="flex">
        <view>{{ listObj.coin_cou }} {{ listObj.coin_symbol }}</view>
      </view>
    </view>

    <!-- <view class="flex_jc">
      <view>{{ $t('c2c.paid.accountName') }}</view>
      <view class="flex">
        <view>{{ listObj.name }}</view>
        <image
          class="w-30rpx h-30rpx ml2"
          @click="copy(listObj.name)"
          src="@/static/images/assets/copy.png"
        />
      </view>
    </view>

    <view class="flex_jc">
      <view>{{ $t('c2c.paid.bankAccount') }}</view>
      <view class="flex">
        <view>{{ listObj.account }}</view>
        <image
          class="w-30rpx h-30rpx ml2"
          @click="copy(listObj.account)"
          src="@/static/images/assets/copy.png"
        />
      </view>
    </view> -->

    <view class="flex_jc">
      <view>{{ $t('c2c.paid.orderID') }}</view>
      <view class="flex">
        <view>{{ listObj.order_code }}</view>
        <image
          class="w-30rpx h-30rpx ml2"
          @click="copy(listObj.order_code)"
          src="@/static/images/assets/copys.png"
        />
      </view>
    </view>

    <view class="flex_jc">
      <view>{{ $t('c2c.paid.orderTime') }}</view>
      <view class="flex">
        <view>{{ formatDate(listObj.order_time) }}</view>
      </view>
    </view>

    <!-- <view class="service" @click="onService">{{ $t('c2c.paid.customerService') }}</view> -->

    <!-- <view v-if="listObj.order_status === '1' && listObj.type === '1'">
      <view class="crypto">{{ $t('c2c.paid.yesPayNotifyMerchant') }}</view>
      <view class="btn">
        <view class="btn_subscribewhine" @click="confirm">{{ $t('c2c.paid.iHavePaid') }}</view>
      </view>
    </view>
    <view v-if="listObj.order_status === '2' && listObj.type === '2'">
      <view class="crypto">{{ $t('c2c.paid.areYouSure') }}</view>
      <view class="btn">
        <view class="btn_subscribewhine" @click="confirmReceipt">
          {{ $t('c2c.paid.confirmToReceipt') }}
        </view>
      </view>
    </view> -->
  </view>

  <ordersucc :listObj="listObj" v-if="listObj.order_status === '3'"></ordersucc>
  <!-- 提示是否需要联系客服 -->
  <wd-popup v-model="serviceshow" custom-style="padding: 30px 40px;border-radius: 20rpx ;">
    <view class="servicepopup">
      <view class="servicepopup_text">
        {{ $t('c2c.paid.orderCancelTips') }}
      </view>

      <view class="flex mt2 servicepopup_btn">
        <view class="servicepopup_btn_cancel">{{ $t('c2c.paid.cancel') }}</view>
        <view class="servicepopup_btn_customer" @click="onService()">
          {{ $t('c2c.paid.customerService') }}
        </view>
      </view>
    </view>
  </wd-popup>
  <wd-message-box selector="wd-message-box-slot"></wd-message-box>
</template>

<script lang="ts" setup>
import dayjs from 'dayjs'
import { useMessage } from 'wot-design-uni'
import { t } from '@/locale'
import ordersucc from '../ordersucc/index.vue'
import { useSystemStore } from '@/store'
import { fetchGetServicePayment, fetchPay, fetchComplete, fetchCancel } from '@/service/ctwoc'
import { onRouter } from '@/utils'
import { toFormat } from '@/utils/number'
import { formatDate } from '@/utils/day'
import config from '@/config'

const { onService } = useSystemStore()
const message = useMessage('wd-message-box-slot')
const serviceshow = ref<boolean>(false)
const id = ref()
const listObj = ref<any>({})
const time = ref<number>()
const coinIcon = ref<string>('')
onLoad((e) => {
  id.value = e.id
  coinIcon.value = decodeURIComponent(e.coin_icon)
})

onShow(() => {
  fetchGetServicePaymentFun()
})

const fetchGetServicePaymentFun = () => {
  fetchGetServicePayment({
    orderId: id.value,
  }).then((res) => {
    // 15分钟超时
    const startTime = new Date(res.data.order_time).getTime()
    const endTime = startTime + 15 * 60 * 1000
    const currTime = new Date().getTime()
    time.value = endTime - currTime
    listObj.value = res.data
  })
}
const finish = () => {
  fetchCancelFun()
}
const orderStatus = () => {
  // 根据买入卖出状态展示对应的状态栏文字 1是买 2是卖
  if (listObj.value.type === '1') {
    return {
      '1': t('c2c.paid.status1-1'),
      '2': t('c2c.paid.status1-2'),
    }[listObj.value.order_status]
  } else {
    return {
      '1': t('c2c.paid.status2-1'),
      '2': t('c2c.paid.status2-2'),
    }[listObj.value.order_status]
  }
}
const fetchCancelFun = () => {
  fetchCancel(listObj.value.id).then((res) => {
    uni.showToast({
      icon: 'none',
      title: t('c2c.paid.canceled'),
      success: function () {
        uni.navigateBack()
      },
    })
  })
}
const confirm = () => {
  message
    .confirm({
      msg: t('c2c.paid.hasPayMsg'),
      title: t('c2c.paid.tips'),
    })
    .then(() => {
      uni.showLoading()
      fetchPay(listObj.value.id).then(() => {
        uni.showToast({
          icon: 'none',
          title: t('c2c.paid.orderStatusChange'),
          success: function () {
            fetchGetServicePaymentFun()
          },
        })
      })
    })
    .finally(() => {
      fetchGetServicePaymentFun()
      uni.hideLoading()
    })
}

const confirmReceipt = () => {
  message
    .confirm({
      msg: t('c2c.paid.receivedAmountMsg'),
      title: t('c2c.paid.tips'),
    })
    .then(() => {
      uni.showLoading()
      fetchComplete(listObj.value.id).then((res) => {
        uni.showToast({
          icon: 'none',
          title: t('c2c.paid.orderStatusChange'),
          success: function () {
            fetchGetServicePaymentFun()
          },
        })
      })
    })
    .finally(() => {
      fetchGetServicePaymentFun()
      uni.hideLoading()
    })
}
const cancel = () => {
  message
    .confirm({
      msg: t('c2c.paid.cancelOrderMsg'),
      title: t('c2c.paid.tips'),
    })
    .then((res) => {
      fetchCancelFun()
    })
}

const copy = (data) => {
  uni.setClipboardData({
    data,
    success: function () {
      uni.showToast({
        title: t('common.success'),
        icon: 'none',
        duration: 2000,
      })
    },
  })
}

function handleOpenLink(url: string) {
  if (url) {
    window.open(url, '_blank')
  }
}

function navigator(url: string) {
  if (listObj.value.appeal_status === 1 || listObj.value.appeal_status === 2) {
    onRouter(`/pages/home/ctwoc/appeal-details/index?orderId=${listObj.value.id}`)
  } else {
    onRouter(
      `/pages/home/ctwoc/appeal/index?bSType=${listObj.value.type}&orderId=${listObj.value.id}`,
    )
  }
}
</script>

<style lang="scss" scoped>
.page {
  // background: var(--background-secondary);
}
:deep(.wd-popup--bottom) {
  border-radius: 10px 10px 0 0;
}
.information {
  margin: 0px 30rpx;

  &-item {
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 330rpx;
    height: 88rpx;
    padding: 20rpx;
    background: var(--background-gary-4);
    border-radius: 15rpx;

    &.disabled {
      opacity: 0.6;
    }
  }
}
.servicepopup {
  width: 482rpx;
  &_text {
    font-family: Asap;
    font-size: 22rpx;
    font-weight: 400;
    line-height: 36rpx;
    text-align: center;
  }
  &_btn {
    display: flex;
    justify-content: space-between;
    width: 482rpx;
    &_cancel {
      width: 234rpx;
      height: 66rpx;
      font-family: Asap;
      font-size: 26rpx;
      font-weight: 500;
      line-height: 66rpx;
      color: var(--text-primary);
      text-align: center;
      border: 1rpx solid #a8a7af;
      border-radius: 100rpx;
    }

    &_customer {
      width: 234rpx;
      height: 66rpx;
      font-family: Asap;
      font-size: 26rpx;
      font-weight: 500;
      line-height: 66rpx;
      color: var(--wot-color-white);
      text-align: center;
      background-color: #00a7ed;
      border: 1rpx solid #a8a7af;
      border-radius: 100rpx;
    }
  }
}
.paypopup {
  position: relative;
  //   padding: 30rpx;
  &_icon {
    text-align: right;
  }
  &_c9 {
    margin-top: 10rpx;
    color: var(--text-inactive);
  }
  &_uploading {
    position: relative;
    width: 200rpx;
    height: 200rpx;
    margin-top: 40rpx;
    margin-bottom: 60rpx;
    border: 1rpx 0px 0px 0px;
    border: 1rpx solid var(--border-color);
    border-radius: 10rpx;
    &_icon {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
  }
  &_title {
    margin-bottom: 30rpx;
    clear: var(--text-primary);
    font-family: Asap;
    font-size: 30rpx;
    font-weight: 500;
    text-align: left;
  }
  &_btn {
    position: absolute;
    top: 100%;
    width: 100%;
    height: 130rpx;
    box-shadow: 0px -5px 21.7px 0px #c6c6c640;
    &_subscribe {
      width: 690rpx;
      height: 90rpx;
      margin: 20rpx auto;
      line-height: 90rpx;
      color: var(--text-inactive) !important;
      text-align: center;
      background-color: var(--border-color-inactive);
      border-radius: 100rpx;
    }
    &_subscribewhine {
      width: 690rpx;
      height: 90rpx;
      margin: 20rpx auto;
      line-height: 90rpx;
      color: var(--wot-color-white) !important;
      text-align: center;
      background-color: #00a7ed;
      border-radius: 100rpx;
    }
  }
}

.service {
  margin-top: 60rpx;
  font-family: Asap;
  font-size: 24rpx;
  text-align: center;
  text-decoration: underline;
}
.schedule {
  width: 690rpx;
  view {
    width: 216rpx;
    height: 4rpx;
    margin-left: 30rpx;
    background-color: var(--background-gary-4);
  }
  &_black {
    background-color: var(--text-primary) !important;
  }
}
.popup {
  position: absolute;
  top: 10%;
  left: 50%;
  z-index: 9999;
  box-sizing: border-box;
  width: 690rpx;
  height: 192rpx;
  padding: 20rpx 30rpx;
  background-color: var(--background-primary);
  border-radius: 20rpx;
  transform: translate(-50%, -0%);
  &_msg {
    margin-top: 50rpx;
    font-family: Asap;
    font-size: 24rpx;
    font-weight: 500;
  }
}
.crypto {
  padding-left: 30rpx;
  margin-top: 100rpx;
  margin-bottom: 60rpx;
  font-size: 30rpx;
  font-weight: 500;
}
.user {
  box-sizing: border-box;
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 690rpx;
  height: 130rpx;
  padding: 30rpx;
  margin: 40rpx auto;
  background-color: var(--background-gary-4);
  border-radius: 20rpx;
  &_chat {
    min-width: 100rpx;
    height: 46rpx;
    padding: 0 20rpx;
    font-size: 22rpx;
    line-height: 46rpx;
    color: var(--wot-color-white);
    text-align: center;
    background-color: var(--color-primary);
    border-radius: 100rpx;
  }
  &_bor {
    padding: 5rpx 15rpx;
    border: 2rpx solid var(--border-color);
    border-radius: 100rpx;
  }
  &_name {
    padding-left: 20rpx;
    font-family: Asap;
    font-size: 28rpx;
    font-weight: 500;
    color: var(--text-primary);
  }
  &_text {
    padding-left: 20rpx;
    margin-top: 10rpx;
  }
}
.list {
  height: 88rpx;
  padding: 0 30rpx;
  margin-top: 30rpx;
  font-size: 26rpx;
  &_cer {
    font-weight: 500;
    color: var(--text-primary);
  }
}
.flex {
  display: flex;
  align-items: center;
}

.btn {
  width: 100%;
  &_subscribe {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--text-inactive) !important;
    text-align: center;
    border-radius: 100rpx;
  }

  &_subscribewhine {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--wot-color-white) !important;
    text-align: center;
    background-color: #00a7ed;
    border-radius: 100rpx;
  }
}
.title {
  padding: 0 30rpx;
  margin: 40rpx 0 40rpx 0;
  font-family: Asap;
  font-size: 34rpx;
  font-weight: 500;
  color: var(--text-primary);
}

.text {
  display: flex;
  align-items: center;
  padding-left: 30rpx;
  margin-bottom: 20rpx;
  color: var(--text-inactive);
  .count-down {
    margin-left: 6rpx;
    color: var(--text-primary) !important;
  }
}
.flex_jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 48rpx;
  padding: 0 30rpx;
  color: var(--text-inactive);
  view:nth-child(2) {
    color: var(--text-primary);
  }
}
</style>
