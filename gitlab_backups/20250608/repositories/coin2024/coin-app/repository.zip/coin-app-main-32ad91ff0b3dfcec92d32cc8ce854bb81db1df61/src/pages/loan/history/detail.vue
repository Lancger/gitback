<template>
  <app-navbar :title="$t('loan.detail')"></app-navbar>
  <!--  -->
  <view class="flex flex-col gap-40rpx p-30rpx py-50rpx">
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.orderId') }}</view>
      <view>{{ info.order_code }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.loanTime') }}</view>
      <view>{{ formatDate(info.create_time) }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.loanTerm') }}</view>
      <view>{{ info.days }} {{ $t('loan.days') }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.loanCoin') }}</view>
      <view>{{ info.loan_symbol }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.loanAmount') }}</view>
      <view>{{ toFormat(info.amount, true) }} {{ info.loan_symbol }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.collateralCoin') }}</view>
      <view>{{ info.pledge_symbol }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.collateralAmount') }}</view>
      <view>{{ toFormat(info.pledge_amount, true) }} {{ info.pledge_symbol }}</view>
    </view>
    <view class="flex items-center justify-between pb-50rpx font-siz-26rpx font-500 b-b">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.status') }}</view>
      <view class="color-[var(--color-primary)]">{{ formatStatus(info.status) }}</view>
    </view>
    <view class="font-size-26rpx font-500">{{ $t('loan.repaymentInformation') }}</view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.totalRepaymentAmount') }}</view>
      <view>{{ toFormat(info.repaymentAmount, true) }} {{ info.loan_symbol }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.principal') }}</view>
      <view>{{ toFormat(info.amount, true) }} {{ info.loan_symbol }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.interest') }}</view>
      <view>{{ toFormat(info.interest, true) }} {{ info.loan_symbol }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.repaymentTime') }}</view>
      <view>{{ formatDate(info.create_time) }}</view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { toFormat } from '@/utils/number'
import { formatDate } from '@/utils/day'
import { t } from '@/locale'

const info = ref(uni.getStorageSync('loanHistoryItem') || {})

const formatStatus = (status) => {
  switch (+status) {
    case -1:
      return t('loan.reject')
    case 0:
      return t('loan.pendingReview')
    case 1:
      return t('loan.ongoing')
    default:
      return t('loan.complete')
  }
}
</script>

<style lang="scss" scoped>
//
</style>
