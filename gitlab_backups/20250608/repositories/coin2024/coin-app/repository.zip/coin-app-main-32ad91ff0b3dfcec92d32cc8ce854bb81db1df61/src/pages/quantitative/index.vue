<template>
  <app-navbar :title="$t('quantitative.title')">
    <template #right>
      <wd-icon
        name="list"
        size="32rpx"
        @click="onRouter('/pages/quantitative/history/index')"
      ></wd-icon>
    </template>
  </app-navbar>
  <view
    style="
      background-image: url('/static/images/quantitative/banner.png');
      background-size: 100% 100%;
    "
    class="relative flex flex-col justify-center items-center w-690rpx h-220rpx m-auto mt-30rpx color-#fff rd-30rpx"
  >
    <view class="font-size-30rpx font-600">{{ $t('quantitative.banner.title') }}</view>
    <view class="mt-20rpx font-size-26rpx font-500">
      {{ $t('quantitative.banner.subtitle') }}
    </view>
  </view>
  <view class="px-30rpx">
    <!-- tabs -->
    <view class="flex items-center gap-20rpx py-30rpx">
      <view
        v-for="(item, index) in tab"
        :key="index"
        class="flex items-center justify-center"
        @click="onTabChange(index)"
      >
        <view
          :class="
            tabIndex === index
              ? 'color-[var(--text-primary)] bg-[var(--background-gary-4)] rd-5rpx'
              : null
          "
          class="min-w-156rpx h-50rpx px-10rpx lh-50rpx text-center font-size-24rpx font-500 color-[var(--text-inactive)] transition-all-300"
        >
          {{ $t(item) }}
        </view>
      </view>
    </view>
    <app-empty :no-data="list.length === 0">
      <!-- product -->
      <template v-if="tabIndex === 0">
        <view
          v-for="(item, index) in list"
          :key="index"
          class="p-30rpx mb-30rpx border-1 border-solid border-color-[var(--border-color-inactive)] rd-20rpx"
        >
          <view class="flex items-center justify-between">
            <view class="flex items-center gap-10rpx">
              <view class="font-size-28rpx font-500">{{ item.projectName }}</view>
              <view
                class="h-30rpx px-6rpx lh-30rpx font-size-20rpx bg-[var(--background-gary-4)] rd-5rpx"
              >
                {{ item.lever }}X
              </view>
            </view>
            <view class="font-size-28rpx font-500">
              {{ item.day }} {{ $t('quantitative.days') }}
            </view>
          </view>
          <!--  -->
          <view class="flex items-center justify-between mt-30rpx">
            <view>
              <view class="font-size-22rpx color-[var(--text-inactive)]">
                {{ $t('quantitative.estYieldRate') }}
              </view>
              <view class="mt-20rpx font-size-30rpx font-500 color-[var(--color-green)]">
                {{ toFormatPercent(item.minProfitRate * 100) }} -
                {{ toFormatPercent(item.maxProfitRate * 100) }}
              </view>
            </view>
            <!--  v-if="index % 2 === 0" -->
            <image class="w-206rpx h-76rpx" src="/static/images/quantitative/green_chart.png" />
            <!-- <image v-else class="w-206rpx h-76rpx" src="/static/images/quantitative/red_chart.png" /> -->
          </view>
          <view class="flex items-center justify-between mt-20rpx">
            <view>
              <view class="font-size-22rpx color-[var(--text-inactive)]">
                {{ $t('quantitative.mdd') }}
              </view>
              <view class="mt-20rpx font-size-26rpx font-500">
                {{ toFormatPercent(item.maxDrawDown * 100) }}
              </view>
            </view>
            <view class="text-right">
              <view class="font-size-22rpx color-[var(--text-inactive)]">
                {{ $t('quantitative.minBuyHandNum') }}
              </view>
              <view class="mt-20rpx font-size-26rpx font-500">
                {{ toFormat(item.minBuyHandNum * item.handPrice, 2) }} {{ item.baseSymbol }}
              </view>
            </view>
          </view>
          <wd-button
            custom-class="mt-30rpx !rd-10rpx"
            size="large"
            block
            @click="onSubscribe(item)"
          >
            {{ $t('quantitative.subscribe') }}
          </wd-button>
        </view>
      </template>
      <!-- holdings -->
      <template v-if="tabIndex === 1">
        <history-list :list="list" @onCallback="getList" />
      </template>
      <wd-loadmore :state="loadMoreState" />
    </app-empty>
  </view>
</template>

<script lang="ts" setup>
import HistoryList from '@/pages/quantitative/components/history-list.vue'
import { fetchProductList, fetchHistoryOrder } from '@/service/quantitative'
import { formatDate } from '@/utils/day'
import { onRouter } from '@/utils'
import { toFixed, toFormat, toFormatPercent } from '@/utils/number'

const tab = ['quantitative.products', 'quantitative.holdings']
const tabIndex = ref(0)
const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
} = usePagination({
  api: (params) => {
    if (tabIndex.value === 1) {
      return fetchHistoryOrder({
        size: params.pageSize,
        current: params.pageNo,
        status: 0,
      })
    }

    return fetchProductList({
      size: params.pageSize,
      current: params.pageNo,
    })
  },
  params: {},
  onLoadMoreFn: onReachBottom,
})

const onTabChange = (index) => {
  tabIndex.value = index
  list.value = []
  getList()
}

const onSubscribe = (item) => {
  onRouter(`/pages/quantitative/detail`)
  uni.setStorageSync('quantitativeProduct', item)
}
</script>

<style lang="scss" scoped>
//
</style>
