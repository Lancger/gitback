import { defineStore } from 'pinia'
import { onRouter } from '@/utils'
import { t } from '@/locale'
import config from '@/config'

export const useTradeStore = defineStore(
  'trade',
  () => {
    const spotSymbol = ref('BTC/USDT')
    const futuresSymbol = ref('BTC/USDT')
    const futuresConfig = reactive({
      unit: '',
      unitLabel: 'PCS',
      unitList: [
        {
          label: 'USDT',
          value: 'u',
        },
        {
          label: 'futures.index.cont',
          value: 'cont',
        },
      ],
    })
    const kLineTab = ref(1)
    const mainIndicatorValue = ref('MA')
    const subIndicatorValue = ref(['VOL'])

    nextTick(() => {
      onUnitInit()
    })

    uni.onLocaleChange((res) => {
      onUnitInit()
    })

    function onUnitInit() {
      const unit = futuresConfig.unitList.find((item) => item.value === config.futuresUnit)
      Object.assign(futuresConfig, {
        unit: unit.value,
        unitLabel: unit.value === 'u' ? unit.label : t(unit.label),
      })
    }

    const onGoToTrade = (type, symbol) => {
      if (type === 'spot') {
        spotSymbol.value = symbol
        onRouter('/pages/trade/index', 'switchTab')
      }

      if (type === 'futures') {
        futuresSymbol.value = symbol
        onRouter('/pages/futures/index', 'switchTab')
      }
    }

    return {
      kLineTab,
      spotSymbol,
      futuresSymbol,
      futuresConfig,
      mainIndicatorValue,
      subIndicatorValue,
      onGoToTrade,
    }
  },
  {
    persist: true,
  },
)
