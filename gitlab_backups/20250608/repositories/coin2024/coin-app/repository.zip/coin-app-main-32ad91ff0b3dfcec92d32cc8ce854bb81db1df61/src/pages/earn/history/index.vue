<template>
  <app-navbar :title="$t('earnNew.history.title')"></app-navbar>
  <wd-tabs
    v-model="tabIndex"
    swipeable
    animated
    sticky
    :offset-top="45 - 44"
    @change="onTabsChange"
  >
    <block v-for="(item, index) in tab" :key="index">
      <wd-tab :title="item">
        <wd-skeleton
          :loading="loading"
          animation="flashed"
          :row-col="[
            { margin: '30rpx 30rpx 0', height: '200rpx', borderRadius: '20rpx' },
            { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
            { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
            { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
            { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
            { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
            { margin: '0 30rpx', height: '200rpx', borderRadius: '20rpx' },
          ]"
        >
          <app-empty :no-data="list.length === 0">
            <view
              v-for="(v, i) in list"
              :key="i"
              class="p-30rpx m-30rpx bg-[var(--background-primary)] rd-20rpx"
            >
              <view class="flex items-center justify-between">
                <view class="flex items-center gap-10rpx">
                  <image class="w-42rpx h-42rpx rd-50%" :src="v.coin_avatar" />
                  <view class="font-size-30rpx font-500">{{ v.coin_name }}</view>
                  <view
                    v-if="index === 1"
                    class="h-30rpx line-height-30rpx px-8rpx font-size-20rpx color-[var(--color-primary)] bg-#00A7ED1A rd-5rpx"
                  >
                    {{ v.day }} {{ $t('earnNew.day') }}
                  </view>
                </view>
                <view class="text-right">
                  <view class="font-size-28rpx">{{ $t('earnNew.settled') }}</view>
                  <view v-if="index === 1" class="mt-10rpx font-size-22rpx">
                    {{ formatDate(v.create_time) }}
                  </view>
                </view>
              </view>
              <view v-if="index === 0" class="py-15rpx pb-0">
                <view class="flex items-center justify-between py-15rpx font-siz-26rpx">
                  <view class="color-[var(--text-inactive)]">
                    {{ $t('earnNew.settledAmount') }}
                  </view>
                  <view>{{ v.amount }} {{ v.coin_name }}</view>
                </view>
                <!-- <view class="flex items-center justify-between py-15rpx font-siz-26rpx">
                  <view class="color-[var(--text-inactive)]">{{ $t('earnNew.earnings') }}</view>
                  <view>{{ v.profit }} {{ v.coin_name }}</view>
                </view> -->
                <view class="flex items-center justify-between py-15rpx pb-10rpx font-siz-26rpx">
                  <view class="color-[var(--text-inactive)]">
                    {{ $t('earnNew.redemptionTime') }}
                  </view>
                  <view>{{ formatDate(v.create_time) }}</view>
                </view>
              </view>
              <view v-else class="py-15rpx pb-0">
                <view class="flex items-center justify-between py-15rpx font-siz-26rpx">
                  <view class="color-[var(--text-inactive)]">
                    {{ $t('earnNew.settledAmount') }}
                  </view>
                  <view>{{ v.buy_cou }} {{ v.coin_name }}</view>
                </view>
                <view class="flex items-center justify-between py-15rpx font-siz-26rpx">
                  <view class="color-[var(--text-inactive)]">{{ $t('earnNew.earnings') }}</view>
                  <view>{{ v.profit }} {{ v.coin_name }}</view>
                </view>
                <view class="flex items-center justify-between py-15rpx pb-10rpx font-siz-26rpx">
                  <view class="color-[var(--text-inactive)]">
                    {{ $t('earnNew.redemptionTime') }}
                  </view>
                  <view>{{ formatDate(v.unlock_time) }}</view>
                </view>
              </view>
            </view>
            <wd-loadmore :state="loadMoreState" />
          </app-empty>
        </wd-skeleton>
      </wd-tab>
    </block>
  </wd-tabs>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import usePagination from '@/hooks/usePagination'
import { useUserStore } from '@/store'
import { onRouter } from '@/utils'
import { fetchFlexibleHistory, fetchFixedHistory } from '@/service/earn'
import { formatDate } from '@/utils/day'

const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
} = usePagination({
  api: (params) => {
    if (tabIndex.value === 0) {
      return fetchFlexibleHistory({
        pageNum: params.pageNo,
        pageSize: params.pageSize,
        type: 1,
      })
    } else {
      return fetchFixedHistory({
        current: params.pageNo,
        size: params.pageSize,
        orderStatus: 1,
      })
    }
  },
  params: {},
  onLoadMoreFn: onReachBottom,
  isInit: false,
})
const userStore = useUserStore()
const tab = ref([t('earnNew.flexible'), t('earnNew.fixed')])
const tabIndex = ref(0)

onLoad((options) => {
  tabIndex.value = +options.t
  getList()
})

function onFixedToDetail(data) {
  userStore.earnHistoryItemData = data
  onRouter('/pages/earn/history/detail?t=1')
}

const onTabsChange = ({ index }) => {
  tabIndex.value = index
  getList()
}
</script>

<style lang="scss" scoped>
:deep(.wd-tabs) {
  background: transparent !important;
}
.page {
  background: var(--background-secondary);
}
</style>
