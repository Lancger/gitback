<template>
  <app-navbar :title="$t('loan.cryptoLoans')">
    <template #right>
      <text
        class="i-carbon-time-filled font-size-32rpx"
        @click="onRouter('/pages/loan/history/index')"
      ></text>
    </template>
  </app-navbar>
  <view class="px-30rpx">
    <view class="mt-30rpx">
      <view class="font-size-24rpx font-500">{{ $t('loan.loanTerm') }}</view>
      <wd-select-picker
        v-model="daysValue"
        use-default-slot
        type="radio"
        :columns="daysList"
        :show-confirm="false"
        @confirm="onConfirm('days', $event)"
      >
        <view
          class="flex items-center gap-20rpx h-90rpx px-30rpx mt-30rpx rd-15rpx bg-[var(--form-item-bg)]"
        >
          <view :class="!daysValue && 'color-[gray]'" class="flex-1 font-size-28rpx font-500">
            {{ daysList.find((item) => item.value === daysValue)?.label || $t('loan.selectTerm') }}
          </view>
          <text class="i-carbon-caret-down font-size-28rpx color-[var(--text-active)]"></text>
        </view>
      </wd-select-picker>
    </view>
    <view class="mt-30rpx">
      <view class="font-size-24rpx font-500">{{ $t('loan.loan') }}</view>
      <view
        class="flex items-center gap-20rpx h-90rpx px-30rpx mt-30rpx rd-15rpx bg-[var(--form-item-bg)]"
      >
        <input
          :value="loanAmount"
          class="flex-1 font-size-28rpx font-500"
          type="digit"
          :placeholder="$t('loan.enterAmount')"
          @input="onInput('loanAmount', $event)"
        />
        <wd-select-picker
          v-model="loanValue"
          :columns="loanList"
          use-default-slot
          type="radio"
          :show-confirm="false"
          @confirm="onConfirm('loan', $event)"
        >
          <view v-if="loanValue" class="flex items-center gap-20rpx">
            <view class="flex items-center gap-20rpx flex-1">
              <image
                v-if="loanWallet.avatar"
                class="w-40rpx h-40rpx"
                :src="loanWallet.avatar"
                mode="scaleToFill"
              />
              <view class="font-size-28rpx font-600">{{ loanValue }}</view>
            </view>
            <text class="i-carbon-caret-down font-size-28rpx color-[var(--text-active)]"></text>
          </view>
          <wd-loading v-else :size="20" />
        </wd-select-picker>
      </view>
    </view>
    <view class="mt-30rpx">
      <view class="font-size-24rpx font-500">{{ $t('loan.collateral') }}</view>
      <view
        :class="pledgeWallet.balance < amount && 'border-1 border-[--color-red] border-solid'"
        class="flex items-center gap-20rpx h-90rpx px-30rpx mt-30rpx rd-15rpx bg-[var(--form-item-bg)] box-border"
      >
        <input
          :value="amount"
          class="flex-1 font-size-28rpx font-500"
          type="digit"
          :placeholder="$t('loan.enterAmount')"
          @input="onInput('amount', $event)"
        />
        <view class="font-size-28rpx font-500 color-[var(--color-primary)]" @click="onMax">
          {{ $t('common.max') }}
        </view>
        <wd-select-picker
          v-model="pledgeValue"
          :columns="walletList"
          use-default-slot
          type="radio"
          :show-confirm="false"
          @confirm="onConfirm('pledge', $event)"
        >
          <view v-if="pledgeValue" class="flex items-center gap-20rpx">
            <view class="flex items-center gap-20rpx flex-1">
              <image
                v-if="pledgeWallet.avatar"
                class="w-40rpx h-40rpx"
                :src="pledgeWallet.avatar"
                mode="scaleToFill"
              />
              <view class="font-size-28rpx font-600">{{ pledgeValue }}</view>
            </view>
            <text class="i-carbon-caret-down font-size-28rpx color-[var(--text-active)]"></text>
          </view>
          <wd-loading v-else :size="20" />
        </wd-select-picker>
      </view>
    </view>
    <view
      v-if="pledgeWallet.balance < amount"
      class="mt-20rpx font-size-22rpx font-500 color-[--color-red]"
    >
      {{ $t('loan.availableAssets') }} {{ toFormat(pledgeWallet.balance, true) }}
      {{ pledgeWallet.symbol }}
    </view>
    <view class="flex items-center justify-between mt-56rpx font-500">
      <view class="color-[var(--text-inactive)">{{ $t('loan.dailyInterestRate') }}</view>
      <view>{{ toFormatPercent((loanItem.interest_rate || 0) * 100) }}</view>
    </view>
  </view>
  <view class="mt-400rpx px-30rpx">
    <view class="mb-30rpx">
      <wd-checkbox v-model="agree" shape="square">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('loan.agree') }}
          <text
            class="color-[var(--color-primary)] underline"
            @click="onRouter('/pages/news/details?code=loanAgreement')"
          >
            {{ $t('loan.cryptoLoanServiceAgreement') }}
          </text>
        </view>
      </wd-checkbox>
    </view>
    <wd-button size="large" block :loading="loading" :disabled="disabled" @click="onSubmit">
      {{ $t('common.confirm') }}
    </wd-button>
    <view
      class="mt-30rpx text-center font-size-28rpx font-500 color-[var(--color-primary)] underline"
      @click="onRouter('/pages/loan/order/index')"
    >
      {{ $t('loan.ongoingLoanOrders') }}
    </view>
  </view>
</template>

<script lang="ts" setup>
import _ from 'lodash'
import { t } from '@/locale'
import { fetchLoanProjectList, fetchApplyLoan } from '@/service/loan'
import { fetchGetCurrencyAccount } from '@/service/assets'
import { fetchConvertExchangeRate } from '@/service/convert'
import { onRouter } from '@/utils'
import { toFormatPercent, inputLimitToDigit, toFixed, toFormat } from '@/utils/number'

const productList = ref([])
const loanAmount = ref(null)
const amount = ref(null)
const loading = ref(false)
const walletData = ref([])
const agree = ref(false)
const disabled = computed(() => {
  return (
    !loanAmount.value || !amount.value || pledgeWallet.value.balance < amount.value || !agree.value
  )
})

// 周期
const daysMap = ref({})
const daysList = computed(() => {
  return Object.keys(daysMap.value).map((key) => {
    return {
      label: String(key) + ' ' + t('loan.days'),
      value: key,
    }
  })
})
const daysValue = ref('')

// 借
const loanValue = ref('')
const loanMap = ref({})
const loanList = computed(() => {
  return Object.keys(loanMap.value).map((key) => {
    return {
      label: key,
      value: key,
    }
  })
})

// 质押
const pledgeValue = ref('')
const pledgeList = computed(() => {
  return loanMap.value[loanValue.value]?.map((item) => item.pledge_symbol)
})

const walletList = computed(() => {
  return walletData.value
    ?.filter((item) => pledgeList.value?.includes(item.symbol))
    .map((item) => {
      return {
        label: item.symbol + ' (' + item.balance + ')',
        value: item.symbol,
      }
    })
})

const loanItem = computed(() => {
  return (
    loanMap.value[loanValue.value]?.find(
      (item) => item.pledge_symbol === pledgeValue.value && item.loan_symbol === loanValue.value,
    ) || {}
  )
})

const pledgeWallet = computed(() => {
  return walletData.value.find((item) => item.symbol === pledgeValue.value) || {}
})

const loanWallet = computed(() => {
  return walletData.value.find((item) => item.symbol === loanValue.value) || {}
})

getList()
getWallet()

async function onSubmit() {
  loading.value = true
  try {
    await fetchApplyLoan({
      id: loanItem.value.id,
      number: amount.value,
    })

    onRouter(
      `/pages/loan/result?loan=${toFormat(loanAmount.value, true) + ' ' + loanValue.value}&pledge=${toFormat(amount.value, true) + ' ' + pledgeValue.value}`,
    )

    loanAmount.value = null
    amount.value = null
  } catch (error) {
    console.log(error)
  } finally {
    loading.value = false
  }
}

function onConfirm(key, e) {
  if (key === 'days') {
    daysValue.value = e.value
    //
    loanMap.value = {}
    daysMap.value[daysValue.value]?.forEach((item) => {
      if (!loanMap.value[item.loan_symbol]) {
        loanMap.value[item.loan_symbol] = []
      }
      loanMap.value[item.loan_symbol].push(item)
    })
    onConfirm('loan', { value: Object.keys(loanMap.value)[0] })
  }

  if (key === 'loan') {
    loanValue.value = e.value
    const [first] = loanMap.value[e.value]
    pledgeValue.value = first.pledge_symbol
    amount.value = null
    loanAmount.value = null
  }

  if (key === 'pledge') {
    pledgeValue.value = e.value
    loanAmount.value = null
    amount.value = null
  }
}

const onInput = _.throttle((key, e) => {
  const value =
    +inputLimitToDigit(
      e.detail.value,
      key === 'amount' ? pledgeWallet.value.base_coin_scale : loanWallet.value.base_coin_scale,
    ) || null
  if (key === 'amount') {
    amount.value = e.detail.value
    nextTick(async () => {
      amount.value = value
      const rate = await getRate()
      loanAmount.value =
        +toFixed(
          amount.value * rate * loanItem.value.pledge_rate,
          loanWallet.value.base_coin_scale,
        ) || null
    })
    return
  }

  if (key === 'loanAmount') {
    loanAmount.value = e.detail.value
    nextTick(async () => {
      loanAmount.value = value
      const rate = await getRate()
      amount.value =
        +toFixed(
          loanAmount.value / rate / loanItem.value.pledge_rate,
          pledgeWallet.value.base_coin_scale,
        ) || null
    })
  }
}, 2000)

function onMax() {
  amount.value = pledgeWallet.value.balance
  onInput('amount', { detail: { value: amount.value } })
}

function onInit() {
  productList.value.forEach((item) => {
    if (!daysMap.value[item.pledge_days]) {
      daysMap.value[item.pledge_days] = []
    }
    daysMap.value[item.pledge_days].push(item)
  })

  onConfirm('days', { value: Object.keys(daysMap.value)[0] })
}

function getList() {
  return fetchLoanProjectList({
    pageNo: 1,
    pageSize: 999,
  }).then((res) => {
    productList.value = res.data.records
    onInit()
  })
}

// 获取现货钱包
function getWallet() {
  return fetchGetCurrencyAccount({ type: 1 }).then((res) => {
    walletData.value = res.data
  })
}

// 获取汇率
function getRate() {
  return fetchConvertExchangeRate({
    fromSymbol: pledgeValue.value,
    toSymbol: loanValue.value,
  }).then((res) => {
    return res.data
  })
}
</script>

<style lang="scss" scoped>
.page {
  --form-item-bg: var(--background-secondary);
}
</style>
