<template>
  <view class="product-list">
    <view
      v-for="(item, index) in list"
      :key="index"
      class="product-list-item"
      @click="emits('click', item)"
    >
      <view
        v-if="showRank"
        :class="{
          one: index === 0,
          two: index === 1,
          three: index === 2,
        }"
        class="product-list-item__rank-on"
      >
        {{ index + 1 }}
      </view>
      <view class="product">
        <image class="product__cover" :src="item.logo" mode="aspectFit" />
        <view class="product__name">
          {{ item.symbol.split('/')[0] }}
          <text class="font-400 font-size-22rpx color-[var(--text-inactive)]">
            /{{ item.symbol.split('/')[1] }}
          </text>
        </view>
        <view class="product__right">
          <view class="product__price">
            {{ toFormat(item.price, item.base_coin_scale || item.baseCoinScale) }}
          </view>
          <view :class="[item.rate >= 0 ? 'up-color' : 'down-color']" class="product__rate">
            {{ item.rate >= 0 ? '+' : '' }}{{ item.rate }}%
          </view>
        </view>
        <view v-if="showFollow" class="mr-10rpx ml-30rpx">
          <wd-icon
            v-if="item.isFollow"
            custom-class="color-#EAB249"
            name="star-filled"
            size="38rpx"
          ></wd-icon>
          <wd-icon v-else name="star" size="38rpx"></wd-icon>
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { toFixed, toFormat, toFormatUnit } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  showRank: {
    type: Boolean,
    default: false,
  },
  showFollow: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['click'])
</script>

<style lang="scss" scoped>
.product-list {
  &-item {
    display: flex;
    align-items: center;
    padding: 20rpx 0;
    &__rank-on {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 25rpx;
      height: 25rpx;
      margin-right: 30rpx;
      font-size: 18rpx;
      color: #fff;
      white-space: nowrap;
      background: var(--color-primary);
      border-radius: 50%;
    }
    .one {
      background: linear-gradient(180deg, #ffe99f 0%, #f1c02d 100%);
    }
    .two {
      background: linear-gradient(180deg, #c5e7ff 0%, #7b9dcb 100%);
    }
    .three {
      background: linear-gradient(180deg, #dddddd 0%, #9391a6 100%);
    }
    .product {
      display: flex;
      flex: 1;
      align-items: center;
      &__cover {
        width: 56rpx;
        height: 56rpx;
        margin-right: 20rpx;
        border-radius: 50%;
      }
      &__name {
        flex: 1;
        font-size: 30rpx;
        font-weight: 500;
      }
      &__right {
        text-align: right;
      }
      &__price {
        font-size: 28rpx;
        font-weight: 500;
      }
      &__rate {
        margin-top: 10rpx;
        font-size: 26rpx;
        font-weight: 500;
      }
    }
  }
}
</style>
