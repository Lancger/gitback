<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    closable
    :zIndex="999"
    custom-style="border-radius: 20rpx 20rpx 0 0"
    @close="onClose"
  >
    <view class="p-30rpx b-b">
      <view class="flex items-center">
        <view class="mr-10rpx pr-10rpx font-size-30rpx font-500 b-r">
          {{ $t('futures.index.stopLimitPopup.title') }}
        </view>
        <view
          :class="[rowData.direction === 1 ? 'up-color' : 'down-color']"
          class="font-size-25rpx font-500"
        >
          {{ rowData.leverage }}
        </view>
      </view>
      <view
        :class="[rowData.direction === 1 ? 'up-color' : 'down-color']"
        class="mt-20rpx font-size-22rpx font-500"
      >
        {{ rowData.direction === 1 ? $t('futures.index.long') : $t('futures.index.short') }}
        {{ rowData.symbol_name }}
      </view>
    </view>
    <view class="flex flex-col gap-30rpx p-30rpx">
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('futures.index.stopLimitPopup.averagePrice') }}
        </view>
        <view class="font-500">{{ toFormat(rowData.avg_price, true) }} USDT</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('futures.index.stopLimitPopup.lastPrice') }}
        </view>
        <view class="font-500">{{ toFormat(rowData.closePrice, true) }} USDT</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">
          {{ $t('futures.index.stopLimitPopup.pl') }}(%)
        </view>
        <view :class="[rowData.pl >= 0 ? 'up-color' : 'down-color']" class="font-500">
          {{ rowData.plRatio }}
        </view>
      </view>
    </view>
    <view class="h-10rpx bg-[var(--background-gary-4)]"></view>
    <view class="p-30rpx">
      <view class="select-box">
        <view :class="{ active: sIndex === 1 }" class="select-box__item" @click="sIndex = 1">
          {{ $t('futures.index.stopLimitPopup.takeProfit') }}
        </view>
        <view :class="{ active: sIndex === 2 }" class="select-box__item" @click="sIndex = 2">
          {{ $t('futures.index.stopLimitPopup.stopLoss') }}
        </view>
        <view
          :style="{ transform: `translateX(${sIndex === 1 ? 0 : 'calc(100% - 20rpx)'})` }"
          class="select-box__block"
        ></view>
      </view>
      <view class="flex gap-16rpx mt-40rpx">
        <app-input
          v-if="isYield"
          v-model="yieldValue"
          custom-class="flex-1"
          :placeholder="$t('futures.index.stopLimitPopup.triggerYield')"
          :isPlaceholderTop="false"
          :formatter="(value) => inputLimitToDigit(value, 2)"
        >
          <template v-if="sIndex === 2" #left>-</template>
          <template #right>%</template>
        </app-input>
        <app-input
          v-else
          v-model="triggerPrice"
          custom-class="flex-1"
          :placeholder="$t('futures.index.stopLimitPopup.triggerPrice')"
          :isPlaceholderTop="false"
          :formatter="(value) => inputLimitToDigit(value, decimal)"
        >
          <template #right>USDT</template>
        </app-input>
        <!-- <wd-button :plain="!isYield" hairline :round="false" @click="isYield = !isYield">
          %
        </wd-button> -->
      </view>
      <!-- <view class="my-20rpx font-size-22rpx color-[var(--text-active)]">
        {{ $t('futures.index.stopLimitPopup.lastPLText') }} --%
      </view>
      <view class="flex gap-16rpx">
        <app-input
          v-model="limitPrice"
          custom-class="flex-1"
          :placeholder="$t('futures.index.stopLimitPopup.limitPrice')"
          :isPlaceholderTop="false"
          :formatter="(value) => inputLimitToDigit(value, decimal)"
          @onFocus="(isMarket = false), (limitPrice = '')"
        >
          <template #right>USDT</template>
        </app-input>
        <wd-button :plain="!isMarket" hairline :round="false" @click="onMarketSwitch">
          {{ $t('futures.index.stopLimitPopup.marketPrice') }}
        </wd-button>
      </view> -->
      <view class="my-20rpx font-size-22rpx color-[var(--text-active)]">
        {{ $t('futures.index.stopLimitPopup.lastPLText') }} 0.00USDT +0.00%
      </view>
      <app-input
        v-model="amount"
        :placeholder="$t('futures.index.volume')"
        :isPlaceholderTop="false"
        :formatter="(value) => inputLimitToDigit(value, BNumber(rowData.balance).dp())"
      >
        <template #right>
          <view class="flex">
            <view class="px-22rpx mr-20rpx font-size-22rpx color-[var(--text-active)] b-r">
              {{ futuresConfig.unit === 'u' ? rowData.balance_symbol : futuresConfig.unitLabel }}
            </view>
            <view class="flex items-center gap-20rpx">
              <view
                v-for="(item, index) in numList"
                :key="index"
                :class="[
                  nIndex === index ? 'color-[var(--color-primary)]' : 'color-[var(--text-active)]',
                ]"
                class="font-size-22rpx"
                @click="onSelect(index)"
              >
                {{ item.label }}
              </view>
            </view>
          </view>
        </template>
      </app-input>
      <view class="my-20rpx font-size-22rpx">
        {{ $t('futures.index.stopLimitPopup.closingBalance') }} {{ rowData.balance }}
        {{ futuresConfig.unit === 'u' ? rowData.balance_symbol : futuresConfig.unitLabel }}
      </view>
      <view class="font-size-22rpx color-[var(--text-active)]">
        {{ $t('futures.index.stopLimitPopup.tips') }}
      </view>
    </view>
    <view class="footer">
      <wd-button size="large" block :loading="loading" @click="onNext">
        {{ $t('common.confirm') }}
      </wd-button>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import Schema from 'async-validator'
import { t } from '@/locale'
import { useTradeStore } from '@/store'
import { fetchPlaceOrder } from '@/service/futures'
import { BNumber, inputLimitToDigit, toFixed, toFormat } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  rowData: {
    type: Object,
    default: () => ({}),
  },
})

const emits = defineEmits(['update:modelValue', 'onCallback'])

const { futuresConfig } = useTradeStore()

const numList = [
  {
    label: '25%',
    value: 0.25,
  },
  {
    label: '50%',
    value: 0.5,
  },
  {
    label: '75%',
    value: 0.75,
  },
  {
    label: '100%',
    value: 1,
  },
]
const nIndex = ref(-1)
const loading = ref(false)
const sIndex = ref(1)
const triggerPrice = ref(null)
const limitPrice = ref(null)
const amount = ref(null)
const isYield = ref(false)
const yieldValue = ref(null)
const isMarket = ref(false)

// 精度
const decimal = computed(() => BNumber(props.rowData.closePrice).dp() || 2)

watch(
  () => props.modelValue,
  (newValue, oldValue) => {
    isYield.value = false
    isMarket.value = true
    triggerPrice.value = props.rowData.closePrice
    limitPrice.value = null
    amount.value = null
  },
)

watch(isYield, (newValue, oldValue) => {
  if (!newValue) {
    yieldValue.value = null
    triggerPrice.value = props.rowData.closePrice
  }
})

watch(yieldValue, (newValue, oldValue) => {
  // 仓位
  const cw = BNumber(props.rowData.balance).plus(props.rowData.frozen_balance)
  // 收益=收益率/100*当前保证金
  const sy = BNumber(sIndex.value === 2 ? 0 - newValue : newValue)
    .div(100)
    .times(props.rowData.principal_amount)
  let trigger = null
  if (props.rowData.direction === 1) {
    // 触发价=收益/仓位+均价
    trigger = BNumber(sy).div(cw).plus(props.rowData.avg_price)
  } else if (props.rowData.direction === 2) {
    // 触发价=均价-收益/仓位
    trigger = BNumber(props.rowData.avg_price).minus(BNumber(sy).div(cw))
  }
  triggerPrice.value = toFixed(trigger, decimal.value)

  console.log(triggerPrice.value)
})

const onMarketSwitch = () => {
  isMarket.value = !isMarket.value
  limitPrice.value = isMarket.value ? 'Market Price' : null
}

const onNext = () => {
  const validator = new Schema({
    triggerPrice: {
      type: 'string',
      required: true,
      message: t('futures.index.stopLimitPopup.triggerPrice'),
      validator: (rule, value) => {
        return Boolean(+value)
      },
    },
    // price: {
    //   type: 'string',
    //   required: true,
    //   message: t('futures.index.stopLimitPopup.price'),
    //   validator: (rule, value) => {
    //     return Boolean(+value)
    //   },
    // },
    amount: {
      type: 'string',
      required: true,
      message: t('futures.index.volume'),
      validator: (rule, value) => {
        return Boolean(+value)
      },
    },
  })
  validator
    .validate({
      triggerPrice: triggerPrice.value,
      price: isMarket.value ? props.rowData.closePrice : limitPrice.value,
      amount: amount.value,
    })
    .then(() => {
      onSubmit()
    })
    .catch(({ errors, fields }) => {
      uni.showToast({
        icon: 'none',
        title: errors[0].message,
      })
    })
}

async function onSubmit() {
  loading.value = true
  try {
    await fetchPlaceOrder(`close/zyzs`, {
      closeLogContractOrderCode: props.rowData.order_code, // 平仓号
      triggerPrice: triggerPrice.value, // 触发价
      price: isMarket.value ? props.rowData.closePrice : limitPrice.value, // 委托价
      amount: amount.value, // 委托量
      zyzsType: sIndex.value, // 1=止盈，2=止损
      direction: props.rowData.direction === 1 ? 3 : 4, // 方向
    })
    onClose()
    emits('onCallback')
    loading.value = false
  } catch (e) {
    onClose()
    loading.value = false
  }
}

const onSelect = (i) => {
  const num = Number(BNumber(props.rowData.balance).times(numList[i].value))
  nIndex.value = i
  amount.value = futuresConfig.unit === 'u' ? num : Math.floor(num)
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.select-box {
  position: relative;
  display: flex;
  align-items: center;
  padding: 10rpx;
  background: var(--background-gary-4);
  border-radius: 100rpx;
  &__item {
    position: relative;
    z-index: 2;
    flex: 1;
    height: 64rpx;
    font-size: 30rpx;
    font-weight: 500;
    line-height: 64rpx;
    text-align: center;
    transition: all 0.3s;
  }
  &__item.active {
    color: #fff;
  }
  &__block {
    position: absolute;
    top: 10rpx;
    left: 10rpx;
    z-index: 1;
    width: 50%;
    height: 64rpx;
    background: var(--color-primary);
    border-radius: 100rpx;
    transition: all 0.3s;
  }
}
.footer {
  padding: 20rpx 30rpx;
  box-shadow: var(--box-shadow);
}
</style>
