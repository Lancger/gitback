<template>
  <app-navbar title="History" />
  <app-empty :no-data="list.length === 0">
    <view class="px-30rpx">
      <history-list :list="list" @onCallback="getList" />
      <wd-loadmore :state="loadMoreState" />
    </view>
  </app-empty>
</template>

<script lang="ts" setup>
import HistoryList from '@/pages/quantitative/components/history-list.vue'
import { fetchHistoryOrder } from '@/service/quantitative'
import { formatDate } from '@/utils/day'
import { onRouter } from '@/utils'

const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
} = usePagination({
  api: (params) => {
    return fetchHistoryOrder({
      size: params.pageSize,
      current: params.pageNo,
      status: '',
    })
  },
  params: {},
  onLoadMoreFn: onReachBottom,
})
</script>

<style lang="scss" scoped>
.page {
  background-color: var(--background-secondary);
}
</style>
