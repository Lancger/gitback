<template>
  <!-- <iframe class="w-100% h-100% border-none" src="/hybrid/html/index.html"></iframe> -->
  <view class="k-line-chart">
    <view class="b-b">
      <wd-segmented :options="list" v-model:value="idx">
        <template #label="{ option }">
          <view>{{ option.payload.title }}</view>
        </template>
      </wd-segmented>
      <view class="flex items-center justify-between">
        <view class="chart-tab">
          <view
            v-for="(item, index) in tab"
            :key="index"
            :class="{ 'in-active': index === tradeStore.kLineTab }"
            class="chart-tab__item"
            @click="onTab(index)"
          >
            {{ item.title }}
          </view>
        </view>
        <view
          v-if="idx === 0"
          class="i-carbon-function-math font-size-30rpx px-30rpx"
          @click="showIndicator = true"
        ></view>
      </view>
    </view>
    <view v-if="idx === 0 && precision" class="w-100% h-[calc(100%-134rpx)] border-none">
      <k-line-base
        :key="url"
        :symbol="symbol"
        :topicSymbol="topicSymbol"
        :tradeType="kType"
        :precision="precision"
        :interval="tab[tradeStore.kLineTab].value"
        :isTime="tradeStore.kLineTab === 0 || showLine"
        :showVol="showVol"
        :showMA="showMA"
      ></k-line-base>
    </view>
    <iframe
      v-if="idx === 1"
      :src="url"
      :key="url"
      class="w-100% h-[calc(100%-134rpx)] border-none"
    ></iframe>
  </view>

  <!-- 技术指标设置 -->
  <k-line-indicator-popup v-model="showIndicator"></k-line-indicator-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { useTradeStore, useThemeStore } from '@/store'
import { subscribeMode } from '@/utils/subscribe'
import config from '@/config'

const props = defineProps({
  symbol: {
    type: String,
    default: 'BTC/USDT',
  },
  kType: {
    type: String,
    default: 'ubw',
  },
  precision: {
    type: Number,
    default: 2,
  },
  chartStyle: {
    type: Number,
    default: 1,
  },
  showVol: {
    type: Boolean,
    default: true,
  },
  showMA: {
    type: Boolean,
    default: true,
  },
  showLine: {
    type: Boolean,
    default: false,
  },
  topicSymbol: {
    type: String,
    default: '',
  },
})

const tradeStore = useTradeStore()
const themeStore = useThemeStore()
const list = computed(() => {
  return [
    {
      value: 0,
      payload: {
        title: t('common.kLineBase'),
      },
    },
    {
      value: 1,
      payload: {
        title: 'TradingView',
      },
    },
  ]
})
const idx = ref(0)
const showIndicator = ref(false)

const BASE_URL =
  process.env.NODE_ENV === 'production' ? '/hybrid/html/index.html' : 'http://127.0.0.1:8080'
const url = ref(BASE_URL)

const tab = [
  {
    title: 'Time',
    value: '1',
  },
  {
    title: '1m',
    value: '1',
  },
  {
    title: '5m',
    value: '5',
  },
  {
    title: '15m',
    value: '15',
  },
  {
    title: '30m',
    value: '30',
  },
  {
    title: '1H',
    value: '60',
  },
  {
    title: '1D',
    value: '1D',
  },
  {
    title: '1W',
    value: '1W',
  },
  {
    title: '1M',
    value: '1M',
  },
]

onInitUrl()

watch(
  () => props.symbol,
  () => {
    onInitUrl()
  },
)

const onTab = (i) => {
  tradeStore.kLineTab = i
  onInitUrl()
}

function onInitUrl() {
  const urlParameters = {
    i: tab[tradeStore.kLineTab].value,
    s: props.symbol,
    ts: props.topicSymbol,
    p: props.precision,
    t: props.kType,
    v: props.showVol ? 1 : 0,
    ma: props.showMA ? 1 : 0,
    style: props.showLine ? props.chartStyle : tradeStore.kLineTab === 0 ? 3 : props.chartStyle,
    theme: themeStore.theme,
    mode: subscribeMode,
    d: config.decimalSeparator,
    g: config.groupingSeparator,
    ymd: `${config.dateFormat.YMD}|${config.dateFormat.HM}|`,
  }
  const query = Object.keys(urlParameters)
    .map((name) => `${name}=${encodeURIComponent(urlParameters[name])}`)
    .join('&')
  url.value = `${BASE_URL}?${query}`
}
</script>

<style lang="scss" scoped>
.k-line-chart {
  width: 100%;
  height: 100%;
  background: var(--background-primary);
  // :deep(.wd-segmented) {
  //   background: var(--background-gary-4);
  // }
  // :deep(.wd-segmented__item--active) {
  //   background: var(--color-primary);
  // }
  // :deep(.wd-segmented__item.is-active) {
  //   color: #fff;
  // }
  .chart-tab {
    display: flex;
  }
  .chart-tab__item {
    position: relative;
    height: 70rpx;
    padding: 0 15rpx;
    font-size: 22rpx;
    font-weight: 600;
    line-height: 70rpx;
    text-align: center;
  }
  .chart-tab__item.in-active {
    font-weight: 500;
    color: var(--color-primary);
  }
  .chart-tab__item.in-active::after {
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 50%;
    height: 1px;
    content: '';
    background: var(--color-primary);
    transform: translateX(-50%);
  }
}
</style>
