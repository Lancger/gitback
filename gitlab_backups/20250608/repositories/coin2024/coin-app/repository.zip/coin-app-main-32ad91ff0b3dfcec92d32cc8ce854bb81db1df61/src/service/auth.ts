import { http } from '@/utils/http'

/** 授权 */
export const fetchAuth = (query: any) => {
  return http({
    url: '/api/blade-auth/oauth/token',
    header: {
      Authorization: 'Basic bWVtYmVyOm1lbWJlcl9zZWNyZXQ=',
    },
    method: 'POST',
    query,
  })
}

// 忘记密码
export const fetchForgetPassword = (data: any) => {
  return http.post('/api/mjkj-web/coin/open/reset-password', data)
}

// 校验邀请码
export const fetchCheckInviteCode = (code) => {
  return http.get(`/api/mjkj-web/coin/open/isInviteCodeExists?invitationCode=${code}`)
}
