<template>
  <app-navbar :title="$t('theme.title')"></app-navbar>
  <view>
    <view
      v-for="(item, index) in list"
      :key="index"
      class="flex items-center justify-between h-100rpx px-30rpx b-b"
      @click="onSwitch(item.value)"
    >
      <view class="font-size-28rpx font-500">{{ $t(item.label) }}</view>
      <wd-checkbox :model-value="themeStore.theme === item.value"></wd-checkbox>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { useThemeStore } from '@/store'

const themeStore = useThemeStore()

const list = [
  {
    label: 'theme.light',
    value: 'light',
  },
  {
    label: 'theme.dark',
    value: 'dark',
  },
  {
    label: 'theme.blue',
    value: 'blue',
  },
]

const onSwitch = (theme) => {
  themeStore.switchTheme(theme)
}
</script>

<style lang="scss" scoped>
:deep(.wd-checkbox__label) {
  display: none;
}
</style>
