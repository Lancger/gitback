<template>
  <view v-if="myBillDataList.length > 0">
    <view class="cell" v-for="(v, i) in myBillDataList" :key="i">
      <view class="flex-jc">
        <view class="flex">
          <image class="w-50rpx h-50rpx img" :src="v.avatar" mode="aspectFit" />
          <view class="title">{{ v.coin_symbol }}</view>
          <view class="market buy up-color" v-if="v.type == 4">buy</view>
          <view class="market sell down-color" v-else-if="v.type == 5">sell</view>
        </view>
        <view
          class="coin"
          :class="{
            red: +v.type === 1,
          }"
        >
          {{ +v.type === 1 ? '-' : '+' }}{{ toFormat(v.amount, true) }}
        </view>
      </view>
      <view class="market f5">
        {{ v.remark }}
        <text v-if="+v.fee_amount">{{ $t('assets.bills.fee') }} {{ v.fee_amount || 0 }}</text>
      </view>

      <view class="flex-jc mt4">
        <view class="time">{{ formatDate(v.create_time) }}</view>
        <view class="time">
          <text class="ml-2">
            {{ $t('assets.bills.balance') }} {{ toFormat(v.member_after_balance, true) }}
          </text>
        </view>
      </view>
    </view>
  </view>

  <!-- <view class="norecord" v-else>
    <image class="w300rpx h177rpx" src="@/static/images/assets/norecord.png" mode="aspectFit" />
    <view class="norecord_text">No record</view>
  </view> -->
  <app-empty v-else :no-data="true"></app-empty>
</template>
<script lang="ts" setup>
import { formatDate } from '@/utils/day'
import { toFormat } from '@/utils/number'

const props = defineProps({
  myBillDataList: {
    type: Object,
    default: () => {
      return {}
    },
  },
})
</script>
<style lang="scss" scoped>
.cell {
  box-sizing: border-box;
  width: 690rpx;
  padding: 20rpx;
  margin: 20rpx auto;
  background-color: var(--background-primary);
  border-radius: 20rpx;
  .flex-jc {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  .flex {
    display: flex;
    align-items: center;
  }
  .market {
    display: flex;
    justify-content: space-between;
    margin-top: 20rpx;
    font-size: 20rpx;
    border-radius: 5rpx;
    text {
      color: var(--text-inactive);
    }
  }
  .buy {
    background-color: #07ba831a;
  }
  .sell {
    background-color: #ff4e431a;
  }
  .img {
    margin-right: 20rpx;
  }
  .title {
    font-family: Asap;
    font-size: 28rpx;
    font-weight: 500;
  }
  .coin {
    font-family: Asap;
    font-size: 26rpx;
    color: #07ba83;
    // color: #FF4E43;
  }
  .cost {
    margin-top: 10rpx;
    color: var(--text-inactive);
    text-align: right;
  }
  .time {
    font-size: 22rpx;
    color: var(--text-inactive);
  }
}

.norecord {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  &_text {
    margin-top: 30rpx;
    color: var(--text-inactive) !important;
    text-align: center;
  }
}

.red {
  color: var(--color-red) !important;
}
</style>
