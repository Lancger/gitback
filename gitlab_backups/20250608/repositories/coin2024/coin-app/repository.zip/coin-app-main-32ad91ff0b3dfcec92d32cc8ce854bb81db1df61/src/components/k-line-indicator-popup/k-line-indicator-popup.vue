<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    :z-index="99"
    custom-style="border-radius: 30rpx 30rpx 0 0"
    @close="onClose"
  >
    <view class="py-30rpx">
      <view class="text-center font-size-32rpx font-700">Indicator</view>
      <scroll-view scroll-y class="max-h-60vh">
        <view class="px-30rpx mt-30rpx font-size-28rpx font-500">Main Indicator</view>
        <wd-radio-group
          :model-value="tradeStore.mainIndicatorValue"
          cell
          shape="button"
          @change="onChange"
        >
          <wd-radio v-for="(item, index) in mainList" :key="index" :value="item">
            {{ item }}
          </wd-radio>
        </wd-radio-group>
        <view class="px-30rpx font-size-28rpx font-500">Sub Indicator</view>
        <wd-checkbox-group v-model="tradeStore.subIndicatorValue" cell shape="button">
          <wd-checkbox v-for="(item, index) in subList" :key="index" :modelValue="item">
            {{ item }}
          </wd-checkbox>
        </wd-checkbox-group>
      </scroll-view>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { useTradeStore } from '@/store'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
})

const emits = defineEmits(['update:modelValue'])

const tradeStore = useTradeStore()

const mainList = ['MA', 'EMA', 'SMA', 'BOLL', 'SAR', 'BBI']
const subList = [
  'MA',
  'EMA',
  'VOL',
  'MACD',
  'BOLL',
  'KDJ',
  'RSI',
  'BISA',
  'BRAR',
  'CCI',
  'DMI',
  'CR',
  'PSY',
  'DMA',
  'TRIX',
  'OBV',
  'VR',
  'WR',
  'MTM',
  'EMV',
  'SAR',
  'SMA',
  'ROC',
  'PVT',
  'BBI',
  'AO',
]

const onChange = ({ value }) => {
  if (tradeStore.mainIndicatorValue === value) {
    tradeStore.mainIndicatorValue = ''
    return
  }
  tradeStore.mainIndicatorValue = value
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped></style>
