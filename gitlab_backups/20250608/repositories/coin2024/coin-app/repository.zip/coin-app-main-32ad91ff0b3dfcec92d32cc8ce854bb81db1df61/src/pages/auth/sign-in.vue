<template>
  <app-navbar custom-class="!bg-transparent" :left-arrow="false" :placeholder="false">
    <template #right>
      <image
        class="w-56rpx h-56rpx"
        :src="onImageToThemeImage('/static/images/user/theme.png')"
        @click="onRouter('/pages/theme/index')"
      ></image>
      <image
        class="w-56rpx h-56rpx ml-20rpx"
        :src="onImageToThemeImage('/static/images/user/language.png')"
        @click="onRouter('/pages/language/index')"
      ></image>
    </template>
  </app-navbar>
  <wd-img
    custom-class="!block mx-auto mt-180rpx rd-20rpx overflow-hidden"
    width="240rpx"
    height="240rpx"
    :src="logo || '/static/logo.png'"
  ></wd-img>
  <view class="px-30rpx pb-200rpx">
    <tab-box v-if="isTab" v-model="tabsIndex" :list="tabs" />
    <wd-form
      :custom-class="`auth-form ${isTab ? 'mt-50rpx' : 'mt-150rpx'}`"
      ref="form"
      :model="model"
      :rules="modelRules"
    >
      <wd-input
        v-model.trim="model.account"
        prop="account"
        no-border
        clearable
        :use-prefix-slot="isPhone"
        :placeholder="accountPlaceholder"
      >
        <template #prefix>
          <area-select-picker @on-confirm="onSelectPickerConfirm">
            <view class="center font-size-26rpx font-500">
              <view class="mr-10rpx">+{{ model.areaCode }}</view>
              <wd-icon name="arrow-down" size="26rpx"></wd-icon>
            </view>
          </area-select-picker>
        </template>
      </wd-input>
      <wd-input
        v-model.trim="model.password"
        prop="password"
        no-border
        show-password
        clearable
        :placeholder="$t('auth.password')"
      />
      <view v-if="config.authRememberPassword" class="mb-30rpx">
        <wd-checkbox v-model="rememberPassword" shape="square" @change="onRememberPasswordChange">
          {{ $t('auth.rememberPassword') }}
        </wd-checkbox>
      </view>
      <view>
        <wd-button type="primary" size="large" :loading="loading" block @click="handleSubmit">
          {{ $t('auth.signIn') }}
        </wd-button>
      </view>
    </wd-form>
    <wd-button
      custom-class="mt-20rpx !bg-transparent"
      type="info"
      size="large"
      block
      @click="onRouter('/pages/auth/forget-password')"
    >
      {{ $t('auth.forgetPassword') }}?
    </wd-button>
    <!-- <view class="link-box">
      <view class="link">Forget Password</view>
      <view>
        No account yet?
        <text class="link">Sign up</text>
      </view>
    </view> -->
    <!-- <view class="tip">
      <wd-checkbox
        v-model="tip"
        size="large"
        custom-class="!flex !flex-items-center"
        custom-label-class="label-class"
      >
        I have read and agreed to the
        <text class="tip__link" @click.stop>User Agreement</text>
        and
        <text class="tip__link" @click.stop>Privacy Policy</text>
      </wd-checkbox>
    </view> -->
  </view>
  <app-footer>
    <view class="p-30rpx">
      <!-- <view class="mt-350rpx"> -->
      <wd-button type="info" plain size="large" block @click="onRouter('/pages/auth/sign-up')">
        {{ $t('auth.signUp') }}
      </wd-button>
      <!-- </view> -->
      <view class="tip" @click="closeOutside">
        <wd-popover
          :model-value="showPopover"
          disabled
          :content="$t('auth.rules.agreement')"
          placement="top"
        >
          <wd-checkbox
            v-model="tip"
            size="large"
            custom-class="!flex !flex-items-center"
            custom-label-class="label-class"
          >
            {{ $t('auth.agreementText') }}
            <text class="tip__link" @click.stop="onRouter(`/pages/news/details?code=A2`)">
              {{ $t('auth.userAgreement') }}
            </text>
            {{ $t('auth.and') }}
            <text class="tip__link" @click.stop="onRouter(`/pages/news/details?code=A3`)">
              {{ $t('auth.privacyPolicy') }}
            </text>
          </wd-checkbox>
        </wd-popover>
      </view>
    </view>
  </app-footer>
</template>

<script lang="ts" setup>
import { useQueue } from 'wot-design-uni'
import TabBox from './components/tab-box.vue'
import { t } from '@/locale'
import { useUserStore, useSystemStore, useThemeStore } from '@/store'
import { onImageToThemeImage, onRouter } from '@/utils'
import { validEmail, validPassword, validPhone } from '@/utils/validate'
import useAuth from './hook/useAuth'
import config from '@/config'

const { tabs, tabsIndex, isTab } = useAuth()
const userStore = useUserStore()
const systemStore = useSystemStore()
const themeStore = useThemeStore()
const { closeOutside } = useQueue()

const rememberPassword = ref(uni.getStorageSync('rememberPassword') || false)

const logo = computed(() =>
  themeStore.isDark ? systemStore.systemConfig.darkLogo : systemStore.systemConfig.lightLogo,
)
const model = reactive({
  tenantId: '000000',
  scope: 'all',
  type: 'account',
  grant_type: 'member',
  loginType: 'login',
  deviceId: '123abc456def789ghi',
  account: '',
  email: '',
  emailCode: '',
  phone: '',
  phoneCode: '',
  areaCode: import.meta.env.VITE_AREACODE,
  password: '',
  step: 2,
})
const modelRules: any = computed(() => {
  return {
    account: [
      { required: true, message: t('auth.account') },
      {
        required: false,
        validator: (value) => {
          if (isPhone.value && !validPhone(value)) {
            return Promise.reject(t('auth.rules.phone'))
          }
          if (!isPhone.value && !validEmail(value)) {
            return Promise.reject(t('auth.rules.email'))
          }
          return Promise.resolve()
        },
      },
    ],
    password: [
      { required: true, message: t('auth.password') },
      // {
      //   required: false,
      //   validator: (value) => {
      //     if (!validPassword(value)) {
      //       return Promise.reject('6-20 digit password letters + numbers')
      //     }
      //     return Promise.resolve()
      //   },
      // },
    ],
  }
})
const form = ref(null)
const tip = ref(true)
const loading = ref(false)
const showPopover = ref(false)

const isPhone = computed(() =>
  isTab.value ? tabsIndex.value === 0 : /^\d{3,}$/.test(model.account),
)
const accountPlaceholder = computed(() => {
  return isTab.value ? (isPhone.value ? t('auth.phone') : t('auth.email')) : t('auth.account')
})

watch(tip, (newVal) => {
  showPopover.value = !newVal
})

watchEffect(() => {
  if (isPhone.value) {
    model.phone = model.account
    model.email = ''
  } else {
    model.email = model.account
    model.phone = ''
  }
})

if (rememberPassword.value) {
  const loginAccount = uni.getStorageSync('loginAccount') || {}
  model.account = loginAccount?.account
  model.password = loginAccount?.password
  model.areaCode = loginAccount?.areaCode || import.meta.env.VITE_AREACODE
}

const onRememberPasswordChange = () => {
  uni.setStorageSync('rememberPassword', rememberPassword.value)
  if (rememberPassword.value) {
    uni.setStorageSync('loginAccount', null)
  }
}

const onSelectPickerConfirm = (e) => {
  model.areaCode = e.code
}

function handleSubmit() {
  form.value
    .validate()
    .then(({ valid, errors }) => {
      if (valid) {
        if (!tip.value) {
          showPopover.value = true
          return
        }
        loading.value = true
        const form = { ...model }
        delete form.account
        userStore
          .onAuth(form)
          .then((res: any) => {
            if (res.error_description === '步骤1登录成功') {
              onRouter('/pages/auth/two-factor?t=auth')
            } else {
              onRouter('/pages/home/index', 'reLaunch')
            }

            if (rememberPassword.value) {
              uni.setStorageSync('loginAccount', {
                account: model.account,
                password: model.password,
                areaCode: model.areaCode,
              })
            }
          })
          .finally(() => {
            loading.value = false
          })
      }
    })
    .catch((error) => {
      console.log(error, 'error')
    })
}
</script>

<style lang="scss" scoped>
:deep(.wd-navbar__left) {
  display: none !important;
}
:deep(.app-footer-bar__main) {
  position: absolute;
}
.tip {
  display: flex;
  justify-content: center;
  margin: 30rpx 0 0;
  &__link {
    color: var(--text-primary);
    text-decoration: underline;
  }
  :deep(.label-class) {
    font-size: 20rpx !important;
    color: var(--text-secondary) !important;
  }
  :deep(.wd-checkbox__shape) {
    flex-shrink: 0 !important;
  }
  :deep(.wd-checkbox__txt) {
    word-break: break-all !important;
  }
}
.link-box {
  display: flex;
  justify-content: space-between;
  margin: 30rpx 0;
  .link {
    font-size: 26rpx;
    font-weight: 500;
    color: var(--color-primary);
  }
}

.page {
  background: var(--background-primary) var(--auth-bg) no-repeat;
  background-size: 100% 744rpx;
}
</style>
