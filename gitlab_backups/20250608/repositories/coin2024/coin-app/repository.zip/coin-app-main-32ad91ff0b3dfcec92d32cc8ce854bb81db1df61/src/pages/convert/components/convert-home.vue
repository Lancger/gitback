<template>
  <view class="px-30rpx py-40rpx min-h-100vh bg-[var(--background-primary)]">
    <view class="h-228rpx p-30rpx bg-[var(--background-gary-4)] rd-30rpx box-border">
      <view class="flex items-center justify-between">
        <view class="font-size-24rpx font-500">{{ $t('convert.from') }}</view>
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('convert.available') }} {{ balance }} {{ fromItem.symbol }}
        </view>
      </view>
      <view class="flex items-center justify-between mt-30rpx">
        <view
          class="flex items-center gap-10rpx font-size-30rpx font-600"
          @click="onShowSelectToken('from')"
        >
          <template v-if="fromItem.symbol">
            <image class="w-40rpx h-40rpx rd-50% overflow-hidden" :src="fromItem.avatar" />
            <view>{{ fromItem.symbol }}</view>
          </template>
          <text class="i-carbon-caret-down color-[var(--text-active)]"></text>
        </view>
        <view class="flex-1 center ml-30rpx">
          <input
            v-model="form.from"
            class="font-size-40rpx font-600 text-right pr-30rpx"
            type="digit"
            :placeholder="$t('convert.amount')"
            @input="onInput('from', fromItem.coin_coin_scale, $event)"
          />
          <wd-button
            type="info"
            plain
            size="small"
            custom-class="!h-42rpx font-size-22rpx"
            @click="onMax"
          >
            {{ $t(`common.max`) }}
          </wd-button>
        </view>
      </view>
      <view v-if="+form.from > +balance" class="flex items-center justify-end mt-10rpx">
        <view class="mr-20rpx font-size-22rpx color-[var(--color-red)]">
          {{ $t('convert.insufficientBalance') }}
        </view>
        <wd-button
          type="info"
          plain
          size="small"
          custom-class="!h-40rpx font-size-22rpx !m-0"
          @click="onRouter('/pages/asset/deposit/index')"
        >
          {{ $t('convert.deposit') }}
        </wd-button>
      </view>
    </view>
    <!--  -->
    <view
      class="relative z-2 center m-auto mt-[-20rpx] w-80rpx h-80rpx bg-[var(--color-primary)] rd-50%"
      @click="onTransform"
    >
      <text class="i-carbon-arrows-vertical font-size-40rpx font-700 color-#fff"></text>
    </view>
    <!--  -->
    <view class="h-228rpx p-30rpx mt-[-20rpx] bg-[var(--background-gary-4)] rd-30rpx box-border">
      <view class="flex items-center justify-between">
        <view class="font-size-24rpx font-500">{{ $t('convert.to') }}</view>
      </view>
      <view class="flex items-center justify-between mt-40rpx">
        <view
          class="flex items-center gap-10rpx font-size-30rpx font-600"
          @click="onShowSelectToken('to')"
        >
          <template v-if="toItem.symbol">
            <image class="w-40rpx h-40rpx rd-50% overflow-hidden" :src="toItem.avatar" />
            <view>{{ toItem.symbol }}</view>
          </template>
          <wd-loading v-else :size="20" />
          <text class="i-carbon-caret-down color-[var(--text-active)]"></text>
        </view>
        <view class="flex-1 ml-30rpx">
          <input
            v-model="form.to"
            class="font-size-40rpx font-600 text-right"
            type="digit"
            :placeholder="$t('convert.amount')"
            @input="onInput('to', toItem.coin_coin_scale, $event)"
          />
        </view>
      </view>
    </view>
    <!--  -->
    <view class="mt-30rpx text-center font-size-22rpx color-[var(--text-inactive)]">
      1 {{ fromItem.symbol }} ≈ {{ toFormat(rate, true) }} {{ toItem.symbol }}
    </view>
    <!--  -->
    <wd-button
      custom-class="!w-100% mt-60rpx"
      size="large"
      :disabled="disabled"
      @click="showConfirmOrder = true"
    >
      {{ $t('common.confirm') }}
    </wd-button>
    <!--  -->
    <view
      class="mt-60rpx font-size-24rpx font-500 text-center underline"
      @click="onRouter('/pages/convert/history')"
    >
      {{ $t('convert.record') }}
    </view>
  </view>

  <!-- 选择币种 -->
  <select-token-popup
    v-model="showSelectToken"
    :list="tokenList"
    select
    selectKey="symbol"
    :selectValue="selectValue"
    @onSelect="onSelectToken"
  ></select-token-popup>

  <!-- 确认订单 -->
  <ConvertConfirmOrder
    v-model="showConfirmOrder"
    :data="{
      from: {
        ...fromItem,
        val: form.from,
      },
      to: {
        ...toItem,
        val: form.to,
      },
    }"
    @onCallback="onSubmitCallback"
  />
</template>

<script lang="ts" setup>
import ConvertConfirmOrder from './convert-confirm-order.vue'
import { onRouter } from '@/utils'
import { inputLimitToDigit, toFixed, toFormat } from '@/utils/number'
import {
  fetchConvertTokenList,
  fetchConvertExchangeRate,
  fetchConvertSubmit,
} from '@/service/convert'
import { fetchWalletToken } from '@/service/assets'

const showSelectToken = ref(false)
const selectType = ref('from')
const selectValue = ref('')
const form = reactive({
  from: undefined,
  to: undefined,
})
const fromItem = ref<any>({})
const toItem = ref<any>({})
const tokenList = ref([])
const balance = ref(0)
const rate = ref(0)
const showConfirmOrder = ref(false)
const disabled = computed(() => !Number(form.from) && !Number(form.to))

watch(
  () => fromItem.value,
  () => {
    getTokenBalance()
  },
)

getTokenList()

onShow(() => {
  if (fromItem.value.symbol) {
    getTokenBalance()
  }
})

const onMax = () => {
  form.from = balance.value
  nextTick(() => {
    form.to = +toFixed(form.from * rate.value, 8) || ''
  })
}

function onSubmitCallback() {
  getTokenBalance()
  form.from = ''
  form.to = ''
}

const onShowSelectToken = (type) => {
  selectType.value = type
  selectValue.value = type === 'from' ? fromItem.value.symbol : toItem.value.symbol
  showSelectToken.value = true
}

const onSelectToken = async (e) => {
  if (selectType.value === 'from') {
    if (e.symbol === toItem.value.symbol) {
      toItem.value = fromItem.value
    }
    fromItem.value = e
  }

  if (selectType.value === 'to') {
    if (e.symbol === fromItem.value.symbol) {
      fromItem.value = toItem.value
    }
    toItem.value = e
  }

  await getRate()
  form.to = +toFixed(form.from * rate.value, 8) || ''
}

function onInput(type, dec, e) {
  const value = inputLimitToDigit(e.detail.value, dec)
  nextTick(() => {
    form.from = type === 'from' ? value : +toFixed(form.to / rate.value, 8) || '' // fromItem.value.coin_coin_scale
    form.to = type === 'to' ? value : +toFixed(form.from * rate.value, 8) || '' // toItem.value.coin_coin_scale
  })
}

function getRate() {
  return fetchConvertExchangeRate({
    fromSymbol: fromItem.value.symbol,
    toSymbol: toItem.value.symbol,
  }).then((res) => {
    rate.value = res.data
  })
}

function onTransform() {
  const from = fromItem.value
  const fromVal = form.from
  form.from = form.to
  form.to = fromVal
  fromItem.value = toItem.value
  toItem.value = from
  getRate()
}

function getTokenBalance() {
  return fetchWalletToken(fromItem.value.symbol).then((res) => {
    balance.value = res.data.wealthBalance
  })
}

function getTokenList() {
  return fetchConvertTokenList().then((res) => {
    tokenList.value = res.data.map((item) => {
      return {
        ...item,
        symbolName: item.symbol,
      }
    })
    fromItem.value = tokenList.value.find((item) => item.symbol === 'USDT') || tokenList.value[0]
    // toItem.value = tokenList.value.find((item) => item.symbol === 'BTC') || res.data[1]
    toItem.value =
      tokenList.value.find((item) => item.symbol === 'BTC') ||
      tokenList.value.filter((item) => item.id !== fromItem.value.id)[0] ||
      {}
    getRate()
  })
}
</script>

<style lang="scss" scoped></style>
