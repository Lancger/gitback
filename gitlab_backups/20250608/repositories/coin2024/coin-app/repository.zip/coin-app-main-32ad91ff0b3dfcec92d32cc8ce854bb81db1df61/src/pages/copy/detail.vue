<template>
  <app-navbar :title="$t('copy.detail')"></app-navbar>
  <!-- info  -->
  <order-list showBtns :list="[productData]" @onEnd="onBack" />
  <!-- tabs  -->
  <wd-tabs
    v-if="productData.follow_mode === 2"
    custom-class="app-tabs--no-flex-1"
    v-model="tabIndex"
    swipeable
    animated
    :map-num="100"
    :slidable-num="2"
    @change="onTabChange"
  >
    <block v-for="(item, index) in tabs" :key="index">
      <wd-tab :title="item.label" :name="item.value">
        <!-- 持仓 -->
        <app-empty
          v-if="item.value === 'position'"
          :no-data="list.length === 0"
          custom-class="h-50vh"
        >
          <trade-position-list
            :list="list"
            :showReverse="false"
            :showShare="false"
            @onEvent="onPositionEvent"
          ></trade-position-list>
        </app-empty>
        <!-- 持仓 -->
        <app-empty
          v-if="item.value === 'tradeHistory'"
          :no-data="list.length === 0"
          custom-class="h-50vh"
        >
          <trade-history-list
            :list="list"
            mode="make"
            tradeMode="futures"
            :showShare="false"
          ></trade-history-list>
          <wd-loadmore :state="loadMoreState" />
        </app-empty>
      </wd-tab>
    </block>
  </wd-tabs>

  <!-- 平仓 -->
  <close-position-popup
    v-model="showClosePositionPopup"
    :row-data="positionRowData"
    @onCallback="
      () => {
        getList()
      }
    "
  ></close-position-popup>
  <!-- TP/SL -->
  <stop-limit-popup
    v-model="showStopLimitPopup"
    :row-data="positionRowData"
    @onCallback="() => {}"
  ></stop-limit-popup>
</template>

<script lang="ts" setup>
import OrderList from './components/order-list.vue'
import closePositionPopup from '../futures/components/close-position-popup.vue'
import stopLimitPopup from '../futures/components/stop-limit-popup.vue'
import { fetchFuturesPosition } from '@/service/futures'
import { fetchGetFutures } from '@/service/market'
import { fetchOrderRecords } from '@/service/trade'
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'
import { BNumber, toFixed, toFormatPercent } from '@/utils/number'
import { useTradeStore } from '@/store'
import { t } from '@/locale'

const tradeStore = useTradeStore()
const tabs = ref([
  // { label: 'Position history', value: 'positionHistory' },
  { label: t('copy.tradeHistory'), value: 'tradeHistory' },
  // { label: 'Profit sharing record', value: 2 },
])
const tabIndex = ref('tradeHistory')
const productData = ref(uni.getStorageSync('copyOrder'))
const positionList = ref([])
const positionRowData = ref(null)
const showStopLimitPopup = ref(false)
const showClosePositionPopup = ref(false)
const futuresList = ref<any>([])

const futuresUnit = computed(() => tradeStore.futuresConfig.unit)

const {
  data: list,
  loadMoreState,
  loading,
  onInit: getList,
  onLoadMore,
} = usePagination({
  api: (params) => {
    if (tabIndex.value === 'tradeHistory') {
      return fetchOrderRecords({
        size: params.pageSize,
        current: params.pageNo,
        currentType: 'ubw',
        entrustType: null,
        jhwtType: null,
        symbolName: '',
        tradeType: '',
        type: 6,
        isShowRevoke: null,
        followId: productData.value.leader_id,
      }).then((res) => {
        res.data.records = res.data.records.map((item) => {
          console.log(toFixed((+item.profit * 100) / item.bzj))
          return {
            ...item,
            plRatio: `${toFormatPercent((+item.profit * 100) / item.bzj)}`,
          }
        })

        return res
      })
    }

    return fetchFuturesPosition('ubw', {
      followId: productData.value.leader_id,
    }).then((res) => {
      res.data = res.data.map((item) => {
        return {
          ...item,
          leverage: item.leverage.toUpperCase(),
        }
      })
      return res
    })
  },
  params: {},
  isInit: false,
})

onLoad(async () => {
  if (productData.value.state === 0) {
    tabs.value.unshift({ label: t('copy.position'), value: 'position' })
    tabIndex.value = 'position'
  }

  await getList()
  if (tabIndex.value === 'position') {
    getFuturesList()
  }

  onSubscribe('all_symbol_detail')
  uni.$on('message', onMessage)
})

onUnload(() => {
  onUnsubscribe('all_symbol_detail')
  uni.$off('message', onMessage)
})

onReachBottom(() => {
  if (tabIndex.value !== 'position') {
    onLoadMore()
  }
})

function onTabChange({ name }) {
  tabIndex.value = name
  getList()
}

function onMessage(msgData) {
  const [topic, data] = msgData
  if (tabIndex.value === 'position') {
    onUpdatePosition(data)
  }
}

function onUpdatePosition(data) {
  if (data.type !== 'ubw' && subscribeMode === 'mqtt') return
  list.value.forEach((item) => {
    if (
      (item.symbol_name !== data.symbolName && subscribeMode === 'mqtt') ||
      (item.subText !== data.symbol && subscribeMode === 'ws')
    ) {
      return item
    }
    item.avg_price = toFixed(item.avg_price, item.base_coin_scale)
    const contractSize =
      futuresList.value.find((item) => item.symbolName === data.symbolName)?.contract_size || 1000
    const marketValue = BNumber(item.balance)
      .plus(item.frozen_balance)
      .times(futuresUnit.value === 'cont' ? Number(contractSize || 0) : 1)
    const ratio =
      item.direction === 1
        ? BNumber(data.close).minus(item.avg_price).div(item.avg_price)
        : BNumber(item.avg_price).minus(data.close).div(item.avg_price)
    item.pl = toFixed(BNumber(marketValue).times(ratio))
    item.plRatio = `${toFixed(BNumber(item.pl).div(item.principal_amount).times(100))}%`
    item.closePrice = toFixed(data.close, item.base_coin_scale)
    item.forcePrice = toFixed(item.forcePrice, item.base_coin_scale)
  })
}

const onPositionEvent = ([event, row]) => {
  positionRowData.value = row
  switch (event) {
    case 'stopLimit':
      showStopLimitPopup.value = true
      break
    case 'close':
      showClosePositionPopup.value = true
      break
    default:
  }
}

function getFuturesList() {
  return fetchGetFutures().then((res) => {
    futuresList.value = res.data.filter((item) => item.contract_type === '1')
    futuresList.value.forEach((item) => {
      onUpdatePosition({
        ...item,
        type: 'ubw',
      })
    })
  })
}

const onBack = () => {
  uni.navigateBack()
}
</script>

<style lang="scss" scoped>
:deep(.trade-order-list__item) {
  margin: 0 !important;
}
</style>
