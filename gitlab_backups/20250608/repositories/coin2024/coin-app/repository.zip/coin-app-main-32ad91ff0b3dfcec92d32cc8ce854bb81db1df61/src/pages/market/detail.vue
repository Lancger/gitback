<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar :title="symbol">
    <template #right>
      <wd-icon
        v-if="isFollow"
        @click="onFollow(0)"
        custom-class="color-#EAB249"
        name="star-filled"
        size="40rpx"
      ></wd-icon>
      <wd-icon v-else @click="onFollow(1)" name="star" size="40rpx"></wd-icon>
    </template>
  </app-navbar>
  <view class="flex p-30rpx bg-[var(--background-primary)]">
    <view class="flex-1">
      <view :class="[isUp ? 'up-color' : 'down-color']" class="font-size-46rpx font-600">
        <text>{{ toFormat(tokenData.close, tokenConfigData.base_coin_scale) }}</text>
        <text :class="[isUp ? 'i-carbon-caret-up' : 'i-carbon-caret-down']"></text>
      </view>
      <view class="mt-20rpx font-size-22rpx font-500">
        <text>
          ≈{{ onExchangeRateConversion(tokenData.close, tokenConfigData.base_coin_scale) }}
        </text>
        <text :class="[tokenData.zdf >= 0 ? 'up-color' : 'down-color']" class="ml-20rpx">
          {{ toFixed(tokenData.zdf) }}%
        </text>
      </view>
    </view>
    <view class="flex flex-col gap-16rpx w-50%">
      <view class="flex justify-between font-size-20rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('market.detail.24hHigh') }}</view>
        <view>{{ toFormat(tokenData.high, tokenConfigData.base_coin_scale) }}</view>
      </view>
      <view class="flex justify-between font-size-20rpx">
        <view class="color-[var(--text-inactive)]">{{ $t('market.detail.24hLow') }}</view>
        <view>{{ toFormat(tokenData.low, tokenConfigData.base_coin_scale) }}</view>
      </view>
      <view class="flex justify-between font-size-20rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('market.detail.24hVol') }} ({{ tokenConfigData.coin_symbol }})
        </view>
        <!-- <view>{{ toFormat(tokenData.amount, tokenConfigData.coin_scale) }}</view> -->
        <view>{{ toFormatUnit(tokenData.amount) }}</view>
      </view>
      <view class="flex justify-between font-size-20rpx">
        <view class="color-[var(--text-inactive)]">
          {{ $t('market.detail.24hTurnover') }} (USDT)
        </view>
        <view>{{ toFormatUnit(tokenData.vol || 0) }}</view>
      </view>
    </view>
  </view>
  <!-- k-line-chart -->
  <view class="h-900rpx my-20rpx">
    <k-line-chart
      v-if="tokenPrecision"
      :symbol="symbol"
      :topicSymbol="tokenData.subText"
      :k-type="tradeType"
      :precision="tokenPrecision"
    ></k-line-chart>
    <view v-else class="center w-100% h-100%">
      <wd-loading :size="30" />
    </view>
  </view>
  <!-- wrap -->
  <view class="wrap mt-20rpx">
    <wd-tabs
      custom-class="app-tabs app-tabs--no-flex-1"
      :model-value="0"
      swipeable
      animated
      :map-num="100"
      :slidable-num="2"
    >
      <block v-for="(item, index) in tab" :key="index">
        <wd-tab :title="$t(item)">
          <order-book
            v-if="index === 0"
            :order-book-data="orderBookData"
            :token-data="tokenData"
            :tokenConfig="tokenConfigData"
          ></order-book>
          <market-trades
            v-if="index === 1"
            :list="marketTradesList"
            :tokenConfig="tokenConfigData"
          ></market-trades>
          <token-info v-if="index === 2" :data="tokenInfoData"></token-info>
        </wd-tab>
      </block>
    </wd-tabs>
  </view>
  <app-footer background="var(--background-primary)">
    <view class="p-20rpx">
      <wd-button
        custom-class="flex-1"
        size="large"
        type="success"
        block
        @click="onGoToTrade(tradeType === 'xh' ? 'spot' : 'futures', symbol)"
      >
        {{ $t('market.detail.trade') }}
      </wd-button>
    </view>
  </app-footer>
</template>

<script lang="ts" setup>
import orderBook from './components/order-book.vue'
import marketTrades from './components/market-trades.vue'
import tokenInfo from './components/token-info.vue'
import { useUserStore, useTradeStore } from '@/store'
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'
import { onRouter } from '@/utils'
import { BNumber, toFixed, toFormat, toFormatUnit } from '@/utils/number'
import { fetchTokenConfig, fetchTokenData } from '@/service/trade'
import { fetchMarketData, fetchFollow, fetchGetFutures } from '@/service/market'
import { fetchFormData } from '@/service/base'

const { onExchangeRateConversion } = useUserStore()
const { onGoToTrade } = useTradeStore()
const subMap = {}
const tab = ref([
  'market.detail.orderBookTab',
  'market.detail.latestDeal',
  'market.detail.tokenInformation',
])
const symbol = ref('BTC/USDT')
const tradeType = ref('xh')
const tokenData = ref<any>({})
const tokenConfigData = ref<any>({})
const orderBookData = ref({})
const lastPrice = ref(0)
const isUp = ref(false)
const marketTradesList = ref([])
const tokenInfoData = ref<any>({})
const tokenPrecision = ref(0)
const futuresList = ref([])

const isFollow = computed(() => {
  if (tradeType.value === 'xh') {
    return +tokenConfigData.value.is_collect === 1
  }

  if (tradeType.value === 'ubw') {
    return futuresList.value.some((item) => item.symbol_name === symbol.value && item.collect === 1)
  }

  return false
})

onLoad(async (options) => {
  symbol.value = options.symbol
  tradeType.value = options.type
  getFutures()
  getInfo()
  await getTokenData()
  getTokenConfig()
  getOrderBook()
  getMarketTrades()

  subMap[`${tradeType.value}_detail_${symbol.value}`] = onTokenFn
  subMap[`${tradeType.value}_deptH_${symbol.value}`] = onOrderBookFn
  subMap[`${tradeType.value}_trade_${symbol.value}`] = onVolFn
  onSubscribe(getSubTopic())
  uni.$on('message', onMessage)
})

onUnload(() => {
  onUnsubscribe(getSubTopic())
  uni.$off('message', onMessage)
})

function getSubTopic() {
  if (subscribeMode === 'mqtt') {
    return Object.keys(subMap)
  } else {
    return [
      `ws.tick.CSPOT.${tokenData.value.subText}.1`,
      `ws.depth.CSPOT.${tokenData.value.subText}.1`,
      `ws.market.CSPOT.${tokenData.value.subText}.1`,
    ]
  }
}

function onVolFn(data) {
  const firstItem = marketTradesList.value[0]
  if (!firstItem) return
  if (marketTradesList.value.length > 20) {
    marketTradesList.value.pop()
  }
  marketTradesList.value.unshift({
    ...data,
    direction: +data.price > +firstItem.price ? 1 : 0,
  })
}

function onTokenFn(data) {
  isUp.value = data.close >= lastPrice.value
  Object.assign(tokenData.value, data)
  lastPrice.value = data.close
}

function onOrderBookFn(data) {
  orderBookData.value = data
}

function onMessage(msgData) {
  const [topic, data] = msgData
  if (subMap[topic] && subscribeMode === 'mqtt') {
    subMap[topic](data)
    return
  }

  if (topic.indexOf('market') !== -1 && data.symbol === tokenData.value.subText) {
    onTokenFn(data)
  }

  if (topic.indexOf('tick') !== -1 && data.symbol === tokenData.value.subText) {
    onVolFn(data)
  }

  if (topic.indexOf('depth') !== -1 && data.symbol === tokenData.value.subText) {
    onOrderBookFn(data)
  }
}

function getInfo() {
  return fetchFormData('1531180815470080002', {
    symbol: symbol.value.split('/')[0],
  }).then((res) => {
    tokenInfoData.value = res.data.records[0]
  })
}

function getTokenData() {
  return fetchTokenData({
    symbolNameList: [symbol.value],
    type: tradeType.value,
  }).then((res) => {
    tokenData.value = res.data[symbol.value]
  })
}

function getTokenConfig() {
  return fetchTokenConfig(`${tradeType.value}/${symbol.value.replace('/', '_')}`).then((res) => {
    tokenConfigData.value = res.data
    tokenPrecision.value = res.data.base_coin_scale
  })
}

function getOrderBook() {
  return fetchMarketData({
    type: `deptH_${tradeType.value}_deptH_${symbol.value}`,
  }).then((res) => {
    orderBookData.value = res.data
  })
}

function getMarketTrades() {
  return fetchMarketData({
    type: `tract_${tradeType.value}_trade_${symbol.value}`,
  }).then((res) => {
    const list = []
    res.data = Array.isArray(res.data) ? res.data : new Array(20).fill({})
    res.data = res.data.sort((a, b) => b.time - a.time)
    res.data = res.data.reverse()
    res.data.reduce(
      (a, b) => {
        b.direction = +b.price >= +a.price ? 1 : 0
        list.push(b)
        return b
      },
      {
        price: 0,
      },
    )
    marketTradesList.value = list.reverse()
  })
}

function onFollow(type) {
  uni.showLoading()
  return fetchFollow(
    `${type === 1 ? 'addOptional' : 'cancelOptional'}/${tokenConfigData.value.id}/${tradeType.value === 'xh' ? 1 : 2}`,
  )
    .then((res) => {
      getTokenData()
      getTokenConfig()
      getFutures()
    })
    .finally(() => {
      uni.hideLoading()
    })
}

function getFutures() {
  return fetchGetFutures().then((res) => {
    futuresList.value = res.data
  })
}
</script>

<style lang="scss" scoped>
:deep(.wd-tabs__line) {
  display: none;
}
.wrap {
  background: var(--background-primary);
}
.page {
  background: var(--background-secondary);
}
</style>
