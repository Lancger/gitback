<template>
  <view>
    <view class="main">
      <view class="mb-30rpx px-30rpx w-100% box-border">
        <text class="color-[var(--color-red)]">*</text>
        {{ $t('kyc.idFront') }}
      </view>
      <view class="passport-front" v-if="formData.cardFront">
        <image
          @click="formData.cardFront = null"
          class="passport-front__close"
          src="@/static/images/user/close.png"
        ></image>
        <image class="passport-front__img" :src="formData.cardFront"></image>
      </view>
      <view class="card" @click="onUpload(0)" v-else>
        <!-- <view v-if="loading" class="loading">上传中...</view> -->
        <!-- <view>
          <view>{{ $t('kyc.uploadDocument') }}</view>
          <view class="card__hint">{{ $t('kyc.uploadTips') }}</view>
        </view> -->
      </view>
      <view class="card__hint">{{ $t('kyc.uploadTips') }}</view>
      <!-- <template v-if="+props.form.cardType === 1"> -->
      <view class="mt-64rpx mb-30rpx px-30rpx w-100% box-border">
        <text class="color-[var(--color-red)]">*</text>
        {{ $t('kyc.idBack') }}
      </view>
      <view class="passport-front" v-if="formData.cardBack">
        <image
          @click="formData.cardBack = null"
          class="passport-front__close"
          src="@/static/images/user/close.png"
        ></image>
        <image class="passport-front__img" :src="formData.cardBack"></image>
      </view>
      <view class="card background-image" @click="onUpload(1)" v-else>
        <!-- <view v-if="form.cardBack" class="loading">上传中...</view> -->
        <!-- <view>
            <view>{{ $t('kyc.uploadDocument') }}</view>
            <view class="card__hint">{{ $t('kyc.uploadTips') }}</view>
          </view> -->
      </view>
      <view class="card__hint">{{ $t('kyc.uploadTips') }}</view>
      <view class="mt-64rpx mb-30rpx px-30rpx w-100% box-border">
        <text class="color-[var(--color-red)]">*</text>
        {{ $t('kyc.idHandheld') }}
      </view>
      <view class="passport-front" v-if="formData.cardHand">
        <image
          @click="formData.cardHand = null"
          class="passport-front__close"
          src="@/static/images/user/close.png"
        ></image>
        <image class="passport-front__img" :src="formData.cardHand"></image>
      </view>
      <view class="card id-card-hand" @click="onUpload(2)" v-else>
        <!-- <view v-if="form.cardBack" class="loading">上传中...</view> -->
        <!-- <view>
            <view>{{ $t('kyc.uploadDocument') }}</view>
            <view class="card__hint">{{ $t('kyc.uploadTips') }}</view>
          </view> -->
      </view>
      <view class="card__hint">{{ $t('kyc.uploadTips') }}</view>
      <!-- </template> -->
    </view>
    <view class="flex gap-30rpx mt-100rpx px-30rpx">
      <wd-button type="info" plain @click="lastStep" size="large" style="width: 100%">
        {{ $t('kyc.lastStep') }}
      </wd-button>
      <wd-button size="large" @click="confirm" style="width: 100%">
        {{ $t('common.confirm') }}
      </wd-button>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchVerified } from '@/service/user'
import { useUserStore } from '@/store'
const userStore = useUserStore()
const { data, run, loading } = useUpload<string>()
const emits = defineEmits(['lastStep'])
const props = defineProps({
  form: {
    type: Object,
    default: () => ({}),
  },
})
const formData = ref({
  cardFront: '',
  cardBack: '',
  cardHand: '',
})

watch(data, () => {
  if (uploadType === 0) {
    formData.value.cardFront = data.value.link
  } else if (uploadType === 1) {
    formData.value.cardBack = data.value.link
  } else if (uploadType === 2) {
    formData.value.cardHand = data.value.link
  }
})

watch(loading, () => {
  if (loading.value) {
    uni.showLoading()
  } else {
    uni.hideLoading()
  }
})

let uploadType = 0

function onUpload(t) {
  uploadType = t
  run()
}
function lastStep() {
  emits('lastStep', 2)
}
function confirm() {
  if (!formData.value.cardFront) {
    return uni.showToast({
      icon: 'none',
      title: t('kyc.rules.idFront'),
    })
  }

  if (+props.form.cardType === 1) {
    if (!formData.value.cardBack) {
      return uni.showToast({
        icon: 'none',
        title: t('kyc.rules.idBack'),
      })
    }
    if (!formData.value.cardHand) {
      return uni.showToast({
        icon: 'none',
        title: t('kyc.rules.idHandheld'),
      })
    }
  }

  fetchVerified({
    ...formData.value,
    ...props.form,
  }).then((res) => {
    userStore.userInfo.real_name_status = 1
    uni.redirectTo({
      url: '/pages/user/kyc/details/index',
    })
  })
}
</script>

<style lang="scss" scoped>
.main {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 60rpx;
  font-size: 24rpx;
  font-weight: 500;
  color: var(--text-primary);
  .background-image {
    background-image: url(@/static/images/user/passport-reverse.png) !important;
    background-size: 100% 100%;
  }
  .id-card-hand {
    background-image: url(@/static/images/user/id-card-hand.png) !important;
    background-size: 100% 100%;
  }
  .card {
    position: relative;
    box-sizing: border-box;
    width: 434rpx;
    height: 260rpx;
    padding-top: 190rpx;
    text-align: center;
    background: linear-gradient(109.67deg, #eef5ff 0%, #f6fbff 51%, #eef9ff 100%);
    background-image: url(@/static/images/user/passport-front.png);
    background-size: 100% 100%;
    border-radius: 16rpx;
    &__hint {
      margin-top: 20rpx;
      font-size: 20rpx;
      font-weight: 400;
      color: var(--text-inactive);
    }
    .loading {
      position: absolute;
      top: 50%;
      left: 50%;
      font-size: 30rpx;
      font-weight: 500;
      color: var(--text-primary);
      transform: translate(-50%, -50%);
    }
  }
}
:deep(.wd-upload__preview) {
  width: 478rpx;
  height: 292rpx;
}
.passport-front {
  position: relative;
  width: 478rpx;
  height: 292rpx;
  border-radius: 16rpx;
  &__close {
    position: absolute;
    top: -10rpx;
    right: -10rpx;
    z-index: 99;
    width: 30rpx;
    height: 30rpx;
  }
  &__img {
    width: 100%;
    height: 100%;
  }
}
.position-fixed {
  position: fixed;
  right: 30rpx;
  bottom: 128rpx;
  left: 30rpx;
  display: flex;
  gap: 30rpx;
}
</style>
