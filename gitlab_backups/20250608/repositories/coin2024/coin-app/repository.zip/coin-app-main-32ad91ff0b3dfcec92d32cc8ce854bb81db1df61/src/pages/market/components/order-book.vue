<template>
  <view class="order-book">
    <view class="order-book__compare">
      <view :style="{ width: buyRatio + '%' }" class="order-book__compare-bar bids">
        <view class="order-book__compare-bar__text">{{ toFormatPercent(buyRatio) }}</view>
      </view>
      <view :style="{ width: sellRatio + '%' }" class="order-book__compare-bar asks">
        <view class="order-book__compare-bar__text text-right">
          {{ toFormatPercent(sellRatio) }}
        </view>
      </view>
    </view>
    <view class="order-book__head">
      <view class="order-book__head-item">
        {{ $t('market.detail.orderBook.amount') }} ({{ tokenConfig.coin_symbol }})
      </view>
      <view class="order-book__head-item">{{ $t('market.detail.orderBook.price') }} (USDT)</view>
      <view class="order-book__head-item">
        {{ $t('market.detail.orderBook.amount') }} ({{ tokenConfig.coin_symbol }})
      </view>
    </view>
    <view class="order-book__list">
      <view class="order-book__list-item">
        <view class="order-book__list-item__title text-right">
          {{ $t('market.detail.orderBook.buy') }}
        </view>
        <view
          v-for="(item, index) in buyList"
          :key="index"
          class="order-book__list-item__progress bids"
        >
          <view class="order-book__list-item__progress-content">
            <text>
              {{
                toFormatUnit(item.amount, tokenConfig.coin_coin_scale || tokenConfig.coin_scale) ||
                '--'
              }}
            </text>
            <text class="up-color">
              {{ toFormat(item.price, tokenConfig.base_coin_scale) || '--' }}
            </text>
          </view>
          <view
            :style="{ transform: `translateX(-${item.ratio || 100}%) `, left: '100%' }"
            class="order-book__list-item__progress-bg"
          ></view>
        </view>
      </view>
      <view class="order-book__list-item">
        <view class="order-book__list-item__title">{{ $t('market.detail.orderBook.sell') }}</view>
        <view
          v-for="(item, index) in sellList"
          :key="index"
          class="order-book__list-item__progress asks"
        >
          <view class="order-book__list-item__progress-content">
            <text class="down-color">
              {{ toFormat(item.price, tokenConfig.base_coin_scale) || '--' }}
            </text>
            <text>
              {{
                toFormatUnit(item.amount, tokenConfig.coin_coin_scale || tokenConfig.coin_scale) ||
                '--'
              }}
            </text>
          </view>
          <view
            :style="{ transform: `translateX(${item.ratio || 100}%) `, right: '100%' }"
            class="order-book__list-item__progress-bg"
          ></view>
        </view>
      </view>
    </view>
    <view class="h-100rpx"></view>
  </view>
</template>

<script lang="ts" setup>
import { BNumber, toFixed, toFormat, toFormatPercent, toFormatUnit } from '@/utils/number'

const props = defineProps({
  orderBookData: {
    type: Object,
    default: () => ({}),
  },
  tokenData: {
    type: Object,
    default: () => ({}),
  },
  tokenConfig: {
    type: Object,
    default: () => ({}),
  },
})

const buyList = ref([])
const sellList = ref([])
const showType = ref(-1)
const isUp = ref(true)
const lastPrice = ref(0)
const buyRatio = ref<any>(50)
const sellRatio = ref<any>(50)

watchEffect(() => {
  isUp.value = props.tokenData.close >= lastPrice.value
  lastPrice.value = props.tokenData.close
  if (props.orderBookData) {
    onInit()
  }
})

function onInit() {
  const len = 10
  let buyMax = []
  if (props.orderBookData.buyItems) {
    const buyData = [...props.orderBookData.buyItems]
    buyData.sort((a, b) => {
      return b.price - a.price
    })
    buyList.value = buyData.slice(0, len)
    buyMax = buyList.value.map((item) => Number(item.amount))
    buyList.value = buyList.value.map((item) => {
      return {
        ...item,
        ratio: (item.amount / Math.max(...buyMax)) * 100,
      }
    })
  } else {
    buyList.value = new Array(len).fill({})
  }

  let sellMax = []
  if (props.orderBookData.sellItems) {
    const sellData = [...props.orderBookData.sellItems]
    sellData.sort((a, b) => {
      return a.price - b.price
    })
    sellList.value = sellData.slice(0, len)
    sellMax = sellList.value.map((item) => Number(item.amount))
    sellList.value = sellList.value.map((item) => {
      return {
        ...item,
        ratio: (item.amount / Math.max(...sellMax)) * 100,
      }
    })
  } else {
    sellList.value = new Array(len).fill({})
  }

  const buyTotal = buyMax.reduce((a, b) => a + b, 0) || 50
  const sellTotal = sellMax.reduce((a, b) => a + b, 0) || 50
  const total = [...buyMax, ...sellMax].reduce((a, b) => a + b, 0) || 100

  buyRatio.value = toFixed(BNumber(buyTotal).times(100).div(total))
  sellRatio.value = toFixed(BNumber(sellTotal).times(100).div(total))
}
</script>

<style lang="scss" scoped>
.order-book {
  min-height: 60vh;
  &__list {
    display: flex;
    &-item {
      flex: 1;
      &__progress {
        position: relative;
        width: 100%;
        height: 54rpx;
        overflow: hidden;
        &-content {
          position: relative;
          z-index: 2;
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 100%;
          padding: 0 20rpx;
          font-size: 22rpx;
        }
        &-bg {
          position: absolute;
          top: 0;
          right: 0;
          z-index: 1;
          width: 100%;
          height: 100%;
          opacity: 0.1;
          transition: all 0.3s;
          transform: tran3lateX(100%);
        }
      }
      &__progress.bids {
        .order-book__list-item__progress-bg {
          background: var(--color-green);
        }
      }
      &__progress.asks {
        .order-book__list-item__progress-bg {
          background: var(--color-red);
        }
      }
      &__title {
        position: relative;
        box-sizing: border-box;
        height: 46rpx;
        padding: 0 20rpx;
        font-size: 20rpx;
        line-height: 46rpx;
        color: var(--text-inactive);
      }
      &:nth-of-type(2) {
        .order-book__list-item__title {
          &::after {
            position: absolute;
            top: 50%;
            left: 0;
            width: 1px;
            height: 24rpx;
            content: '';
            background: var(--background-gary-4);
            transform: translateY(-50%);
          }
        }
      }
    }
  }
  &__head {
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 60rpx;
    padding: 0 20rpx;
    border-bottom: 1px solid var(--background-gary-4);
    &-item {
      font-size: 22rpx;
      color: var(--text-inactive);
    }
  }
  &__compare {
    display: flex;
    gap: 40rpx;
    align-items: center;
    height: 60rpx;
    padding: 0 20rpx;
    &-bar {
      position: relative;
      box-sizing: border-box;
      width: 50%;
      min-width: 20%;
      height: 46rpx;
      padding: 0 30rpx;
      font-size: 24rpx;
      line-height: 46rpx;
      color: #fff;
      border-radius: 100rpx;
      transition: all 0.3s;

      &__text {
        position: relative;
        z-index: 2;
      }
      &::before {
        position: absolute;
        top: 0;
        right: -10rpx;
        z-index: 1;
        width: 50%;
        height: 100%;
        content: '';
        background-color: inherit;
        transform: translate(0) rotate(0) skewX(-35deg) skewY(0) scaleX(1) scaleY(1);
      }
      + .order-book__compare-bar {
        &::before {
          right: auto;
          left: -10rpx;
        }
      }
    }
    &-bar.bids {
      background: var(--color-green);
    }
    &-bar.asks {
      background: var(--color-red);
    }
  }
}
</style>
