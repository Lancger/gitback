<template>
  <view class="p-30rpx">
    <app-navbar custom-class="bg-transparent" :title="title"></app-navbar>
    <view v-if="params.index === 2">
      <view class="crypto">{{ $t('c2c.buyAndSell.youPay') }}</view>
      <view class="flex buy">
        <view class="w70">
          <wd-input
            type="number"
            no-border
            v-model="harvestNum"
            :placeholder="
              listObj.min_transaction
                ? $t('common.min') +
                  ' ' +
                  toFormat((listObj.min_transaction * listObj.rate).toFixed(2))
                : $t('c2c.buyAndSell.pleaseEnter')
            "
            @input="inputNum('harvestNum')"
          />
        </view>
        <view class="buy_type">
          <image class="w-40rpx h-40rpx mr2 ml1" :src="params.receiveIcon" />
          <text class="buy_text">{{ listObj.fiat_currency }}</text>
        </view>
      </view>

      <view class="text">
        {{ 1 + listObj.coin_symbol }} = {{ listObj.rate + listObj.fiat_currency }}
      </view>
      <view class="crypto">{{ $t('c2c.buyAndSell.youReceive') }}</view>
      <view class="flex buy">
        <view class="w70">
          <wd-input
            type="number"
            no-border
            v-model="payOutNum"
            :placeholder="
              listObj.min_transaction
                ? $t('common.min') + ' ' + toFormat(listObj.min_transaction)
                : $t('c2c.buyAndSell.pleaseEnter')
            "
            @input="inputNum('payOutNum')"
          />
        </view>
        <view class="buy_type">
          <image class="w-40rpx h-40rpx mr2 ml1" :src="params.payIcon" />
          <text class="buy_text">{{ listObj.coin_symbol }}</text>
        </view>
      </view>
      <view class="text">
        <view>
          {{ toFormat(listObj.min_transaction) }} - {{ toFormat(listObj.max_transaction) }}
          {{ listObj.coin_symbol }}
        </view>
        <view class="flex">
          <wd-count-down
            ref="countDown"
            custom-class="count-down"
            :time="time"
            format="ss"
            @finish="finish"
          />
          <text>{{ $t('c2c.buyAndSell.refresh') }}</text>
        </view>
      </view>
    </view>
    <view v-else>
      <view class="crypto">{{ $t('c2c.buyAndSell.youSell') }}</view>
      <view class="flex buy">
        <view class="w70">
          <wd-input
            type="number"
            no-border
            v-model="payOutNum"
            :placeholder="
              listObj.min_transaction
                ? $t('common.min') + ' ' + toFormat(listObj.min_transaction)
                : $t('c2c.buyAndSell.pleaseEnter')
            "
            @input="inputNum('payOutNum')"
          />
        </view>
        <view class="buy_type">
          <image class="w-40rpx h-40rpx mr2 ml1" :src="params.payIcon" />
          <text class="buy_text">{{ listObj.coin_symbol }}</text>
        </view>
      </view>
      <view class="text">
        {{ toFormat(listObj.min_transaction) }} - {{ toFormat(listObj.max_transaction) }}
        {{ listObj.coin_symbol }}
      </view>
      <view class="crypto">{{ $t('c2c.buyAndSell.youReceive') }}</view>
      <view class="flex buy">
        <view class="w70">
          <wd-input
            type="number"
            no-border
            v-model="harvestNum"
            :placeholder="
              listObj.min_transaction
                ? $t('common.min') +
                  ' ' +
                  toFormat((listObj.min_transaction * listObj.rate).toFixed(2))
                : $t('c2c.buyAndSell.pleaseEnter')
            "
            @input="inputNum('harvestNum')"
          />
        </view>
        <view class="buy_type">
          <image class="w-40rpx h-40rpx mr2 ml1" :src="params.receiveIcon" />
          <text class="buy_text">{{ listObj.fiat_currency }}</text>
        </view>
      </view>
      <view class="text">
        {{ 1 + listObj.coin_symbol }} = {{ listObj.rate + listObj.fiat_currency }}
      </view>
    </view>

    <view class="btn">
      <view class="btn_subscribe" v-if="!forbidden">
        {{ $t('c2c.buyAndSell.selectPaymentMethod') }}
      </view>
      <view class="btn_subscribewhine" v-else @click="navigator">
        {{ $t('c2c.buyAndSell.selectPaymentMethod') }}
      </view>
    </view>

    <view class="glide" @click="onRouter(`/pages/home/ctwoc/history/index?serviceType=2`)">
      {{ $t('c2c.buyAndSell.pendingOrder') }}
    </view>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchOpenp2p, fetchSubmitOrder } from '@/service/ctwoc'
import { toFormat, BNumber } from '@/utils/number'
import { fetchGetData, fetchGetPayment } from '@/service/user'
import { useUserStore } from '@/store'
import { onRouter } from '@/utils'

const params = ref<any>({})
const listObj = ref<any>({})
const payOutNum = ref()
const valueCree = ref<any>({})
const harvestNum = ref<any>('')
const valueCoin = ref<any>({})
const title = ref('')
const time = ref<number>(30 * 1000)
const countDown = ref<any>(null)
const myPayMethods = ref([]) // 判断有无银行卡
const userInfo = useUserStore().userInfo

onLoad((e) => {
  params.value = uni.getStorageSync('ctwoc')
  openp2pFun()
  initialData()
})
const openp2pFun = () => {
  fetchOpenp2p({
    id: params.value.id,
  }).then((res) => {
    listObj.value = res.data.records[0] || params.value.itemData
    if (params.value.index === 2) {
      title.value = `${t('c2c.buy')}  ${listObj.value.coin_symbol}`
    } else {
      title.value = `${t('c2c.sell')}  ${listObj.value.coin_symbol}`
    }
  })
}

const initialData = () => {
  fetchGetData().then((res) => {
    myPayMethods.value = res.data.records
    fetchGetPayment().then((ress) => {
      myPayMethods.value = myPayMethods.value.map((item) => {
        ress.data.forEach((child) => {
          if (item.id === child.pay_method_id) {
            item.data = child
          }
        })
        return item
      })
    })
  })
}

const inputNum = (name) => {
  if (name === 'payOutNum') {
    harvestNum.value = BNumber(payOutNum.value).times(listObj.value.rate).toFixed(2).toString()
  } else {
    payOutNum.value = BNumber(harvestNum.value).div(listObj.value.rate).toFixed(2).toString()
  }
}
const navigator = () => {
  const data = {
    sum: payOutNum.value,
    value: harvestNum.value,
    valueCree: {
      local_currency: listObj.value.fiat_currency,
    },
    valueCoin: {
      name: listObj.value.coin_symbol,
    },
    index: params.value.index,
    id: params.value.id,
  }
  // uni.setStorageSync('buyAndSell', data)
  // uni.redirectTo({
  //   url: '/pages/home/ctwoc/payment/index',
  // })
  onSubmitOrder(data)
}

function onSubmitOrder(data) {
  uni.showLoading()
  const obj = {
    advertiseId: data.id,
    coinCou: data.sum,
    fiatCurrencyAmount: data.value,
    serviceType: '2',
    type: data.index === 1 ? '2' : '1',
  }
  return fetchSubmitOrder(obj)
    .then((res) => {
      onRouter(`/pages/home/ctwoc/paid/index?id=${res.data}`, 'redirectTo')
    })
    .finally(() => {
      uni.hideLoading()
    })
}

const forbidden = computed(() => {
  return payOutNum.value > 0 && harvestNum.value > 0
})

const finish = () => {
  countDown.value.reset()
  openp2pFun()
}
</script>

<style lang="scss" scoped>
.flex {
  display: flex;
  align-items: center;
  justify-content: center;
}

.glide {
  color: var(--text-primary);
  text-align: center;
  text-decoration: underline;
}
.btn {
  margin-top: 80rpx;
  &_subscribe {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--text-inactive) !important;
    text-align: center;
    background-color: var(--border-color-inactive);
    border-radius: 100rpx;
  }

  &_subscribewhine {
    width: 690rpx;
    height: 90rpx;
    margin: 20rpx auto;
    line-height: 90rpx;
    color: var(--wot-color-white) !important;
    text-align: center;
    background-color: #00a7ed;
    border-radius: 100rpx;
  }
}
.text {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 20rpx;
  color: var(--text-inactive);
  .count-down {
    color: var(--text-inactive);
  }
}
.flex {
  display: flex;
  align-items: center;
}
.buy {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 100rpx;
  margin-top: 20rpx;
  border-bottom: 2rpx solid var(--border-color-active);
  &_type {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 198rpx;
    height: 72rpx;
    background: var(--background-gary-4);
    border-radius: 10rpx;
    image {
      border-radius: 50%;
    }
  }
}

.crypto {
  margin-top: 30rpx;
  margin-bottom: 10rpx;
  font-size: 30rpx;
}
</style>
