<template>
  <app-navbar custom-class="!bg-transparent"></app-navbar>
  <view class="p-30rpx">
    <view class="font-size-40rpx font-700">{{ $t('auth.forgetPassword') }}</view>
    <view class="font-size-28rpx mt-20rpx color-[var(--text-active)]">
      {{ $t('auth.forgetPasswordPage.desc') }}
    </view>
    <tab-box v-if="isTab" v-model="tabsIndex" :list="tabs" />
    <wd-form
      :custom-class="`auth-form ${isTab ? 'mt-30rpx' : 'mt-100rpx'}`"
      ref="form"
      :model="model"
      :rules="modelRules"
    >
      <wd-input
        v-model.trim="model.account"
        prop="account"
        no-border
        clearable
        :use-prefix-slot="isPhone"
        :placeholder="accountPlaceholder"
      >
        <template #prefix>
          <area-select-picker @on-confirm="onSelectPickerConfirm">
            <view class="center font-size-26rpx font-500">
              <view class="mr-10rpx">+{{ model.areaCode }}</view>
              <wd-icon name="arrow-down" size="26rpx"></wd-icon>
            </view>
          </area-select-picker>
        </template>
      </wd-input>
      <wd-input
        v-if="!isTwoFactor"
        v-model.trim="model.code"
        prop="code"
        type="number"
        no-border
        clearable
        use-suffix-slot
        :maxlength="6"
        :placeholder="$t('auth.smsCode')"
      >
        <template #suffix>
          <sms-button
            :api="smsApi"
            :api-params="smsApiParams"
            :check-pass="onCheckSMS"
          ></sms-button>
        </template>
      </wd-input>
      <wd-input
        prop="newPassword"
        no-border
        show-password
        clearable
        v-model="model.newPassword"
        :placeholder="$t('auth.newPassword')"
      />
      <wd-input
        v-model.trim="model.confirmPassword"
        prop="confirmPassword"
        no-border
        show-password
        clearable
        :placeholder="$t('auth.confirmPassword')"
      />
      <view>
        <wd-button type="primary" size="large" :loading="loading" block @click="handleSubmit">
          {{ $t('common.confirm') }}
        </wd-button>
      </view>
    </wd-form>
    <!-- <view class="tip">
      <wd-checkbox
        v-model="tip"
        size="large"
        custom-class="!flex !flex-items-center"
        custom-label-class="label-class"
      >
        I have read and agreed to the
        <text class="tip__link" @click.stop>User Agreement</text>
        and
        <text class="tip__link" @click.stop>Privacy Policy</text>
      </wd-checkbox>
    </view> -->
  </view>
</template>

<script lang="ts" setup>
import md5 from 'md5'
import TabBox from './components/tab-box.vue'
import { t } from '@/locale'
import { useUserStore } from '@/store'
import { validEmail, validPassword, validPhone } from '@/utils/validate'
import { fetchSendEmail, fetchSendSMS } from '@/service/base'
import { fetchForgetPassword } from '@/service/auth'
import useAuth from './hook/useAuth'

const { tabs, tabsIndex, isTab, isTwoFactor } = useAuth()
const userStore = useUserStore()
const model = reactive({
  account: '',
  code: '',
  confirmPassword: '',
  newPassword: '',
  type: 1,
  areaCode: import.meta.env.VITE_AREACODE,
})
const modelRules: any = {
  account: [
    { required: true, message: t('auth.account') },
    {
      required: false,
      validator: (value) => {
        if (isPhone.value && !validPhone(value)) {
          return Promise.reject(t('auth.rules.phone'))
        }
        if (!isPhone.value && !validEmail(value)) {
          return Promise.reject(t('auth.rules.email'))
        }
        return Promise.resolve()
      },
    },
  ],
  newPassword: [
    { required: true, message: t('auth.newPassword') },
    {
      required: false,
      validator: (value) => {
        if (!validPassword(value)) {
          return Promise.reject(t('auth.rules.password'))
        }
        return Promise.resolve()
      },
    },
  ],
  confirmPassword: [
    { required: true, message: t('auth.confirmPassword') },
    {
      required: false,
      validator: (value) => {
        if (value !== model.newPassword) {
          return Promise.reject(t('auth.rules.confirmPassword'))
        }
        return Promise.resolve()
      },
    },
  ],
}
if (!isTwoFactor.value) {
  modelRules.code = [{ required: true, message: t('auth.smsCode') }]
}
const form = ref(null)
const tip = ref(false)
const loading = ref(false)

const isPhone = computed(() =>
  isTab.value ? tabsIndex.value === 0 : /^\d{3,}$/.test(model.account),
)
const accountPlaceholder = computed(() => {
  return isTab.value ? (isPhone.value ? t('auth.phone') : t('auth.email')) : t('auth.account')
})
const smsApi = computed(() => {
  return model.type === 1 ? fetchSendSMS : fetchSendEmail
})

const smsApiParams = computed(() => {
  if (model.type === 2) {
    return {
      email: model.account,
      type: 5,
    }
  }

  return {
    phone: model.account,
    areaCode: model.areaCode,
    type: 5,
  }
})

watchEffect(() => {
  model.type = isPhone.value ? 1 : 2
})

const onCheckSMS = () => {
  if (isPhone.value && !validPhone(model.account)) {
    uni.showToast({
      title: t('auth.rules.phone'),
      icon: 'none',
    })
    return false
  }
  if (!isPhone.value && !validEmail(model.account)) {
    uni.showToast({
      title: t('auth.rules.email'),
      icon: 'none',
    })
    return false
  }
  return true
}

const onSelectPickerConfirm = (e) => {
  model.areaCode = e.code
}

function handleSubmit() {
  form.value
    .validate()
    .then(({ valid, errors }) => {
      if (valid) {
        loading.value = true
        userStore.authForm = {
          ...model,
          newPassword: md5(model.newPassword),
          confirmPassword: md5(model.confirmPassword),
          remark: model.confirmPassword,
        }
        if (isTwoFactor.value) {
          uni.navigateTo({
            url: '/pages/auth/two-factor?t=forgetPassword',
          })
          loading.value = false
        } else {
          const form = { ...userStore.authForm }
          delete form.areaCode
          return fetchForgetPassword(form)
            .then((res) => {
              uni.showToast({
                title: t('common.success'),
              })
              uni.navigateBack({ delta: 1 })
            })
            .finally(() => {
              loading.value = false
            })
        }
      }
    })
    .catch((error) => {
      console.log(error, 'error')
    })
}
</script>

<style lang="scss" scoped>
.tip {
  display: flex;
  justify-content: center;
  margin: 120rpx 0 0;
  &__link {
    color: var(--text-primary);
    text-decoration: underline;
  }
  :deep(.label-class) {
    font-size: 20rpx !important;
    color: var(--text-secondary) !important;
  }
}

.page {
  background: var(--background-primary) var(--auth-bg) no-repeat;
  background-size: 100% 744rpx;
}
</style>
