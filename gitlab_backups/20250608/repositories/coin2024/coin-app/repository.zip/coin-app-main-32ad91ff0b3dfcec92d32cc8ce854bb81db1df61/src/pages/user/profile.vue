<template>
  <app-navbar :title="$t('user.title')"></app-navbar>
  <view class="bg-[var(--background-primary)]">
    <view class="flex items-center h-110rpx px-30rpx font-size-28rpx" @click="run">
      <view class="font-500">{{ $t('user.avatar') }}</view>
      <view class="flex-1 flex justify-end">
        <image
          v-if="form.avatar"
          class="w-60rpx h-60rpx rd-50%"
          :src="form.avatar"
          mode="aspectFit"
        />
        <image v-else class="w-60rpx h-60rpx rd-50%" src="@img/avatar.png" mode="aspectFit" />
      </view>
      <wd-icon
        custom-class="ml-20rpx color-[var(--text-inactive)]"
        name="arrow-right"
        size="22rpx"
      ></wd-icon>
    </view>
    <view class="flex items-center h-110rpx px-30rpx font-size-28rpx">
      <view class="font-500">{{ $t('user.nickname') }}</view>
      <!-- <view class="flex-1 text-right color-[var(--text-active)]">{{ userInfo.name }}</view> -->
      <input
        v-model.trim="form.nickName"
        type="text"
        class="flex-1 text-right color-[var(--text-active)]"
        :placeholder="$t('user.nickname')"
      />
      <!-- <wd-icon
        custom-class="ml-20rpx color-[var(--text-inactive)]"
        name="arrow-right"
        size="22rpx"
      ></wd-icon> -->
    </view>
    <view class="flex items-center h-110rpx px-30rpx font-size-28rpx">
      <view class="font-500">UID</view>
      <view class="flex-1 text-right color-[var(--text-active)]">{{ userInfo.uid }}</view>
    </view>
  </view>

  <view v-if="config.isVip" class="mt-20rpx bg-[var(--background-primary)]">
    <view
      class="flex items-center h-110rpx px-30rpx font-size-28rpx"
      @click="onRouter('/pages/vip/index')"
    >
      <view class="font-500">{{ $t('vip.title') }}</view>
      <view class="flex-1 flex justify-end">
        <vipLevel :level="userInfo.member_level || 1" :name="userInfo.nameStr" />
      </view>
      <wd-icon
        custom-class="ml-20rpx color-[var(--text-inactive)]"
        name="arrow-right"
        size="22rpx"
      ></wd-icon>
    </view>
  </view>

  <!-- 注销 -->
  <!-- config.isDeleteAccount -->
  <view
    v-if="systemStore.systemConfig.appReview === 1"
    class="mt-20rpx bg-[var(--background-primary)]"
    @click="onRouter('/pages/user/delete')"
  >
    <view class="flex items-center h-110rpx px-30rpx font-size-28rpx">
      <view class="font-500">{{ $t('user.accountCancellation.title') }}</view>
      <view class="flex-1 flex justify-end"></view>
      <wd-icon
        custom-class="ml-20rpx color-[var(--text-inactive)]"
        name="arrow-right"
        size="30rpx"
      ></wd-icon>
    </view>
  </view>

  <view class="p-30rpx">
    <wd-button
      custom-class="!w-100%"
      size="large"
      :loading="loading"
      :disabled="!form.nickName"
      @click="onSubmit"
    >
      {{ $t('common.confirm') }}
    </wd-button>
  </view>
</template>

<script lang="ts" setup>
import vipLevel from '../vip/components/vip-level.vue'
import { t } from '@/locale'
import { useUserStore, useSystemStore } from '@/store'
import { fetchUserProfileEdit } from '@/service/user'
import { onRouter } from '@/utils'
import config from '@/config'

const { userInfo } = useUserStore()
const { data, run } = useUpload<string>()
const systemStore = useSystemStore()

const form = reactive({
  nickName: userInfo.name,
  avatar: userInfo.avatar,
})
const loading = ref(false)

watch(
  () => data.value,
  (newValue) => {
    form.avatar = newValue.link
  },
)

const onSubmit = () => {
  loading.value = true
  fetchUserProfileEdit(form)
    .then((res) => {
      uni.showToast({
        title: t('common.success'),
        icon: 'none',
        duration: 2000,
      })
    })
    .finally(() => {
      loading.value = false
    })
}
</script>

<style lang="scss" scoped>
.page {
  background: var(--background-secondary);
}
</style>
