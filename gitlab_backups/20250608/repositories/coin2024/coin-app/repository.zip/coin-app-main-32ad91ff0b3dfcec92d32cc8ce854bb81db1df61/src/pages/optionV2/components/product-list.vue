<template>
  <view>
    <view
      v-for="(item, index) in list"
      :key="index"
      class="p-30rpx m-30rpx border-1 border-solid border-color-[var(--border-color-inactive)] rd-20rpx"
      @click="onItemClick(item)"
    >
      <!-- <view class="flex items-center gap-20rpx">
        <wd-icon
          custom-class="color-[var(--color-primary)]"
          name="star-filled"
          size="40rpx"
        ></wd-icon>
        <view class="font-size-30rpx font-500">
          {{ toFormat(item.close, item.base_coin_scale) }} Up
        </view>
        <app-tag type="info">1754.88x</app-tag>
      </view>
      <view class="flex items-center justify-between mt-30rpx">
        <view class="w-33.33%">
          <view class="font-size-22rpx color-[var(--text-inactive)]">Break-even point(%)</view>
          <view class="font-size-25rpx font-500 mt-26rpx">
            {{ toFormat(item.close, item.base_coin_scale) }} (0.00%)
          </view>
        </view>
        <view class="w-33.33%">
          <view class="font-size-22rpx color-[var(--text-inactive)]">Win rate</view>
          <view class="font-size-25rpx font-500 mt-26rpx">96.6%</view>
        </view>
        <view class="w-170rpx h-84rpx pt-12rpx bg-#07BA831A rd-10rpx text-center box-border">
          <view class="font-size-20rpx color-[var(--text-inactive)]">Mark price</view>
          <view class="font-size-26rpx font-500 mt-10rpx up-color">3.3</view>
        </view>
      </view> -->
      <view class="font-size-24rpx font-500">
        {{ formatDate(item[0]) }}-{{ formatDate(item[1]) }}
      </view>
      <view class="flex items-center justify-between mt-30rpx">
        <view class="flex flex-col justify-between h-84rpx">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ $t('optionV2.ratio') }}
          </view>
          <view class="font-size-28rpx font-500">
            {{ optionsData.mode === 0 ? optionsData.up_odds.odds : optionsData.down_odds.odds }}
          </view>
        </view>
        <view
          :class="optionsData.mode === 0 ? 'bg-[var(--color-green)]' : 'bg-[var(--color-red)]'"
          class="w-270rpx h-84rpx font-size-30rpx font-500 rd-10rpx text-center lh-84rpx color-#fff"
        >
          {{ optionsData.mode === 0 ? $t('optionV2.up') : $t('optionV2.down') }}
        </view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { onRouter } from '@/utils'
import { formatDate } from '@/utils/day'
import { toFormat } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
  optionsData: {
    type: Object,
    default: () => {},
  },
})

const emits = defineEmits(['click'])

const onItemClick = (item: any) => {
  emits('click', item)
}
</script>

<style lang="scss" scoped>
//
</style>
