<template>
  <view
    v-for="(item, index) in list"
    :key="index"
    class="p-30rpx m-30rpx border-1 border-solid border-color-[var(--border-color-inactive)] rd-20rpx"
  >
    <view class="flex items-center gap-20rpx">
      <image
        class="w-80rpx h-80rpx rd-50%"
        :src="item.avatar || '/static/images/avatar.png'"
        mode="scaleToFill"
      />
      <view>
        <view class="font-size-28rpx font-500">{{ item.nickname }}</view>
        <app-tag custom-class="mt-14rpx !font-size-22rpx" type="info">
          <view class="flex items-center gap-10rpx">
            <text class="i-carbon-user-multiple font-size-18rpx"></text>
            <view>{{ item.curNum }}/{{ item.totalNum }}</view>
          </view>
        </app-tag>
      </view>
    </view>
    <!--  -->
    <view class="flex items-end justify-between mt-20rpx">
      <view>
        <view class="font-size-24rpx color-[var(--text-inactive)]">
          {{ $t('copy.pnl30d') }}
        </view>
        <view class="font-size-42rpx font-600 mt-16rpx up-color">
          {{ item.profit > 0 ? '+' : '' }}{{ item.profit }}
        </view>
        <view class="mt-26rpx">
          <text class="color-[var(--text-inactive)]">{{ $t('copy.pnl30d') }}%</text>
          <text class="up-color ml-10rpx">
            {{ item.earnings_rate > 0 ? '+' : '' }}{{ toFormatPercent(item.earnings_rate * 100) }}
          </text>
        </view>
      </view>
      <image
        v-if="index % 2 === 0"
        class="w-232rpx h-100rpx"
        src="/static/images/copy/green_chart.png"
        mode="scaleToFill"
      />
      <image
        v-else
        class="w-232rpx h-100rpx"
        src="/static/images/copy/red_chart.png"
        mode="scaleToFill"
      />
    </view>
    <!--  -->
    <view class="flex flex-wrap mt-40rpx">
      <view class="w-33.33%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.aum') }}
        </view>
        <view class="font-500 mt-20rpx">{{ toFormat(item.aum, true) }}</view>
      </view>
      <view class="w-33.33% text-right">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.maxDrawdown') }}
        </view>
        <view class="font-500 mt-20rpx">{{ toFormatPercent(item.mdd) }}</view>
      </view>
      <view class="w-33.33% text-right">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('copy.sharpeRatio') }}
        </view>
        <view class="font-500 mt-20rpx">{{ item.sharpe_ratio }}</view>
      </view>
    </view>
    <!--  -->
    <wd-button custom-class="mt-60rpx !rd-10rpx" size="large" block @click="handleClick(item)">
      {{ $t('copy.followTrade') }}
    </wd-button>
  </view>
</template>

<script lang="ts" setup>
import { toFixed, toFormat, toFormatPercent } from '@/utils/number'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
})

const emits = defineEmits(['click'])

const handleClick = (item: any) => {
  emits('click', item)
}
</script>

<style lang="scss" scoped>
//
</style>
