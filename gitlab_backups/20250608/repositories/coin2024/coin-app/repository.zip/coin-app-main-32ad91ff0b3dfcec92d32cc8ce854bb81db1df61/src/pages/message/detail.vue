<template>
  <app-navbar :title="data.title" left-arrow></app-navbar>
  <view class="p-30rpx">
    <!-- <mp-html :content="articleContent" /> -->
    <div v-html="data.content"></div>
  </view>
</template>
<script lang="ts" setup>
// @ts-expect-error 没有声明文件
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'
import { fetchFormDetailData, fetchFormData } from '@/service/base'

const data = ref(uni.getStorageSync('notifyDetail') || {})
</script>
<style lang="scss" scoped>
img {
  max-width: 100%;
}
</style>
