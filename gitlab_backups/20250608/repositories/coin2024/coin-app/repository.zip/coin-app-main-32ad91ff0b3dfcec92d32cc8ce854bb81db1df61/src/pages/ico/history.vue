<route lang="json5" type="page">
{
  layout: 'default',
}
</route>

<template>
  <app-navbar :title="$t('ico.history')"></app-navbar>
  <view class="header">
    <view class="flex relative b-b">
      <wd-tabs
        custom-class="app-tabs--no-flex-1"
        v-model="tabIndex"
        swipeable
        animated
        :map-num="100"
        @change="onChange"
      >
        <block v-for="(item, index) in tab" :key="index">
          <wd-tab :title="$t(item)"></wd-tab>
        </block>
      </wd-tabs>
    </view>
    <view @click="closeOutside">
      <wd-drop-menu>
        <wd-drop-menu-item v-model="listParams.state" :options="options" @change="onChange" />
      </wd-drop-menu>
    </view>
  </view>
  <view class="h-176rpx"></view>
  <view class="wrap mt-8rpx">
    <app-empty :no-data="list.length === 0">
      <view class="list">
        <view v-for="(item, index) in list" :key="index" class="list__item">
          <view class="list__item-head">
            <view class="token-info">
              <image class="token-info__logo" :src="item.avatar" mode="aspectFit" />
              <view class="token-info__name">
                {{ item.symbol }}
                <text class="font-size-22rpx color-[var(--text-inactive)]">/USDT</text>
              </view>
            </view>
            <view class="status">{{ formatStatusToText(item.state) }}</view>
          </view>
          <view class="detail-list">
            <view class="detail-list-item">
              <view class="detail-list-item__label">{{ $t('ico.subscribeQuantity') }}</view>
              <view class="detail-list-item__value">{{ item.purchase_quantity }}</view>
            </view>
            <view class="detail-list-item" v-if="item.state === 'pending_subscription'">
              <view class="detail-list-item__label">{{ $t('ico.offeringQuantity') }}</view>
              <view class="detail-list-item__value">{{ item.allotment_quantity }}</view>
            </view>
            <view class="detail-list-item">
              <view class="detail-list-item__label">{{ $t('ico.offeringPrice') }}</view>
              <view class="detail-list-item__value">{{ item.subscribed_price }} USDT</view>
            </view>
            <view class="detail-list-item">
              <view class="detail-list-item__label">{{ $t('ico.subscriptionTime') }}</view>
              <view class="detail-list-item__value">{{ formatDate(item.create_time) }}</view>
            </view>
          </view>
        </view>
        <wd-loadmore :state="loadMoreState" />
      </view>
    </app-empty>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { useQueue } from 'wot-design-uni'
import usePagination from '@/hooks/usePagination'
import { fetchIcoSubscribeRecords, fetchIcoPlacingRecords } from '@/service/ico'
import dayjs, { formatDate } from '@/utils/day'

const { closeOutside } = useQueue()
const tab = ref(['ico.subscription', 'ico.placement'])
const tabIndex = ref(0)
const options = ref<Record<string, any>>([
  { label: t('ico.all'), value: null },
  { label: t('ico.purchased'), value: 'purchased' },
  { label: t('ico.win'), value: 'pending_subscription' },
  { label: t('ico.fail'), value: 'not_allotted' },
  { label: t('ico.canceled'), value: 'cancelled' },
])

const listParams = reactive({
  state: null,
  pay_state: '',
  pageNo: 1,
  pageSize: 12,
})

const {
  data: subscribeList,
  loadMoreState: subscribeLoadMoreState,
  onInit: subscribeInit,
} = usePagination({
  api: fetchIcoSubscribeRecords,
  params: listParams,
  onLoadMoreFn: onReachBottom,
})

const {
  data: placingList,
  loadMoreState: placingLoadMoreState,
  onInit: placingInit,
} = usePagination({
  api: fetchIcoPlacingRecords,
  params: listParams,
  onLoadMoreFn: onReachBottom,
})

const list = computed(() => (tabIndex.value === 0 ? subscribeList.value : placingList.value))

const loadMoreState = computed(() =>
  tabIndex.value === 0 ? subscribeLoadMoreState.value : placingLoadMoreState.value,
)

const onChange = ({ index }) => {
  if (index === 0) {
    subscribeInit()
  } else {
    placingInit()
  }
}

function formatStatusToText(status) {
  const selectItem = options.value.find((item) => item.value === status)
  return selectItem.label ? selectItem.label : ''
}
</script>

<style lang="scss" scoped>
:deep(.wd-tabs__line) {
  bottom: 0 !important;
}
:deep(.wd-drop-menu__item) {
  flex: none;
  .wd-drop-menu__item-title {
    padding: 0 30rpx;
  }
}
.header {
  position: fixed;
  top: 44px;
  right: 0;
  left: 0;
  z-index: 10;
  background: var(--background-primary);
}
.list {
  &__item {
    padding: 30rpx;
    margin: 30rpx;
    border: 1px solid var(--border-color);
    border-radius: 20rpx;
    &:nth-of-type(1) {
      margin-top: 0;
    }
    &-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .token-info {
      display: flex;
      align-items: center;
      &__logo {
        width: 46rpx;
        height: 46rpx;
        margin-right: 20rpx;
        border-radius: 50%;
      }
      &__name {
        font-size: 30rpx;
        font-weight: 500;
      }
    }
    .detail-list {
      &-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 30rpx;
        &__label {
          color: var(--text-inactive);
        }
      }
    }
  }
}
</style>
