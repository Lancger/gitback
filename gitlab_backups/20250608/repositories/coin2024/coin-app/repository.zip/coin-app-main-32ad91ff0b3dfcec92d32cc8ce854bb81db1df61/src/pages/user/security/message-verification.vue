<template>
  <app-navbar :title="$t('safe.smsPage.title')" left-arrow></app-navbar>
  <!-- 绑定页面 -->
  <view class="p-30rpx" v-if="!userStore.userInfo.phone">
    <wd-form custom-class="auth-form mt-30rpx" ref="form" :model="model">
      <wd-input
        prop="phone"
        no-border
        use-prefix-slot
        use-suffix-slot
        v-model="model.phone"
        :placeholder="$t('safe.smsPage.phone')"
        :maxlength="11"
        type="number"
        :rules="[{ required: true, message: $t('safe.smsPage.phone') }]"
      >
        <template #prefix>
          <area-select-picker @on-confirm="onSelectPickerConfirm">
            <view class="center font-size-26rpx font-500">
              <view class="mr-10rpx">+{{ model.areaCode }}</view>
              <wd-icon name="arrow-down" size="26rpx"></wd-icon>
            </view>
          </area-select-picker>
        </template>
        <template #suffix>
          <view class="countDown" @click="countDown">
            {{ timeout ? t('safe.smsPage.sendTime', { time }) : $t('safe.smsPage.sendCode') }}
          </view>
        </template>
      </wd-input>
    </wd-form>
    <wd-password-input
      v-model="verificationCode"
      :mask="false"
      :gutter="10"
      :length="6"
      :focused="showKeyboard"
      @focus="showKeyboard = true"
    />
    <wd-number-keyboard
      v-model="verificationCode"
      v-model:visible="showKeyboard"
      :maxlength="6"
      @close="showKeyboard = false"
    />
    <wd-button class="mt-160rpx" size="large" block :disabled="disabled" @click="confirm">
      {{ $t('common.confirm') }}
    </wd-button>
  </view>
  <!-- 解绑页面 -->
  <view class="p-30rpx unbind" v-else>
    <view class="head">
      <text>{{ $t('safe.smsPage.bind') }}</text>
      <text>{{ userStore.userInfo.phone }}</text>
    </view>
    <view class="hint">
      {{ $t('safe.smsPage.bindDesc') }}
    </view>
    <wd-button class="po-fixed" size="large" block @click="unbind">
      {{ $t('safe.smsPage.unBind') }}
    </wd-button>
  </view>
  <wd-popup
    v-model="show"
    position="right"
    custom-style="width:100vw;paddingTop: 30rpx;"
    @close="show = false"
    closable
  >
    <verification :title="$t('safe.smsPage.title')" type="message-verification"></verification>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchSendSMS } from '@/service/base'
import { fetchAccountVerificationBinding } from '@/service/user'
import { useUserStore } from '@/store'
import { useMessage } from 'wot-design-uni'
import verification from './components/verification.vue'
const userStore = useUserStore()
const message = useMessage()
const time = ref(60)
const timeout = ref(null)
const model = reactive({
  areaCode: import.meta.env.VITE_AREACODE,
  phone: '',
  type: 4,
})
const show = ref(false)
const disabled = computed(() => {
  return !model.areaCode || !model.phone || verificationCode.value.length !== 6
})
const verificationCode = ref('')
const showKeyboard = ref(false)
const onSelectPickerConfirm = (e) => {
  model.areaCode = e.code
}

const countDown = () => {
  if (!model.phone) {
    return uni.showToast({
      title: t('safe.smsPage.rules.phone'),
      icon: 'none',
    })
  }
  if (timeout.value) return
  uni.showLoading()
  fetchSendSMS(model)
    .then((res) => {
      timeout.value = setInterval(() => {
        time.value -= 1
        if (time.value === 0) {
          clearInterval(timeout.value)
          timeout.value = null
          time.value = 60
        }
      }, 1000)
    })
    .finally(() => {
      uni.hideLoading()
    })
}

const confirm = () => {
  uni.showLoading()
  fetchAccountVerificationBinding({
    account: model.phone,
    accountType: 1,
    checkType: 2,
    phoneRegion: model.areaCode,
    verificationCode: verificationCode.value,
  })
    .then((res) => {
      userStore
        .getUserInfo()
        .then(() => {
          uni.showToast({
            title: t('common.success'),
            icon: 'none',
            success: function () {
              uni.navigateBack()
            },
          })
        })
        .finally(() => {
          uni.hideLoading()
        })
    })
    .finally(() => {
      uni.hideLoading()
    })
}

const unbind = () => {
  if (userStore.userInfo.phone && userStore.userInfo.google_key) {
    show.value = true
  } else {
    message.alert({
      title: t('safe.smsPage.dialog.title'),
      msg: t('safe.smsPage.dialog.msg'),
    })
  }
}
</script>

<style lang="scss" scoped>
.countDown {
  font-size: 30rpx;
  font-weight: 500;
  color: var(--color-primary);
}
:deep(.wd-password-input) {
  margin: 200rpx 0 0 !important;
}
:deep(.wd-password-input__item) {
  background: var(--background-tertiary) !important;
  border: 1px solid var(--border-color);
  border-radius: 10rpx !important;
}
.unbind {
  .head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    text:nth-child(1) {
      font-size: 30rpx;
      font-weight: 500;
      color: var(--text-primary);
    }
    text:nth-child(2) {
      color: var(--text-inactive);
    }
  }
  .hint {
    margin-top: 40rpx;
    font-size: 26rpx;
    line-height: 30rpx;
    color: var(--text-primary);
  }
  .po-fixed {
    position: fixed;
    right: 30rpx;
    bottom: 30rpx;
    left: 30rpx;
  }
}
</style>
