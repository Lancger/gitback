<template>
  <app-navbar title="Order details" />

  <view class="px-30rpx">
    <view class="py-30rpx mt-10rpx b-b">
      <view class="font-size-30rpx font-500">XRP 2.05 FSFGR</view>
      <view class="flex items-center gap-20rpx mt-20rpx">
        <app-tag type="success">Up</app-tag>
        <app-tag type="info">Options</app-tag>
      </view>
    </view>
    <view class="flex flex-col gap-y-30rpx mt-30rpx">
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">Order ID</view>
        <view class="font-500">0.0/4.9</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">Time</view>
        <view class="font-500">0.0/4.9</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">Vol</view>
        <view class="font-500">0.0/4.9</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">Price</view>
        <view class="font-500">0.0/4.9</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">Fee</view>
        <view class="font-500">0.0/4.9</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">Order duration</view>
        <view class="font-500">0.0/4.9</view>
      </view>
      <view class="flex items-center justify-between">
        <view class="color-[var(--text-inactive)]">Status</view>
        <view class="font-500">0.0/4.9</view>
      </view>
    </view>
  </view>
</template>

<script lang="ts" setup>
//
</script>

<style lang="scss" scoped>
//
</style>
