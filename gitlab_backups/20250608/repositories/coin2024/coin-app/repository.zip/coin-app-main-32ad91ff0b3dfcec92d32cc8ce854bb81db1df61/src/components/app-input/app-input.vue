<template>
  <view
    :class="[customClass, (focus || modelValue) && isPlaceholderTop ? 'app-input--focus' : null]"
    class="app-input"
  >
    <view class="app-input__left">
      <slot name="left"></slot>
    </view>
    <view v-if="isPlaceholderTop" class="app-input__label">
      {{ placeholder }}
    </view>
    <input
      v-model="inputValue"
      :placeholder="!isPlaceholderTop ? placeholder : ''"
      class="app-input__content"
      :type="type"
      placeholder-class="color-[var(--text-inactive)] font-400"
      :focus="focus"
      @focus="onFocus"
      @blur="onBlur"
      @input="onInput"
    />
    <view class="app-input__right">
      <slot name="right"></slot>
    </view>
  </view>
</template>

<script lang="ts" setup>
const props = defineProps({
  modelValue: {
    type: [String, Number],
    default: null,
  },
  type: {
    type: String,
    default: 'text',
  },
  customClass: {
    type: String,
    default: '',
  },
  placeholder: {
    type: String,
    default: '',
  },
  isPlaceholderTop: {
    type: Boolean,
    default: true,
  },
  formatter: {
    type: Function,
    default: null,
  },
})

const emits = defineEmits(['update:modelValue', 'onFocus'])

const focus = ref(false)
const inputValue = ref<number | string>('')

watchEffect(() => {
  inputValue.value = props.modelValue || ''
})

const onInput = (e) => {
  let value = e.detail.value

  if (props.formatter) {
    value = props.formatter(value)
  }

  nextTick(() => {
    inputValue.value = value
    emits('update:modelValue', value)
  })
}

const onFocus = () => {
  focus.value = true
  emits('onFocus')
}

const onBlur = () => {
  focus.value = false
}
</script>

<style lang="scss" scoped>
.app-input {
  position: relative;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  height: 72rpx;
  padding: 0 20rpx;
  &::after {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
    box-sizing: border-box;
    width: 200%;
    height: 200%;
    pointer-events: none;
    content: '';
    border: 1px solid var(--border-color);
    border-radius: 10rpx;
    transform: scale(0.5, 0.5);
    transform-origin: 0 0;
  }
  &__label {
    position: absolute;
    top: 50%;
    left: 0;
    padding: 0 20rpx;
    font-size: 28rpx;
    color: var(--text-inactive);
    pointer-events: none;
    transition: all 0.3s;
    transform: translateY(-50%);
  }
  &__content {
    box-sizing: border-box;
    flex: 1;
    height: 100%;
    min-height: 100%;
    font-size: 28rpx;
    font-weight: 500;
    line-height: auto;
  }
  &__right {
    display: flex;
    align-items: center;
    height: 100%;
  }
  &--focus {
    .app-input__label {
      top: 8rpx;
      font-size: 20rpx;
      transform: translateY(0);
    }
    .app-input__content {
      padding-top: 30rpx;
      font-size: 26rpx;
    }
  }
}
</style>
