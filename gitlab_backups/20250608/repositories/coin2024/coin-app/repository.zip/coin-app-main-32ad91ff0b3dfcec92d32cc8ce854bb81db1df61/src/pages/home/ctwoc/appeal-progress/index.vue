<template>
  <app-navbar
    :title="$t('c2c.appealProgress.title')"
    left-arrow
    custom-class="!bg-transparent"
  ></app-navbar>
  <view class="p-30rpx">
    <view v-for="item in appealOrder" :key="item.id" class="mb-30rpx">
      <view class="time">{{ formatDate(item.create_time) }}</view>
      <view v-if="item.type === '6'">
        <view class="box-finish">
          <view>{{ $t('c2c.appealProgress.appealResults') }}</view>
          <view>{{ $t('c2c.appealProgress.appealHasBeenWithdrawn') }}</view>
        </view>
      </view>
      <view v-else>
        <view class="box-list">
          <view class="box-list__title">{{ status(item) }}</view>
          <!-- <view class="box-list__content mb-20rpx">m166@163.com</view> -->
          <view class="mb-20rpx" v-if="item.type === '1'">
            <view class="box-list__name mb-10rpx">{{ $t('c2c.appealProgress.reason') }}</view>
            <view class="box-list__content">{{ item.reason }}</view>
          </view>
          <view class="mb-20rpx">
            <view class="box-list__name mb-10rpx">{{ $t('c2c.appealProgress.description') }}</view>
            <view class="box-list__content">{{ item.description }}</view>
          </view>
          <view class="box-list__img">
            <image v-for="src in item.proofArr" :src="src" :key="src"></image>
          </view>
        </view>
      </view>
    </view>
  </view>
</template>
<script lang="ts" setup>
import { t } from '@/locale'
import { fetchAppealOrder } from '@/service/ctwoc'
import { formatDate } from '@/utils/day'

const appealOrder = ref([])

const typeList = [
  {
    label: t('c2c.appealProgress.status1'),
    value: '1',
  },
  {
    label: t('c2c.appealProgress.status2'),
    value: '2',
  },
  {
    label: t('c2c.appealProgress.status3'),
    value: '3',
  },
  {
    label: t('c2c.appealProgress.status4'),
    value: '4',
  },
  {
    label: t('c2c.appealProgress.status5'),
    value: '5',
  },
  {
    label: t('c2c.appealProgress.status6'),
    value: '6',
  },
]
onLoad((e) => {
  fetchAppealOrder(e.orderId).then((res) => {
    console.log(res)
    appealOrder.value = res.data.map((item) => {
      return {
        proofArr: item.proof ? item.proof.split(',') : [],
        ...item,
      }
    })
    console.log(appealOrder.value)
  })
})

const status = (item) => {
  if (item.type === '1') {
    return t('c2c.appealProgress.status7')
  } else if (item.type === '5') {
    return t('c2c.appealProgress.status5')
  } else if (item.initiator_id) {
    return (
      t('c2c.appealProgress.complainant') + typeList.find((key) => key.value === item.type).label
    )
  } else if (!item.initiator_id) {
    return (
      t('c2c.appealProgress.Respondent') + typeList.find((key) => key.value === item.type).label
    )
  }
}
//
</script>
<style lang="scss" scoped>
.page {
  background-color: var(--background-tertiary);
}
.time {
  margin-bottom: 20rpx;
  color: var(--text-inactive);
}
.box-finish {
  padding: 30rpx;
  background-color: var(--background-primary);
  view:nth-child(1) {
    margin-bottom: 20rpx;
    font-weight: 500;
  }
}
.box-list {
  padding: 0 30rpx;
  background-color: var(--background-primary);
  &__title {
    padding: 30rpx 0;
    font-size: 30rpx;
    font-weight: 500;
  }
  &__name {
    font-size: 26rpx;
    color: var(--text-inactive);
  }
  &__content {
    font-size: 26rpx;
  }
  &__img {
    display: flex;
    flex-wrap: wrap;
    gap: 20rpx;
    align-items: center;
    padding-bottom: 30rpx;
    image {
      width: 150rpx;
      height: 150rpx;
    }
  }
}
//
</style>
