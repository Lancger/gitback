<template>
  <view id="chart" class="w-100% h-100%" />
</template>
<script setup>
import dayjs from 'dayjs'
import { init, dispose } from 'klinecharts'
import { fetchKLineHistory } from '@/service/market'
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'
import { useTradeStore, useThemeStore } from '@/store'
import config from '@/config'
import { toFormat, toFormatUnit } from '@/utils/number'

const props = defineProps({
  symbol: {
    type: String,
    default: 'BTC/USDT',
  },
  tradeType: {
    type: String,
    default: 'ubw',
  },
  precision: {
    type: Number,
    default: 2,
  },
  interval: {
    type: String,
    default: '',
  },
  isTime: {
    type: Boolean,
    default: false,
  },
  showVol: {
    type: Boolean,
    default: true,
  },
  showMA: {
    type: Boolean,
    default: true,
  },
  topicSymbol: {
    type: String,
    default: '',
  },
})

const tradeStore = useTradeStore()
const themeStore = useThemeStore()

let chart = null
const upColor = '#449782'
const downColor = '#DF484C'
const colorA = themeStore.isDark ? '#242631' : '#f2f3f3'
const font = 'Asap'
const candleType = props.isTime ? 'area' : 'candle_solid'
const topicTimeMap = {
  1: '1m',
  5: '5m',
  15: '15m',
  30: '30m',
  60: '1h',
  '1D': '1d',
  '1W': '1wk',
  '1M': '1mo',
}
const subTopic =
  subscribeMode === 'mqtt'
    ? `${props.tradeType}_kline_${props.symbol}`
    : `ws.kline.CSPOT.${props.topicSymbol}.1.${topicTimeMap[props.interval]}`

let paneId = []

watch(
  () => tradeStore.mainIndicatorValue,
  (newValue) => {
    if (chart) {
      if (newValue) {
        chart.createIndicator(newValue, false, { id: 'candle_pane' })
      } else {
        chart.removeIndicator('candle_pane')
      }
    }
  },
)

watch(
  () => tradeStore.subIndicatorValue,
  (newValue, oldValue) => {
    if (chart) {
      paneId.forEach((id) => {
        chart.removeIndicator(id)
      })
      nextTick(() => {
        paneId = []
        chart.createIndicator(tradeStore.mainIndicatorValue, false, { id: 'candle_pane' })
        newValue.forEach((name) => {
          onSetSubIndicator(name)
        })
      })
    }
  },
)

onMounted(async () => {
  onSubscribe(subTopic)
  chart = init('chart', {
    styles: {
      // 网格线
      grid: {
        horizontal: {
          family: font,
          color: colorA,
        },
        vertical: {
          family: font,
          color: colorA,
        },
      },
      // 蜡烛图
      candle: {
        // 蜡烛图类型 'candle_solid'|'candle_stroke'|'candle_up_stroke'|'candle_down_stroke'|'ohlc'|'area'
        type: candleType,
        // 蜡烛柱
        bar: {
          upColor,
          downColor,
          noChangeColor: upColor,
          upBorderColor: upColor,
          downBorderColor: downColor,
          noChangeBorderColor: upColor,
          upWickColor: upColor,
          downWickColor: downColor,
          noChangeWickColor: upColor,
        },
        // 提示
        tooltip: {
          showType: 'rect',
          showRule: 'follow_cross',
          text: {
            family: font,
          },
        },
        priceMark: {
          // 最新价标记
          last: {
            upColor,
            downColor,
            noChangeColor: upColor,
            text: {
              family: font,
            },
          },
        },
      },
      // x轴
      xAxis: {
        // x轴线
        axisLine: {
          family: font,
          color: colorA,
        },
        // x轴分割文字
        tickText: {
          color: '#b0b3bb',
          family: font,
        },
        // x轴分割线
        tickLine: {
          family: font,
          color: colorA,
        },
      },
      // y轴
      yAxis: {
        // y轴线
        axisLine: {
          family: font,
          color: colorA,
        },

        // x轴分割文字
        tickText: {
          color: '#b0b3bb',
          family: font,
        },
        // x轴分割线
        tickLine: {
          family: font,
          color: colorA,
        },
      },
      // 图表之间的分割线
      separator: {
        color: colorA,
        family: font,
        activeBackgroundColor: 'rgba(230, 230, 230, .15)',
      },
      // 技术指标
      indicator: {
        ohlc: {
          upColor,
          downColor,
          noChangeColor: upColor,
        },
        bars: [
          {
            upColor,
            downColor,
            noChangeColor: upColor,
          },
        ],
        tooltip: {
          family: font,
        },
      },
    },
    customApi: {
      formatDate: (timestamp, _, type) => {
        if (type === 0) {
          return dayjs(timestamp).format(config.dateFormat.YMDHM)
        }
        switch (props.interval) {
          case '1D':
          case '1W':
            return dayjs(timestamp).format(config.dateFormat.YMD)
          case '1M':
            return dayjs(timestamp).format(config.dateFormat.YM)
          default:
            return dayjs(timestamp).format(config.dateFormat.HM)
        }
      },
    },
    decimalFold: { threshold: 1000 },
  })

  chart.setPrecision({
    price: props.precision,
    volume: props.precision,
  })
  chart.setZoomEnabled(false)
  chart.setScrollEnabled(true)
  // 格式化数字
  chart.setThousandsSeparator({
    format: (value) => {
      const sign = config.groupingSeparator
      const v = `${value}`
      if (v.includes('.')) {
        const [integer, decimal] = v.split('.')
        return `${integer.replace(/(\d)(?=(\d{3})+$)/g, ($1) => `${$1}${sign}`)}${config.decimalSeparator}${decimal}`
      }
      return v.replace(/(\d)(?=(\d{3})+$)/g, ($1) => `${$1}${sign}`)
    },
  })
  // 指标
  if (props.showMA && tradeStore.mainIndicatorValue) {
    chart.createIndicator(tradeStore.mainIndicatorValue, false, { id: 'candle_pane' })
  }
  // 成交量
  if (props.showVol) {
    tradeStore.subIndicatorValue.forEach((name) => {
      onSetSubIndicator(name)
    })
  }

  chart.setLoadMoreDataCallback(async (params) => {
    if (params.type === 'backward') {
      params.callback([], false)
    }
    if (params.type === 'forward') {
      const data = await getList(params.data.timestamp - 1)
      params.callback(data, data.length !== 0)
    }
  })

  const data = await getList(Date.now())

  chart.applyNewData(data, data.length !== 0)

  // chart.subscribeAction('onScroll', (data) => {
  //   console.log(data)
  // })

  uni.$on('message', onMessage)
})

onUnmounted(() => {
  dispose('chart')
  onUnsubscribe(subTopic)
  uni.$off('message', onMessage)
})

function onSetSubIndicator(name) {
  paneId.push(chart.createIndicator(name))
}

function onMessage(msgData) {
  const [topic, data] = msgData
  if (chart && topic === subTopic) {
    const { kline } = data
    if (subscribeMode === 'mqtt') {
      if (props.interval === '1' && kline.period !== '1min') return
      if (props.interval === '5' && kline.period !== '5min') return
      if (props.interval === '15' && kline.period !== '15min') return
      if (props.interval === '30' && kline.period !== '30min') return
      if (props.interval === '60' && kline.period !== '60min') return
      if (props.interval === '240' && kline.period !== '4hour') return
      if (props.interval === '1D' && kline.period !== '1day') return
      if (props.interval === '1W' && kline.period !== '1week') return
      if (props.interval === '1M' && kline.period !== '1mon') return
    }
    chart.updateData({
      timestamp: kline.time * 1000,
      open: kline.openPrice,
      close: kline.closePrice,
      high: kline.highestPrice,
      low: kline.lowestPrice,
      volume: kline.volume,
      turnover: kline.turnover,
    })
  }
}

let isInit = true
let step = 1

function getList(to, ratio = 500) {
  let from = 0
  if (props.interval === '1D') {
    from = dayjs(to)
      .subtract(1 * ratio, 'day')
      .valueOf()
  } else if (props.interval === '1W') {
    from = dayjs(to)
      .subtract(1 * ratio, 'week')
      .valueOf()
  } else if (props.interval === '1M') {
    from = dayjs(to)
      .subtract(1 * ratio, 'month')
      .valueOf()
  } else {
    from = dayjs(to)
      .subtract(props.interval * ratio, 'minute')
      .valueOf()
  }
  return fetchKLineHistory({
    type: props.tradeType,
    symbol: props.symbol,
    from,
    to,
    resolution: props.interval,
  }).then((res) => {
    // fix: 后端 1、5、 30数据断了几天请求不到数据
    if (isInit && res.data.length === 0 && step <= 5) {
      step++
      return getList(Date.now(), ratio * step)
    }
    isInit = false
    return res.data.map((item) => {
      return {
        close: +item.closePrice,
        high: +item.highestPrice,
        low: +item.lowestPrice,
        open: +item.openPrice,
        volume: +item.volume,
        turnover: +item.turnover,
        timestamp: item.time * 1000,
      }
    })
  })
}
</script>
