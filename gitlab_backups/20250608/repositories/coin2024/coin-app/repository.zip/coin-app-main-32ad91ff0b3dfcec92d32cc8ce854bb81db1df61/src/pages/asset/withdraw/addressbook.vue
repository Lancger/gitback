<template>
  <app-navbar custom-class="bg-transparent" title="Address book">
    <template #right>
      <wd-icon name="view-module" size="22px" @click="navigator"></wd-icon>
    </template>
  </app-navbar>

  <view class="cell flex_jc" @click="bank">
    <view class="cell_icon">
      <image class="w-30rpx h-30rpx" src="@/static/images/assets/xuanzhong.png" mode="aspectFit" />
      <!-- <image
        class="w-30rpx h-30rpx"
        src="@/static/images/assets/weixuanzhong.png"
        mode="aspectFit"
      /> -->
    </view>
    <view class="cell_text flex_jc">
      <view class="flex">
        <view>
          <image
            class="w-76rpx h-76rpx mr3"
            src="@/static/images/assets/yan.png"
            mode="aspectFit"
          />
        </view>
        <view>
          <view class="cell_text_name">名称</view>
          <view class="cell_text_address">地址</view>
        </view>
      </view>
      <view>
        <image class="w-40rpx h-40rpx" src="@/static/images/assets/bianji.png" mode="aspectFit" />
      </view>
    </view>
  </view>
  <view class="btn">Confirm</view>
</template>
<script lang="ts" setup>
function navigator() {
  uni.navigateTo({
    url: `/pages/asset/deposit/History/index`,
  })
}

function bank() {
  uni.navigateBack()
}
</script>

<style lang="scss" scoped>
.page {
  background: var(--background-secondary);
}
.btn {
  width: 690rpx;
  height: 90rpx;
  margin: 50rpx auto;
  line-height: 90rpx;
  color: #fff !important;
  text-align: center;
  background-color: #00a7ed;
  border-radius: 100rpx;
}
.flex {
  display: flex;
  align-items: center;
}
.flex_jc {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.cell {
  width: 690rpx;
  margin: 28rpx auto;
  &_text {
    box-sizing: border-box;
    width: 630rpx;
    height: 144rpx;
    padding: 0 30rpx;
    background-color: var(--background-primary);
    border-radius: 16rpx;
    &_name {
      color: var(--text-inactive) !important;
    }
    &_address {
      color: var(--text-primary) !important;
    }
  }
}
</style>
