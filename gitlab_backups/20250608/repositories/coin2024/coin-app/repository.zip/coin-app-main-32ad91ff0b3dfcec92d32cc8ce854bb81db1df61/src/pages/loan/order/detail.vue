<template>
  <app-navbar :title="$t('loan.detail')"></app-navbar>
  <!--  -->
  <view class="flex flex-col gap-40rpx p-30rpx py-50rpx">
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.status') }}</view>
      <view class="color-[var(--color-primary)]">{{ formatStatus(info.status) }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.orderId') }}</view>
      <view>{{ info.order_code }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.loanTerm') }}</view>
      <view>{{ info.days }} {{ $t('loan.days') }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.totalDebt') }}</view>
      <view>{{ toFormat(info.total_debt, true) }} {{ info.loan_symbol }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.collateral') }}</view>
      <view>{{ toFormat(info.pledge_amount, true) }} {{ info.pledge_symbol }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.loanPrincipal') }}</view>
      <view>{{ toFormat(info.amount, true) }} {{ info.loan_symbol }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.dailyInterestRate') }}</view>
      <view>{{ toFormatPercent(info.interest_rate * 100) }}</view>
    </view>
    <view class="flex items-center justify-between font-siz-26rpx font-500">
      <view class="color-[var(--text-inactive)]">{{ $t('loan.loanTime') }}</view>
      <view>{{ formatDate(info.create_time) }}</view>
    </view>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { toFormat, toFormatPercent } from '@/utils/number'
import { formatDate } from '@/utils/day'

const info = ref(uni.getStorageSync('loanOrderItem') || {})

const formatStatus = (status) => {
  switch (+status) {
    case -1:
      return t('loan.reject')
    case 0:
      return t('loan.pendingReview')
    case 1:
      return t('loan.ongoing')
    default:
      return ''
  }
}
</script>

<style lang="scss" scoped>
//
</style>
