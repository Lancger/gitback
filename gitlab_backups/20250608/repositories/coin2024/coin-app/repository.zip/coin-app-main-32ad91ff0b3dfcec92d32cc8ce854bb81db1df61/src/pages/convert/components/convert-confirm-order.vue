<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    :z-index="99"
    closable
    custom-style="border-radius: 30rpx 30rpx 0 0"
    @close="onClose"
  >
    <view class="p-30rpx">
      <view class="font-size-32rpx font-600">{{ $t('convert.confirmOrder') }}</view>
      <view class="flex items-center my-50rpx">
        <view class="flex-1 flex flex-col items-center justify-center">
          <image class="w-60rpx h-60rpx rd-50%" :src="data.from.avatar" />
          <view class="my-10rpx font-size-24rpx color-[var(--text-inactive)]">
            {{ $t('convert.from') }}
          </view>
          <view class="font-size-35rpx font-600">
            {{ toFormat(data.from.val, true) }} {{ data.from.symbol }}
          </view>
        </view>
        <text class="i-carbon-arrow-right font-size-30rpx color-[var(--text-inactive)]"></text>
        <view class="flex-1 flex flex-col items-center justify-center">
          <image class="w-60rpx h-60rpx rd-50%" :src="data.to.avatar" />
          <view class="my-10rpx font-size-26rpx color-[var(--text-inactive)]">
            {{ $t('convert.to') }}
          </view>
          <view class="font-size-32rpx font-600">
            {{ toFormat(toVal, true) }} {{ data.to.symbol }}
          </view>
        </view>
      </view>
      <view class="flex flex-col gap-20rpx">
        <view class="flex items-center justify-between">
          <view class="font-size-26rpx color-[var(--text-inactive)]">{{ $t('convert.type') }}</view>
          <view class="font-size-26rpx font-500">{{ $t('convert.market') }}</view>
        </view>
        <view class="flex items-center justify-between">
          <view class="font-size-26rpx color-[var(--text-inactive)]">
            {{ $t('convert.transactionFees') }}
          </view>
          <view class="font-size-26rpx font-500">0 {{ data.to.symbol }}</view>
        </view>
        <view class="flex items-center justify-between">
          <view class="font-size-26rpx color-[var(--text-inactive)]">{{ $t('convert.rate') }}</view>
          <view class="flex items-center font-size-26rpx font-500">
            <view v-if="isSwitch">
              {{ toVal }} {{ data.to.symbol }} ≈ {{ data.from.val }} {{ data.from.symbol }}
            </view>
            <view v-else>
              1 {{ data.from.symbol }} ≈ {{ toFormat(rate, true) }} {{ data.to.symbol }}
            </view>
            <!-- <wd-icon
              custom-class="color-[var(--color-primary)] ml-10rpx"
              name="translate-bold"
              size="24rpx"
              @click="isSwitch = !isSwitch"
            ></wd-icon> -->
          </view>
        </view>
      </view>
      <wd-button custom-class="!w-100% mt-30rpx" size="large" :loading="loading" @click="onSubmit">
        <view v-if="!loading">{{ $t('common.confirm') }} ({{ time }}s)</view>
      </wd-button>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { fetchConvertExchangeRate, fetchConvertSubmit } from '@/service/convert'
import { onRouter } from '@/utils'
import { toFixed, toFormat } from '@/utils/number'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  data: {
    type: Object,
    default: () => ({}),
  },
})

const emits = defineEmits(['update:modelValue', 'onCallback'])

let timer = null
const loading = ref(false)
const rate = ref(0)
const time = ref(8)
const isSwitch = ref(false)
const toVal = computed(() => +toFixed(props.data.from.val * rate.value, 8))

watch(
  () => props.modelValue,
  async (newValue) => {
    if (newValue) {
      getRate()
    } else {
      clearTimeout(timer)
    }
  },
)

function onCountdown() {
  if (time.value < 1) {
    time.value = 8
    getRate()
    return
  }
  timer = setTimeout(() => {
    time.value--
    onCountdown()
  }, 1000)
}

function getRate() {
  loading.value = true
  return fetchConvertExchangeRate({
    fromSymbol: props.data.from.symbol,
    toSymbol: props.data.to.symbol,
  })
    .then((res) => {
      rate.value = res.data

      loading.value = false
      onCountdown()
    })
    .catch(() => {
      loading.value = false
    })
}

async function onSubmit() {
  clearTimeout(timer)
  loading.value = true
  try {
    await fetchConvertSubmit({
      fromCoinId: props.data.from.id,
      toCoinId: props.data.to.id,
      fromAmount: props.data.from.val,
    })
    emits('onCallback')
    onRouter('/pages/convert/history')
    onClose()
    loading.value = false
  } catch (error) {
    loading.value = false
  }
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped></style>
