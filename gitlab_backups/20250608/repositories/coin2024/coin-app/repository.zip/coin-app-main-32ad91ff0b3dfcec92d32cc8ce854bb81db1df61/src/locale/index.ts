import { createI18n } from 'vue-i18n'
import { Locale } from 'wot-design-uni'
// 引入英文语言包
import enUS from 'wot-design-uni/locale/lang/en-US'
import zhHK from 'wot-design-uni/locale/lang/zh-HK'
import thTH from 'wot-design-uni/locale/lang/th-TH'
import frFR from './wot-design-uni/fr-FR'
import arSA from './wot-design-uni/ar-SA'
import deDE from './wot-design-uni/de-DE'
import esES from './wot-design-uni/es-ES'
import jaJP from './wot-design-uni/ja-JP'
import koKR from './wot-design-uni/ko-KR'
import msMS from './wot-design-uni/ms-MS'
import ptPT from './wot-design-uni/pt-PT'
import ruRU from './wot-design-uni/ru-RU'
import trTR from './wot-design-uni/tr-TR'

import en from './en.json'
import fr from './fr.json'
import zhHant from './zh-Hant.json'
import ar from './ar.json'
import de from './de.json'
import es from './es.json'
import ja from './ja.json'
import ko from './ko.json'
import ms from './ms.json'
import pt from './pt.json'
import ru from './ru.json'
import th from './th.json'
import tr from './tr.json'

const locale = uni.getLocale()

const wotLocaleMap = {
  'en-US': enUS,
  'zh-HK': zhHK,
  'fr-PR': frFR,
  'th-TH': thTH,
  'ar-SA': arSA,
  'de-DE': deDE,
  'es-ES': esES,
  'ja-JP': jaJP,
  'ko-KR': koKR,
  'ms-MS': msMS,
  'pt-PT': ptPT,
  'ru-RU': ruRU,
  'tr-TR': trTR,
}

const localToWotLocalMap = {
  'zh-Hant': 'zh-HK',
  en: 'en-US',
  fr: 'fr-PR',
  th: 'th-TH',
  ar: 'ar-SA',
  de: 'de-DE',
  es: 'es-ES',
  ja: 'ja-JP',
  ko: 'ko-KR',
  ms: 'ms-MS',
  pt: 'pt-PT',
  ru: 'ru-RU',
  tr: 'tr-TR',
}

function onWotUiLocaleSwitch(key) {
  Locale.use(localToWotLocalMap[key], wotLocaleMap[localToWotLocalMap[key]])
}

onWotUiLocaleSwitch(locale)

uni.onLocaleChange((res) => {
  onWotUiLocaleSwitch(res.locale)
})

const messages = {
  en,
  fr,
  ar,
  de,
  es,
  ja,
  ko,
  ms,
  pt,
  ru,
  th,
  tr,
  'zh-Hant': zhHant,
}

const i18n = createI18n({
  locale,
  messages,
})

/**
 * 可以拿到原始的语言模板，非 vue 文件使用这个方法，
 * @param { string } key 多语言的key，eg: "app.name"
 * @returns {string} 返回原始的多语言模板，eg: "{heavy}KG"
 */
export const getTemplateByKey = (key: string) => {
  if (!key) {
    console.error(`[i18n] Function getTemplateByKey(), key param is required`)
    return ''
  }
  const locale = uni.getLocale()

  const message = messages[locale] // 拿到某个多语言的所有模板（是一个对象)
  if (Object.keys(message).includes(key)) {
    return message[key]
  }

  try {
    const keyList = key.split('.')
    return keyList.reduce((pre, cur) => {
      if (pre[cur]) {
        return pre[cur]
      }
      throw new Error('[i18n] Function getTemplateByKey(), Error')
    }, message)
  } catch (error) {
    console.error(`[i18n] Function getTemplateByKey(), key param ${key} is not existed.`)
    return ''
  }
}

/**
 * formatI18n('我是{name},身高{detail.height},体重{detail.weight}',{name:'张三',detail:{height:178,weight:'75kg'}})
 * 暂不支持数组
 * @param template 多语言模板字符串，eg: `我是{name}`
 * @param {Object|undefined} data 需要传递的数据对象，里面的key与多语言字符串对应，eg: `{name:'菲鸽'}`
 * @returns
 */
function formatI18n(template: string, data?: any) {
  return template.replace(/\{([^}]+)\}/g, function (match, key: string) {
    try {
      const keyList = key.split('.').map((item) => item.trim())
      return keyList.reduce((pre, cur) => {
        if (pre[cur]) {
          return pre[cur]
        }
        throw new Error('[i18n] Function formatI18n(), Error')
      }, data)
    } catch (error) {
      console.error(`[i18n] Function formatI18n(), key param ${key} is not existed.`)
      return ''
    }
  })
}

/**
 * t('introduction',{name:'张三',detail:{height:178,weight:'75kg'}})
 * => formatI18n('我是{name},身高{detail.height},体重{detail.weight}',{name:'张三',detail:{height:178,weight:'75kg'}})
 * 没有key的，可以不传 data；暂不支持数组
 * @param template 多语言模板字符串，eg: `我是{name}`
 * @param {Object|undefined} data 需要传递的数据对象，里面的key与多语言字符串对应，eg: `{name:'菲鸽'}`
 * @returns
 */
export function t(key, data?) {
  return formatI18n(getTemplateByKey(key), data)
}

export function $t(key, data?) {
  return i18n.global.t(key, data)
}

export default i18n
