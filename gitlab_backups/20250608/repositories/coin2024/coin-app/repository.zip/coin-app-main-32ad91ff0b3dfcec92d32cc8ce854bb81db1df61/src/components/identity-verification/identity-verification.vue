<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    :z-index="99"
    closable
    custom-style="border-radius: 40rpx 40rpx 0 0"
    @close="onClose"
  >
    <component :is="modelComponents" @onCallback="onCallback"></component>
  </wd-popup>
</template>

<script lang="ts" setup>
import googleAuthenticator from './modules/google-authenticator.vue'
import payPassword from './modules/pay-password.vue'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false,
  },
  model: {
    type: String,
    default: 'google',
  },
})

const emits = defineEmits(['update:modelValue', 'onCallback'])

const componentsMap = {
  google: googleAuthenticator,
  pay: payPassword,
}
const modelComponents = computed(() => componentsMap[props.model])

const onCallback = (params) => {
  emits('onCallback', params)
  onClose()
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped></style>
