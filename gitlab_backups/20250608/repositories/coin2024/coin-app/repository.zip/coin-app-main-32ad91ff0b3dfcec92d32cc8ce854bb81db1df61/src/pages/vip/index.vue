<template>
  <app-navbar custom-class="!bg-transparent"></app-navbar>
  <image class="absolute top-0 right-0 w-406rpx h-410rpx" :src="info.icon" mode="scaleToFill" />
  <view class="p-30rpx">
    <view class="w-50% mt-50rpx font-size-22rpx color-[var(--text-inactive)]">
      {{ $t('vip.vipLevel') }}
    </view>
    <view class="w-50% mt-40rpx font-size-40rpx font-500">{{ info.nameStr }}</view>
    <!-- <view class="w-50% mt-30rpx font-size-24rpx color-[var(--color-primary)]">Rate table</view> -->
    <!-- 1 -->
    <view class="mt-100rpx mb-30rpx font-size-24rpx color-[var(--text-inactive)]">
      {{ $t('vip.24') }}
    </view>
    <view class="p-40rpx border-1 border-solid border-[var(--border-color-inactive)] rd-15rpx">
      <view class="flex">
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ $t('vip.used') }}
          </view>
          <view class="mt-20rpx font-size-26rpx font-500">
            {{ toFormat(info.todayWithdrawalAmount) }} USDT
          </view>
        </view>
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ $t('vip.available') }}
          </view>
          <view class="mt-20rpx font-size-26rpx font-500">
            {{ toFormat(info.withdrawal_limit) }} USDT
          </view>
        </view>
      </view>
    </view>
    <!--  -->
    <view class="mt-40rpx mb-30rpx font-size-24rpx color-[var(--text-inactive)]">
      {{ $t('vip.fee') }}
    </view>
    <view class="p-40rpx border-1 border-solid border-[var(--border-color-inactive)] rd-15rpx">
      <view class="mb-30rpx font-size-28rpx font-500">
        {{ $t('vip.spotAccount') }}
      </view>
      <view class="flex">
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ $t('vip.orderPlacer') }}
          </view>
          <view class="mt-20rpx font-size-26rpx font-500">
            {{ toFormatPercent(info.spot_buy_rate * 100) }}
          </view>
        </view>
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ $t('vip.orderParty') }}
          </view>
          <view class="mt-20rpx font-size-26rpx font-500">
            {{ toFormatPercent(info.spot_sell_rate * 100) }}
          </view>
        </view>
      </view>
      <view class="b-b my-40rpx"></view>
      <view class="mb-30rpx font-size-28rpx font-500">
        {{ $t('vip.futuresAccount') }}
      </view>
      <view class="flex">
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ $t('vip.orderPlacer') }}
          </view>
          <view class="mt-20rpx font-size-26rpx font-500">
            {{ toFormatPercent(info.contract_buy_rate * 100) }}
          </view>
        </view>
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ $t('vip.orderParty') }}
          </view>
          <view class="mt-20rpx font-size-26rpx font-500">
            {{ toFormatPercent(info.contract_sell_rate * 100) }}
          </view>
        </view>
      </view>
    </view>
    <!--  -->
    <view class="mt-40rpx mb-30rpx font-size-24rpx color-[var(--text-inactive)]">
      {{ $t('vip.transactionData') }}
    </view>
    <view class="p-40rpx border-1 border-solid border-[var(--border-color-inactive)] rd-15rpx">
      <view class="flex">
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ $t('vip.30dSpotTradingVol') }}
          </view>
          <view class="mt-20rpx font-size-26rpx font-500">
            {{ toFormat(info.spotTransactionAmount) }} USDT
          </view>
        </view>
        <view class="flex-1">
          <view class="font-size-22rpx color-[var(--text-inactive)]">
            {{ $t('vip.30dFuturesTradingVol') }}
          </view>
          <view class="mt-20rpx font-size-26rpx font-500">
            {{ toFormat(info.contractTransactionAmount) }} USDT
          </view>
        </view>
      </view>
    </view>
    <!-- <view class="mt-40rpx font-size-26rpx color-[var(--color-primary)] underline">
      View all VIP plans
    </view> -->
  </view>
</template>

<script lang="ts" setup>
import { fetchMemberLevelInfo } from '@/service/member'
import { toFixed, toFormat, toFormatPercent } from '@/utils/number'

const info = ref<any>({})

onLoad(() => {
  getInfo()
})

function getInfo() {
  return fetchMemberLevelInfo().then((res) => {
    info.value = res.data
  })
}
</script>

<style lang="scss" scoped>
//
</style>
