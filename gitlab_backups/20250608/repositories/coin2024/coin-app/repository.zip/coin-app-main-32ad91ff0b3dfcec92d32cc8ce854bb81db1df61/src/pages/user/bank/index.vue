<template>
  <app-navbar :title="$t('bank.title')" left-arrow custom-class="!bg-transparent"></app-navbar>
  <view class="p-30rpx pt-40rpx">
    <view class="list" v-if="bankArr.length > 0">
      <view class="list__leftImg">
        <image src="@/static/images/user/bank-icon.png"></image>
      </view>
      <view class="list__content">
        <view>{{ model.name }}</view>
        <view>{{ model.bank }}</view>
      </view>
      <view class="list__rightImg" @click="show = true">
        <image src="@/static/images/user/modification-icon.png"></image>
      </view>
    </view>
    <app-empty v-if="bankArr.length === 0" no-data></app-empty>
    <wd-button
      class="add-button"
      @click="addAddress"
      size="large"
      block
      v-if="bankArr.length === 0"
    >
      {{ $t('bank.bankCardAdd') }}
    </wd-button>
    <!--  -->
    <wd-popup
      v-model="show"
      position="right"
      custom-style="width: 100vw;"
      @close="show = false"
      closable
    >
      <view class="popup">
        <view class="popup__title">
          <text>{{ $t('bank.bankCard') }}</text>
          <text @click="deleteData" v-if="bankArr.length > 0">{{ $t('bank.delete') }}</text>
        </view>
        <wd-form custom-class="auth-form mt-30rpx" ref="form" :model="model">
          <view>
            <view class="popup__name">{{ $t('bank.name') }}</view>
            <wd-input prop="name" no-border v-model="model.name" disabled></wd-input>
          </view>
          <view>
            <!-- <view v-if="countryName">{{ countryName }}</view>
            <view v-else class="popup__input__placeholder">Select</view> -->
            <area-select-picker
              selectMode="country"
              @on-confirm="onSelectPickerConfirm"
              v-model="model.country_id"
            >
              <wd-input
                prop="country_id"
                no-border
                v-model="countryName"
                suffix-icon="arrow-right"
              ></wd-input>
            </area-select-picker>
          </view>
          <view>
            <view class="popup__name">{{ $t('bank.bankCardNo') }}</view>
            <wd-input
              prop="account"
              no-border
              clearable
              v-model="model.account"
              :placeholder="$t('bank.input.bankCardNo')"
              :rules="[
                {
                  required: true,
                  message: $t('bank.rules.bankCardNo'),
                },
              ]"
            ></wd-input>
          </view>
          <view>
            <view class="popup__name">{{ $t('bank.depositBank') }}</view>
            <wd-input
              prop="bank"
              no-border
              clearable
              v-model="model.bank"
              :placeholder="$t('bank.input.depositBank')"
              :rules="[
                {
                  required: true,
                  message: $t('bank.rules.depositBank'),
                },
              ]"
            ></wd-input>
          </view>
          <view>
            <view class="popup__name">{{ $t('bank.bankAddress') }}</view>
            <wd-input
              no-border
              clearable
              v-model="model.branch"
              :placeholder="$t('bank.input.bankAddress')"
            ></wd-input>
          </view>
        </wd-form>
        <wd-button block size="large" @click="modify">
          {{ bankArr.length === 0 ? $t('bank.add') : $t('bank.edit') }}
        </wd-button>
      </view>
    </wd-popup>
    <!--  -->
    <wd-popup
      v-model="verificationShow"
      position="bottom"
      custom-style="height:70vh;paddingTop: 30rpx;"
      @close="verificationShow = false"
      closable
    >
      <verification
        :title="$t('safe.payPasswordPage.securityVerification')"
        :hint="$t('safe.payPasswordPage.tips')"
        @hidePopup="hidePopup"
        type="bank"
        ref="verificationRef"
      ></verification>
    </wd-popup>
  </view>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { fetchGetPayment, fetchGetData, fetchPayment, fetchGetNationList } from '@/service/user'
import { useUserStore } from '@/store'
import verification from '../security/components/verification.vue'
import { useMessage } from 'wot-design-uni'
const userStore = useUserStore()
const bankArr = ref([])
const show = ref(false)
const verificationShow = ref(false)
const form = ref()
const operationType = ref('')
const verificationRef = ref<any>()
const message = useMessage()
const model = reactive({
  code: '',
  checkType: 0,
  account: '',
  bank: '',
  branch: '',
  country_id: '',
  name: userStore.userInfo.real_name,
  pay_method_id: '',
  is_deleted: false,
})
const currCollection = ref({
  id: '',
})
const countryName = ref()

fetchGetData().then((res) => {
  currCollection.value = res.data.records[0]
})
const fetchGetPaymentFun = () => {
  fetchGetPayment().then((res) => {
    bankArr.value = res.data
    Object.assign(model, bankArr.value[0])
    fetchGetNationList({
      pageSize: '-521',
      column: 'sort',
      order: 'asc',
      is_auth: '1',
    }).then((res) => {
      console.log(res.data.records)
      res.data.records.forEach((item) => {
        if (item.id === model.country_id) {
          countryName.value = item.zh_name
        }
      })
    })
  })
}
const addAddress = () => {
  show.value = true
}
const onSelectPickerConfirm = (e) => {
  model.country_id = e.id
  countryName.value = e.zh_name
}
const modify = () => {
  if (bankArr.value.length === 0) {
    model.pay_method_id = currCollection.value.id
  }
  form.value.validate().then(({ valid, errors }) => {
    if (valid) {
      operationType.value = 'modify'
      // verificationShow.value = true
      fetchPaymentFun()
    }
  })
}

const hidePopup = (verificationCode, trading, phone) => {
  model.code = verificationCode
  // 谷歌验证checkType为3 手机号为1 邮箱为2
  if (trading === 0) {
    model.checkType = 3
  } else {
    if (phone) {
      model.checkType = 1
    } else {
      model.checkType = 2
    }
  }
  verificationShow.value = false

  if (operationType.value === 'delete') {
    model.is_deleted = true
    message
      .confirm({
        title: t('bank.delDialog.title'),
        msg: t('bank.delDialog.msg'),
      })
      .then(() => {
        fetchPaymentFun()
      })
    return
  }

  fetchPaymentFun()
}
const fetchPaymentFun = () => {
  uni.showLoading()
  fetchPayment(model)
    .then((res) => {
      fetchGetPaymentFun()
      show.value = false
      verificationRef.value.reset()
    })
    .finally(() => {
      uni.hideLoading()
    })
}
const deleteData = () => {
  operationType.value = 'delete'
  // verificationShow.value = true
  message
    .confirm({
      title: t('bank.delDialog.title'),
      msg: t('bank.delDialog.msg'),
    })
    .then(() => {
      model.is_deleted = true
      fetchPaymentFun()
    })
}
fetchGetPaymentFun()
</script>

<style lang="scss" scoped>
.page {
  background-color: var(--background-tertiary);
}

.list {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 144rpx;
  padding: 0 30rpx;
  background-color: var(--background-primary);
  border-radius: 16rpx;
  &__leftImg {
    width: 76rpx;
    height: 76rpx;
    image {
      width: 100%;
      height: 100%;
    }
  }
  &__content {
    flex: 1;
    padding-left: 30rpx;
    view:nth-child(1) {
      color: var(--text-inactive);
    }
    view:nth-child(2) {
      margin-top: 20rpx;
      color: var(--text-primary);
    }
  }
  &__rightImg {
    width: 40rpx;
    height: 40rpx;
    image {
      width: 100%;
      height: 100%;
    }
  }
}
.add-button {
  position: fixed;
  right: 30rpx;
  bottom: 50rpx;
  left: 30rpx;
}
.popup {
  padding: 30rpx;
  padding-top: 100rpx;
  &__title {
    display: flex;
    align-items: center;
    justify-content: space-between;
    text:nth-child(1) {
      font-size: 34rpx;
      color: var(--text-primary);
    }
    text:nth-child(2) {
      font-size: 30rpx;
      color: var(--text-active);
    }
  }
  &__name {
    margin-bottom: 30rpx;
    font-size: 30rpx;
    color: var(--text-primary);
  }
  &__input {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 90rpx;
    padding: 0 30rpx;
    margin-bottom: 30rpx;
    font-size: 30rpx;
    color: var(--text-primary);
    background-color: var(--input-bg-color);
    border: 1px solid var(--input-border-color);
    border-radius: 10rpx;
    &__placeholder {
      color: var(--text-inactive);
    }
    &__img {
      width: 14rpx;
      height: 10rpx;
    }
  }
}
</style>
