<template>
  <wd-popup
    :model-value="modelValue"
    position="bottom"
    custom-style="border-radius: 20rpx 20rpx 0 0"
    :z-index="99"
    closable
    @close="onClose"
  >
    <view class="popup-content p-30rpx py-50rpx">
      <view class="font-size-30rpx font-500">{{ $t('loan.repayment') }}</view>
      <view class="mt-50rpx">
        <view class="font-size-24rpx font-500">{{ $t('loan.totalRepayment') }}</view>
        <view
          class="flex items-center gap-20rpx h-90rpx px-30rpx mt-30rpx rd-15rpx bg-[var(--form-item-bg)]"
        >
          <input
            v-model="amount"
            class="flex-1 font-size-28rpx font-500"
            type="text"
            :placeholder="$t('loan.enterAmount')"
          />
          <view class="font-size-28rpx font-500 color-[var(--color-primary)]" @click="onMax">
            {{ $t('common.max') }}
          </view>
          <view v-if="assets.symbol" class="flex items-center gap-20rpx">
            <image class="w-40rpx h-40rpx" :src="assets.avatar" mode="scaleToFill" />
            <view class="font-size-28rpx font-600">{{ assets.symbol }}</view>
          </view>
          <wd-loading v-else :size="20" />
        </view>
      </view>
      <!--  -->
      <view class="mt-30rpx">
        <view class="font-size-22rpx font-500 color-[var(--text-inactive)]">
          {{ $t('loan.availableAssetsTwo') }} {{ toFormat(assets.balance, true) }}
          {{ assets.symbol }}
        </view>
        <view class="px-20rpx">
          <app-slider
            v-model="inputValue"
            :options="sliderOptions"
            :min="0"
            :max="100"
            @update:model-value="onSlider"
          ></app-slider>
        </view>
      </view>
      <!--  -->
      <view class="flex flex-col gap-40rpx mt-30rpx">
        <view class="flex items-center justify-between pb-30rpx b-b font-siz-26rpx font-500">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.totalDebt') }}</view>
          <view>{{ toFormat(rowData.total_debt, true) }} {{ rowData.loan_symbol }}</view>
        </view>
        <view class="flex items-center justify-between font-siz-26rpx font-500">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.remainingPrincipal') }}</view>
          <view>{{ toFormat(rowData.amount, true) }} {{ rowData.loan_symbol }}</view>
        </view>
        <view class="flex items-center justify-between font-siz-26rpx font-500">
          <view class="color-[var(--text-inactive)]">{{ $t('loan.remainingInterest') }}</view>
          <view>
            {{ toFormat(rowData.total_debt - rowData.repaymentAmount, true) }}
            {{ rowData.loan_symbol }}
          </view>
        </view>
      </view>
      <wd-button custom-class="mt-90rpx" size="large" block :loading="loading" @click="onSubmit">
        {{ $t('loan.repayment') }}
      </wd-button>
    </view>
  </wd-popup>
</template>

<script lang="ts" setup>
import { t } from '@/locale'
import { inputLimitToDigit, BNumber, toFixed, toFormat } from '@/utils/number'
import { fetchLoanRepayment } from '@/service/loan'
import { fetchGetCurrencyAccount } from '@/service/assets'

const props = defineProps({
  modelValue: {
    type: Boolean,
    default: true,
  },
  rowData: {
    type: Object,
    default: () => {},
  },
})

const emits = defineEmits(['update:modelValue', 'onCallBack'])

const sliderOptions = [
  {
    label: '0%',
    value: 0,
  },
  {
    label: '25%',
    value: 25,
  },
  {
    label: '50%',
    value: 50,
  },
  {
    label: '75%',
    value: 75,
  },
  {
    label: '100%',
    value: 100,
  },
]
const inputValue = ref(0)

const loading = ref(false)
const assets = ref<any>({})
const amount = ref(null)

watch(
  () => props.modelValue,
  (newVal) => {
    if (newVal) {
      assets.value = {}
      getWallet()
    }
  },
)

function onSlider(val) {
  amount.value =
    +toFixed(props.rowData.total_debt * (val / 100), assets.value.base_coin_scale) || null
}

async function onPlaceOrder() {
  loading.value = true
  try {
    await fetchLoanRepayment({
      id: props.rowData.id,
      number: amount.value,
    })
    uni.showToast({
      title: t('common.success'),
      icon: 'success',
      duration: 2000,
    })
    emits('onCallBack')
    onClose()
    loading.value = false
  } catch (e) {
    loading.value = false
  }
}

async function onSubmit() {
  onPlaceOrder()
}

function onMax() {
  inputValue.value = 100
  onSlider(100)
}

function getWallet() {
  return fetchGetCurrencyAccount({ type: 1 }).then((res) => {
    assets.value = res.data.find((item) => item.symbol === props.rowData.loan_symbol) || {}
  })
}

const onClose = () => {
  emits('update:modelValue', false)
}
</script>

<style lang="scss" scoped>
.popup-content {
  --form-item-bg: var(--background-secondary);
}
</style>
