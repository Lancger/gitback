import {
  onConnect as mqttConnect,
  onSubscribe as mqttSubscribe,
  onUnsubscribe as mqttUnsubscribe,
} from './mqtt'
import {
  onConnect as wsConnect,
  onSubscribe as wsSubscribe,
  onUnsubscribe as wsUnsubscribe,
} from './socket'

let onSubscribe = null
let onUnsubscribe = null
const subscribeMode = import.meta.env.VITE_SUBSCRIBEMODE

// init
if (subscribeMode === 'ws') {
  wsConnect()
  onSubscribe = wsSubscribe
  onUnsubscribe = wsUnsubscribe
} else {
  mqttConnect()
  onSubscribe = mqttSubscribe
  onUnsubscribe = mqttUnsubscribe
}

export { onSubscribe, onUnsubscribe, subscribeMode }
