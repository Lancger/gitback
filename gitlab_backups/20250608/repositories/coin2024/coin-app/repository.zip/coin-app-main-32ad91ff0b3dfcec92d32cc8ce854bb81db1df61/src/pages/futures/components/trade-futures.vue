<template>
  <!-- wrap -->
  <view class="wrap">
    <view class="px-30rpx py-25rpx border-b-1 border-b-[var(--background-gary-4)] border-b-solid">
      <view class="flex items-center">
        <view class="flex-1 flex items-center">
          <view class="flex items-center mr-20rpx" @click="showSelectToken = true">
            <view class="font-size-30rpx font-700">{{ symbol }}</view>
            <wd-icon custom-class="!font-700" name="caret-down-small" size="30rpx"></wd-icon>
          </view>
          <view :class="[tokenData.zdf >= 0 ? 'up-color' : 'down-color']" class="font-size-22rpx">
            <text class="mr-20rpx">
              {{ toFormat(tokenData.close, tokenConfigData.base_coin_scale) }}
            </text>
            <text>{{ toFormatPercent(tokenData.zdf) }}</text>
          </view>
        </view>
        <view
          class="center pl-22rpx mr-20rpx h-36rpx font-size-22rpx line-height-36rpx border-1 border-[var(--border-color)] border-solid rd-5rpx"
          @click="showLeverage = true"
        >
          <text>{{ walletData.leverage }}X</text>
          <wd-icon name="caret-down-small" size="22px"></wd-icon>
        </view>
        <image
          class="w-36rpx h-36rpx"
          :src="onImageToThemeImage('/static/images/icons/k-line.png')"
          @click="onRouter(`/pages/market/detail?symbol=${symbol}&type=ubw`)"
        />
      </view>
    </view>
    <view
      class="flex justify-end items-center mt-20rpx px-30rpx font-size-20rpx color-[var(--text-inactive)]"
    >
      <!-- <view class="mr-10rpx">
        {{ $t('futures.index.funding') }}
        <text class="color-[var(--text-active)]">{{ tokenConfigData.fundingRate || '--' }}%</text>
      </view> -->
      <view class="mr-10rpx">
        {{ $t('futures.index.overnight') }}
        <text class="color-[var(--text-active)]">
          {{ toFixed(tokenConfigData.night_rate * 100) || '--' }}%
        </text>
      </view>
      <view>
        {{ $t('futures.index.countdown') }}
        <text class="color-[var(--text-active)]">{{ fundingRateCountdown }}</text>
      </view>
    </view>
    <view class="flex p-30rpx px-20rpx pt-16rpx">
      <view class="w-42%">
        <order-book
          :order-book-data="orderBookData"
          :token-data="tokenData"
          :tokenConfig="tokenConfigData"
          :max="10"
          :min="5"
          @onSelect="(val) => (form.price = val)"
        ></order-book>
      </view>
      <view class="flex-1 p-l-20rpx overflow-hidden">
        <view class="trade-tag">
          <view
            v-for="(item, index) in directionList"
            :key="index"
            :class="{
              'in-active': directionIndex === item.value,
              'trade-tag__item-buy': index === 0,
              'trade-tag__item-sell': index === 1,
            }"
            class="trade-tag__item"
            @click="onSwitchDirection(item)"
          >
            <text class="trade-tag__item__text">{{ $t(item.label) }}</text>
          </view>
        </view>
        <view class="trade-type border-box" @click="showMode = true">
          <view class="trade-type__name">{{ modeList[mode].title }}</view>
          <wd-icon
            custom-class="!font-700 color-[var(--text-inactive)]"
            name="caret-down-small"
            size="26rpx"
          ></wd-icon>
        </view>
        <app-input
          v-if="modeKey === 'ptwt'"
          v-model="form.price"
          type="digit"
          custom-class="mt-20rpx"
          :placeholder="`${$t('futures.index.price')} (USDT)`"
          :formatter="(value) => inputLimitToDigit(value, BNumber(tokenData.close).dp() || 2)"
          @update:model-value="onInputEvent('price', $event)"
        >
          <template #right>
            <view class="exchange-rate">≈{{ userStore.onExchangeRateConversion(form.price) }}</view>
          </template>
        </app-input>
        <view
          v-if="modeKey === 'sjwt'"
          class="mt-20rpx h-72rpx font-size-26rpx font-500 line-height-72rpx text-center color-[var(--text-inactive)] rounded-10rpx bg-[var(--background-gary-4)]"
        >
          {{ $t('futures.index.marketPrice') }}
        </view>
        <app-input
          v-model="form.amount"
          :type="futuresUnit === 'u' ? 'digit' : 'number'"
          custom-class="mt-20rpx"
          :placeholder="`${futuresUnit === 'cont' ? $t('futures.index.volume') : $t('futures.index.margin')}`"
          :formatter="
            (value) =>
              inputLimitToDigit(value, futuresUnit === 'cont' ? 0 : tokenConfigData.coin_scale)
          "
          @update:model-value="onInputEvent('amount', $event)"
        >
          <template #right>
            <text class="font-size-26rpx font-500">{{ tradeStore.futuresConfig.unitLabel }}</text>
          </template>
        </app-input>
        <view v-if="futuresUnit === 'u'" class="mt-7rpx flex justify-between">
          <text class="color-[var(--text-inactive)]">{{ $t('futures.index.volume') }}</text>
          <text>
            <!-- {{ toFormat(BNumber(form.amount || 0).times(walletData.leverage || 0), true) }} USDT -->
            {{
              toFormat(
                +BNumber(form.amount).times(walletData.leverage).div(tokenData.close),
                +tokenConfigData.coin_scale,
              )
            }}
            {{ tokenConfigData.coin_symbol }}
          </text>
        </view>
        <view v-else class="mt-7rpx flex justify-between">
          <text class="color-[var(--text-inactive)]">{{ $t('futures.index.margin') }}</text>
          <text>{{ margin }} USDT</text>
        </view>
        <view class="mt-20rpx px-20rpx">
          <app-slider v-model="sliderValue" @update:model-value="onSlider"></app-slider>
        </view>
        <view class="stop-limit my-10rpx">
          <view class="flex items-center">
            <wd-checkbox v-model="isStopLimit" shape="square">
              {{ $t('futures.index.tp/sl') }}
              <text class="font-size-20rpx color-[var(--text-inactive)]">
                （{{ $t('futures.index.takeProfit') }}/{{ $t('futures.index.stopLoss') }}）
              </text>
            </wd-checkbox>
          </view>
          <template v-if="isStopLimit">
            <app-input
              v-model="form.takeProfitPrice"
              type="digit"
              custom-class="mt-20rpx"
              :formatter="(value) => inputLimitToDigit(value, BNumber(tokenData.close).dp() || 2)"
              :placeholder="$t('futures.index.takeProfit')"
            ></app-input>
            <app-input
              v-model="form.stopLossPrice"
              type="digit"
              custom-class="mt-20rpx"
              :formatter="(value) => inputLimitToDigit(value, BNumber(tokenData.close).dp() || 2)"
              :placeholder="$t('futures.index.stopLoss')"
            ></app-input>
          </template>
        </view>
        <block v-if="userStore.isLogined">
          <view class="mt-40rpx flex justify-between">
            <text class="color-[var(--text-inactive)]">{{ $t('futures.index.fee') }}</text>
            <text class="color-[var(--text-active)]">
              {{ fee }}
              USDT
            </text>
          </view>
          <view
            class="mt-14rpx flex justify-between"
            @click="onRouter('/pages/asset/transfer/index')"
          >
            <view class="color-[var(--text-inactive)] mr-10rpx">
              {{ $t('futures.index.available') }}
            </view>
            <view class="center">
              {{ toFormat(walletData.hyBaseBalance) }} USDT
              <wd-icon
                custom-class="color-[var(--color-primary)] ml-10rpx"
                name="translate-bold"
                size="24rpx"
              ></wd-icon>
            </view>
          </view>
          <wd-button
            custom-class="mt-20rpx"
            :type="directionIndex === 0 ? 'success' : 'error'"
            block
            @click="onNext(directionIndex === 0 ? 1 : 2)"
          >
            {{
              directionIndex === 0
                ? $t('futures.index.placeBuyOrder')
                : $t('futures.index.placeSellOrder')
            }}
          </wd-button>
        </block>
        <wd-button v-else custom-class="mt-20rpx" block @click="onRouter('/pages/auth/sign-in')">
          {{ $t('common.signIn') }}/{{ $t('common.signUp') }}
        </wd-button>
      </view>
    </view>
  </view>
  <!-- 订单 -->
  <view class="order-wrap">
    <view class="order-wrap__tab">
      <wd-tabs
        custom-class="app-tabs app-tabs--no-flex-1"
        v-model="orderTabIndex"
        swipeable
        animated
        :map-num="100"
        :slidable-num="3"
        @change="onOrderTabChange"
      >
        <block v-for="(item, index) in orderTab" :key="index">
          <wd-tab :title="$t(item.label)" :name="item.value">
            <!-- 持仓 -->
            <app-empty
              v-if="item.value === 'position'"
              :no-data="positionList.length === 0"
              custom-class="h-500rpx"
            >
              <view class="position-wrap">
                <view class="position-wrap__head">
                  <wd-button custom-class="position-wrap__btn" @click="onShowDialog('closeAll')">
                    {{ $t('futures.index.closeAll') }}
                  </wd-button>
                </view>

                <trade-position-list
                  :list="positionList"
                  :riskRate="riskRate"
                  @onEvent="onPositionEvent"
                ></trade-position-list>
              </view>
            </app-empty>
            <!-- 资产 -->
            <view v-if="item.value === 'assets'" class="assets-box">
              <view class="font-size-30rpx font-500">{{ $t('futures.index.assets.title') }}</view>
              <view class="assets-box__list">
                <view class="assets-box__list__item">
                  <image
                    class="assets-box__list__item__cover"
                    :src="tokenConfigData.base_avatar"
                    mode="aspectFit"
                  />
                  <view class="assets-box__list__item__title">
                    {{ tokenConfigData.base_symbol }}
                  </view>
                  <view class="assets-box__list__item__num">
                    {{ toFormat(walletData.hyBaseBalance) }}
                  </view>
                </view>
              </view>
              <view class="flex justify-between py-55rpx gap-20rpx">
                <wd-button
                  custom-class="flex-1"
                  type="info"
                  :round="false"
                  @click="onRouter('/pages/home/express/index')"
                >
                  {{ $t('futures.index.assets.buy') }}
                </wd-button>
                <wd-button
                  custom-class="flex-1"
                  type="info"
                  :round="false"
                  @click="onRouter('/pages/asset/deposit/index')"
                >
                  {{ $t('futures.index.assets.topUp') }}
                </wd-button>
                <wd-button
                  custom-class="flex-1"
                  type="info"
                  :round="false"
                  @click="onRouter('/pages/asset/transfer/index')"
                >
                  {{ $t('futures.index.assets.transfer') }}
                </wd-button>
              </view>
            </view>
            <app-empty
              v-if="item.value === 'dqwt'"
              :no-data="limitOrder.length === 0"
              custom-class="h-500rpx"
            >
              <trade-order-list
                trade-mode="futures"
                :list="limitOrder"
                @onCancel="
                  (e) => {
                    onShowDialog('orderCancel'), (positionRowData = e)
                  }
                "
              ></trade-order-list>
            </app-empty>
            <app-empty
              v-if="item.value === 'zyzs'"
              :no-data="stopLimitOrder.length === 0"
              custom-class="h-500rpx"
            >
              <trade-order-list
                trade-mode="futures"
                mode="stopLimit"
                :list="stopLimitOrder"
                @onCancel="
                  (e) => {
                    onShowDialog('stopLimitCancel'), (positionRowData = e)
                  }
                "
              ></trade-order-list>
            </app-empty>
          </wd-tab>
        </block>
      </wd-tabs>
      <!-- <image
        class="absolute top-28rpx right-30rpx w-32rpx h-32rpx"
        src="@img/icons/records.png"
        @click="onRouter('/pages/trade/history/index?t=futures')"
      /> -->
      <!-- <view
        class="absolute top-27rpx right-30rpx font-size-28rpx font-500"
        @click="onRouter('/pages/trade/history/index?t=futures')"
      >
        {{ $t('futures.index.history.title') }}
      </view> -->
    </view>
  </view>

  <!-- 选择币种 -->
  <select-token-popup
    v-model="showSelectToken"
    :list="futuresList"
    @onSelect="onSelectToken"
  ></select-token-popup>
  <!-- 选择交易模式 -->
  <trade-mode-popup v-model="mode" v-model:show="showMode" :list="modeList"></trade-mode-popup>
  <!-- 杠杆 -->
  <trade-leverage
    :model-value="Number(walletData.leverage)"
    v-model:show="showLeverage"
    :data="{
      ...tokenConfigData,
      ...walletData,
      unit: futuresUnit,
      unitLabel: tradeStore.futuresConfig.unitLabel,
    }"
    :max="Number(tokenConfigData.leverage || 100)"
    @onCallback="getWallet"
  ></trade-leverage>
  <!-- 下单确认 -->
  <confirm-order-dialog
    v-model="showConfirmDialog"
    :data="{
      ...form,
      leverage: walletData.leverage,
      orderType: modeKey,
      unit: futuresUnit,
      unitLabel: tradeStore.futuresConfig.unitLabel,
      margin,
    }"
    :loading="submitLoading"
    @onConfirm="onSubmit"
  ></confirm-order-dialog>
  <!-- dialog -->
  <app-dialog
    v-model="showDialog"
    :title="$t(dialogMain.title)"
    :content="$t(dialogMain.content)"
    :loading="dialogLoading"
    @onConfirm="onDialogConfirm"
  ></app-dialog>
  <!-- 平仓 -->
  <close-position-popup
    v-model="showClosePositionPopup"
    :row-data="positionRowData"
    @onCallback="
      () => {
        getPosition()
        getWallet()
      }
    "
  ></close-position-popup>
  <!-- 快速平仓 -->
  <fast-close-position-popup
    v-model="showFastClosePositionPopup"
    :row-data="positionRowData"
    @onCallback="
      () => {
        getPosition()
        getWallet()
      }
    "
  ></fast-close-position-popup>
  <!-- TP/SL -->
  <stop-limit-popup
    v-model="showStopLimitPopup"
    :row-data="positionRowData"
    @onCallback="
      () => {
        getStopLimitOrder()
        getWallet()
      }
    "
  ></stop-limit-popup>
  <!-- 反向开仓 -->
  <reverse-position-dialog
    v-model="showReverseDialog"
    :row-data="{
      ...positionRowData,
      unit: futuresUnit,
      unitLabel: tradeStore.futuresConfig.unitLabel,
    }"
    @onCallback="
      () => {
        getPosition()
        getWallet()
      }
    "
  ></reverse-position-dialog>
  <!-- 海报 -->
  <futures-poster v-model="showShare" :row-data="{ ...positionRowData }"></futures-poster>
</template>

<script lang="ts" setup>
import Schema from 'async-validator'
import confirmOrderDialog from './confirm-order-dialog.vue'
import closePositionPopup from './close-position-popup.vue'
import fastClosePositionPopup from './fast-close-position-popup.vue'
import reversePositionDialog from './reverse-position-dialog.vue'
import stopLimitPopup from './stop-limit-popup.vue'
import { t } from '@/locale'
import { useTradeStore, useUserStore, useSystemStore } from '@/store'
import { onImageToThemeImage, onRouter } from '@/utils'
import { toFixed, toFormat, inputLimitToDigit, BNumber, toFormatPercent } from '@/utils/number'
import { onSubscribe, onUnsubscribe, subscribeMode } from '@/utils/subscribe'
import { fetchTokenConfig, fetchTokenData, fetchOrderCancel } from '@/service/trade'
import {
  fetchFuturesPosition,
  fetchOrderList,
  fetchFuturesWallet,
  fetchPlaceOrder,
  fetchCloseAll,
  fetchGetFundingRate,
  fetchGetPositionRisk,
} from '@/service/futures'
import { fetchMarketData, fetchGetFutures } from '@/service/market'
import dayjs from '@/utils/day'

const tradeType = 'ubw'
const tradeStore = useTradeStore()
const userStore = useUserStore()
const systemStore = useSystemStore()
const showStopLimitPopup = ref(false)
const showFastClosePositionPopup = ref(false)
const showClosePositionPopup = ref(false)
const showDialog = ref(false)
const showConfirmDialog = ref(false)
const showLeverage = ref(false)
const showReverseDialog = ref(false)
const showShare = ref(false)
const directionList = [
  {
    label: 'futures.index.long',
    value: 0,
  },
  {
    label: 'futures.index.short',
    value: 1,
  },
]
const directionIndex = ref(0)
const modeList = computed(() => {
  return [
    {
      url: '/static/images/trade/market-order.png',
      title: t('trade.mode.market.title'),
      desc: t('trade.mode.market.desc'),
      value: 'sjwt',
    },
    {
      url: '/static/images/trade/limit-order.png',
      title: t('trade.mode.limit.title'),
      desc: t('trade.mode.limit.desc'),
      value: 'ptwt',
    },
  ]
})
const isStopLimit = ref(false)
const sliderValue = ref(0)
const showSelectToken = ref(false)
const showMode = ref(false)
const mode = ref(0)
const orderBookData = ref({})
const symbol = computed(() => tradeStore.futuresSymbol)
const walletData = ref<any>({
  leverage: 10,
  hyBaseBalance: 0,
  hyBaseFrozenBalance: 0,
})
const tokenData = ref<any>({})
const tokenConfigData = ref<any>({
  contract_size: 1000,
  base_coin_scale: 2,
  open_fee: 0,
})
const formDefault = () => {
  return {
    contractType: 1,
    direction: 1, // 1 开多 2 开空 3 平多 4 平空
    exchangeCoinStr: symbol.value,
    pattern: 2,
    patternType: 1,
    amount: null,
    price: null,
    takeProfitPrice: null,
    stopLossPrice: null,
  }
}
const form = reactive<any>(formDefault())
const modeKey = computed(() => modeList.value[mode.value].value)
const orderTab = ref([
  {
    label: 'futures.index.tabs.position',
    value: 'position',
  },
  {
    label: 'futures.index.tabs.orders',
    value: 'dqwt',
  },
  {
    label: 'futures.index.tabs.tp/sl',
    value: 'zyzs',
  },
  {
    label: 'futures.index.tabs.assets',
    value: 'assets',
  },
  {
    label: 'futures.index.history.title',
    value: 'history',
  },
])
const orderTabIndex = ref('position')
const positionList = ref([])
const limitOrder = ref([])
const stopLimitOrder = ref([])
const submitLoading = ref(false)

const subMap = ref({
  [`${tradeType}_detail_${symbol.value}`]: onAllSymbolFun,
  [`${tradeType}_deptH_${symbol.value}`]: onOrderBookFn,
  all_symbol_detail: onAllSymbolFun,
  [`FORCE_${userStore.userInfo.id}`]: onForceCloseFn,
})
const futuresUnit = computed(() => tradeStore.futuresConfig.unit)

const dialogMainMap = {
  closeAll: {
    title: 'futures.index.closeAllDialog.title',
    content: 'futures.index.closeAllDialog.content',
    fun: onCloseAll,
  },
  orderCancel: {
    title: 'futures.index.orderCancelDialog.title',
    content: 'futures.index.orderCancelDialog.content',
    fun: onLimitOrderCancel,
  },
  stopLimitCancel: {
    title: 'futures.index.stopLimitCancelDialog.title',
    content: 'futures.index.stopLimitCancelDialog.content',
    fun: onStopLimitOrderCancel,
  },
}
const dialogKey = ref('closeAll')
const dialogLoading = ref(false)
const dialogMain = computed(() => dialogMainMap[dialogKey.value])

const positionRowData = ref<any>({})
const futuresList = ref([])

// 张数最大手续费
// 余额 * 杠杠 * 手续费
const maxFee = computed(() => {
  return toFixed(
    BNumber(walletData.value.hyBaseBalance || 0)
      .times(walletData.value.leverage)
      .times(tokenConfigData.value.open_fee),
    tokenConfigData.value.base_coin_scale,
  )
})

const fee = computed(() => {
  if (futuresUnit.value === 'u') {
    // 金额 * 杠杠 * 手续费
    return toFormat(
      BNumber(form.amount || 0)
        .times(walletData.value.leverage)
        .times(tokenConfigData.value.open_fee),
    )
  } else {
    // 张数 * 面值 * 手续费
    return toFormat(
      BNumber(form.amount || 0)
        .times(tokenConfigData.value.contract_size)
        .times(tokenConfigData.value.open_fee),
    )
  }
})

const margin = computed(() => {
  return toFormat(
    BNumber(form.amount || 0).times(
      tokenConfigData.value.contract_size / walletData.value.leverage || 0,
    ),
  )
})

// 最大开仓数量
const maxOpen = computed(() => {
  if (futuresUnit.value === 'u') {
    return Number(
      toFixed(
        BNumber(walletData.value.hyBaseBalance).minus(maxFee.value),
        tokenConfigData.value.base_coin_scale,
      ),
    )
  } else {
    // return Math.floor(
    //   +BNumber(walletData.value.hyBaseBalance)
    //     .minus(maxFee.value)
    //     .div(tokenConfigData.value.contract_size / walletData.value.leverage),
    // )
    return calculateMaxCards(
      +walletData.value.hyBaseBalance,
      +tokenConfigData.value.open_fee,
      +tokenConfigData.value.contract_size,
      +walletData.value.leverage,
    )
  }
})

// 风险率
const riskRate = computed(() => {
  // 持仓保证金
  const positionMargin = positionList.value.reduce((acc, cur) => {
    return acc + Number(cur.principal_amount)
  }, 0)
  // 持仓盈亏
  const pl = positionList.value.reduce((acc, cur) => {
    return acc + Number(cur.pl || 0)
  }, 0)
  // 总市值
  const marketValue = +BNumber(walletData.value.hyBaseBalance)
    .plus(positionMargin)
    .plus(walletData.value.hyBaseFrozenBalance)
  return toFixed(BNumber(marketValue).plus(pl).div(positionMargin).times(100), 2)
})

watch(symbol, async () => {
  form.exchangeCoinStr = symbol.value
  onUnsubscribe(getSubTopic())
  await getTokenData()
  getTokenConfig()
  getWallet()
  getOrderBook()
  geFundingRate()
  onFormDefault()
  subMap.value = {
    [`${tradeType}_detail_${symbol.value}`]: onAllSymbolFun,
    [`${tradeType}_deptH_${symbol.value}`]: onOrderBookFn,
    all_symbol_detail: onAllSymbolFun,
    [`FORCE_${userStore.userInfo.id}`]: onForceCloseFn,
  }
  onSubscribe(getSubTopic())
})

watch(mode, () => {
  onFormDefault()
})

watch(directionIndex, () => {
  onFormDefault()
})

let timer = null
let isMounted = true
const timeSeconds = 3 * 1000
watch(orderTabIndex, () => {
  clearTimeout(timer)
  timer = setTimeout(onGetList, timeSeconds)
})

onLoad(async () => {
  getTokenConfig()
  getOrderBook()
  geFundingRate()
  await getPosition(true)
  await getLimitOrder()
  await getStopLimitOrder()
})

onShow(async () => {
  isMounted = true
  await getTokenData()
  await getFutures()
  getWallet()

  form.exchangeCoinStr = symbol.value

  onSubscribe(getSubTopic())
  uni.$on('message', onMessage)

  clearTimeout(timer)
  timer = setTimeout(onGetList, timeSeconds)
})

onHide(() => {
  isMounted = false
  clearTimeout(timer)
  onUnsubscribe(getSubTopic())
  uni.$off('message', onMessage)
})

onUnload(() => {
  isMounted = false
  clearTimeout(timer)
  onUnsubscribe(getSubTopic())
  uni.$off('message', onMessage)
})

function onForceCloseFn(data) {
  positionList.value = []
  getPosition()
  getWallet()
}

function getSubTopic() {
  if (subscribeMode === 'mqtt') {
    return Object.keys(subMap.value)
  } else {
    const allSymbol = futuresList.value
      .filter((item) => Boolean(item.subText))
      .map((item) => `ws.market.CSPOT.${item.subText}.1`)
    return [
      `ws.depth.CSPOT.${tokenData.value.subText}.1`,
      `ws.market.CSPOT.${tokenData.value.subText}.1`,
      ...allSymbol,
    ]
  }
}

async function onGetList() {
  switch (orderTabIndex.value) {
    case 'position':
      await getPosition()
      break
    case 'dqwt':
      await getLimitOrder()
      break
    case 'zyzs':
      await getStopLimitOrder()
      break
    case 'assets':
      return
    default:
  }

  if (isMounted) {
    timer = setTimeout(onGetList, timeSeconds)
  }
}

const positionSymbolMap = new Map()
const futuresListSymbolMap = new Map()
function onAllSymbolFun(data) {
  if (data.type !== 'ubw' && subscribeMode === 'mqtt') return
  if (
    (data.symbolName === symbol.value && subscribeMode === 'mqtt') ||
    (data.symbol === tokenData.value.subText && subscribeMode === 'ws')
  ) {
    onTokenFn(data)
  }

  if (futuresListSymbolMap.get(data.symbolName) || subscribeMode === 'ws') {
    let findFun
    if (subscribeMode === 'ws') {
      findFun = (item) => data.symbol === item.subText
    } else {
      findFun = (item) => data.symbolName === item.symbolName
    }
    // 合约列表
    const fIndex = futuresList.value.findIndex(findFun)
    if (fIndex !== -1) {
      futuresList.value.splice(fIndex, 1, {
        ...futuresList.value[fIndex],
        close: data.close,
        zdf: data.zdf,
      })
    }
  }

  if (positionSymbolMap.get(data.symbolName) || subscribeMode === 'ws') {
    onUpdatePosition(data)
  }
}

// 资金费率
const fundingRateCountdown = ref('00:00:00')
function onFundingRateCountdown() {
  // const hourCount = 8
  // const intervalSeconds = hourCount * 3600
  // const nowTime = Math.floor(new Date().getTime() / 1000)
  // const diffTime = nowTime % intervalSeconds
  // const remainder = intervalSeconds - diffTime
  // console.log(diffTime, remainder)
  // systemStore.serverTime.
  const nowTime = dayjs().utc().tz(systemStore.serverTime.timeZone)
  // const endTime = dayjs(dayjs().add(1, 'day').format('YYYY/MM/DD 00:00:00')).tz(
  //   systemStore.serverTime.timeZone,
  // )
  const endTime = nowTime.endOf('d')
  // console.log(nowTime.format(), endTime.format())
  const remainder = (+endTime - +nowTime) / 1000
  const h = String(Math.floor(remainder / 3600))
  const m = String(Math.floor((remainder % 3600) / 60))
  const s = String(Math.floor(remainder % 60))
  fundingRateCountdown.value = `${h.padStart(2, '0')}:${m.padStart(2, '0')}:${s.padStart(2, '0')}`
  if (remainder <= 0) {
    geFundingRate()
    return
  }
  setTimeout(onFundingRateCountdown, 1000)
}
function geFundingRate() {
  return fetchGetFundingRate(symbol.value).then((res) => {
    tokenConfigData.value = {
      ...tokenConfigData.value,
      fundingRate: toFixed(res.data * 100, 4),
    }
    onFundingRateCountdown()
  })
}

const onShowDialog = (key) => {
  dialogKey.value = key
  showDialog.value = true
}

const onDialogConfirm = async () => {
  await dialogMain.value.fun()
  showDialog.value = false
}

async function onCloseAll() {
  dialogLoading.value = true
  try {
    await fetchCloseAll({
      oneKeySymbolNameList: positionList.value.map((item) => item.symbol_name),
      contractType: 1,
    })
    getPosition()
    getWallet()
    uni.showToast({
      title: t('common.success'),
      icon: 'none',
    })
  } catch (error) {
    //
  } finally {
    dialogLoading.value = false
  }
}

const onSelectToken = (e) => {
  tradeStore.futuresSymbol = e.symbolName
}

const onOrderTabChange = ({ index, name }) => {
  switch (name) {
    case 'position':
      getPosition()
      break
    case 'dqwt':
      getLimitOrder()
      break
    case 'zyzs':
      getStopLimitOrder()
      break
    case 'assets':
      getWallet()
      break
    case 'history':
      onRouter('/pages/trade/history/index?t=futures')
      nextTick(() => {
        orderTabIndex.value = 'position'
      })
      break
    default:
  }
}

const onPositionEvent = ([event, row]) => {
  positionRowData.value = row
  switch (event) {
    case 'reverse':
      showReverseDialog.value = true
      break
    case 'stopLimit':
      showStopLimitPopup.value = true
      break
    case 'fastClose':
      showFastClosePositionPopup.value = true
      break
    case 'close':
      showClosePositionPopup.value = true
      break
    case 'share':
      showShare.value = true
      break
    default:
  }
}

function onLimitOrderCancel() {
  return fetchOrderCancel({
    idList: [positionRowData.value.id],
    type: 'contract_dqwt',
  }).then((res) => {
    getLimitOrder()
  })
}

function onStopLimitOrderCancel() {
  return fetchOrderCancel({
    idList: [positionRowData.value.id],
    type: 'contract_zyzs',
  }).then((res) => {
    getStopLimitOrder()
  })
}

const onNext = (direction) => {
  const validator = new Schema({
    amount: {
      type: 'string',
      required: true,
      message: t('futures.index.volume'),
      validator: (rule, value) => {
        return Boolean(+value)
      },
    },
    price: {
      type: 'string',
      required: true,
      message: t('futures.index.price'),
      validator: (rule, value) => {
        return Boolean(+value)
      },
    },
  })
  form.direction = direction
  validator
    .validate(form)
    .then(() => {
      showConfirmDialog.value = true
    })
    .catch(({ errors, fields }) => {
      uni.showToast({
        icon: 'none',
        title: errors[0].message,
      })
    })
}

function onSubmit() {
  submitLoading.value = true
  // U ｜ 张数
  const price = modeKey.value === 'ptwt' ? form.price : tokenData.value.close
  const amount =
    futuresUnit.value === 'u'
      ? toFixed(
          BNumber(form.amount).times(walletData.value.leverage).div(price),
          +walletData.value.coin_coin_scale,
        )
      : form.amount
  return fetchPlaceOrder(`open/${modeKey.value}`, {
    ...form,
    amount,
  })
    .then(async (res) => {
      uni.showToast({
        title: t('common.success'),
        icon: 'none',
      })
      submitLoading.value = false
      showConfirmDialog.value = false
      onFormDefault()
      getWallet()
      switch (modeKey.value) {
        case 'sjwt':
          getPosition(true)
          break
        case 'ptwt':
          getLimitOrder(true)
          break
        case 'zyzs':
          getStopLimitOrder(true)
          break
        default:
      }
    })
    .catch((_) => {
      submitLoading.value = false
    })
}

const onSlider = (val) => {
  if (futuresUnit.value === 'u') {
    form.amount = val
      ? toFixed(BNumber(maxOpen.value).times(val / 100), tokenConfigData.value.base_coin_scale)
      : null
  } else {
    // 最大买入张数公式： (余额 - 最大手续费) * x / (合约张数 / 杠杠)
    form.amount = val ? toFixed(BNumber(maxOpen.value).times(val / 100), 0) : null
  }
}

// 输入框
function onInputEvent(type, value) {
  switch (type) {
    case 'amount':
      if (maxOpen.value > 0) {
        sliderValue.value = (value / maxOpen.value) * 100
        if (sliderValue.value >= 100) {
          nextTick(() => {
            form.amount = maxOpen.value
          })
        }
      }
      break
    default:
  }
}

// 切换方向
function onSwitchDirection(item) {
  directionIndex.value = item.value
}

function onUpdatePosition(data) {
  if (data.type !== 'ubw' && subscribeMode === 'mqtt') return
  positionList.value = positionList.value.map((item) => {
    if (
      (item.symbol_name !== data.symbolName && subscribeMode === 'mqtt') ||
      (item.subText !== data.symbol && subscribeMode === 'ws')
    ) {
      return item
    }
    item.avg_price = toFixed(item.avg_price, item.base_coin_scale)
    const contractSize =
      futuresList.value.find((item) => item.symbolName === data.symbolName)?.contract_size ||
      tokenConfigData.value.contract_size ||
      1000
    const marketValue = BNumber(item.balance)
      .plus(item.frozen_balance)
      .times(futuresUnit.value === 'cont' ? contractSize || 0 : item.avg_price)
    const ratio =
      item.direction === 1
        ? BNumber(data.close).minus(item.avg_price).div(item.avg_price)
        : BNumber(item.avg_price).minus(data.close).div(item.avg_price)
    item.pl = toFixed(BNumber(marketValue).times(ratio))
    item.plRatio = `${toFixed(BNumber(item.pl).div(item.principal_amount).times(100))}%`
    item.marginRatio = `${toFixed(
      BNumber(+item.balance + +item.frozen_balance)
        .times(item.avg_price)
        .times(
          (+tokenConfigData.value.close_fee || 0) +
            (+tokenConfigData.value.maintenance_margin_rate || 0),
        )
        .div(item.principal_amount)
        .times(100),
    )}%`
    item.closePrice = toFixed(data.close, item.base_coin_scale)
    item.forcePrice = toFixed(item.forcePrice, item.base_coin_scale)
    return item
  })
}

async function getPosition(select?: boolean) {
  // const riskRate = await fetchGetPositionRisk()
  return fetchFuturesPosition('ubw').then((res) => {
    positionList.value = res.data.map((item, index) => {
      positionSymbolMap.set(item.symbol_name, true)
      if (
        positionList.value[index] &&
        positionList.value[index].symbol_name === item.symbol_name &&
        positionList.value[index].direction === item.direction
      ) {
        return {
          ...positionList.value[index],
          ...item,
          leverage: item.leverage.toUpperCase(),
        }
      }
      return {
        ...item,
        leverage: item.leverage.toUpperCase(),
      }
    })

    // // 合约列表更新持仓
    // futuresList.value.forEach((item) => {
    //   onUpdatePosition({
    //     ...item,
    //     type: 'ubw',
    //   })
    // })

    if (
      orderTab.value.findIndex((item) => item.value === 'position') === -1 &&
      positionList.value.length > 0
    ) {
      orderTab.value.unshift({
        label: 'futures.index.tabs.position',
        value: 'position',
      })
    }

    if (positionList.value.length > 0 && select) {
      orderTabIndex.value = 'position'
    }

    // if (positionList.value.length <= 0) {
    //   orderTab.value = orderTab.value.filter((item) => item.value !== 'position')
    //   orderTabIndex.value === 'position' && (orderTabIndex.value = 'assets')
    // }
  })
}

function getLimitOrder(select?: boolean) {
  return fetchOrderList(`${tradeType}/dqwt`, {
    pageNo: 1,
    pageSize: -521,
  }).then((res) => {
    limitOrder.value = res.data.map((item) => {
      return {
        ...item,
        symbol: item.symbol_name,
        direction: item.direction,
        date: item.create_time,
        price: item.entrust_price,
        qty: Number(item.entrust_balance),
        total: BNumber(item.entrust_price).times(item.entrust_balance),
        ratio: `${toFixed(BNumber(item.success_balance).div(item.entrust_balance).times(100))}%`,
      }
    })
    if (
      orderTab.value.findIndex((item) => item.value === 'dqwt') === -1 &&
      limitOrder.value.length > 0
    ) {
      orderTab.value.push({
        label: 'futures.index.tabs.orders',
        value: 'dqwt',
      })
    }

    if (limitOrder.value.length > 0 && select) {
      orderTabIndex.value = 'dqwt'
    }

    // if (limitOrder.value.length <= 0) {
    //   orderTab.value = orderTab.value.filter((item) => item.value !== 'dqwt')
    //   orderTabIndex.value === 'dqwt' && (orderTabIndex.value = 'assets')
    // }
  })
}

function getStopLimitOrder(select?: boolean) {
  return fetchOrderList(`${tradeType}/zyzs`, {
    pageNo: 1,
    pageSize: -521,
  }).then((res) => {
    stopLimitOrder.value = res.data.map((item) => {
      return {
        ...item,
        symbol: item.symbol_name,
        direction: item.direction,
        date: item.create_time,
        price: item.entrust_price,
        qty: Number(item.entrust_balance),
        total: Number(item.entrust_total_balance),
        stopPrice: Number(item.trigger_price),
      }
    })
    if (
      orderTab.value.findIndex((item) => item.value === 'zyzs') === -1 &&
      stopLimitOrder.value.length > 0
    ) {
      orderTab.value.push({
        label: 'futures.index.tabs.tp/sl',
        value: 'zyzs',
      })
    }

    if (stopLimitOrder.value.length > 0 && select) {
      orderTabIndex.value = 'zyzs'
    }

    // if (stopLimitOrder.value.length <= 0) {
    //   orderTab.value = orderTab.value.filter((item) => item.value !== 'zyzs')
    //   orderTabIndex.value === 'zyzs' && (orderTabIndex.value = 'assets')
    // }
  })
}

function onTokenFn(data) {
  Object.assign(tokenData.value, data)
}

function onOrderBookFn(data) {
  orderBookData.value = data
}

function onMessage(msgData) {
  const [topic, data] = msgData
  if (subMap.value[topic] && subscribeMode === 'mqtt') {
    subMap.value[topic](data)
    return
  }

  if (topic.indexOf('market') !== -1) {
    onAllSymbolFun(data)
  }

  if (topic.indexOf('depth') !== -1) {
    onOrderBookFn(data)
  }
}

function getTokenData() {
  return fetchTokenData({
    symbolNameList: [symbol.value],
    type: tradeType,
  }).then((res) => {
    tokenData.value = res.data[symbol.value]
    tokenData.value.symbolName = symbol.value
    form.price = tokenData.value.close
  })
}

function getTokenConfig() {
  return fetchTokenConfig(`${tradeType}/${symbol.value.replace('/', '_')}`).then((res) => {
    tokenConfigData.value = {
      ...tokenConfigData.value,
      ...res.data,
    }
  })
}

function getWallet() {
  return fetchFuturesWallet(symbol.value.replace('/', '_')).then((res) => {
    walletData.value = res.data
  })
}

function getOrderBook() {
  return fetchMarketData({
    type: `deptH_${tradeType}_deptH_${symbol.value}`,
  }).then((res) => {
    orderBookData.value = res.data
  })
}

function getFutures() {
  return fetchGetFutures().then((res) => {
    futuresList.value = res.data.filter((item) => item.contract_type === '1')
    futuresList.value.forEach((item) => {
      onUpdatePosition({
        ...item,
        type: 'ubw',
      })
      futuresListSymbolMap.set(item.symbolName, true)
    })
  })
}

function onFormDefault() {
  Object.assign(form, formDefault(), {
    exchangeCoinStr: symbol.value,
    price: tokenData.value.close,
  })
  sliderValue.value = 0
}

// 计算最大可开张数
function calculateMaxCards(balance, feeRate, cardValue, leverage) {
  if (!balance || !feeRate || !cardValue || !leverage) return 0
  // 初始最大张数为0
  let maxCards = 0

  // 当余额足够支付一定数量的卡和手续费时，增加张数
  while (true) {
    // 尝试购买下一个张数的总成本
    const potentialCost = ((maxCards + 1) * cardValue) / leverage
    const totalCostWithFee = potentialCost + (maxCards + 1) * cardValue * feeRate
    // 如果余额足够支付这笔交易，继续增加张数，否则退出循环
    if (totalCostWithFee <= balance) {
      maxCards += 1
    } else {
      break
    }
  }

  return maxCards
}
</script>

<style lang="scss" scoped>
.app-tabs {
  :deep(.wd-tabs__nav-item) {
    font-size: 28rpx !important;
    color: var(--text-active);
  }
  :deep(.wd-tabs__nav-item.is-active) {
    font-size: 30rpx !important;
    font-weight: 600 !important;
    color: var(--text-primary);
  }
}
.position-wrap {
  &__head {
    display: flex;
    gap: 20rpx;
    align-items: center;
    justify-content: flex-end;
    // height: 60rpx;
    padding: 10rpx 30rpx;
    border: 1px solid var(--background-gary-4);
    border-right: none;
    border-left: none;
  }
  &__btn {
    flex: none !important;
    min-width: auto !important;
    height: 60rpx !important;
    margin: 0;
    // font-size: 20rpx;
  }
}
.order-wrap {
  margin-top: 20rpx;
  background: var(--background-primary);
  &__tab {
    position: relative;
    display: flex;
    align-items: center;
    border-bottom: 1px solid var(--background-gary-4);
    // :deep(.wd-tabs__nav--wrap) {
    //   padding-right: 100rpx !important;
    // }
    :deep(.wd-tabs__line) {
      display: none;
    }
  }
  .assets-box {
    padding: 30rpx;
    &__list {
      padding: 20rpx 30rpx 10rpx;
      margin: 0 -30rpx;
      border-bottom: 1px solid var(--background-gary-4);
      &__item {
        display: flex;
        align-items: center;
        padding: 20rpx 0;
        &__cover {
          width: 50rpx;
          height: 50rpx;
          border-radius: 50%;
        }
        &__title {
          flex: 1;
          padding: 0 20rpx;
          font-size: 30rpx;
          font-weight: 500rpx;
        }
        &__num {
          font-size: 30rpx;
          font-weight: 500rpx;
        }
      }
    }
  }
}
.border-box {
  position: relative;
  &::after {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
    box-sizing: border-box;
    width: 200%;
    height: 200%;
    pointer-events: none;
    content: '';
    border: 1px solid var(--border-color);
    transform: scale(0.5, 0.5);
    transform-origin: 0 0;
  }
}
.wrap {
  background: var(--background-primary);
  border-radius: 20rpx 20rpx 0 0;
  .exchange-rate {
    align-self: flex-end;
    padding-bottom: 8rpx;
    font-size: 20rpx;
    color: var(--text-inactive);
  }
  .trade-type {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12rpx 20rpx;
    margin-top: 20rpx;
    &::after {
      border-radius: 10rpx;
    }
    &__name {
      font-size: 26rpx;
      font-weight: 500;
    }
  }
  .trade-tag {
    display: flex;
    gap: 40rpx;
    align-items: center;
    &__item {
      position: relative;
      box-sizing: border-box;
      width: 50%;
      height: 60rpx;
      font-size: 26rpx;
      font-weight: 500;
      line-height: 60rpx;
      text-align: center;
      background: var(--background-gary-7);
      border-radius: 100rpx;
      transition: all 0.3s;
      &__text {
        position: relative;
        z-index: 2;
      }
      &::before {
        position: absolute;
        top: 0;
        right: -10rpx;
        z-index: 1;
        width: 50%;
        height: 100%;
        content: '';
        background-color: inherit;
        transform: translate(0) rotate(0) skewX(-35deg) skewY(0) scaleX(1) scaleY(1);
        transform-origin: center;
      }
      + .trade-tag__item {
        &::before {
          right: auto;
          left: -10rpx;
        }
      }
    }
    &__item-buy.in-active {
      color: #fff;
      background: var(--color-green);
    }
    &__item-sell.in-active {
      color: #fff;
      background: var(--color-red);
    }
  }
}
</style>
