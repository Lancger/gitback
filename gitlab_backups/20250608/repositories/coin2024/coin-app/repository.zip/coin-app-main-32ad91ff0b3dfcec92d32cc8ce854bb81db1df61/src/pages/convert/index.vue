<template>
  <app-navbar custom-class="bg-transparent" :title="$t('convert.title')"></app-navbar>
  <convert-home></convert-home>
</template>

<script lang="ts" setup>
import ConvertHome from './components/convert-home.vue'
</script>

<style lang="scss" scoped>
//
</style>
