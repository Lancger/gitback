<template>
  <app-navbar :title="$t('user.accountCancellation.title')"></app-navbar>
  <view class="flex items-center gap-20rpx p-30rpx">
    <wd-img
      custom-class="!block rd-20rpx overflow-hidden"
      width="100rpx"
      height="100rpx"
      :src="logo || '/static/logo.png'"
    ></wd-img>
    <view class="font-size-32rpx font-500">{{ systemStore.systemConfig.appName }}</view>
  </view>
  <view class="center mt-30rpx">
    <wd-icon custom-class="color-[var(--color-red)]" name="warn-bold" size="60px"></wd-icon>
  </view>
  <view class="font-size-40rpx font-500 text-center mt-30rpx">
    {{ $t('user.accountCancellation.deleteAccount') }}
  </view>
  <view class="mt-30rpx mx-30rpx p-30rpx bg-[var(--background-primary)] rd-20rpx">
    <view class="font-size-28rpx font-500">
      {{ $t('user.accountCancellation.deleteAccountTips') }}
    </view>
    <view class="mt-20rpx font-size-24rpx font-500 color-[var(--text-inactive)] lh-36rpx">
      {{ $t('user.accountCancellation.deleteAccountTips2') }}
    </view>
  </view>

  <app-footer>
    <view class="p-30rpx">
      <view class="font-size-22rpx font-500 mb-20rpx text-center color-[var(--text-inactive)]">
        {{ $t('user.accountCancellation.deleteAccountTips3') }}
      </view>
      <wd-button type="error" size="large" block @click="onAccountCancellation">
        {{ $t('user.accountCancellation.deleteAccount') }}
      </wd-button>
    </view>
  </app-footer>
</template>

<script lang="ts" setup>
import { useMessage, useToast } from 'wot-design-uni'
import { t } from '@/locale'
import { useUserStore, useSystemStore, useThemeStore } from '@/store'
import { fetchDeleteAccount } from '@/service/user'

const userStore = useUserStore()
const systemStore = useSystemStore()
const themeStore = useThemeStore()
const { userInfo } = toRefs(userStore)
const message = useMessage()
const toast = useToast()

const logo = computed(() =>
  themeStore.isDark ? systemStore.systemConfig.darkLogo : systemStore.systemConfig.lightLogo,
)

const onAccountCancellation = () => {
  message
    .confirm({
      title: t('user.accountCancellation.dialog.title'),
      msg: t('user.accountCancellation.dialog.msg'),
      beforeConfirm: async ({ resolve }) => {
        toast.loading(t('common.loading'))
        try {
          await fetchDeleteAccount()
          toast.close()
          resolve(true)
          toast.success(t('common.success'))
          userStore.onLogout()
          uni.reLaunch({
            url: '/pages/auth/sign-in',
          })
        } catch (error) {
          //
        }
      },
    })
    .then(async () => {
      // if (userInfo.value.email) {
      //   userStore.accountCancellationList.push(userInfo.value.email)
      // }
      // if (userInfo.value.phone) {
      //   userStore.accountCancellationList.push(userInfo.value.phone)
      // }
    })
}
</script>

<style lang="scss" scoped>
.page {
  background-color: var(--background-secondary);
}
</style>
