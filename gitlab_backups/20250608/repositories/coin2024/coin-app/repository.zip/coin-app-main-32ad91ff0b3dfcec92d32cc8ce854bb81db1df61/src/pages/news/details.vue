<template>
  <app-navbar :title="title" left-arrow></app-navbar>
  <view class="p-30rpx">
    <!-- <mp-html :content="articleContent" /> -->
    <div v-html="articleContent"></div>
  </view>
</template>
<script lang="ts" setup>
// @ts-expect-error 没有声明文件
import mpHtml from 'mp-html/dist/uni-app/components/mp-html/mp-html'
import { fetchFormDetailData, fetchFormData } from '@/service/base'

const articleContent = ref('')
const title = ref('')

onLoad(async (options) => {
  if (options.code) {
    const resData = await fetchFormData('1530431184536666113', {
      article_code: options.code,
      article_lang: uni.getLocale() === 'zh-Hant' ? 'zh_tw' : uni.getLocale(),
    })
    const [first] = resData.data.records
    options.id = first.id
  }

  fetchFormDetailData('1530431184536666113', options.id).then((res) => {
    title.value = res.data.article_title
    articleContent.value = res.data.article_content
  })
})
</script>
<style lang="scss" scoped>
img {
  max-width: 100%;
}
</style>
