<template>
  <view v-for="item in list" :key="item" class="mx-30rpx py-36rpx b-b">
    <view class="flex items-center justify-between">
      <view class="font-size-30rpx font-500">{{ item.pair_name }}-{{ item.time_name }}</view>
      <view>
        <wd-count-down
          :time="dayjs(item.end_time_number).valueOf() - dayjs().valueOf()"
          @finish="emits('onCountDownEnd')"
        >
          <template #default="{ current }">
            <view class="flex items-center gap-10rpx">
              <text
                class="w-32rpx font-size-20rpx color-#fff text-center bg-[var(--color-primary)] rd-5rpx"
              >
                {{ current.hours }}
              </text>
              <text class="font-size-24rpx font-500">:</text>
              <text
                class="w-32rpx font-size-20rpx color-#fff text-center bg-[var(--color-primary)] rd-5rpx"
              >
                {{ current.minutes }}
              </text>
              <text class="font-size-24rpx font-500">:</text>
              <text
                class="w-32rpx font-size-20rpx color-#fff text-center bg-[var(--color-primary)] rd-5rpx"
              >
                {{ current.seconds }}
              </text>
            </view>
          </template>
        </wd-count-down>
      </view>
    </view>
    <view class="flex items-center justify-between gap-20rpx mt-20rpx">
      <app-tag :type="item.up_down === 1 ? 'success' : 'error'">
        {{ item.up_down === 1 ? 'Up' : 'Down' }}
      </app-tag>
      <app-tag type="info">
        {{ $t('optionV2.options') }}
      </app-tag>
      <view class="flex-1 text-right font-size-22rpx color-[var(--text-inactive)]">
        {{ $t('optionV2.expirationDate') }} {{ formatDate(item.end_time) }}
      </view>
    </view>
    <view class="flex flex-wrap gap-y-26rpx mt-30rpx">
      <view class="w-33.33%">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('optionV2.volume') }}({{ $t('optionV2.unit') }})
        </view>
        <view class="font-size-24rpx font-500 mt-20rpx">{{ item.bet_amount }}</view>
      </view>
      <view class="w-33.33% text-center">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('optionV2.rate') }}
        </view>
        <view class="font-size-24rpx font-500 mt-20rpx">{{ item.odds }}</view>
      </view>
      <view class="w-33.33% text-right">
        <view class="font-size-22rpx color-[var(--text-inactive)]">
          {{ $t('optionV2.orderNumber') }}
        </view>
        <view class="font-size-24rpx font-500 mt-20rpx">{{ item.order_no }}</view>
      </view>
      <!-- <view class="w-33.33% text-center">
        <view class="font-size-22rpx color-[var(--text-inactive)]">Mark price</view>
        <view class="font-size-24rpx font-500 mt-20rpx">0.5096 (+8.32%)</view>
      </view>
      <view class="w-33.33% text-right">
        <view class="font-size-22rpx color-[var(--text-inactive)]">Break-even price(%)</view>
        <view class="font-size-24rpx font-500 mt-20rpx">0.5096 (+8.32%)</view>
      </view> -->
    </view>
    <!--  -->
    <!-- <view class="flex items-center gap-20rpx mt-40rpx">
      <wd-button custom-class="flex-1" type="info">Add to position</wd-button>
      <wd-button custom-class="flex-1" type="info">Close</wd-button>
    </view> -->
  </view>
</template>

<script lang="ts" setup>
import dayjs, { formatDate } from '@/utils/day'

const props = defineProps({
  list: {
    type: Array<any>,
    default: () => [],
  },
})

const emits = defineEmits(['onCountDownEnd'])
</script>

<style lang="scss" scoped>
//
</style>
