import { defineUniPages } from '@uni-helper/vite-plugin-uni-pages'
import path from 'node:path'
import { loadEnv } from 'vite'

// 获取环境变量的范例
const env = loadEnv(process.env.NODE_ENV!, path.resolve(process.cwd(), 'env'))
const { VITE_APP_TITLE } = env

export default defineUniPages({
  globalStyle: {
    navigationStyle: 'custom',
    navigationBarTitleText: VITE_APP_TITLE,
    navigationBarBackgroundColor: '#ffffff',
    navigationBarTextStyle: 'white',
    backgroundColor: '#FFFFFF',
  },
  easycom: {
    autoscan: true,
    custom: {
      '^wd-(.*)': 'wot-design-uni/components/wd-$1/wd-$1.vue',
      '^(?!z-paging-refresh|z-paging-load-more)z-paging(.*)':
        'z-paging/components/z-paging$1/z-paging$1.vue',
    },
  },
  tabBar: {
    color: '#999999',
    selectedColor: '#018d71',
    backgroundColor: '#F8F8F8',
    borderStyle: 'black',
    list: [
      {
        iconPath: '/static/tabbar/home.png',
        selectedIconPath: '/static/tabbar/home_act.png',
        pagePath: 'pages/home/index',
        text: 'tabbar.home',
        visible: false,
      },
      {
        iconPath: '/static/tabbar/market.png',
        selectedIconPath: '/static/tabbar/market_act.png',
        pagePath: 'pages/market/index',
        text: 'tabbar.market',
        visible: false,
      },
      {
        iconPath: '/static/tabbar/trade.png',
        selectedIconPath: '/static/tabbar/trade_act.png',
        pagePath: 'pages/trade/index',
        text: 'tabbar.trade',
        visible: false,
      },
      {
        iconPath: '/static/tabbar/futures.png',
        selectedIconPath: '/static/tabbar/futures_act.png',
        pagePath: 'pages/futures/index',
        text: 'tabbar.futures',
        visible: false,
      },
      {
        iconPath: '/static/tabbar/assets.png',
        selectedIconPath: '/static/tabbar/assets_act.png',
        pagePath: 'pages/asset/index',
        text: 'tabbar.assets',
        visible: false,
      },
    ],
  },
})
