package org.springblade.auth.config;

import org.springblade.auth.exception.EmailOAuth2Exception;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.provider.error.DefaultWebResponseExceptionTranslator;

@Configuration
public class EmailExceptionTranslator extends DefaultWebResponseExceptionTranslator {
	@Override
	public ResponseEntity<OAuth2Exception> translate(Exception e) throws Exception {
		if (e instanceof EmailOAuth2Exception) {
			OAuth2Exception oAuth2Exception = OAuth2Exception.create(OAuth2Exception.ACCESS_DENIED, e.getMessage());
			oAuth2Exception.addAdditionalInformation("required", "email");
			return ResponseEntity.ok(oAuth2Exception);
		}
		return super.translate(e);
	}
}
