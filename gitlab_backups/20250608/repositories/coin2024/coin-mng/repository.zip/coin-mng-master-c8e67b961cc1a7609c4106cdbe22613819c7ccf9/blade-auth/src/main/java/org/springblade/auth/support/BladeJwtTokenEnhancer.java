/*
 *      Copyright (c) 2018-2028, Chill Zhuang All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *  Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in the
 *  documentation and/or other materials provided with the distribution.
 *  Neither the name of the dreamlu.net developer nor the names of its
 *  contributors may be used to endorse or promote products derived from
 *  this software without specific prior written permission.
 *  Author: Chill 庄骞 (smallchill@163.com)
 */
package org.springblade.auth.support;

import cn.hutool.http.useragent.UserAgent;
import cn.hutool.http.useragent.UserAgentUtil;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import lombok.AllArgsConstructor;
import org.springblade.auth.mapper.MjkjAuthMapper;
import org.springblade.auth.service.BladeUserDetails;
import org.springblade.auth.utils.AddressUtils;
import org.springblade.auth.utils.TokenUtil;
import org.springblade.core.jwt.JwtUtil;
import org.springblade.core.jwt.props.JwtProperties;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.core.tool.utils.WebUtil;
import org.springblade.third.cache.CacheNames;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;

import java.util.HashMap;
import java.util.Map;

/**
 * jwt返回参数增强
 *
 * @author Chill
 */
@AllArgsConstructor
public class BladeJwtTokenEnhancer implements TokenEnhancer {

	private final JwtAccessTokenConverter jwtAccessTokenConverter;
	private final JwtProperties jwtProperties;
	private final BladeRedis bladeRedis;
	private final MjkjAuthMapper mjkjAuthMapper;

	@Override
	public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {
		BladeUserDetails principal = (BladeUserDetails) authentication.getUserAuthentication().getPrincipal();

		//token参数增强
		Map<String, Object> info = new HashMap<>(16);
		info.put(TokenUtil.CLIENT_ID, TokenUtil.getClientIdFromHeader());
		info.put(TokenUtil.USER_ID, Func.toStr(principal.getUserId()));
		info.put(TokenUtil.DEPT_ID, Func.toStr(principal.getDeptId()));
		info.put(TokenUtil.POST_ID, Func.toStr(principal.getPostId()));
		info.put(TokenUtil.ROLE_ID, Func.toStr(principal.getRoleId()));
		info.put(TokenUtil.TENANT_ID, principal.getTenantId());
		info.put(TokenUtil.OAUTH_ID, principal.getOauthId());
		info.put(TokenUtil.ACCOUNT, principal.getAccount());
		info.put(TokenUtil.USER_NAME, principal.getUsername());
		info.put(TokenUtil.NICK_NAME, principal.getName());
		info.put(TokenUtil.REAL_NAME, principal.getRealName());
		info.put(TokenUtil.ROLE_NAME, principal.getRoleName());
		info.put(TokenUtil.AVATAR, principal.getAvatar());
		info.put(TokenUtil.DETAIL, principal.getDetail());
		info.put(TokenUtil.LICENSE, TokenUtil.LICENSE_NAME);
		((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(info);

		//token状态设置
		if (jwtProperties.getState()) {
			OAuth2AccessToken oAuth2AccessToken = jwtAccessTokenConverter.enhance(accessToken, authentication);
			String accessTokenValue = oAuth2AccessToken.getValue();
			String tenantId = principal.getTenantId();
			String userId = Func.toStr(principal.getUserId());
			JwtUtil.addAccessToken(tenantId, userId, accessTokenValue, accessToken.getExpiresIn());
			// 清除token黑名单
			bladeRedis.del(CacheNames.BLACK_LIST+tenantId+":"+principal.getUserId());

			try {
				String str = Func.toStr(principal.getDetail().get("deviceId"));
				if (Func.isNotEmpty(str)) {
					Map<String, Object> member = mjkjAuthMapper.getMember(principal.getUserId());
					final UserAgent userAgent = UserAgentUtil.parse(WebUtil.getHeader("User-Agent"));
					String Key = "blade_device_" + principal.getUserId()+str;
					bladeRedis.setEx(Key, accessTokenValue, Long.valueOf(accessToken.getExpiresIn()));
					// 获取客户端操作系统
					// String os = userAgent.getOs().getName();
					// 获取客户端浏览器
					String browser = userAgent.isMobile() ? WebUtil.getHeader("model") : userAgent.getBrowser().getName();
					Map<String, Object> device = mjkjAuthMapper.getDevice(String.valueOf(principal.getUserId()),str);
					if (Func.isEmpty(device)) {
						mjkjAuthMapper.addDevice(IdWorker.getId(),Func.toStr(member.get("id")),browser,DateUtil.now(),WebUtil.getIP(),DateUtil.now(),DateUtil.now(),AddressUtils.getRealAddressByIP(WebUtil.getIP()),accessToken.getValue(),str);
					} else {
						mjkjAuthMapper.updateDevice(Func.toStr(device.get("id")), DateUtil.parse(Func.toStr(device.get("update_time")), DateUtil.PATTERN_DATETIME),DateUtil.now(), accessToken.getValue());
					}
				}
			} catch (Exception e) {

			}



			if (jwtProperties.getSingle()) {
				OAuth2RefreshToken oAuth2RefreshToken = oAuth2AccessToken.getRefreshToken();
				String refreshTokenValue = oAuth2RefreshToken.getValue();
				JwtUtil.addRefreshToken(tenantId, userId, refreshTokenValue, accessToken.getExpiresIn() * 168);
			}
		}

		return accessToken;
	}
}
