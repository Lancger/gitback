package org.springblade.job.executor.jobhandler;

import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import org.springblade.core.tool.utils.Func;
import org.springblade.feign.*;
import org.springblade.plugin.message.feign.IMessageClient;
import org.springblade.plugin.message.model.SocketMsgModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * 定时器处理
 */
@Component
public class MjkjXxlJob {

	@Lazy
	@Autowired
	private IMjkjMarketClient mjkjMarketClient;
	@Lazy
	@Autowired
	private IMjkjWebClient webClient;

	@Lazy
	@Autowired
	private IMjkjWalletClient walletClient;

	@Lazy
	@Autowired
	private IMessageClient messageClient;

	@Lazy
	@Autowired
	private IMjkjBladexClient bladexClient;

	@Lazy
	@Autowired
	private IMjkjMatchClient matchClient;

	/**
	 * 每5秒钟
	 * ping 心跳校验
	 */
	@XxlJob("pingHandler")
	public ReturnT<String> pingHandler(String param) throws Exception {
		mjkjMarketClient.ping();
		return ReturnT.SUCCESS;
	}

	/**
	 * 前端socket心跳
	 */
	@XxlJob("socketHeartbeatHandler")
	public ReturnT<String> socketHeartbeatHandler(String param) throws Exception {
		SocketMsgModel socketMsgModel = new SocketMsgModel();
		socketMsgModel.setTopic("socketHeartbeat");
		socketMsgModel.setContent("1");
		messageClient.sendSocketMsg(socketMsgModel);
		return ReturnT.SUCCESS;
	}


	/**
	 * 每分钟校验交易所的连接是否连上
	 * socket 心跳校验
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("socketConnectJobHandler")
	public ReturnT<String> socketConnectJobHandler(String param) throws Exception {
		mjkjMarketClient.checkSocketConnect();//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 订阅交易所消息
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("socketSubJobHandler")
	public ReturnT<String> socketSubJobHandler(String param) throws Exception {
		mjkjMarketClient.socketSubJobHandler("XH");//void
		Thread.sleep(1000);
		mjkjMarketClient.socketSubJobHandler("UBW");//void
		Thread.sleep(1000);
		//mjkjMarketClient.socketSubJobHandler("BBW");//void
		return ReturnT.SUCCESS;
	}

	/**
	 * 订阅中台消息
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("socketSubMidStandJobHandler")
	public ReturnT<String> socketSubMidStandJobHandler(String param) throws Exception {
		mjkjMarketClient.socketSubMidStandJobHandler();
		return ReturnT.SUCCESS;
	}

	/**
	 * 订阅交易所消息-k线
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("socketSubKlineJobHandler")
	public ReturnT<String> socketSubKlineJobHandler(String param) throws Exception {
		mjkjMarketClient.socketSubKlineJobHandler("XH");//ok
		mjkjMarketClient.socketSubKlineJobHandler("UBW");//ok
		//mjkjMarketClient.socketSubKlineJobHandler("BBW");//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 获取交易所消息-k线
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("socketReqKlineJobHandler")
	public ReturnT<String> socketReqKlineJobHandler(String param) throws Exception {
		mjkjMarketClient.socketReqKlineJobHandler("XH");//ok
		mjkjMarketClient.socketReqKlineJobHandler("UBW");//ok
		//mjkjMarketClient.socketReqKlineJobHandler("BBW");//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 获取交易所消息-k线
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("socketReqMidStandKlineJobHandler")
	public ReturnT<String> socketReqMidStandKlineJobHandler(String param) throws Exception {
		int number = 500;
		if (Func.isNotEmpty(param)){
			number = Integer.parseInt(param);
		}
		//获取自有源k线
		mjkjMarketClient.socketReqMidStandKlineJobHandler(number);
		return ReturnT.SUCCESS;
	}

	/**
	 * 获取交易所消息-k线
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("socketReqKlineNumJobHandler")
	public ReturnT<String> socketReqKlineNumJobHandler(String param) throws Exception {
		mjkjMarketClient.socketReqKlineNumJobHandler();//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 获取税率
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("quotedPriceJobHandler")
	public ReturnT<String> quotedPriceJobHandler(String param) throws Exception {
		mjkjMarketClient.getQuotedPrice();//ok
		return ReturnT.SUCCESS;
	}


	/**
	 * 借款利息计算
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("borrowInterestJobHandler")
	public ReturnT<String> borrowInterestJobHandler(String param) throws Exception {
		mjkjMarketClient.borrowInterestJobHandler();//ok
		return ReturnT.SUCCESS;
	}


	/**
	 * 每分钟取消15分内未付款订单
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("orderTimeOutJobHandler")
	public ReturnT<String> orderTimeOutJobHandler(String param) throws Exception {
		webClient.orderTimeOutJobHandler();//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 每30分钟重置引擎
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("matchJobHandler")
	public ReturnT<String> matchJobHandler(String param) throws Exception {
		webClient.resetMath();//ok
		return ReturnT.SUCCESS;
	}


	/**
	 * 每5分钟判断市值收益
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("marketJobHandler")
	public ReturnT<String> marketJobHandler(String param) throws Exception {
		webClient.marketProfit();//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 直推奖励发放
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("inviteRewardJobHandler")
	public ReturnT<String> inviteRewardJobHandler(String param) throws Exception {
		webClient.inviteReward();//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 合约代理手续费发放
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("contractProfit")
	public ReturnT<String> contractProfit(String param) throws Exception {
		webClient.contractProfit(param);//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 重置用户等级
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("resetMemberLevelJobHandler")
	public ReturnT<String> resetMemberLevelJobHandler(String param) throws Exception {
		webClient.resetMemberLevel(param);//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 处理链上转账信息
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("chainJobHandler")
	public ReturnT<String> chainJobHandler(String param) throws Exception {
		walletClient.handleChain();//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 归集处理
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("collectJobHandler")
	public ReturnT<String> collectJobHandler(String param) throws Exception {
		walletClient.jobCollect();//ok
		return ReturnT.SUCCESS;
	}


	/**
	 * 扫块处理
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("scanBlockJobHandler")
	public ReturnT<String> scanBlockJobHandler(String param) throws Exception {
		walletClient.jobScanBlock();//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 存币生息发放收益
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("wealthOrderProfitJobHandler")
	public ReturnT<String> wealthOrderProfitJobHandler(String param) throws Exception {
		webClient.wealthCbsxProfit();//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 存币生息状态修改
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("wealthGoodsStatusobHandler")
	public ReturnT<String> wealthGoodsStatusobHandler(String param) throws Exception {
		webClient.changeCbsxGoodsStatus();//ok
		return ReturnT.SUCCESS;
	}

	@XxlJob("wealthGoodsCurrentProfitHandler")
	public ReturnT<String> wealthGoodsCurrentProfitHandler(String param) throws Exception {
		webClient.wealthCbsxCurrentProfit();//ok
		return ReturnT.SUCCESS;
	}

	/**
	 * 系统余额提醒
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("balanceRemindHandler")
	public ReturnT<String> balanceRemindHandler(String param) throws Exception {
		walletClient.balanceRemind();
		bladexClient.baBalanceRemind();
		return ReturnT.SUCCESS;
	}

	/**
	 * 申述超时
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("orderAppealTimeOutJobHandler")
	public ReturnT<String> orderAppealTimeOutJobHandler(String param) throws Exception {
		webClient.orderAppealTimeOutJobHandler();
		return ReturnT.SUCCESS;
	}

	/**
	 * 财务统计
	 */
	@XxlJob("financialStatistical")
	public ReturnT<String> financialStatistical(String param) throws Exception {
		bladexClient.financialStatistical();
		return ReturnT.SUCCESS;
	}

	/**
	 * 财务统计-合约监控
	 */
	@XxlJob("financialContractMonitor")
	public ReturnT<String> financialContractMonitor(String param) throws Exception {
		bladexClient.financialContractMonitor();
		return ReturnT.SUCCESS;
	}

	/**
	 * 过夜费
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("nightFeeJobHandler")
	public ReturnT<String> nightFeeJobHandler(String param) throws Exception {
		webClient.handleNightFee();
		return ReturnT.SUCCESS;
	}


	/**
	 * 资金费计算
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("capitalFeeJobHandler")
	public ReturnT<String> capitalFeeJobHandler(String param) throws Exception {
		webClient.handleCapitalFee();
		return ReturnT.SUCCESS;
	}

	/**
	 * 提币自动审核
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("withdrawalAutoJobHandler")
	public ReturnT<String> withdrawalAutoJobHandler(String param) throws Exception {
		bladexClient.withdrawAutoAmount();
		return ReturnT.SUCCESS;
	}

	/**
	 * 定时处理现货订单
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("matchResetJobHandler")
	public ReturnT<String> matchResetJobHandler(String param) throws Exception {
		matchClient.resetRedis();
		return ReturnT.SUCCESS;
	}


	/**
	 * 定时定时生成K线，每分钟生成一条
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("coinhouseXhKlineJobHandler")
	public ReturnT<String> coinhouseXhKlineJobHandler(String param) throws Exception {
		mjkjMarketClient.messageCoinhouseXhKlineGenerate();
		return ReturnT.SUCCESS;
	}

	/**
	 * 定时触发撮合
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("refreshExchangeJobHandler")
	public ReturnT<String> refreshExchangeJobHandler(String param) throws Exception {
		matchClient.jobRefreshExchange();
		return ReturnT.SUCCESS;
	}

	/**
	 * 定时触发自动减仓
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("automaticallyReducePositionHandler")
	public ReturnT<String> automaticallyReducePositionHandler(String param) throws Exception {
		webClient.automaticallyReducePosition();
		return ReturnT.SUCCESS;
	}

	/**
	 * 定时触发手续费统计
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("statisticsFeeHandler")
	public ReturnT<String> statisticsFee(String param) throws Exception {
		webClient.statisticsFee();
		return ReturnT.SUCCESS;
	}


	/**
	 * 定时触发手续费返佣
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("feeRebateHandler")
	public ReturnT<String> feeRebate(String param) throws Exception {
		webClient.feeRebate(param);
		return ReturnT.SUCCESS;
	}


	/**
	 * 申购到了上市时间发放认缴的币
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("coinReleaseJobHandler")
	public ReturnT<String> coinReleaseJobHandler(String param) throws Exception {
		webClient.coinRelease();
		return ReturnT.SUCCESS;
	}

	/**
	 * 公布时间未中签用户回退保证金
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("notAllottedRefundJobHandler")
	public ReturnT<String> notAllottedRefundJobHandler(String param) throws Exception {
		webClient.notAllottedRefund();
		return ReturnT.SUCCESS;
	}

	/**
	 * 截止支付时间未支付回退保证金
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("overdueUnpaidSubscriptionJobHandler")
	public ReturnT<String> overdueUnpaidSubscriptionJobHandler(String param) throws Exception {
		webClient.overdueUnpaidSubscription();
		return ReturnT.SUCCESS;
	}

	/**
	 * 期货扫描是否到结算时间
	 *
	 * @param param
	 * @return
	 * @throws Exception
	 */
	@XxlJob("optionsSettlementJobHandler")
	public ReturnT<String> OptionsSettlementJobHandler(String param) throws Exception {
		webClient.optionsSettlement();
		return ReturnT.SUCCESS;
	}

}

