package org.springblade.flow.core.entity;

import lombok.Data;

@Data
public class MjkjStartProcessModel {
	private String desformCode;
	private String desformDataJson;
	private String processDefinitionId;
	private String resourceId;
	private String roleName;

	private Long flowTime;
}
