package org.springblade.web.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.mp.support.Condition;
import org.springblade.core.mp.support.Query;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.jackson.JsonUtil;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.entity.Appeal;
import org.springblade.feign.IMjkjWebClient;
import org.springblade.plugin.message.model.MessageStruct;
import org.springblade.plugin.message.model.SocketMsgModel;
import org.springblade.web.param.ChatRecordParam;
import org.springblade.web.param.FinancialParam;
import org.springblade.web.param.SsKfclParam;
import org.springblade.web.service.IFinancialService;
import org.springblade.web.service.IMjkjBuyService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;


@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("coin/mng/mjkj")
@Api(value = "后台钱包相关", tags = "后台钱包相关")
public class MjkjMngController {

	@Autowired
	private IMjkjBaseSqlService mjkjBaseSqlService;


	@Autowired
	private RabbitTemplate rabbitTemplate;

	@Autowired
	private IMjkjBuyService mjkjBuyService;

	@Autowired
	private IMjkjWebClient mjkjWebClient;

	@Autowired
	private IFinancialService financialService;


	@ApiOperationSupport(order = 1)
	@GetMapping("/chat/myList")
	@ApiOperation(value = "获取我的聊天列表", notes = "获取我的聊天列表")
	public R chatMyList() {
		Long userId = AuthUtil.getUserId();
		QueryWrapper<Object> wrapper = new QueryWrapper<>();
		wrapper.select("chat_id");
		wrapper.eq("chat_type", 2);//客服
		wrapper.likeLeft("chat_id", "_" + userId);
		wrapper.orderByDesc("id+0");
		List<Map<String, Object>> dataList = mjkjBaseSqlService.getDataListByFieldParams("coin_chat_record", wrapper);
		if (Func.isEmpty(dataList)) {
			return R.data(dataList);
		}
		List<String> chatIdList = new ArrayList<>();
		for (Map<String, Object> dataMap : dataList) {
			String chatId = MjkjUtils.getMap2Str(dataMap, "chat_id");
			if (chatIdList.contains(chatId)) {
				continue;
			}
			chatIdList.add(chatId);
		}

		List<Map<String, Object>> resultMapList = new ArrayList<>();
		List<String> memberIdList = new ArrayList<>();
		for (String chatId : chatIdList) {
			String chatIdStr = chatId.replace("chatKey_", "");
			String[] s = chatIdStr.split("_");
			String fromBladeUserId = s[0];//用户id

			Map<String, Object> bladeUserMap = mjkjBaseSqlService.getTableByIdL("blade_user", Func.toLong(fromBladeUserId));
			if (Func.isEmpty(bladeUserMap)) {
				continue;
			}
			String pid = MjkjUtils.getMap2Str(bladeUserMap, "pid");
			if (Func.isNotEmpty(pid) && !Func.equals(userId + "", pid)) {
				continue;
			}

			Map<String, Object> memberMap = mjkjBaseSqlService.getDataOneByField("coin_member", "blade_user_id", fromBladeUserId);
			String memberId = MjkjUtils.getMap2Str(memberMap, "id");

			if (memberIdList.contains(memberId)) {
				continue;
			}

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put("chatId", chatId);
			resultMap.put("member_id", memberId);//用户id
			resultMap.put("member_name", MjkjUtils.getMap2Str(memberMap, "name"));//用户名称
			resultMap.put("member_avatar", MjkjUtils.getMap2Str(memberMap, "avatar"));//用户头像
			resultMapList.add(resultMap);

			memberIdList.add(memberId);
		}
		return R.data(resultMapList);
	}


	@ApiOperationSupport(order = 1)
	@PostMapping("/chat/info/{chatId}")
	@ApiOperation(value = "获取我的聊天记录", notes = "获取我的聊天记录")
	public R chatInfo(@PathVariable("chatId") String chatId, @RequestBody Query query) {
		IPage<Object> page = Condition.getPage(query);

		QueryWrapper<Object> wrapper = new QueryWrapper<>();
		wrapper.eq("chat_id", chatId);
		wrapper.eq("chat_type", 2);//客服
		wrapper.orderByDesc("id+0");
		IPage<Map<String, Object>> pages = mjkjBaseSqlService.getDataIPageByFieldParams("coin_chat_record", page, wrapper);
		if (Func.isNotEmpty(pages)) {
			List<Map<String, Object>> dataMapList = pages.getRecords();
			if (Func.isNotEmpty(dataMapList)) {
				Collections.reverse(dataMapList);//反向
			}
		}
		return R.data(pages);
	}

	@ApiOperationSupport(order = 1)
	@PostMapping({"/chat/sendChatRecord"})
	@ApiOperation(value = "客服回复聊天", notes = "回复客服聊天")
	public R sendChatRecord(@RequestBody ChatRecordParam param) {
		Map<String, Object> map = new HashMap<>();
		map.put("blade_user_id", AuthUtil.getUserId() + "");
		map.put("content", param.getContent());
		map.put("content_type", param.getContentType());
		map.put("chat_type", "2");//客服
		map.put("create_time", DateUtil.now());
		map.put("chat_id", param.getChatId());
		mjkjBaseSqlService.baseInsertData("coin_chat_record", map);

		map.remove("select_sql");//移除

		SocketMsgModel model = new SocketMsgModel();
		model.setTopic(param.getChatId());
		model.setContent(JsonUtil.toJson(map));

		//发送消息
		String exchanges = "message.chat.exchange";
		String queue = "message.chat.queue";
		MessageStruct messageStruct = new MessageStruct(JsonUtil.toJson(model));
		rabbitTemplate.convertAndSend(exchanges, queue, messageStruct);

		return R.success("成功");
	}

	@ApiOperationSupport(order = 1)
	@PostMapping({"/chat/sendOrderChatRecord"})
	@ApiOperation(value = "承兑商回复聊天", notes = "承兑商回复聊天")
	public R sendOrderChatRecord(@RequestBody ChatRecordParam param) {
		Map<String, Object> map = new HashMap<>();
		map.put("blade_user_id", AuthUtil.getUserId() + "");
		map.put("content", param.getContent());
		map.put("content_type", param.getContentType());
		map.put("chat_type", "1");//订单id
		map.put("create_time", DateUtil.now());
		map.put("chat_id", param.getChatId());
		mjkjBaseSqlService.baseInsertData("coin_chat_record", map);

		map.remove("select_sql");//移除

		SocketMsgModel model = new SocketMsgModel();
		model.setTopic("CHAT_" + param.getChatId());
		model.setContent(JsonUtil.toJson(map));

		//发送消息
		String exchanges = "message.chat.exchange";
		String queue = "message.chat.queue";
		MessageStruct messageStruct = new MessageStruct(JsonUtil.toJson(model));
		rabbitTemplate.convertAndSend(exchanges, queue, messageStruct);

		return R.success("成功");
	}


	@ApiOperationSupport(order = 1)
	@PostMapping({"/ss/kfcl"})
	@ApiOperation(value = "申诉，客服处理", notes = "申诉，客服处理")
	public R ssKfcl(@RequestBody SsKfclParam param) {

		String appealId = param.getAppealId();
		String type = param.getType();
		Map<String, Object> orderAppealMap = mjkjBaseSqlService.getTableById("coin_order_appeal", appealId);
		if (Func.isEmpty(orderAppealMap)) {
			return R.fail("申诉订单不存在");
		}
		//判断该订单状态
		String orderId = MjkjUtils.getMap2Str(orderAppealMap, "order_id");
		Map<String, Object> orderMap = mjkjBaseSqlService.getTableById("coin_order", orderId);
		if (Func.isEmpty(orderMap)) {
			return R.fail("订单不存在");
		}
		String appealStatus = MjkjUtils.getMap2Str(orderMap, "appeal_status");
		if (!Func.equals(MjkjUtils.getMap2Str(orderAppealMap, "status"), "1")) {
			return R.fail("该订单申诉已完成，不允许操作");
		}
		//订单状态  【待收/付款->1】【进行中->2】【已完成->3】【已取消->4】【已退款->5】
		String orderStatus = MjkjUtils.getMap2Str(orderMap, "order_status");

		if (Func.equals(type, "1")) {//取消订单
			if (Func.equals(orderStatus, "1") || Func.equals(orderStatus, "2")) {//订单属于冻结状态，可以取消
				mjkjBuyService.ssCancelOrder(param);
				return R.data("成功");
			}
		} else if (Func.equals(type, "2")) {//强制将承兑商的币种 划转给用户
			if (Func.equals(orderStatus, "1") || Func.equals(orderStatus, "2")) {//订单属于冻结状态，可以强制划转
				mjkjBuyService.ssExchangeCoinOrder(param);
				return R.data("成功");
			}
		} else if (Func.equals(type, "3")) {//结束当前申诉
			//只是结束申请，其他没有影响
			mjkjBuyService.ssCancelOrder(param);
			return R.data("成功");
		}

		return R.fail("状态不符");
	}

	@ApiOperationSupport(order = 1)
	@GetMapping({"/ss/getAppealOrder"})
	@ApiOperation(value = "获取申诉订单详情", notes = "获取申诉订单详情")
	public R getAppealOrder(String appealId) {
		Map<String, Object> appealMap = mjkjBaseSqlService.getTableById("coin_order_appeal", appealId);
		if (Func.isEmpty(appealMap)) {
			return R.fail("申诉订单不存在");
		}
		String orderId = MjkjUtils.getMap2Str(appealMap, "order_id");//订单id
		String associateId = MjkjUtils.getMap2Str(appealMap, "associate_id");//被申述用户
		String initiatorId = MjkjUtils.getMap2Str(appealMap, "initiator_id");//申诉人用户
		String ssrPhone = MjkjUtils.getMap2Str(appealMap, "phone");

		Map<String, Object> orderMap = mjkjBaseSqlService.getTableById("coin_order", orderId);
		if (Func.isEmpty(orderMap)) {
			return R.fail("订单不存在");
		}
		String orderType = MjkjUtils.getMap2Str(orderMap, "type");//订单类型  1=买入  2=卖出
		String countryId = MjkjUtils.getMap2Str(orderMap, "country_id");//国家
		String memberId = MjkjUtils.getMap2Str(orderMap, "member_id");//用户
		String payServiceId = MjkjUtils.getMap2Str(orderMap, "pay_service_id");//承兑商

		Map<String, Object> countryMap = mjkjBaseSqlService.getTableById("coin_country", countryId);
		Map<String, Object> memberMap = mjkjBaseSqlService.getTableById("coin_member", memberId);
		Map<String, Object> payServiceMap = mjkjBaseSqlService.getTableById("coin_pay_service", payServiceId);
		Map<String, Object> payServiceMemberMap = mjkjBaseSqlService.getTableById("coin_member", MjkjUtils.getMap2Str(payServiceMap, "member_id"));

		String symbol = mjkjBaseSqlService.getSysDictItemValueByText("quoted_country", MjkjUtils.getMap2Str(orderMap, "fiat_currency"), true);


		Integer status = 0;
		if (MjkjUtils.getMap2Integer(appealMap, "status") == -1) { //结果
			status = 4;
		} else if (MjkjUtils.getMap2Integer(appealMap, "status") == 1) { //等待客服处理
			status = 2;
		}/* else if ((Func.isEmpty(associateReplayMap) || MjkjUtils.getMap2Long(appealMap, "id") > MjkjUtils.getMap2Long(associateReplayMap, "id")) &&
			memberId.equals(initiatorId)) { //发起申述(等待被申述方处理)
			status=0;
		} else if (!memberId.equals(processor) && !memberId.equals(initiatorId)) { //被申述方处理
			status=1;
		} */ else { //被申述方处理后 申述方处理
			status = 3;
		}


		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("ddid", MjkjUtils.getMap2Str(orderMap, "id"));//订单id
		resultMap.put("ddh", MjkjUtils.getMap2Str(orderMap, "order_code"));//订单号
		resultMap.put("ddje", MjkjUtils.getMap2Str(orderMap, "fiat_currency_amount"));//法币金额
		resultMap.put("ddfh", symbol);//订单符号
		resultMap.put("ddgj", MjkjUtils.getMap2Str(countryMap, "zh_name"));//订单国家
		resultMap.put("ddsl", MjkjUtils.getMap2Str(orderMap, "coin_cou"));//订单数量
		resultMap.put("ddbz", MjkjUtils.getMap2Str(orderMap, "coin_symbol"));//币种符号
		resultMap.put("ddzt", MjkjUtils.getMap2Str(orderMap, "order_status"));//法币金额
		BigDecimal dddj = MjkjUtils.getMap2BigD(orderMap, "fiat_currency_amount").divide(MjkjUtils.getMap2BigD(orderMap, "coin_cou"), 2, RoundingMode.HALF_UP);
		resultMap.put("dddj", dddj.stripTrailingZeros().toPlainString());//订单单价
		resultMap.put("status", status);

		//处理申诉人
		if (Func.equals(orderType, "1")) {//买入单

			String ssrFlag = Func.equals(initiatorId, memberId) ? "(买方)" : "(卖方)";//申诉人是用户
			resultMap.put("ssrid", initiatorId);
			resultMap.put("ssrmc", MjkjUtils.getMap2Str(memberMap, "name") + ssrFlag);
			resultMap.put("ssrdh", ssrPhone);

			String bssrFlag = !Func.equals(initiatorId, memberId) ? "(买方)" : "(卖方)";//申诉人是承兑商
			resultMap.put("bssrid", associateId);
			resultMap.put("bssrmc", MjkjUtils.getMap2Str(payServiceMap, "name") + bssrFlag);
			resultMap.put("bssrdh", MjkjUtils.getMap2Str(payServiceMemberMap, "phone"));

		} else {//卖出单
			String ssrFlag = Func.equals(initiatorId, memberId) ? "(卖方)" : "(买方)";//申诉人是用户

			resultMap.put("ssrid", initiatorId);//申诉人id
			resultMap.put("ssrmc", MjkjUtils.getMap2Str(memberMap, "name") + ssrFlag);//申诉人名称
			resultMap.put("ssrdh", ssrPhone);//申诉人电话

			String bssrFlag = !Func.equals(initiatorId, memberId) ? "(卖方)" : "(买方)";//申诉人是用户
			resultMap.put("bssrid", associateId);
			resultMap.put("bssrmc", MjkjUtils.getMap2Str(payServiceMap, "name") + bssrFlag);
			resultMap.put("bssrdh", MjkjUtils.getMap2Str(payServiceMemberMap, "phone"));

		}
		return R.data(resultMap);
	}

	@ApiOperationSupport(order = 1)
	@GetMapping({"/ss/appealinfo/{orderId}"})
	@ApiOperation(value = "获取订单申述", notes = "获取订单申述")
	public R getAppeal(@PathVariable String orderId) {
		List<Map<String, Object>> dataList = mjkjBaseSqlService.getDataListByFieldParams("coin_order_appeal a left join coin_member m " +
				"on m.id = ifnull(initiator_id, associate_id) ",
			Wrappers.query()
				.eq("a.order_id", orderId)
				.orderByDesc("a.id")
				.select("a.*, m.name, m.avatar"));
		return R.data(dataList);
	}

	@ApiOperationSupport(order = 1)
	@PostMapping({"/ss/appeal"})
	@ApiOperation(value = "订单申述", notes = "订单申述")
	public R appeal(@Validated @RequestBody Appeal appeal) {
		R ret = mjkjWebClient.appeal(appeal);
		if (ret.isSuccess()) {
			return R.data(ret.getData(),"success_ht");
		} else {
			return R.fail(ret.getCode(), ret.getMsg());
		}
	}

	@ApiOperationSupport(order = 1)
	@GetMapping({"/financial/statistical"})
	@ApiOperation(value = "财务统计", notes = "财务统计")
	public R financial() {
		return R.data(financialService.getFinancialSta());
	}

	@ApiOperationSupport(order = 1)
	@GetMapping({"/financial/statistical/detail"})
	@ApiOperation(value = "财务统计", notes = "财务统计")
	public R financialByType(FinancialParam param) throws BusinessException {
		return R.data(financialService.getSta(param));
	}

	@ApiOperationSupport(order = 1)
	@GetMapping({"/contract/qbqp"})
	@ApiOperation(value = "对合约订单进行强爆或者强平", notes = "对合约订单进行强爆或者强平")
	@ApiImplicitParams({
		@ApiImplicitParam(paramType = "query", name = "logContractId", value = "会员id", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "type", value = "类型（1=强爆 2=强平）", dataType = "String"),
	})
	public R contractQbqp(String logContractId,String type) {
		if(!(Func.equals(type,"1") || Func.equals(type,"2"))){
			return R.fail("类型有误");
		}
		if(!(AuthUtil.isAdmin() || AuthUtil.isAdministrator())){
			return R.fail("该操作只允许管理员操作");
		}
		Map<String, Object> logContractMap = mjkjBaseSqlService.getTableById("coin_log_contract", logContractId);
		if(Func.isEmpty(logContractMap)){
			return R.fail("仓位不存在");
		}
		String orderStatus = MjkjUtils.getMap2Str(logContractMap, "order_status");
		if(!Func.equals(orderStatus,"0")){
			return R.fail("该仓位状态不服，当前状态不是进行中的");
		}
		BigDecimal balance = MjkjUtils.getMap2BigD(logContractMap, "balance");//可用
		BigDecimal frozenBalance = MjkjUtils.getMap2BigD(logContractMap, "frozen_balance");//冻结
		BigDecimal totalBalance = balance.add(frozenBalance);//总仓位
		if(totalBalance.compareTo(BigDecimal.ZERO)!=1){
			return R.fail("仓位有误");
		}
		//校验完成，进行爆仓
		R r = mjkjWebClient.handleContractRg(logContractId, type);
		if(r.isSuccess()){
			return R.data("成功");
		}
		return R.fail("失败");
	}

}
