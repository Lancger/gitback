package org.springblade.web.enhance.action;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.RequiredArgsConstructor;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.utils.Func;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component("marketActionLogEnhanceList")
@RequiredArgsConstructor
public class MarketActionLogEnhanceList implements CgformEnhanceJavaListInter {
	private final IMjkjBaseSqlService sqlService;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		IPage<Map<String, Object>> page = sqlService.getDataIPageByFieldParams("coin_log_action a left join blade_user u on a.create_user = u.id",
			MjkjUtils.getPage(params),
			Wrappers
				.query()
				.eq("a.is_deleted", 0)
				.like("table_name", "market")
				.select("a.*", "a.create_time time", "u.name")
				.orderByDesc("a.id"));
		for (Map<String, Object> record : page.getRecords()) {
			String tb = MjkjUtils.getMap2Str(record, "table_name");
			Map<String, Object> map = sqlService.getDataOneByField(tb, "id", MjkjUtils.getMap2Str(record, "log_id"));
			String symbolName = MjkjUtils.getMap2Str(map, "symbol_name");
			if (Func.isEmpty(symbolName)) {
				symbolName = "维护周期:" + MjkjUtils.getMap2Str(map, "main_period");
			}
			record.put("data_name", symbolName);
		}
		MjkjUtils.setPageResult(params, page);
	}
}
