package org.springblade.web.enhance.assets;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import lombok.RequiredArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.config.constant.WalletTypeEnum;
import org.springblade.feign.ICoboWalletClient;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.constant.WalletConstant;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.entity.SubFrozenWalletParam;
import org.springblade.entity.WalletGetParam;
import org.springblade.feign.ICregisWalletClient;
import org.springblade.feign.IMjkjWalletClient;
import org.springblade.feign.IMjkjWebClient;
import org.springblade.web.service.IMngService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Author: @Wai
 * Date: 2022-7-12
 */
@Component("withdrawalEnhanceUpdate")
@RequiredArgsConstructor
public class WithdrawalEnhanceUpdate implements CgformEnhanceJavaInter {

	@Autowired
	private IMjkjWebClient webClient;

	@Autowired
	private IMjkjWalletClient walletClient;

	@Autowired
	private ICoboWalletClient coboWalletClient;

	@Autowired
	private ICregisWalletClient cregisWalletClient;

	@Autowired
	private IMjkjBaseSqlService baseSqlService;

	@Autowired
	private IMngService mngService;

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		String status = MjkjUtils.getMap2Str(jsonobject, "log_status");//-1 不通过  0=待审核 1=通过 2=转账中
		String id = MjkjUtils.getMap2Str(jsonobject, "id");
		Map<String, Object> oldData = baseSqlService.getTableById("coin_log_withdrawal", id);
		String oldStatus = MjkjUtils.getMap2Str(oldData, "log_status");
		if (!Func.equals(oldStatus, "0")) {
			throw new BusinessException("状态不符合");
		}
		if (Func.equals(status, oldStatus)) {//一样，不用操作
			return 2;
		}
		WalletGetParam param = new WalletGetParam();
		param.setType(WalletConstant.WALLET_TYPE_WALLET);
		param.setMemberId(MjkjUtils.getMap2Str(jsonobject, "member_id"));
		param.setCoinId(MjkjUtils.getMap2Str(jsonobject, "coin_id"));
		R<Map<String, Object>> r = webClient.getWalletInfo(param);
		if (!r.isSuccess()) {
			throw new BusinessException("钱包不存在");
		}
		Map<String, Object> walletMap = r.getData();
		if (Func.isEmpty(walletMap)) {
			throw new BusinessException("钱包不存在");
		}

		String now = DateUtil.now();
		jsonobject.put("examine_blade_user_id", AuthUtil.getUserId());
		jsonobject.put("examine_time", now);
		jsonobject.put("withdrawal_time", now);
		jsonobject.put("auto_flag", "0");//有人为操作，改为0

		if (status.equals("-1")) {//不通过，减少冻结资产
			SubFrozenWalletParam subFrozenWalletParam = new SubFrozenWalletParam();
			subFrozenWalletParam.setTableName("coin_member_wallet");
			subFrozenWalletParam.setWalletId(MjkjUtils.getMap2Str(walletMap, "id"));
			subFrozenWalletParam.setSubfrozenBalance(MjkjUtils.getMap2BigD(jsonobject, "amount"));
			R r1 = webClient.subFrozenWallet(subFrozenWalletParam);
			if (!r1.isSuccess()) {
				throw new BusinessException("提现失败");
			}
		} else if (status.equals("1")) {//审核通过,在回调处理
			String chainType = MjkjUtils.getMap2Str(oldData, "chain_type");
			String taskId = MjkjUtils.getMap2Str(oldData, "id");
			String address = MjkjUtils.getMap2Str(oldData, "address");
			BigDecimal arrivedAmount = MjkjUtils.getMap2BigD(oldData, "arrived_amount");//到账金额
			String coinSymbol = MjkjUtils.getMap2Str(oldData, "coin_symbol");//币种

			QueryWrapper<Object> chainWrapper = new QueryWrapper<>();
			chainWrapper.eq("chain_type", chainType);
			chainWrapper.eq("coin_symbol", coinSymbol);
			Map<String, Object> chainMap = baseSqlService.getDataOneByFieldParams("coin_chain_list", chainWrapper);
			if (Func.isEmpty(chainMap)) {
				throw new BusinessException("链路不存在");
			}
			String contractAddress = MjkjUtils.getMap2Str(chainMap, "contract_address");

			// todo:查看是否是内部转账 下次实现

			String walletType = MjkjUtils.getMap2Str(chainMap, "wallet_type");
			//进行放币
			if (WalletTypeEnum.Owner.name().equals(walletType)) {
				try {
					mngService.checkSystemWithdrawWallet(oldData);
				} catch (Exception e) {
					throw new BusinessException(e.getMessage());
				}
				walletClient.transfer(chainType, taskId, address, arrivedAmount, contractAddress); // 自建钱包
			} else if (WalletTypeEnum.Cobo.name().equals(walletType)) {
				// cobo 第三方钱包
				String coboSymbol = MjkjUtils.getMap2Str(chainMap, "cobo_symbol");
				int decimal = MjkjUtils.getMap2Integer(chainMap, "original_decimals");
				coboWalletClient.transfer(chainType, taskId, coboSymbol, address, arrivedAmount, contractAddress, decimal);
			} else if (WalletTypeEnum.Cregis.name().equals(walletType)) {
				String chainId = MjkjUtils.getMap2Str(chainMap, "chain_id");
				String tokenId = MjkjUtils.getMap2Str(chainMap, "token_id");
				String symbolName = MjkjUtils.getMap2Str(chainMap, "coin_symbol");
				cregisWalletClient.transfer(chainType, symbolName, taskId, chainId, tokenId, address, arrivedAmount);
			} else {
				throw new BusinessException("链路不存在");
			}
			jsonobject.put("log_status", 2);//转账中
			return 2;
		}
		return 2;
	}


}
