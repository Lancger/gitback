package org.springblade.web.enhance.ggjy;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.mapper.XhjyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 杠杠交易-交易明细
 */
@Component("ggjymxEnhanceList")
public class GgjymxEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private XhjyMapper xhjyMapper;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		params.put("jylx","gg");
		String userRole = AuthUtil.getUserRole();
		Long userId = null;
		if(!userRole.contains("administrator")){//不是超级管理员
			userId = AuthUtil.getUserId();
		}
		params.put("userId",userId);
		Page pages = xhjyMapper.getXhjymxPage(page, params);
		List<Map<String, Object>> records = pages.getRecords();
		if (Func.isEmpty(records)) {
			return;
		}
		for (Map<String, Object> dataMap : records) {
			String direction = MjkjUtils.getMap2Str(dataMap, "direction");

			String frozenBalance = MjkjUtils.getMap2BigD(dataMap, "frozen_balance").stripTrailingZeros().toPlainString();//交易金额
			String frozenSymbol = MjkjUtils.getMap2Str(dataMap, "frozen_symbol");//交易币种

			String feeBalance = MjkjUtils.getMap2BigD(dataMap, "fee_balance").stripTrailingZeros().toPlainString();//手续费
			String feeSymbol = MjkjUtils.getMap2Str(dataMap, "fee_symbol");//手续费币种

			String balance = MjkjUtils.getMap2BigD(dataMap, "balance").toPlainString();//到账金额
			String balanceSymbol = MjkjUtils.getMap2Str(dataMap, "balance_symbol");//导致币种

			String success_price = MjkjUtils.getMap2BigD(dataMap, "success_price").stripTrailingZeros().toPlainString();//成交价格
			Date completedTime = MjkjUtils.getMap2DateTime(dataMap, "completed_time");

			String tradeType = MjkjUtils.getMap2Str(dataMap, "trade_type");//交易类型
			if(tradeType.contains("ggzc")){
				dataMap.put("trade_type","杠杠逐仓");
			}else if(tradeType.contains("ggqc")){
				dataMap.put("trade_type","杠杠全仓");
			}else{
				dataMap.put("trade_type","现货");
			}

			dataMap.put("direction", Func.equals(direction, "1") ? "买入" : "卖出");
			dataMap.put("jy_balance", "-" + frozenBalance + frozenSymbol);//交易币种
			dataMap.put("sxf_balance", "-" + feeBalance + feeSymbol);//手续费
			dataMap.put("dz_balance", "+" + balance + balanceSymbol);//到账币种
			dataMap.put("success_price", success_price);
			if (Func.isNotEmpty(completedTime)) {
				dataMap.put("completed_time", DateUtil.format(completedTime, DateUtil.PATTERN_DATETIME));
			} else {
				dataMap.put("completed_time", "-");
			}
		}
		MjkjUtils.setPageResult(params, pages);
	}
}
