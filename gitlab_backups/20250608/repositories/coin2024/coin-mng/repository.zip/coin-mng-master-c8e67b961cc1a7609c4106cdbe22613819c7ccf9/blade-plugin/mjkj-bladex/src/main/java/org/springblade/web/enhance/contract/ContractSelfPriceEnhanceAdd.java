package org.springblade.web.enhance.contract;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import lombok.RequiredArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.config.market.MarketKlineUtils;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.feign.IMjkjMarketClient;
import org.springblade.model.KlineMessageModel;
import org.springblade.web.model.MongoDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 合约自定义价格-新增
 */
@Component("contractSelfPriceEnhanceAdd")
@RequiredArgsConstructor
public class ContractSelfPriceEnhanceAdd implements CgformEnhanceJavaInter {
	private final IMjkjBaseSqlService mjkjBaseSqlService;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private IMjkjMarketClient mjkjMarketClient;

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		String contractCoinId = jsonobject.getString("contract_coin_name");
		String selfPriceStr = jsonobject.getString("price");
		String contractType = jsonobject.getString("contract_type");//合约类型 1=U本位  2=币本位
		String contractTypeStr = Func.equals(contractType, "1") ? "UBW" : "BBW";

		if(Func.isEmpty(selfPriceStr)){
			throw new BusinessException("价格允许为空");
		}
		if(Func.isEmpty(contractCoinId)){
			throw new BusinessException("交易对不允许为空");
		}
		if(Func.isEmpty(contractType)){
			throw new BusinessException("合约类型不允许为空");
		}


		Map<String, Object> coinContractMap = mjkjBaseSqlService.getTableById("coin_coin_contract", contractCoinId);
		String symbolName = MjkjUtils.getMap2Str(coinContractMap, "symbol_name");//交易对名称



		QueryWrapper<Object> wrapper=new QueryWrapper<>();
		wrapper.eq("is_deleted","0");
		wrapper.eq("contract_coin_id",contractCoinId);
		wrapper.eq("zt","未触发");
		Map<String, Object> selfPriceMap = mjkjBaseSqlService.getDataOneByFieldParams("coin_contract_self_price", wrapper);
		if(Func.isNotEmpty(selfPriceMap)){
			throw new BusinessException("该交易对存在未触发的自定义价格");
		}

		//自定义价格id
		String contractSelfPriceId = IdWorker.getIdStr();

		//处理详情
		String detailMongodbKey = MarketKlineUtils.getDetailMongdbKey(contractTypeStr,symbolName);
		Query detailquery = new Query().limit(1);
		MongoDetail mongoDetail = mongoTemplate.findOne(detailquery, MongoDetail.class, detailMongodbKey);
		if (Func.isEmpty(mongoDetail)) {
			throw new BusinessException("获取不到行情数据");
		}
		//处理详情-----------开始----------
		BigDecimal high = mongoDetail.getHigh();
		BigDecimal low = mongoDetail.getLow();
		BigDecimal selfPrice = new BigDecimal(selfPriceStr);
		if (selfPrice.compareTo(high) == 1) {//自定义价格高于最高价
			high = selfPrice;
		}
		if (selfPrice.compareTo(low) == -1) {//自定义价格低于最高价
			low = selfPrice;
		}
		//更新
		Update detailUpdate = new Update();
		detailUpdate.set("type", 1);//自定义行情
		detailUpdate.set("executeFlag", 0);//未执行
		detailUpdate.set("close", selfPrice);//结束价格不变，使用自定义的
		detailUpdate.set("high", high);
		detailUpdate.set("low", low);
		detailUpdate.set("contractSelfPriceId", contractSelfPriceId);
		mongoTemplate.findAndModify(detailquery, detailUpdate, MongoDetail.class, detailMongodbKey);
		//处理详情-----------结束----------


		//处理K线-----------结束----------
		String periodListStr = "1min,5min,15min,30min,60min,4hour,1day,1mon,1week";
		List<String> periodList = Func.toStrList(periodListStr);
		for (String period : periodList) {
			String mongodbkey =MarketKlineUtils.getKLineMongdbKey(contractTypeStr, symbolName, period);
			Sort sort = Sort.by(new Sort.Order(Sort.Direction.DESC, "time"));
			Query query = new Query().with(sort).limit(1);
			org.springblade.web.model.KLine selectKLine = mongoTemplate.findOne(query, org.springblade.web.model.KLine.class,mongodbkey);//拿到最后一条

			BigDecimal highestPrice = selectKLine.getHighestPrice();
			BigDecimal lowestPrice = selectKLine.getLowestPrice();
			if (selfPrice.compareTo(highestPrice) == 1) {//自定义价格高于最高价
				highestPrice = selfPrice;
			}
			if (selfPrice.compareTo(lowestPrice) == -1) {//自定义价格低于最高价
				lowestPrice = selfPrice;
			}

			Update update = new Update();
			//只更新这几个
//			update.set("closePrice", selfPrice);//结束价格不变，使用自定义的
			update.set("highestPrice", highestPrice);
			update.set("lowestPrice", lowestPrice);
			update.set("type", 1);//自定义行情
			update.set("selfPrice", selfPrice);//自定义价格
			mongoTemplate.findAndModify(query, update, org.springblade.web.model.KLine.class, mongodbkey);//更新K线

			//推送K线
			KlineMessageModel klineMessageModel=new KlineMessageModel();
			KlineMessageModel.Kline kline=new KlineMessageModel.Kline();
			kline.setOpenPrice(selectKLine.getOpenPrice());
			kline.setHighestPrice(highestPrice);
			kline.setLowestPrice(lowestPrice);
			kline.setClosePrice(selectKLine.getClosePrice());
			kline.setTime(selectKLine.getTime());
			kline.setPeriod(selectKLine.getPeriod());
			kline.setCount(selectKLine.getCount());
			kline.setVolume(selectKLine.getVolume());
			kline.setTurnover(selectKLine.getTurnover());
			kline.setType(selectKLine.getType());
			klineMessageModel.setContractType(contractTypeStr);
			klineMessageModel.setKline(kline);
			klineMessageModel.setSymbolName(symbolName);
			mjkjMarketClient.messageWebKline(klineMessageModel);
		}


		Date now = DateUtil.now();
		jsonobject.put("id",contractSelfPriceId);//id
		jsonobject.put("contract_coin_id",contractCoinId);
		jsonobject.put("contract_coin_name", symbolName);
		jsonobject.put("zt", "未触发");
		jsonobject.put("czr", AuthUtil.getNickName());
		jsonobject.put("czsj", DateUtil.format(now, DateUtil.PATTERN_DATETIME));

		//推送详情
		mjkjMarketClient.messageWebDetail(contractTypeStr,symbolName,selfPrice);//发送mq触发


		return 1;
	}



}
