package org.springblade.web.enhance.file;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.config.util.FileSizeUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.mapper.MjkjFileMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 资源审核
 * mjkj_file_view
 */
@Component("fileViewEnhanceList")
public class FileViewEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private MjkjFileMapper fileMapper;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		Page pages = fileMapper.getFileViewEnhanceList(page, params);
		if(Func.isNotEmpty(pages) && Func.isNotEmpty(pages.getRecords())){
			List<Map<String,Object>> records = page.getRecords();
			records.forEach(map->{
				Long fileSize = MjkjUtils.getMap2Long(map, "file_size");
				String fileSizeStr = FileSizeUtil.formatFileSize(fileSize);
				map.put("file_size",fileSizeStr);

				String fileType = MjkjUtils.getMap2Str(map, "file_type");
				if(Func.equals(fileType,"文件夹")){//文件夹没有大小
					map.remove("file_size");
				}
			});
		}

		MjkjUtils.setPageResult(params, pages);
	}
}
