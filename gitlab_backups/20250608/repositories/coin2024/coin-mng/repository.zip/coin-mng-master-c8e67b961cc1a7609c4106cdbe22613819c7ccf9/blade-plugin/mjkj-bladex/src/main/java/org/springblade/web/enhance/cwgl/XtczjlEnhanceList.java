package org.springblade.web.enhance.cwgl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 财务管理-系统充值记录
 */
@Component("cwglXtczjlEnhanceList")
public class XtczjlEnhanceList implements CgformEnhanceJavaListInter {
	@Autowired
	private IMjkjBaseSqlService sqlService;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		HashMap<String, Object> otherData = new HashMap<>();
		Map<String, Object> yesterdayMap = sqlService.getDataOneByFieldParams("coin_financial_statistical", Wrappers.query()
			.eq("is_deleted", 0)
			.eq("type", 7)
			.orderByDesc("(id+0)"));
		otherData.put("year", MjkjUtils.getMap2Str(yesterdayMap, "data"));
		params.put("dataOther", otherData);
	}
}
