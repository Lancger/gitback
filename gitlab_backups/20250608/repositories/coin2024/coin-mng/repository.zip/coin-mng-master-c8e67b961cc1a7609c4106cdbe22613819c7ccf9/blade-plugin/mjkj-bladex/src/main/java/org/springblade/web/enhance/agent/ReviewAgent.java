package org.springblade.web.enhance.agent;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.AllArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.constant.WalletConstant;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.entity.SubFrozenWalletParam;
import org.springblade.entity.WalletGetParam;
import org.springblade.feign.IMjkjWalletClient;
import org.springblade.feign.IMjkjWebClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.web3j.abi.datatypes.Int;

import java.beans.Transient;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@AllArgsConstructor
@Component("reviewAgent")
public class ReviewAgent implements CgformEnhanceJavaInter {
 	@Autowired
	private IMjkjBaseSqlService baseSqlService;
	@Override
	@Transactional(rollbackFor = Exception.class)
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		String status = MjkjUtils.getMap2Str(jsonobject, "apply_status");//0=待审核 1=通过 2=拒绝
		String id = MjkjUtils.getMap2Str(jsonobject, "id");
		Map<String, Object> oldData = baseSqlService.getTableById("coin_agent_application_record", id);
		String oldStatus = MjkjUtils.getMap2Str(oldData, "apply_status");
		if(!Func.equals(oldStatus,"0")){
			throw new BusinessException("状态不符合");
		}
		if(Func.equals(status,oldStatus)){//一样，不用操作
			return 2;
		}
		if (status.equals("1")) {
			String level=jsonobject.getString("agent_level");
			//通过进行设置代理等级
			Map<String, Object> agentLevel=baseSqlService.getTableById("coin_agent_level", level);
			if(agentLevel.isEmpty()){
				throw new BusinessException("代理等级不存在");
			}
			Map<String, Object> map =new LinkedHashMap<>();
			map.put("agent_level", level);
			baseSqlService. baseUpdateDataWhere("coin_member",map,"id",jsonobject.getString("member_id"));
		}
		return 2;
	}
}
