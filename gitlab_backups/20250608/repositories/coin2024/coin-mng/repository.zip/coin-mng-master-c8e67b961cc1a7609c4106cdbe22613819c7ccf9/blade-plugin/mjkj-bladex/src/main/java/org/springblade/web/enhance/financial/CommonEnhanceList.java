package org.springblade.web.enhance.financial;

import cn.hutool.core.date.DateUtil;
import lombok.AllArgsConstructor;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.param.FinancialParam;
import org.springblade.web.service.IFinancialService;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Component("commonFinancialEnhanceExport")
@AllArgsConstructor
public class CommonEnhanceList implements CgformEnhanceJavaListInter {
	private final IFinancialService financialService;
	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		FinancialParam param = new FinancialParam();
		param.setType(MjkjUtils.getMap2Integer(params, "type"));
		param.setDateType(Func.toInt(params.get("dateType"), 1));
		param.setStartDate(DateUtil.parseDate("2020-01-01"));
		param.setEndDate(new Date());
		if (param.getType() == 11)
			param.setSymbolType(2);
		Map<String, ?> sta = financialService.getSta(param);
		List record = (List)sta.get("record");
		list.addAll(record);
	}
}
