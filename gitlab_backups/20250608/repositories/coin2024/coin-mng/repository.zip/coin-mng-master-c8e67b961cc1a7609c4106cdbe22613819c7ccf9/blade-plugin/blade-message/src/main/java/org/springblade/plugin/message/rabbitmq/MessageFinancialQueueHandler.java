package org.springblade.plugin.message.rabbitmq;

import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springblade.core.tool.jackson.JsonUtil;
import org.springblade.plugin.message.model.MessageStruct;
import org.springblade.plugin.message.model.SocketMsgModel;
import org.springblade.plugin.message.service.IMessageService;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * 消息队列----处理
 *
 */
@Component
@Slf4j
public class MessageFinancialQueueHandler {

	@Autowired
	private IMessageService messageService;

	@RabbitListener(queues = "message.financial.queue")
	public void directHandlerManualAck(MessageStruct messageStruct, Message message, Channel channel) {
		//log.info("MessageFinancialQueueHandler messageStruct:{}", messageStruct);
		//  如果手动ACK,消息会被监听消费,但是消息在队列中依旧存在,如果 未配置 acknowledge-mode 默认是会在消费完毕后自动ACK掉
		final long deliveryTag = message.getMessageProperties().getDeliveryTag();
		String messageStructMessage = messageStruct.getMessage();
		SocketMsgModel socketMsgModel = JsonUtil.parse(messageStructMessage, SocketMsgModel.class);
		try {
			messageService.sendMessage(socketMsgModel.getTopic(),socketMsgModel.getContent());
			// 通知 MQ 消息已被成功消费,可以ACK了
			channel.basicAck(deliveryTag, false);
		} catch (Exception e) {
			try {
				channel.basicAck(deliveryTag, false);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}
