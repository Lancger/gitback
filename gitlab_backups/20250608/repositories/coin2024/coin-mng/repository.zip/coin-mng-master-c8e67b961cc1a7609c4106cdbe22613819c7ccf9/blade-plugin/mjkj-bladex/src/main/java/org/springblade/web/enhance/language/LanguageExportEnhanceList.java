package org.springblade.web.enhance.language;

import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.jackson.JsonUtil;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 语言导出表
 */
@Component("languageExportEnhanceList")
public class LanguageExportEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private IMjkjBaseSqlService mjkjBaseSqlService;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		List<Map<String, Object>> languageMapList = mjkjBaseSqlService.getDataByTable("coin_language");
		if (Func.isEmpty(languageMapList)) {
			return;
		}
		//进行备份
		String batchCode = DateUtil.format(DateUtil.now(), DateUtil.PATTERN_DATETIME_MINI);
		for (Map<String, Object> dataMap : languageMapList) {
			Map<String, Object> addMap = new HashMap<>();
			addMap.put("batch_code", batchCode);
			addMap.put("code", MjkjUtils.getMap2Str(dataMap, "code"));
			addMap.put("text", MjkjUtils.getMap2Str(dataMap, "text"));
			addMap.put("attr_page", MjkjUtils.getMap2Str(dataMap, "attr_page"));
			addMap.put("attr_page_code", MjkjUtils.getMap2Str(dataMap, "attr_page_code"));
			mjkjBaseSqlService.baseInsertData("coin_language_bk", addMap);
		}

		//{}
		String htListStr = "ht_config";
		// return
		String returnListStr = "top,home_index,all,article,login_and_register,exchange,full,user,move_index,move_quotation" +
			",center,move_transaction,popup_tips,move_assets,move-contract,move_contract,order,buy_coins_relevant,merchant" +
			",market,coin_treasure,assets,entrust";

		List<String> htList = Func.toStrList(htListStr);
		List<String> returnList = Func.toStrList(returnListStr);

		//处理，导出
		for (Map<String, Object> dataMap : languageMapList) {
			String id = MjkjUtils.getMap2Str(dataMap, "id");
			String attrPage = MjkjUtils.getMap2Str(dataMap, "attr_page");
			String text = MjkjUtils.getMap2Str(dataMap, "text");

			String zh_cn = "";
			String zh_tw = "";
			String en = "";

			String ko = "";
			String ja = "";
			String th = "";
			String pt = "";
			String fr = "";
			String es = "";


			if (!htList.contains(attrPage)) {//前台
				text = text.replace("return", "").trim();
			}
			LanguageModel model = JsonUtil.parse(text.trim(), LanguageModel.class);
			if (Func.isEmpty(model)) {
				text = text.replaceAll("\r\n|\r|\n", "")
					.replace(",}", "}")
					.replaceAll("'", "\"")
					.replace("zh_cn", "\"zh_cn\"")
					.replace("zh_tw", "\"zh_tw\"")
					.replace("en", "\"en\"")
					.replace("ko", "\"ko\"")//韩语
					.replace("ja", "\"ja\"")//日语
					.replace("th", "\"th\"")//泰语
					.replace("pt", "\"pt\"")//葡语
					.replace("fr", "\"fr\"")//法语
					.replace("es", "\"es\"");//西班牙语




				String s = text;
				model = JsonUtil.parse(s, LanguageModel.class);
				if (Func.isEmpty(model)) {
					continue;
				}
			}
			zh_cn = model.getZh_cn();
			zh_tw = model.getZh_tw();
			en = model.getEn();

			ko=model.getKo();
			ja=model.getJa();
			th=model.getTh();
			pt=model.getPt();
			fr=model.getFr();
			es=model.getEs();

			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put("language_id", id);
			resultMap.put("zh_cn", zh_cn);
			resultMap.put("zh_tw", zh_tw);
			resultMap.put("en", en);

			resultMap.put("ko", ko);
			resultMap.put("ja", ja);
			resultMap.put("th", th);
			resultMap.put("pt", pt);
			resultMap.put("fr", fr);
			resultMap.put("es", es);
			list.add(resultMap);
		}
		list.sort(Comparator.comparing(m -> Func.isEmpty(m.get("en")) ? 0 : 1));
	}
}
