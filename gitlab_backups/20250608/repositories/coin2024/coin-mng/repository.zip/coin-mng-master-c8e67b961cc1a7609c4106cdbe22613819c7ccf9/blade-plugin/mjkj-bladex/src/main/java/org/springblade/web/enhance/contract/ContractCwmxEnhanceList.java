package org.springblade.web.enhance.contract;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.extern.slf4j.Slf4j;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.constant.WalletConstant;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.entity.WalletGetParam;
import org.springblade.feign.IMjkjWebClient;
import org.springblade.third.cache.CacheNames;
import org.springblade.web.mapper.HtHyMapper;
import org.springblade.web.service.IHtMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 合约交易-仓位明细
 */
@Component("contractCwmxEnhanceList")
@Slf4j
public class ContractCwmxEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private HtHyMapper htHyMapper;

	@Autowired
	private IHtMongoService htMongoService;

	@Autowired
	private IMjkjWebClient mjkjWebClient;

	@Autowired
	private IMjkjBaseSqlService baseSqlService;

	@Autowired
	private BladeRedis bladeRedis;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		String userRole = AuthUtil.getUserRole();
		Long userId = null;
		if (!userRole.contains("administrator")) {//不是超级管理员
			userId = AuthUtil.getUserId();
		}
		params.put("userId", userId);
		Page pages = htHyMapper.getContractCwmxPage(page, params);

		List<Map<String, Object>> records = pages.getRecords();
		if (Func.isEmpty(records)) {
			return;
		}
		for (Map<String, Object> dataMap : records) {
			String memberId = MjkjUtils.getMap2Str(dataMap, "member_id");
			String contractLogId = MjkjUtils.getMap2Str(dataMap, "id");
			String direction = MjkjUtils.getMap2Str(dataMap, "direction");
			String contractType = MjkjUtils.getMap2Str(dataMap, "contract_type");//合约类型

			BigDecimal avgPrice = MjkjUtils.getMap2BigD(dataMap, "avg_price");
			String avgPriceStr = avgPrice.stripTrailingZeros().toPlainString();

			String symbolName = MjkjUtils.getMap2Str(dataMap, "symbol_name");


			BigDecimal balance = MjkjUtils.getMap2BigD(dataMap, "balance");//仓位
			BigDecimal frozenBalance = MjkjUtils.getMap2BigD(dataMap, "frozen_balance");//冻结仓位
			BigDecimal nightAmount = MjkjUtils.getMap2BigD(dataMap, "night_amount");//过夜费

			String balanceStr = balance.stripTrailingZeros().toPlainString();//仓位
			String frozenBalanceStr = frozenBalance.stripTrailingZeros().toPlainString();//冻结仓位
			String balanceSymbol = MjkjUtils.getMap2Str(dataMap, "balance_symbol");//仓位币种
			String nightAmountStr = nightAmount.stripTrailingZeros().toPlainString();//过夜费


			String principal_amount = MjkjUtils.getMap2BigD(dataMap, "principal_amount").stripTrailingZeros().toPlainString();//保证金
			String principal_symbol = MjkjUtils.getMap2Str(dataMap, "principal_symbol");//保证金

			BigDecimal nowPrice = BigDecimal.ZERO;
			String ggLv = "-";
			if (Func.equals(contractType, "1")) {
				nowPrice = htMongoService.getPriceBySymbol("ubw", symbolName);
				ggLv = getGgLv(symbolName, memberId, ggLv);
			} else if (Func.equals(contractType, "2")) {
				nowPrice = htMongoService.getPriceBySymbol("bbw", symbolName);
			}


			String directionStr = "";
			if (Func.equals(direction, "1")) {
				directionStr = "开多";
			} else if (Func.equals(direction, "2")) {
				directionStr = "开空";
			} else if (Func.equals(direction, "3")) {
				directionStr = "平多";
			} else if (Func.equals(direction, "4")) {
				directionStr = "平空";
			}

			String contractTypeStr = "U本位";
			if (Func.equals(contractType, "2")) {
				contractTypeStr = "币本位";
			}

			BigDecimal profit = BigDecimal.ZERO;

			if (nowPrice.compareTo(BigDecimal.ZERO) == 1) {
				if (Func.equals(direction, "1")) {//开多
					profit = nowPrice.subtract(avgPrice).multiply(balance.add(frozenBalance));
				} else if (Func.equals(direction, "2")) {//开空
					profit = avgPrice.subtract(nowPrice).multiply(balance.add(frozenBalance));
				}
			}
			if (Func.equals(contractType, "2")) {//币本位，需要转为本身币种
				profit = profit.divide(nowPrice, 8, BigDecimal.ROUND_DOWN);
			}

//			dataMap.put("direction", directionStr);
//			dataMap.put("contract_type",contractTypeStr);//合约类型
			dataMap.put("avg_price", avgPriceStr);//均价
			dataMap.put("now_price", nowPrice.compareTo(BigDecimal.ZERO) == 1 ? nowPrice.stripTrailingZeros().toPlainString() : "-");
			dataMap.put("cw_balance", balance.compareTo(BigDecimal.ZERO) == 1 ? balanceStr + balanceSymbol : "-");//仓位
			dataMap.put("djcw_balance", frozenBalance.compareTo(BigDecimal.ZERO) == 1 ? frozenBalanceStr + balanceSymbol : "-");//冻结仓位
			dataMap.put("bzj_balance", principal_amount + principal_symbol);//保证金
			dataMap.put("gyf_balance", nightAmount.compareTo(BigDecimal.ZERO) == 1 ? nightAmountStr + principal_symbol : "-");//过夜费
			dataMap.put("yk_balance", profit.compareTo(BigDecimal.ZERO) != 0 ? profit.stripTrailingZeros().toPlainString() + principal_symbol : "-");//未实现盈亏
			BigDecimal forcePrice = mjkjWebClient.getForcePrice(contractLogId, contractType);//获取强平价格
			dataMap.put("forcePrice", forcePrice.setScale(4, BigDecimal.ROUND_DOWN));
			dataMap.put("gg_lv",ggLv); // 添加杠杆倍数

		}
		MjkjUtils.setPageResult(params, pages);
	}

	/**
	 * 获取u本位的杠杆倍数
	 * @param symbolName 交易对
	 * @param memberId 用户id
	 * @param ggLv 返回的杠杆倍数
	 * @return
	 */
	private String getGgLv(String symbolName, String memberId, String ggLv) {
		try {
			int slashIndex = symbolName.lastIndexOf('/');
			String beforeSlash = symbolName.substring(0, slashIndex);
			// 拿到币
			Object obj = bladeRedis.get(CacheNames.SYS_COIN_COIN+beforeSlash);
			Map map;
			if (Func.isNotEmpty(obj)) {
				map = JSON.parseObject(obj.toString(), Map.class);
			} else {
				map = baseSqlService.getDataOneByFieldParams("coin_coin", Wrappers.query().eq("name", beforeSlash));
				if (Func.isNotEmpty(map)){
					bladeRedis.set(CacheNames.SYS_COIN_COIN+beforeSlash, JSON.toJSONString(map));
				} else {
					return ggLv;
				}
			}
			String coinCoinId = MjkjUtils.getMap2Str(map, "id");
			// 拿到对应的钱包，解出杠杆倍数
			WalletGetParam walletGetParam = new WalletGetParam();
			walletGetParam.setCoinId(coinCoinId);
			walletGetParam.setMemberId(memberId);
			walletGetParam.setType(WalletConstant.WALLET_TYPE_CONTRACT);
			R<Map<String, Object>> walletInfo = mjkjWebClient.getWalletInfo(walletGetParam);
			Map<String, Object> data = walletInfo.getData();
			if (Func.isNotEmpty(data)) {
				// 币本位现在没有，币本位的杠杆：current_bbw_leverage
				// 这里只拿U本位的杠杆倍数
				String leverage = MjkjUtils.getMap2Str(data, "current_ubw_leverage");
				ggLv = Func.toDouble(leverage) + "x";
			}
		} catch (Exception e) {
			log.error("获取杠杆倍数错误，交易对：{}",symbolName);
		}
		return ggLv;
	}
}
