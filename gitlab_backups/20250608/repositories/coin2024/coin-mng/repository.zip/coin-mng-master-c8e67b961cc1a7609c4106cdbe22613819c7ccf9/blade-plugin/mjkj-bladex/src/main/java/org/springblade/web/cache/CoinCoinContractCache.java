package org.springblade.web.cache;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.core.redis.cache.BladeRedis;
import org.springblade.core.tool.utils.Func;
import org.springblade.third.cache.CacheNames;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 用来缓存合约交易对信息
 * @author py
 */
@Component
public class CoinCoinContractCache {
	/**
	 * 一次存入全部币信息
	 */
	public void refPutAll(IMjkjBaseSqlService baseSqlService, BladeRedis bladeRedis){
		QueryWrapper<Object> queryWrapper = new QueryWrapper<>();
		queryWrapper.eq("is_deleted",0);
		List<Map<String, Object>> coinCoin = baseSqlService.getDataListByFieldParams("coin_coin_contract", queryWrapper);
		if (!Func.isEmpty(coinCoin)){
			coinCoin.forEach(coinMap -> {
				// 作为key存入缓存
				String symbolName = MjkjUtils.getMap2Str(coinMap, "symbol_name");
				String jsonMap = JSON.toJSONString(coinMap);
				bladeRedis.set(CacheNames.SYS_COIN_CONTRACT+symbolName, jsonMap);
			});
		}
	}
}
