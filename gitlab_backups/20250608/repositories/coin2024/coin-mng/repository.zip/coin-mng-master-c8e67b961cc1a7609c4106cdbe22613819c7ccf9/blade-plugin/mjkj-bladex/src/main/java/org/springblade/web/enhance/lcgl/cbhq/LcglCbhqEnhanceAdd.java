package org.springblade.web.enhance.lcgl.cbhq;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.AllArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 活期存币计划新增处理
 */
@Component("lcglCbhqEnhanceAdd")
@AllArgsConstructor
public class LcglCbhqEnhanceAdd implements CgformEnhanceJavaInter {
	private final IMjkjBaseSqlService mjkjBaseSqlService;


	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		// 存储的上架状态
		String onlineStatus = MjkjUtils.getMap2Str(jsonobject, "online_status");
		String coinId = MjkjUtils.getMap2Str(jsonobject, "coin_id");
		BigDecimal rateYear = MjkjUtils.getMap2BigD(jsonobject, "rate_year");// 年化率
		String houTitle = MjkjUtils.getMap2Str(jsonobject, "hou_title");// 标题
		String title = MjkjUtils.getMap2Str(jsonobject, "title");// 国际化
		BigDecimal buyMinCou = MjkjUtils.getMap2BigD(jsonobject, "buy_min_cou");// 单次最小购买数
		BigDecimal redMinCou = MjkjUtils.getMap2BigD(jsonobject, "red_min_cou");// 单次最小赎回数
		String idStr = MjkjUtils.getMap2Str(jsonobject, "id");// id
		Map<String, Object> dataMap = new HashMap<>();
		if (rateYear.compareTo(BigDecimal.ZERO) <= 0){
			throw new BusinessException("年化率不能小于0");
		}
		// 获取所以未被删除的存币活期商品
		List<Map<String, Object>> hqGoods = mjkjBaseSqlService.getDataListByFieldParams("coin_wealth_current", Wrappers
			.query()
			.eq("is_deleted", 0)
			.eq("coin_id", coinId));
		// 判断是否存在已上架的存币商品
		if ("1".equals(onlineStatus)) {
			// 不上架处理、校验唯一上架在修改处
			return 1;
		}
		// 没有直接存
		if (hqGoods.isEmpty()){
			return 1;
		}
		List<Map<String, Object>> onlineStatus0 =
			hqGoods.stream().
				filter(map -> "0".equals(MjkjUtils.getMap2Str(map, "online_status")) ||
					MjkjUtils.getMap2Str(map,"id").equals(idStr))
				.collect(Collectors.toList());
		if (!onlineStatus0.isEmpty()){
			// 新增为1未上架状态
			dataMap.put("online_status", 1);
			mjkjBaseSqlService.baseUpdateData("coin_wealth_current",dataMap,idStr);
			return 2;
		}
		return -1;
	}
}
