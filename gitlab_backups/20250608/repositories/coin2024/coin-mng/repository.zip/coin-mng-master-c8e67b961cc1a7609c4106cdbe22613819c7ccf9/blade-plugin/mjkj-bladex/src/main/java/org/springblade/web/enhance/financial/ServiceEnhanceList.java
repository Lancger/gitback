package org.springblade.web.enhance.financial;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateUtil;
import lombok.AllArgsConstructor;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.web.param.FinancialParam;
import org.springblade.web.service.IFinancialService;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component("serviceFinancialEnhanceExport")
@AllArgsConstructor
public class ServiceEnhanceList implements CgformEnhanceJavaListInter {
	private final IFinancialService financialService;
	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		FinancialParam param = new FinancialParam();
		param.setType(2);
		param.setDateType(1);
		param.setStartDate(DateUtil.offset(new Date(), DateField.YEAR, -10));
		param.setEndDate(new Date());
		Map<String, Map<String, Object>> sta = (Map<String, Map<String, Object>>) financialService.getSta(param);
		List<Map<String, Object>> collect = sta.values().stream()
			.sorted(Comparator.comparing(m -> MjkjUtils.getMap2BigD(m, "tran").negate()))
			.collect(Collectors.toList());
		list.addAll(collect);
	}
}
