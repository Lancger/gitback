package org.springblade.web.enhance.contract;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.web.mapper.HtHyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component("contractJysxfEnhanceList")
public class ContractJysxfEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private HtHyMapper htHyMapper;
	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		String userRole = AuthUtil.getUserRole();
		Long userId = null;
		if(!userRole.contains("administrator")){//不是超级管理员
			userId = AuthUtil.getUserId();
		}
		params.put("userId",userId);
		Page pages = htHyMapper.getContractJysxfPage(page, params);
		MjkjUtils.setPageResult(params, pages);
	}
}
