package org.springblade.web.enhance.lcgl.cbhq;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import lombok.AllArgsConstructor;
import org.springblade.cgform.entity.CgformHead;
import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.utils.Func;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 活期存币计划删除处理
 * 1=新增  2=更新 -1=不操作
 */
@Component("lcglCbhqEnhanceDel")
@AllArgsConstructor
public class LcglCbhqEnhanceDel implements CgformEnhanceJavaInter {
	private final IMjkjBaseSqlService mjkjBaseSqlService;


	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		Map<String, Object> hqGood = mjkjBaseSqlService.getDataOneByFieldParams("coin_wealth_current", Wrappers
			.query()
			.eq("id", MjkjUtils.getMap2Str(jsonobject, "id")));
		// 判断该币种是否存在其他的计划 存在就放行删除不存在就校验该计划是否有用户进行存币了
		if (Func.isEmpty(hqGood)){
			return 2;
		}
		String coinId = MjkjUtils.getMap2Str(hqGood, "coin_id");
		boolean isPass = checkHasUserBuy(coinId);
		if (isPass){
			throw new BusinessException("该存币计划有订单数据，无法删除！");
		}
		// 校验是否存在用户存该币种活期
		return -1;
	}

	// 判断是否还有用户存活期
	public boolean checkHasUserBuy(String coinId){
		List<Map<String, Object>> allMember = mjkjBaseSqlService.getDataListByFieldParams("coin_wealth_current_history", Wrappers
			.query()
			.eq("coin_id", coinId)
		);
		// 根据用户id进行分组
		Map<String, List<Map<String, Object>>> recordsByUserId = allMember.stream()
			.collect(Collectors.groupingBy(record -> (String) record.get("member_id")));
		boolean userHasUnmatchedBuy = recordsByUserId.values().stream()
			.anyMatch(records -> {
				BigDecimal buyAmount = BigDecimal.ZERO;
				BigDecimal sellAmount = BigDecimal.ZERO;

				for (Map<String, Object> record : records) {
					int type = (int) record.get("type"); // 0 买, 1 卖
					BigDecimal amount = (BigDecimal) record.get("amount");

					if (type == 0) {
						buyAmount = buyAmount.add(amount);
					} else if (type == 1) {
						sellAmount = sellAmount.add(amount);
					}
				}

				return buyAmount.compareTo(sellAmount) > 0;
			});
		return userHasUnmatchedBuy;
	}
}
