package org.springblade.web.enhance.ggjy;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.mapper.GgjyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 杠杠交易-还款记录
 */
@Component("ggjyHkjlEnhanceList")
public class HkjlEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private GgjyMapper ggjyMapper;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		String userRole = AuthUtil.getUserRole();
		Long userId = null;
		if(!userRole.contains("administrator")){//不是超级管理员
			userId = AuthUtil.getUserId();
		}
		params.put("userId",userId);
		Page pages = ggjyMapper.getHkjlPage(page, params);

		List<Map<String, Object>> records = pages.getRecords();
		if (Func.isEmpty(records)) {
			return;
		}
		for (Map<String, Object> dataMap : records) {
			String stillAmountStr = MjkjUtils.getMap2BigD(dataMap, "still_amount").stripTrailingZeros().toPlainString();//借币数量
			Date stillTime = MjkjUtils.getMap2DateTime(dataMap, "still_time");

			dataMap.put("still_amount",stillAmountStr);

			if (Func.isNotEmpty(stillTime)) {
				dataMap.put("still_time", DateUtil.format(stillTime, DateUtil.PATTERN_DATETIME));
			} else {
				dataMap.put("still_time", "-");
			}
		}
		MjkjUtils.setPageResult(params, pages);
	}
}
