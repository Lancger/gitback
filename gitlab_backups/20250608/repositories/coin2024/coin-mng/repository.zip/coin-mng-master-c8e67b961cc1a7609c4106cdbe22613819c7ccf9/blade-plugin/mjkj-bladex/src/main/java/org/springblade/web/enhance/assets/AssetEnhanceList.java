package org.springblade.web.enhance.assets;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.utils.Func;
import org.springblade.entity.WalletGetParam;
import org.springblade.feign.IMjkjWebClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Author: @Wai
 * Date: 2022-8-20
 */
@Service("assetEnhanceList")
@AllArgsConstructor
public class AssetEnhanceList implements CgformEnhanceJavaListInter {

	private final IMjkjBaseSqlService sqlService;

	@Autowired
	private IMjkjWebClient mjkjWebClient;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		//默认服务商
		Map<String, Object> payServiceMap = sqlService.getDataOneByField("coin_pay_service", "is_default", 1);

		String serviceId = MjkjUtils.getMap2Str(payServiceMap, "id");
		String supportCoinListStr = MjkjUtils.getMap2Str(payServiceMap, "support_coin_list");
		List<String> coinIdList = Func.toStrList(supportCoinListStr);


		QueryWrapper<Object> walletWrapper=new QueryWrapper<>();
		walletWrapper.eq("is_deleted",0);
		walletWrapper.eq("member_id",serviceId);
		walletWrapper.in("coin_id",coinIdList);
		IPage<Map<String, Object>> walletMapPage = sqlService.getDataIPageByFieldParams("coin_service_wallet", page, walletWrapper);//钱包列表
		if(Func.isEmpty(walletMapPage)){
			return;
		}

		//创建钱包
		List<Map<String, Object>> dataMapList = walletMapPage.getRecords();
		for (Map<String, Object> dataMap:dataMapList) {
			String coinId = MjkjUtils.getMap2Str(dataMap, "coin_id");

			WalletGetParam walletGetParam=new WalletGetParam();
			walletGetParam.setType("service");
			walletGetParam.setMemberId(serviceId);
			walletGetParam.setCoinId(coinId);
			mjkjWebClient.getWalletInfo(walletGetParam);
		}

		MjkjUtils.setPageResult(params, walletMapPage);
	}
}
