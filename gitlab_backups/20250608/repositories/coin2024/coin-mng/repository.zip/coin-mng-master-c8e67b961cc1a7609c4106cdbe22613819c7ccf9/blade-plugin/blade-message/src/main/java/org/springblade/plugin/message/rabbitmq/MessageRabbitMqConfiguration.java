package org.springblade.plugin.message.rabbitmq;

import lombok.extern.slf4j.Slf4j;
import org.springblade.third.constant.ActivityCommonConstant;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ配置，主要是配置队列，如果提前存在该队列，可以省略本配置类
 *
 * @author yangkai.shen
 */
@Slf4j
@Configuration
public class MessageRabbitMqConfiguration {

	@Bean
	public RabbitTemplate rabbitTemplate(CachingConnectionFactory connectionFactory) {
		connectionFactory.setPublisherConfirms(true);
		connectionFactory.setPublisherReturns(true);
		RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
		rabbitTemplate.setMandatory(true);
//		rabbitTemplate.setConfirmCallback((correlationData, ack, cause) -> log.info("消息发送成功:correlationData({}),ack({}),cause({})", correlationData, ack, cause));
		rabbitTemplate.setReturnCallback((message, replyCode, replyText, exchange, routingKey) -> log.info("消息丢失:exchange({}),route({}),replyCode({}),replyText({}),message:{}", exchange, routingKey, replyCode, replyText, message));
		return rabbitTemplate;
	}
	//---------------------------------------魔晶自定义----------------------------------------------------------------



	//websocket消息相关
	@Bean
	public TopicExchange messageExchangeMessage() {
		return new TopicExchange("message.websocket.exchange");
	}

	/**
	 * websocket
	 * @return
	 */
	@Bean
	public Queue messageQueue() {
		return new Queue("message.websocket.queue");
	}
	@Bean
	public Binding topicBindingMessage(Queue messageQueue, TopicExchange messageExchangeMessage) {
		return BindingBuilder.bind(messageQueue).to(messageExchangeMessage).with("message.websocket.queue");
	}


	//购买消息
	@Bean
	public TopicExchange buyExchangeMessage() {
		return new TopicExchange("message.buy.exchange");
	}

	/**
	 * 购买消息
	 */
	@Bean
	public Queue buyQueue() {
		return new Queue("message.buy.queue");
	}
	@Bean
	public Binding topicBindingXh(Queue buyQueue, TopicExchange buyExchangeMessage) {
		return BindingBuilder.bind(buyQueue).to(buyExchangeMessage).with("message.buy.queue");
	}



	//客服消息
	@Bean
	public TopicExchange chatExchangeMessage() {
		return new TopicExchange("message.chat.exchange");
	}

	/**
	 * 客服
	 */
	@Bean
	public Queue chatQueue() {
		return new Queue("message.chat.queue");
	}
	@Bean
	public Binding topicBindingChat(Queue chatQueue, TopicExchange chatExchangeMessage) {
		return BindingBuilder.bind(chatQueue).to(chatExchangeMessage).with("message.chat.queue");
	}

	@Bean
	public TopicExchange financialExchangeMessage() {
		return new TopicExchange("message.financial.exchange");
	}

	@Bean
	public Queue financialQueue() {
		return new Queue("message.financial.queue");
	}
	@Bean
	public Binding topicBindingFinancial(Queue financialQueue, TopicExchange financialExchangeMessage) {
		return BindingBuilder.bind(financialQueue).to(financialExchangeMessage).with("message.financial.queue");
	}

	//TODO 配置活动相关MQ队列


	@Bean
	public TopicExchange spotTradeExchangeMessage() {
		return new TopicExchange(ActivityCommonConstant.SPOT_TRADE_EXCHANGE);
	}
	@Bean
	public Queue spotTradeQueue() {
		return new Queue(ActivityCommonConstant.SPOT_TRADE_QUEUE);
	}
	@Bean
	public Binding topicBindingSpotTrade(Queue spotTradeQueue, TopicExchange spotTradeExchangeMessage) {
		return BindingBuilder.bind(spotTradeQueue).to(spotTradeExchangeMessage).with(ActivityCommonConstant.SPOT_TRADE_QUEUE);
	}

	@Bean
	public TopicExchange contractTradeExchangeMessage() {
		return new TopicExchange(ActivityCommonConstant.CONTRACT_TRADE_EXCHANGE);
	}
	@Bean
	public Queue contractTradeQueue() {
		return new Queue(ActivityCommonConstant.CONTRACT_TRADE_QUEUE);
	}
	@Bean
	public Binding topicBindingContractTrade(Queue contractTradeQueue, TopicExchange contractTradeExchangeMessage) {
		return BindingBuilder.bind(contractTradeQueue).to(contractTradeExchangeMessage).with(ActivityCommonConstant.CONTRACT_TRADE_QUEUE);
	}



	@Bean
	public TopicExchange memberRegExchangeMessage() {
		return new TopicExchange(ActivityCommonConstant.MEMBER_REG_EXCHANGE);
	}
	@Bean
	public Queue memberRegQueue() {
		return new Queue(ActivityCommonConstant.MEMBER_REG_QUEUE);
	}
	@Bean
	public Binding topicBindingMemberReg(Queue memberRegQueue, TopicExchange memberRegExchangeMessage) {
		return BindingBuilder.bind(memberRegQueue).to(memberRegExchangeMessage).with(ActivityCommonConstant.MEMBER_REG_QUEUE);
	}


	@Bean
	public TopicExchange memberKycExchangeMessage() {
		return new TopicExchange(ActivityCommonConstant.MEMBER_KYC_EXCHANGE);
	}
	@Bean
	public Queue memberKycQueue() {
		return new Queue(ActivityCommonConstant.MEMBER_KYC_QUEUE);
	}
	@Bean
	public Binding topicBindingMemberKyc(Queue memberKycQueue, TopicExchange memberKycExchangeMessage) {
		return BindingBuilder.bind(memberKycQueue).to(memberKycExchangeMessage).with(ActivityCommonConstant.MEMBER_KYC_QUEUE);
	}


	@Bean
	public TopicExchange memberRechargeExchangeMessage() {
		return new TopicExchange(ActivityCommonConstant.MEMBER_RECHARGE_EXCHANGE);
	}
	@Bean
	public Queue memberRechargeQueue() {
		return new Queue(ActivityCommonConstant.MEMBER_RECHARGE_QUEUE);
	}
	@Bean
	public Binding topicBindingMemberRecharge(Queue memberRechargeQueue, TopicExchange memberRechargeExchangeMessage) {
		return BindingBuilder.bind(memberRechargeQueue).to(memberRechargeExchangeMessage).with(ActivityCommonConstant.MEMBER_RECHARGE_QUEUE);
	}

}
