package org.springblade.web.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springblade.web.feign.SelfRemoteClient;
import org.springblade.web.param.*;
import org.springblade.web.response.JsonResult;
import org.springblade.web.service.ICoreService;
import org.springblade.web.service.MarketRemoteService;
import org.springblade.web.utils.kline.KLineDrawingTool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import static org.springblade.web.service.impl.CoreServiceImpl.MODEL_KEY;


@Slf4j
@RestController
@RequestMapping("coin/self")
@Api(value = "自有源管理", tags = "自有源管理")
public class SelfModelController {

	@Autowired
	private ICoreService coreService;

	@Autowired
	private MarketRemoteService marketRemoteService;

	@Autowired
	private SelfRemoteClient selfRemoteClient;


	@Value("${mid.stand.systemId}")
	private int systemId;

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-获取symbol列表", notes = "后管-获取symbol列表")
	@PostMapping("/modelTaskList")
	public JsonResult modelTaskList(@RequestBody JSONObject jsonObject) {
		jsonObject.put("systemId", systemId);
		return JsonResult.data(selfRemoteClient.modelTaskList(jsonObject));
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-修改symbol记录", notes = "后管-修改symbol记录")
	@PostMapping("/saveOrUpdateModelTask")
	public JsonResult saveModelTask(@RequestBody ModelTaskDTO modelTaskDTO) {
		modelTaskDTO.setSystemId(systemId);
		return JsonResult.data(selfRemoteClient.saveModelTask(modelTaskDTO));
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-deleteModelTask", notes = "后管-deleteModelTask")
	@PostMapping("/deleteModelTask")
	public JsonResult deleteModelTask(@RequestBody JSONObject jsonObject) {
		return JsonResult.data(selfRemoteClient.deleteModelTask(jsonObject));
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-提交分时K线", notes = "后管-提交分时K线")
	@PostMapping("/new/saveOrUpdateModel")
	public JsonResult newSaveModel(@RequestBody ModelPM pm) {
		return coreService.saveModel(pm);
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-生成分时K线", notes = "后管-生成分时K线")
	@PostMapping("/getNewModel")
	public JsonResult getNewModel(@RequestBody ModelPM pm) {
		return coreService.getNewModel(pm);
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-长控生成分时K线")
	@PostMapping("/getControlModel")
	public JsonResult getControlModel(@RequestBody ControlPM pm) {
		Long startTime = DateUtil.beginOfMinute(new DateTime(pm.startTime * 1000L)).getTime() / 1000;
		Long endTime = DateUtil.beginOfMinute(new DateTime(pm.endTime * 1000L)).getTime() / 1000;
		pm.setStartTime(startTime);
		pm.setEndTime(endTime);
		return coreService.getControlModel(pm);
	}

	@ApiOperation(value = "后管-控盘提交")
	@PostMapping("/controlQuotes")
	public JsonResult controlQuotes(@RequestBody ControlPM pm) {
		Long startTime = DateUtil.beginOfMinute(new DateTime(pm.startTime * 1000L)).getTime() / 1000;
		Long endTime = DateUtil.beginOfMinute(new DateTime(pm.endTime * 1000L)).getTime() / 1000;
		pm.setStartTime(startTime);
		pm.setEndTime(endTime);
		return coreService.controlQuotes(pm);
	}

	@Deprecated
	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-刷新K线", notes = "后管-刷新K线")
	@PostMapping("/selfSaveKline")
	public JsonResult saveKLine(@RequestBody SaveKLinePM saveKLinePM) {
		marketRemoteService.selfSaveKline(saveKLinePM);
		return JsonResult.success();
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-获取历史K线记录", notes = "后管-获取历史K线记录")
	@PostMapping("/historyKline")
	public JsonResult historyKline(@RequestBody ModelPM pm) {
		return coreService.historyKline(pm);
	}


	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-获取分时K线列表", notes = "后管-获取分时K线列表")
	@PostMapping("/modelList")
	public JsonResult modelList(@RequestBody JSONObject jsonObject) {
		return JsonResult.data(selfRemoteClient.modelList(jsonObject));
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-根据时间区间删除分时K线", notes = "后管-根据时间区间删除分时K线")
	@PostMapping("/deleteModel")
	public JsonResult deleteModel(@RequestBody JSONObject jsonObject) {
		return JsonResult.data(selfRemoteClient.deleteModel(jsonObject));
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-modelListByTime", notes = "后管-modelListByTime")
	@PostMapping("/modelListByTime")
	public JsonResult modelListByTime(@RequestBody JSONObject jsonObject) {
		return JsonResult.data(marketRemoteService.modelListByTime(jsonObject));
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-klineListMongo", notes = "后管-klineListMongo")
	@PostMapping("/klineListMongo")
	public JsonResult klineListMongo(@RequestBody JSONObject jsonObject) {
		Object result = marketRemoteService.klineListMongo(jsonObject);
		return JsonResult.success(result);
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-kLineList", notes = "后管-kLineList")
	@PostMapping("/kLineList")
	public JsonResult kLineList(@RequestBody JSONObject jsonObject) {
		Object result = marketRemoteService.kLineList(jsonObject);
		return JsonResult.success(result);
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-MongoKlineRemove", notes = "后管-MongoKlineRemove")
	@PostMapping("/MongoKlineRemove")
	public JsonResult MongoKlineRemove(@RequestBody JSONObject jsonObject) {
		return JsonResult.data(marketRemoteService.MongoKlineRemove(jsonObject));
	}

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-MongoKlineUpdate", notes = "后管-MongoKlineUpdate")
	@PostMapping("/MongoKlineUpdate")
	public JsonResult MongoKlineUpdate(@RequestBody JSONObject jsonObject) {
		return JsonResult.data(marketRemoteService.MongoKlineUpdate(jsonObject));
	}


	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "后管-getOpenAndClose", notes = "后管-getOpenAndClose")
	@PostMapping("/getOpenAndClose")
	public JsonResult getOpenAndClose(@RequestBody JSONObject jsonObject) {
		return JsonResult.data(marketRemoteService.getOpenAndClose(jsonObject));
	}

}
