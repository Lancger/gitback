package org.springblade.web.enhance.file;

import com.alibaba.fastjson.JSONObject;
import org.springblade.cgform.entity.CgformHead;

import org.springblade.cgform.model.CgformEnhanceJavaInter;
import org.springblade.cgform.model.file.FileLogModel;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;

import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.event.FileLogEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 文件列表-删除
 * 表明：mjkj_file_list
 */
@Component("fileListEnhanceDel")
public class FileListEnhanceDel implements CgformEnhanceJavaInter {

	@Autowired
	private IMjkjBaseSqlService mjkjBaseSqlService;

	@Autowired
	private ApplicationContext applicationContext;

	@Override
	public int execute(CgformHead head, JSONObject jsonobject) throws BusinessException {
		Long id = jsonobject.getLong("id");
		Map<String, Object> pfileMap = mjkjBaseSqlService.getTableByIdL("mjkj_file_list", id);
		Long create_user = MjkjUtils.getMap2Long(pfileMap,"create_user");
		if(create_user.longValue()!= AuthUtil.getUserId()){
			return -1;
		}
		//个人空间目录不允许操作
		Map<String, Object> grkjMap = mjkjBaseSqlService.getDataOneByField("mjkj_file_list", "file_type", "1");
		Map<String, Object> myfileMap = mjkjBaseSqlService.getTableByIdL("mjkj_file_list", id);
		String grkjId = MjkjUtils.getMap2Str(grkjMap, "id");
		String selectPid = MjkjUtils.getMap2Str(myfileMap, "pid");
		if(Func.equals(grkjId,selectPid)){
			throw new BusinessException("该文件不允许删除");
		}
		//获取所有子节点
		List<Map<String, Object>> subDataList = mjkjBaseSqlService.getDataListByLike("mjkj_file_list", "pstr", ","+id+",",null);
		if(Func.isNotEmpty(subDataList)){
			for (Map<String, Object> subData:subDataList) {
				Long subId = MjkjUtils.getMap2Long(subData, "id");
				mjkjBaseSqlService.baseDeleteSql("mjkj_file_list",subId);
				//写入预览记录
				FileLogModel logModel=new FileLogModel();
				logModel.setFile_id(subId);
				logModel.setFile_title(MjkjUtils.getMap2Str(pfileMap,"title"));
				logModel.setOperate_user_id(AuthUtil.getUserId());
				logModel.setOperate_user_name(AuthUtil.getNickName());
				logModel.setTenant_id(AuthUtil.getTenantId());
				logModel.setRemark(AuthUtil.getNickName()+" 删除文件夹");
				logModel.setType("删除");
				applicationContext.publishEvent(new FileLogEvent(logModel));
			}
		}


		//写入预览记录
		FileLogModel logModel=new FileLogModel();
		logModel.setFile_id(id);
		logModel.setFile_title(MjkjUtils.getMap2Str(pfileMap,"title"));
		logModel.setOperate_user_id(AuthUtil.getUserId());
		logModel.setOperate_user_name(AuthUtil.getNickName());
		logModel.setTenant_id(AuthUtil.getTenantId());
		logModel.setRemark(AuthUtil.getNickName()+" 删除");
		logModel.setType("删除");
		applicationContext.publishEvent(new FileLogEvent(logModel));
		return 1;
	}


}
