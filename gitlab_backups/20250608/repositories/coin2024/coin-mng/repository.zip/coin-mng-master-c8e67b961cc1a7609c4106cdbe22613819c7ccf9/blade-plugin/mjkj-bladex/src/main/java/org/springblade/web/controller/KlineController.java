package org.springblade.web.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.utils.Func;
import org.springblade.feign.IMjkjMarketClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



/**
 * Author: @Wai
 * Date: 2022-7-16
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("coin/kline")
@Api(value = "k线管理", tags = "k线管理")
public class KlineController {
	@Autowired
	private IMjkjMarketClient mjkjMarketClient;



	@ApiOperationSupport(order = 1)
	@PostMapping("/contract/syncKline")
	@ApiOperation(value = "同步合约k线", notes = "同步合约k线")
	public R syncContractKline(@RequestBody JSONObject jsonObject) {
		String contractType = jsonObject.getString("contract_type");
		String symbolName = jsonObject.getString("symbol_name");
		String exchangeType = jsonObject.getString("exchange_type");
		String source = jsonObject.getString("source");
		if (Func.equals("1", contractType)) {
			mjkjMarketClient.syncKline("UBW", symbolName, exchangeType, source);
		}
		if (Func.equals("2", contractType)) {
			mjkjMarketClient.syncKline("BBW", symbolName, exchangeType, source);
		}

		return R.success("成功");
	}


	@ApiOperationSupport(order = 1)
	@PostMapping("/exchange/syncKline")
	@ApiOperation(value = "同步现货k线", notes = "同步现货k线")
	public R syncExchangeKline(@RequestBody JSONObject jsonObject) {
		String symbolName = jsonObject.getString("symbol_name");
		String exchangeType = jsonObject.getString("exchange_type");
		mjkjMarketClient.syncKline("XH", symbolName, exchangeType, "");
		return R.success("成功");
	}


}
