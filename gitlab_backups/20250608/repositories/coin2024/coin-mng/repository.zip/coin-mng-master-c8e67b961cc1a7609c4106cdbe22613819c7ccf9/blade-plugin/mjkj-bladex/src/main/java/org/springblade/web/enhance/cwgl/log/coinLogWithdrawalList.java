package org.springblade.web.enhance.cwgl.log;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.common.utils.UserRoleUtil;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.utils.Func;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 财务管理>提币申请
 */
@Component("coinLogWithdrawalList")
public class coinLogWithdrawalList implements CgformEnhanceJavaListInter {

	@Autowired
	private IMjkjBaseSqlService sqlService;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		QueryWrapper<Object> queryWrapper = new QueryWrapper<>();
		queryWrapper = UserRoleUtil.UserRole(queryWrapper,"coin_log_withdrawal");
		// entry_time_begin entry_time_end withdrawal_time_begin withdrawal_time_end address chain_type
		String entryTimeBegin = MjkjUtils.getMap2Str(params, "entry_time_begin");
		String entryTimeEnd = MjkjUtils.getMap2Str(params, "entry_time_end");
		String withdrawalTimeBegin = MjkjUtils.getMap2Str(params, "withdrawal_time_begin");
		String withdrawalTimeEnd = MjkjUtils.getMap2Str(params, "withdrawal_time_end");
		String address = MjkjUtils.getMap2Str(params, "address");
		String chainType = MjkjUtils.getMap2Str(params, "chain_type");
		String logStatus = MjkjUtils.getMap2Str(params, "log_status");

		// 体现时间
		if (Func.isNotEmpty(entryTimeBegin)){
			queryWrapper.gt("entry_time",entryTimeBegin);
		}

		if (Func.isNotEmpty(entryTimeEnd)){
			queryWrapper.lt("entry_time",entryTimeEnd);
		}

		// 完成时间
		if (Func.isNotEmpty(withdrawalTimeBegin)){
			queryWrapper.gt("withdrawal_time",withdrawalTimeBegin);
		}

		if (Func.isNotEmpty(withdrawalTimeEnd)){
			queryWrapper.gt("withdrawal_time",withdrawalTimeEnd);
		}

		// 地址
		if (Func.isNotEmpty(address)){
			queryWrapper.like("address",address);
		}

		// 链路类型
		if (Func.isNotEmpty(chainType)){
			queryWrapper.eq("chain_type",chainType);
		}

		// 状态
		if (Func.isNotEmpty(logStatus)){
			queryWrapper.eq("log_status",logStatus);
		}
		IPage<Map<String, Object>> pageData = sqlService.getDataIPageByFieldParams("coin_log_withdrawal", page, queryWrapper);
		MjkjUtils.setPageResult(params,pageData);
	}
}
