package org.springblade.web.enhance.activity;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.mapper.CoinUserStatsActivityMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Component("statsUserActivityEnhanceList")
public class StatsUserActivityEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private IMjkjBaseSqlService sqlService;

	@Autowired
	private CoinUserStatsActivityMapper userStatsActivityMapper;
	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		String uidQuery = MjkjUtils.getMap2Str(params, "uid");
		String activityIdQuery = MjkjUtils.getMap2Str(params, "activity_id");
		QueryWrapper<Object> wrapper=new QueryWrapper<>();
		if(Func.isNotEmpty(uidQuery)){
			wrapper.eq("uid",uidQuery);
		}
		if(Func.isNotEmpty(activityIdQuery)){
			wrapper.eq("activity_id",activityIdQuery);
		}
		wrapper.eq("is_deleted","0");
		wrapper.orderByDesc("id");

		IPage<Map<String, Object>> mapIPage = sqlService.getDataIPageByFieldParams("coin_stats_user_activity", page, wrapper);

		List<Map<String, Object>> records = mapIPage.getRecords();
		if (Func.isEmpty(records)) {
			return;
		}
		for (Map<String, Object> record : records) {
			String memberId = MjkjUtils.getMap2Str(record, "member_id");
			Date startTime = MjkjUtils.getMap2DateTime(record, "start_time");
			Date endTime = MjkjUtils.getMap2DateTime(record, "end_time");
			getContractAmount(record,memberId,startTime,endTime);
			getDepositAmount(record,memberId,startTime,endTime);
			getWithdrawAmount(record,memberId,startTime,endTime);
		}
		MjkjUtils.setPageResult(params, mapIPage);
	}


	private void getContractAmount(Map<String, Object> record,String memberId,Date startTime,Date endTime){
		Integer count = userStatsActivityMapper.getUserStatsCountByTime(memberId,1,startTime,endTime);
		Map<String, Object> userStatsByTime = userStatsActivityMapper.getUserStatsByTime(memberId,1,startTime,endTime);
		record.put("count",Func.isEmpty(count)?0:count);
		BigDecimal amount = MjkjUtils.getMap2BigD(userStatsByTime, "amount");
		BigDecimal fee = MjkjUtils.getMap2BigD(userStatsByTime, "fee");
		record.put("amount",amount.stripTrailingZeros().toPlainString());
		record.put("fee",fee.stripTrailingZeros().toPlainString());
	}

	private void getDepositAmount(Map<String, Object> record,String memberId,Date startTime,Date endTime){
		BigDecimal depositAmount = userStatsActivityMapper.getUserStatsDepositByTime(memberId,startTime,endTime);
		record.put("deposit_amount",depositAmount.stripTrailingZeros().toPlainString());
	}

	private void getWithdrawAmount(Map<String, Object> record,String memberId,Date startTime,Date endTime){
		BigDecimal withdrawAmount = userStatsActivityMapper.getUserStatsWithdrawByTime(memberId,startTime,endTime);
		record.put("withdraw_amount",withdrawAmount.stripTrailingZeros().toPlainString());
	}
}
