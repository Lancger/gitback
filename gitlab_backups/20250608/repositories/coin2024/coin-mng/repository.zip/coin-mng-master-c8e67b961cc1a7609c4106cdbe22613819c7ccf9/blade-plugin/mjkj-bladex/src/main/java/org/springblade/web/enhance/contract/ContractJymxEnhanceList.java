package org.springblade.web.enhance.contract;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.mapper.HtHyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 合约交易-交易明细
 */
@Component("contractJymxEnhanceList")
public class ContractJymxEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private HtHyMapper htHyMapper;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		String userRole = AuthUtil.getUserRole();
		Long userId = null;
		if(!userRole.contains("administrator")){//不是超级管理员
			userId = AuthUtil.getUserId();
		}
		params.put("userId",userId);
		Page pages = htHyMapper.getContractJymxPage(page, params);

		List<Map<String, Object>> records = pages.getRecords();
		if (Func.isEmpty(records)) {
			return;
		}
		for (Map<String, Object> dataMap : records) {
			String direction = MjkjUtils.getMap2Str(dataMap, "direction");
			String contractType = MjkjUtils.getMap2Str(dataMap, "contract_type");//合约类型

			String avgPrice = MjkjUtils.getMap2BigD(dataMap, "avg_price").stripTrailingZeros().toPlainString();
			String success_price = MjkjUtils.getMap2BigD(dataMap, "success_price").stripTrailingZeros().toPlainString();//成交价格
			Date completedTime = MjkjUtils.getMap2DateTime(dataMap, "completed_time");


			String entrustBalance = MjkjUtils.getMap2BigD(dataMap, "entrust_balance").stripTrailingZeros().toPlainString();//成交量
			String entrustSymbol = MjkjUtils.getMap2Str(dataMap, "entrust_symbol");//成交币种

			String feeBalance = MjkjUtils.getMap2BigD(dataMap, "fee_balance").stripTrailingZeros().toPlainString();//手续费
			String feeSymbol = MjkjUtils.getMap2Str(dataMap, "fee_symbol");//手续费币种

			String profit = MjkjUtils.getMap2BigD(dataMap, "profit").stripTrailingZeros().toPlainString();//盈亏
			String profitSymbol = MjkjUtils.getMap2Str(dataMap, "profit_symbol");//盈亏币种



			String directionStr="";
			if(Func.equals(direction,"1")){
				directionStr="开多";
			}else if(Func.equals(direction,"2")){
				directionStr="开空";
			}else if(Func.equals(direction,"3")){
				directionStr="平多";
			}else if(Func.equals(direction,"4")){
				directionStr="平空";
			}

			String contractTypeStr="U本位";
			if(Func.equals(contractType,"2")){
				contractTypeStr="币本位";
			}

			dataMap.put("direction", directionStr);
			dataMap.put("contract_type",contractTypeStr);//合约类型
			dataMap.put("avg_price",avgPrice);//均价
			dataMap.put("success_price", success_price);
			if (Func.isNotEmpty(completedTime)) {
				dataMap.put("completed_time", DateUtil.format(completedTime, DateUtil.PATTERN_DATETIME));
			} else {
				dataMap.put("completed_time", "-");
			}
			dataMap.put("cjl_balance",  entrustBalance + entrustSymbol);//交易币种



			dataMap.put("sxf_balance", feeBalance );//手续费
			dataMap.put("sxf_coinName", feeSymbol);//手续费币种


			if(Func.equals(direction,"1")||Func.equals(direction,"2")){
				dataMap.put("yk_balance", "-");//开仓没有盈亏
				dataMap.put("yk_coinName",  "-");//盈亏币种
			}else{
				dataMap.put("yk_balance",  profit );//盈亏
				dataMap.put("yk_coinName",  profitSymbol);//盈亏币种
			}


		}
		MjkjUtils.setPageResult(params, pages);
	}
}
