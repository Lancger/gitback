package org.springblade.web.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.github.xiaoymin.knife4j.annotations.DynamicParameter;
import com.github.xiaoymin.knife4j.annotations.DynamicParameters;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.core.tool.api.R;
import org.springblade.core.tool.constant.BladeConstant;
import org.springblade.web.entity.CoinQuoteControlRecord;
import org.springblade.web.feign.SelfRemoteClient;
import org.springblade.web.param.ResultBody;
import org.springblade.web.response.JsonResult;
import org.springblade.web.service.ICoinQuoteControlRecordService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping("coin/controlRecord")
@Api(value = "平台控盘", tags = "平台控盘")
public class CoinQuoteControlRecordController {

	@Resource
	private ICoinQuoteControlRecordService coinQuoteControlRecordService;

	@Resource
	private IMjkjBaseSqlService baseSqlService;

	@Resource
	private SelfRemoteClient selfRemoteClient;

	@Value("${mid.stand.systemId}")
	private int systemId;

	@GetMapping("/list")
	@ApiOperation(value = "控盘记录列表", notes = "控盘记录列表")
	@ApiImplicitParams({
		@ApiImplicitParam(paramType = "query", name = "symbol", value = "交易对", dataType = "String"),
		@ApiImplicitParam(paramType = "query", name = "controlType", value = "控盘类型（1-长控 2-短控 3-插针）", dataType = "Integer"),
		@ApiImplicitParam(paramType = "query", name = "controlPriceType", value = "控盘方向（1-涨 2-跌）", dataType = "Integer"),
		@ApiImplicitParam(paramType = "query", name = "status", value = "状态（1-未上线 2-进行中 3-已结束）", dataType = "Integer"),
		@ApiImplicitParam(paramType = "query", name = "pageNo", value = "起始页", dataType = "Integer"),
		@ApiImplicitParam(paramType = "query", name = "pageSize", value = "每页数", dataType = "Integer")
	})
	public R list(@ApiIgnore @RequestParam(required = false) Map<String, Object> params) {
		IPage records = coinQuoteControlRecordService.getAllRecordList(params);
		return R.data(records);
	}

	@ApiOperation(value = "控盘记录详情")
	@PostMapping("/detail/{id}")
	public R<CoinQuoteControlRecord> detail(@PathVariable("id") String id) {
		CoinQuoteControlRecord info = coinQuoteControlRecordService.getById(id);
		return R.data(info);
	}

	@ApiOperation(value = "删除控盘记录")
	@PostMapping("/delete/{id}")
	public R deleteByIds(@PathVariable("id") Long id) {
		coinQuoteControlRecordService.lambdaUpdate()
			.set(CoinQuoteControlRecord::getIsDeleted, BladeConstant.DB_IS_DELETED)
			.eq(CoinQuoteControlRecord::getId, id).update();
		return R.success("成功");
	}

	@ApiOperation(value = "获取交易对列表，包含现货和合约")
	@GetMapping("/symbolList/{type}")
	@ApiImplicitParams({
		@ApiImplicitParam(paramType = "path", name = "type", value = "行情类型（1-币 2-外汇）", dataType = "String", defaultValue = "1"),
	})
	public R symbolList(@PathVariable("type") String type) {

		// 获取所有合约交易对
		QueryWrapper<Object> wrapper = new QueryWrapper<>();
		wrapper.eq("is_deleted",0);
		wrapper.select("symbol_name", "exchange_type");
		List<Map<String, Object>> dataMapList2 = baseSqlService.getDataListByFieldParams("coin_coin_contract", wrapper);
		Map<Object, List<Map<String, Object>>> exchangeType = dataMapList2.stream().collect(Collectors.groupingBy((Map<String, Object> map) -> map.get("exchange_type")));

		if ("1".equals(type)) {
			/*
			 * 币的交易对
			 */
			// 获取所有现货交易对
			wrapper = new QueryWrapper<>();
			wrapper.eq("is_deleted",0);
			wrapper.select("symbol_name");
			List<Map<String, Object>> dataMapList = baseSqlService.getDataListByFieldParams("coin_coin_exchange", wrapper);

			// 币，现货+全约
			dataMapList.addAll(exchangeType.get("1"));
			List<String> symbolList = dataMapList.stream().map(map -> (String) map.get("symbol_name")).distinct().collect(Collectors.toList());
			return R.data(symbolList);
		} else if ("2".equals(type)) {
			/*
			 * 外汇的交易对
			 */
			List<Map<String, Object>> maps = exchangeType.get("2");
			List<String> symbolList = maps.stream().map(map -> (String) map.get("symbol_name")).distinct().collect(Collectors.toList());
			return R.data(symbolList);
		}

        return R.data(null);
    }

	@ApiOperationSupport(order = 1)
	@ApiOperation(value = "根据行情类型获取交易对列表")
	@PostMapping("/selfSourceList")
	@DynamicParameters(name = "params", properties={
		@DynamicParameter(name = "market", value = "行情类型（1-CSPOT 2-FX）", example = "CSPOT")
	})
	public R selfSourceList(@RequestBody JSONObject jsonObject) {
		jsonObject.put("systemId", systemId);
		// 1 未过期 不传值查所有
		jsonObject.put("status", 1);
		jsonObject.put("pageIndex", 1);
		jsonObject.put("pageSize", 200);
		ResultBody resultBody = selfRemoteClient.modelTaskList(jsonObject);
		LinkedHashMap result = (LinkedHashMap) resultBody.getResult();
		ArrayList records = (ArrayList) result.get("records");

		return R.data(records);
	}
}
