package org.springblade.web.enhance.ggjy;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.DateUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.mapper.GgjyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 杠杠交易-借币记录
 */
@Component("ggjyJbjlEnhanceList")
public class JbjlEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private GgjyMapper ggjyMapper;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		list.clear();
		Page page = MjkjUtils.getPage(params);
		String userRole = AuthUtil.getUserRole();
		Long userId = null;
		if(!userRole.contains("administrator")){//不是超级管理员
			userId = AuthUtil.getUserId();
		}
		params.put("userId",userId);
		Page pages = ggjyMapper.getJbjlPage(page, params);

		List<Map<String, Object>> records = pages.getRecords();
		if (Func.isEmpty(records)) {
			return;
		}
		for (Map<String, Object> dataMap : records) {
			String direction = MjkjUtils.getMap2Str(dataMap, "direction");

			String borrowAmountStr = MjkjUtils.getMap2BigD(dataMap, "borrow_amount").stripTrailingZeros().toPlainString();//借币数量
			String stillBorrowAmountStr = MjkjUtils.getMap2BigD(dataMap, "still_borrow_amount").stripTrailingZeros().toPlainString();//还币数量
			String interestAmountStr = MjkjUtils.getMap2BigD(dataMap, "interest_amount").stripTrailingZeros().toPlainString();//利息
			String stillInterestAmountStr = MjkjUtils.getMap2BigD(dataMap, "still_interest_amount").stripTrailingZeros().toPlainString();//已还利息
			Date borrowTime = MjkjUtils.getMap2DateTime(dataMap, "borrow_time");
			String borrowStatus = MjkjUtils.getMap2Str(dataMap, "borrow_status");//借币状态

			dataMap.put("borrow_amount",borrowAmountStr);
			dataMap.put("still_borrow_amount",stillBorrowAmountStr);
			dataMap.put("interest_amount",interestAmountStr);
			dataMap.put("still_interest_amount",stillInterestAmountStr);
			if (Func.isNotEmpty(borrowTime)) {
				dataMap.put("completed_time", DateUtil.format(borrowTime, DateUtil.PATTERN_DATETIME));
			} else {
				dataMap.put("completed_time", "-");
			}
			dataMap.put("borrow_status", Func.equals(borrowStatus, "0") ? "借币中" : "已完成");
		}
		MjkjUtils.setPageResult(params, pages);
	}
}
