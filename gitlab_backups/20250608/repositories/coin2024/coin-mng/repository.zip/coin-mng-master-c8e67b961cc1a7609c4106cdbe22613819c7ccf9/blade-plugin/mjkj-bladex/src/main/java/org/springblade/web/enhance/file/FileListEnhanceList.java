package org.springblade.web.enhance.file;

import org.springblade.cgform.model.CgformEnhanceJavaListInter;
import org.springblade.cgform.service.IMjkjBaseSqlService;
import org.springblade.common.utils.MjkjUtils;
import org.springblade.config.exception.BusinessException;
import org.springblade.core.secure.BladeUser;
import org.springblade.core.secure.utils.AuthUtil;
import org.springblade.core.tool.utils.Func;
import org.springblade.web.service.IMjkjFileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 文件列表-列表
 * 表明：mjkj_file_list
 */
@Component("fileListEnhanceList")
public class FileListEnhanceList implements CgformEnhanceJavaListInter {

	@Autowired
	private IMjkjFileService fileService;

	@Autowired
	private IMjkjBaseSqlService mjkjBaseSqlService;

	@Override
	public void execute(String tableName, String tenantId, List<Map<String, Object>> list, Map<String, Object> params) throws BusinessException {
		BladeUser user = AuthUtil.getUser();
		list.clear();
		//获取我所有有权限的文件夹
		//根据父级获取下级
		Long pid = MjkjUtils.getMap2Long(params, "pid");
		List<Map<String, Object>> dataList = mjkjBaseSqlService.getDataListByField("mjkj_file_list", "pid", pid);
		if(Func.isEmpty(dataList)){
			return;
		}
		long userId = AuthUtil.getUserId().longValue();
		List<Long> deptList = Func.toLongList( AuthUtil.getDeptId());
		List<Long> roleList = Func.toLongList(AuthUtil.getUser().getRoleId());
		List<Long> myFileIdList = fileService.getMyRoleFileIdList(userId, roleList, deptList);

		Iterator<Map<String, Object>> iterator = dataList.iterator();
		while (iterator.hasNext()){
			Map<String, Object> dataMap = iterator.next();
			Long createUser = MjkjUtils.getMap2Long(dataMap, "create_user");
			Integer type = MjkjUtils.getMap2Integer(dataMap, "type");
			Long id = MjkjUtils.getMap2Long(dataMap, "id");
			String pstr = MjkjUtils.getMap2Str(dataMap, "pstr");
			if(userId==createUser){//当前文件是我自己创建
				continue;
			}
			if(Func.equals("administrator", AuthUtil.getUser().getRoleName())){
				continue;
			}

			//没有进行过授权，删除
			if(Func.isEmpty(myFileIdList)){
				iterator.remove();
				continue;
			}

			if(myFileIdList.contains(id)){
				continue;
			}
			//该文件是否是我的子文件
			List<Long> fileIds = Func.toLongList(pstr);
			boolean flag=false;
			for (Long fileId:fileIds) {
				if(myFileIdList.contains(fileId)){
					flag=true;//存在
					break;
				}
			}
			if(!flag){
				iterator.remove();
				continue;
			}
			//判断该子文件是否单独给某一个人
			List<Long> userIdList = fileService.getMyRoleFileIdListUserId(id);
			List<Long> roleIdList = fileService.getMyRoleFileIdListRoleId(id);
			Set<Long> deptIdList = fileService.getMyRoleFileIdListDeptId(id);
			//该文件有勾选到权限
			if(Func.isNotEmpty(userIdList) || Func.isNotEmpty(roleIdList) || Func.isNotEmpty(deptIdList)){
				boolean exitFlag=false;
				if(Func.isNotEmpty(userIdList) && userIdList.contains(userId)){
					exitFlag=true;
				}
				if(!exitFlag){
					if(Func.isNotEmpty(roleIdList)&& roleIdList.retainAll(roleList)){
						exitFlag=true;
					}
				}
				if(!exitFlag){
					if(Func.isNotEmpty(deptIdList)&& deptIdList.retainAll(deptList)){
						exitFlag=true;
					}
				}
				if(!exitFlag){
					iterator.remove();
					continue;
				}
			}
		}


		list.addAll(dataList);
		//只能查看有权限的文件
		if(Func.isNotEmpty(list)){
			for (Map<String, Object> map:list){
				map.put("file_url","");
				map.put("file_pwd","");
				map.put("file_salt","");
				Integer type = MjkjUtils.getMap2Integer(map, "type");
				if(Func.isNotEmpty(type) && type==1){//文件夹
					map.put("download_num","");
					map.put("view_num","");
					map.put("file_size","");
				}
			}
		}
	}
}
