package org.springblade.third.constant.activity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ActivityTaskOperateTypeEnum {

	/**
	 * 任务获取类型：1-注册，2-首充，3-首次合约交易，4-KYC，5-邀请KYC，6-合约交易额，7-现货交易额，
	 * 8-邀请入金，9-每日合约交易手续费，10-每日充值,11-签到
	 */
	REG("注册", 1),
	RECHARGE_FIRST("首充", 2),
	CONTRACT_First("首次合约交易", 3),
	KYC("KYC", 4),
	INVITE_KYC("邀请KYC", 5),
	CONTRACT_AMOUNT("合约交易额", 6),
	SPOT_AMOUNT("现货交易额", 7),
	INVITE_RECHARGE("邀请入金", 8),
	CONTRACT_FEE_DAY("每日合约交易手续费", 9),
	RECHARGE_DAY("每日充值", 10),
	CHECK_IN("签到", 11),
	;

	final String name;
	final int status;
}
