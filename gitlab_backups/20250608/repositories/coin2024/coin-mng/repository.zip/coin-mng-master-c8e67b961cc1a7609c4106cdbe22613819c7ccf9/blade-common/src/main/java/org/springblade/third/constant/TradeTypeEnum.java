package org.springblade.third.constant;

/**
 * @author Watson
 * @date 2024/1/23 11:08
 */
public enum TradeTypeEnum {
	USDT_M("ubw"),
	COIN_M("bbw"),
	SPOT("xh");


	private final String type;

	TradeTypeEnum(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public static TradeTypeEnum fromType(String type) {
		if (USDT_M.getType().equalsIgnoreCase(type)) {
			return USDT_M;
		} else if (COIN_M.getType().equalsIgnoreCase(type)) {
			return COIN_M;
		} else if (SPOT.getType().equalsIgnoreCase(type)) {
			return SPOT;
		}
		throw new RuntimeException("illegal entrust type");
	}


}
