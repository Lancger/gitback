package org.springblade.third.constant.activity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ActivityRewardTypeEnum {

	/**
	 * 奖品类型：0-谢谢惠顾，1-手续费抵扣金，2-手续费返现卡，3-合约赠金，4-现金红包，5-礼品卡
	 */
	NONE("谢谢惠顾", 0),
	FEE_OFFSET("手续费抵扣金", 1),
	FEE_CASHBACK("手续费返现卡", 2),
	GIFT_MONEY("合约赠金", 3),
	CASH_GIFT("现金红包", 4),
	GIFT_CARD("礼品卡", 5),
	;

	final String name;
	final int status;
}
