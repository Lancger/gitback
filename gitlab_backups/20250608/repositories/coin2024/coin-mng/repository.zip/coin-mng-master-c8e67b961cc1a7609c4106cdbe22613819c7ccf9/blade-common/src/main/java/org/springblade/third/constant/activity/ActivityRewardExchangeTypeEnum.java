package org.springblade.third.constant.activity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ActivityRewardExchangeTypeEnum {

	/**
	 * 手续费奖品适用类型：1-现货，2-合约
	 */
	SPOT("现货", 1),
	CONTRACT("合约", 2),
	;

	final String name;
	final int status;
}
