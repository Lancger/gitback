package org.springblade.third.utils;

/**
 * @author Watson
 * @date 2024/2/28 17:44
 */
public class StringUtil {


	public static String emailOrPhoneDesensitization(String original) {
		if (original.contains("@")) {
			return emailDesensitizationV2(original);
		} else {
			return phoneDesensitizationV2(original);
		}
	}


	public static String emailDesensitization(String original) {
		return original.replaceAll("(^\\w)[^@]*(@.*$)", "$1****$2");
	}

	public static String emailDesensitizationV2(String original) {
		String[] split = original.split("@");
		String head = split[0];
		String tail = split[1];
		if (head.length() > 3) {
			return head.substring(0, 3) + "****@" + tail;
		} else {
			return head + "****@" + tail;
		}
	}


	public static String phoneDesensitization(String original) {
		return original.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
	}

	public static String phoneDesensitizationV2(String original) {
		if (original.length() >= 7) {
			String head = original.substring(0, 3);
			String tail = original.substring(original.length() - 4);
			return head + "****" + tail;
		} else {
			return original;
		}
	}


}
