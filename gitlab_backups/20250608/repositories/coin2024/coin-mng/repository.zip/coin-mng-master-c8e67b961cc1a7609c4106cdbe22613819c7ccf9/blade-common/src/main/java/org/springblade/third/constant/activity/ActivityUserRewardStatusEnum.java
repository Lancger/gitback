package org.springblade.third.constant.activity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ActivityUserRewardStatusEnum {

	/**
	 * 0-待使用，1-已使用，2-使用中，3-已过期，4-停用
	 */
	PENDING("待使用", 0),
	USING("已使用", 1),
	ONGOING("使用中", 2),
	OUT_TIME("已过期", 3),
	STOP("停用", 4),
	;

	final String name;
	final int status;
}
