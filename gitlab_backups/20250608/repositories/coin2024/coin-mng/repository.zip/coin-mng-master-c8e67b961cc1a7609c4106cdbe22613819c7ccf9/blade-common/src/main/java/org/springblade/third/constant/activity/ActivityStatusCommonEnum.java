package org.springblade.third.constant.activity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ActivityStatusCommonEnum {

	/**
	 * 0-待生效，1-进行中，2-已结束，3-停用
	 */
	PENDING("待生效", 0),
	ONGOING("进行中", 1),
	END("已结束", 2),
	STOP("停用", 3),
	;

	final String name;
	final int status;
}
