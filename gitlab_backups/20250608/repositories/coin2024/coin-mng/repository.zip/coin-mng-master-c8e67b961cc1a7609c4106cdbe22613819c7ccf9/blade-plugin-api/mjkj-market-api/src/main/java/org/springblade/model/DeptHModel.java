package org.springblade.model;

import lombok.Data;

import java.util.List;
import java.util.TreeSet;

@Data
public class DeptHModel {
	private TreeSet<TradePlateItem> buyItems;//买盘深度
	private TreeSet<TradePlateItem> sellItems;//卖盘深度
	private String symbolName;//交易对
	private String topic;//主题

}
