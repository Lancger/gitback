package org.springblade.constant;

/**
 * 这个是合约钱包流水类型  之前没有枚举，数据库看到的业务 流水类型最大是9
 *
 * @author Watson
 * @date 2023/12/22 11:32
 */
public enum WalletServiceType {

	FREEZE("50", "冻结资金"),
	UNFREEZE("51", "解冻资金");


	private final String serviceType;
	private final String remark;

	WalletServiceType(String serviceType, String remark) {
		this.serviceType = serviceType;
		this.remark = remark;
	}

	public String getServiceType() {
		return serviceType;
	}

	public String getRemark() {
		return remark;
	}
}
