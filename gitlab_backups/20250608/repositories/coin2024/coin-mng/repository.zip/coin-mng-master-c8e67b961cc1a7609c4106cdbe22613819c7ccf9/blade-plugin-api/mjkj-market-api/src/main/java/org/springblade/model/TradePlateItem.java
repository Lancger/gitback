package org.springblade.model;

import lombok.Data;
import org.aspectj.bridge.Constants;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Random;
import java.util.TreeSet;

@Data
public class TradePlateItem implements Comparable<TradePlateItem>{

	/**
	 *  订单类型 1 买单 2 卖单
	 */
	private Integer orderType;
    private BigDecimal price;
    private BigDecimal amount;

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append(price).append(":").append(amount);
        return sb.toString();
    }

	@Override
	public int compareTo(TradePlateItem tradePlateItem) {

		// 买单队列从高到低排序
		if (this.orderType == 1) {
			int i = tradePlateItem.getPrice().compareTo(this.getPrice());
			if(0==i){
				//替换amount 为新的
				tradePlateItem.setAmount(this.getAmount());
			}
			return i;
		}

		// 卖单队列从低到高排序
		int i = this.getPrice().compareTo(tradePlateItem.getPrice());
		if(0==i){
			//替换amount 为新的
			tradePlateItem.setAmount(this.getAmount());
		}
		return i;
	}
}
