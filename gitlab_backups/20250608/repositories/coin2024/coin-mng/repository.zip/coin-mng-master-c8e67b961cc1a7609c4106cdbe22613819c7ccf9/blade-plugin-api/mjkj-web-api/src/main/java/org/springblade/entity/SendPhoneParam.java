package org.springblade.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * Author: @Wai
 * Date: 2022-10-28
 */
@Data
public class SendPhoneParam implements Serializable {
	private String phone;
	private String content;
	private String areaCode;
}
