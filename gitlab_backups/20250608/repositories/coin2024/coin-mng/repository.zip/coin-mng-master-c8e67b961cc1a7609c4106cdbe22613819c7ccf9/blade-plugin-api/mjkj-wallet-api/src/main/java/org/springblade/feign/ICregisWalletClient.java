package org.springblade.feign;

import org.springblade.core.tool.api.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

@FeignClient(
	value = "mjkj-wallet"
)
public interface ICregisWalletClient {
	String API_PREFIX = "/cregis-wallet";
	String GET_ADDRESS = API_PREFIX + "/get-address";//创建钱包地址
	String CHECK_ADDRESS = API_PREFIX + "/check-address";//校验地址
	String TRANSFER = API_PREFIX + "/transfer";//转账

	/**
	 * 获取钱包
	 *
	 * @return
	 */
	@PostMapping(GET_ADDRESS)
	R<String> getAddress(@RequestParam("chainId") String chainId, @RequestParam("memberId") String memberId);


	/**
	 * 校验地址
	 *
	 * @param chainId
	 * @param address
	 * @return
	 */
	@PostMapping(CHECK_ADDRESS)
	R<Boolean> checkAddress(@RequestParam("chainId") String chainId, @RequestParam("address") String address);


	/**
	 * 提现
	 *
	 * @param chainType
	 * @param coinSymbol
	 * @param taskId
	 * @param tokenId
	 * @param address
	 * @param amount
	 */
	@PostMapping(TRANSFER)
	void transfer(@RequestParam("chainType") String chainType, @RequestParam("coinSymbol") String coinSymbol,
				  @RequestParam("taskId") String taskId, @RequestParam("chainId") String chainId,
				  @RequestParam("tokenId") String tokenId, @RequestParam("address") String address,
				  @RequestParam("amount") BigDecimal amount);
}
