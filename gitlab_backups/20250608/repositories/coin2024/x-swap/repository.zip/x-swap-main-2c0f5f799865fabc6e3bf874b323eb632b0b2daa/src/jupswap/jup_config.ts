interface Config {
    walletAddress: string;
    PRIVATE_KEY: string;
    Symbol: string;
    USDT: string;
    Time: number;
}

export const JupSwapConfig: Config = {
    walletAddress: "",
    PRIVATE_KEY: process.env.PRIVATE_KEY || "",
    Symbol: process.env.Symbol || "",
    USDT: process.env.USDT || "",
    Time: process.env.Time ? parseInt(process.env.Time) : 0,
}