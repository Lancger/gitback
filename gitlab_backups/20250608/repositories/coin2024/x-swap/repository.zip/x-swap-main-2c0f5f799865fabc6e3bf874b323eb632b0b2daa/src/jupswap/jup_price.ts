import axios from 'axios';

// 定义返回数据的类型 (根据实际返回的数据结构进行定义)
interface PriceResponse {
    [key: string]: any; // 根据API返回的数据结构进行调整
}

export async function price(s: string): Promise<PriceResponse> {
    const priceResponse = await axios.get(`https://price.jup.ag/v4/price?ids=${s}`);
    const data: PriceResponse = priceResponse.data;
    return data;
}
