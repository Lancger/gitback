// 入口文件
import { config } from 'dotenv';
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import path from 'path';
import { Connection } from '@solana/web3.js';
// import { pay } from './src/pay';
// import { price } from './src/price';
// import { quote } from './src/quote';
// import { strict } from './src/strict';
// import './src/tgbot';
// import { checkPriceAndTrade } from './src/task';
// import { lastPrice } from './src/lastPrice';

// 环境
const envFile = process.env.NODE_ENV === 'production' ? '.env.production' : '.env.development';
const envPath = path.join(__dirname, '..', envFile);
config({ path: envPath });

import { jupTaskStart,jupTaskStop } from './jupswap/api/jup_api';
import { uniStarTask,uniQuote } from './uniswap/api/uni_api'; 
const app = express();
app.use(cors());
app.use(bodyParser.json());

// const connection = new Connection('https://neat-hidden-sanctuary.solana-mainnet.discover.quiknode.pro/2af5315d336f9ae920028bbb90a73b724dc1bbed/');

// 查看某一个的价格
// app.get('/api/price', (req, res) => {
//   price(req.query.symbol).then(response =>{
//     let quoteData = response
//     res.json(quoteData);
//   })
// });

// // 进行交换支付
// app.get('/api/pay', (req, res) => {
//   const inputMint = "So11111111111111111111111111111111111111112"
//   const outputMint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
//   pay(inputMint,outputMint,1).then(response => {
//     res.json(response);
//   })
// });

// 一个换取另外一个的价格
// app.get('/api/quote', (req, res) => {
//   const inputMint = "So11111111111111111111111111111111111111112"
//   const outputMint = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
//   quote(inputMint,outputMint,1).then(response => {
//     res.json(response);
//   })
// });

// 获取swap的币种地址及其他信息
// app.get('/api/strict', (req, res) => {
//   strict().then(response => {
//     res.json(response);
//   })
// });

// 测试用的接口
app.get('/api/env', (req,res) => {
  // checkPriceAndTrade(50,"solusdt")
  res.json()
})

// 开启任务
app.get('/api/jup/star',jupTaskStart)

// 结束任务
app.get('/api/jup/stop',jupTaskStop)

/**------------------------------------------ */
app.get('/api/uni/star',uniStarTask)

app.get('/api/uni/quote',uniQuote)



const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));