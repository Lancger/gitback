import axios from 'axios';
import { pay } from './jup_swap';
import { price } from './jup_price';
import { quote } from './jup_quote';
import { strict } from './jup_strict';
// import TelegramBot from 'node-telegram-bot-api';
import { logger } from '../commons/logger';
import globals from '../commons/singleton';
import { JupSwapConfig } from './jup_config';

const USDTMint:string = JupSwapConfig.USDT || "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB";
const timeExternal:number = JupSwapConfig.Time || 3600000;

interface MarketData {
  data: {
    buyList: [number[]];
  };
}

async function fetchData(symbol: string): Promise<MarketData> {
  try {
    const response = await axios.get<MarketData>(`https://server.ichcoin.top/api/app/exchange/getMarketInfo?symbol=${symbol}`);
    return response.data;
  } catch (error) {
    logger.error('Error', error);
    throw error;
  }
}

export async function lastPrice(symbol: string): Promise<number | undefined> {
  try {
    const data = await fetchData(symbol);
    let items: number[] = [];
    data.data.buyList[0].forEach((item, index) => {
      if (index === 0) {
        items.push(item);
      }
    });
    return items[0];
  } catch (error) {
    logger.error('Error fetching data:', error);
  }
}

export async function getPrice1(symbol: string): Promise<number | undefined> {
  let symbolU = symbol.toUpperCase().replace("USDT", "");
  const inputMint = await mint(symbolU);
  if (!inputMint) {
    logger.error('价格1中获取inputMint地址错误');
    return;
  }
  const price1 = await priceToUSDT(inputMint, symbolU);
  const price1Key = "price1_" + symbol;
  globals.setObjectProperty(price1Key, price1);
  return price1;
}

export async function getPrice2(symbol: string): Promise<number[] | undefined> {
  const data = await fetchData(symbol);
  let item = data.data.buyList[0];
  const lastPriceKey = "lastPrice_" + symbol;
  if (item[0]) {
    globals.setObjectProperty(lastPriceKey, item[0]);
    const amountKey = "amount_" + symbol;
    globals.setObjectProperty(amountKey, item[1]);
    return item;
  }
  return item;
}

function calculatePriceDifference(price1: number, price2: number): number {
  return Math.abs((price1 - price2) / price1) * 100;
}

function transactionVolume(symbol: string): number {
  const randomValue1 = Math.random() * (0.80 - 0.70) + 0.70;
  const amountKey = "amount_" + symbol;
  const a = globals.getObjectProperty(amountKey);
  const lastPriceKey = "lastPrice_" + symbol;
  const lastPrice = globals.getObjectProperty(lastPriceKey);
  let amount1 = a * randomValue1;
  const randomValue2 = Math.floor(Math.random() * (100 - 80 + 1) + 80);
  let amount2 = randomValue2 / lastPrice;
  return Math.max(amount1, amount2);
}

async function mint(symbolU: string): Promise<string | null> {
  const mintData = await strict();
  let tagData: string | null = null;
  mintData.forEach((item: { symbol: string; address: string | null; }) => {
    if (item.symbol === symbolU) {
      tagData = item.address;
    }
  });
  return tagData;
}

async function priceToUSDT(inputMint: string, symbol: string): Promise<number> {
  const priceData = await quote(inputMint, USDTMint, 1, 0);
  const price1 = Number(priceData.outAmount) / 100000;
  const price1Key = 'price_' + symbol;
  globals.setObjectProperty(price1Key, price1);
  return price1;
}

function task(symbol: string, inputMint: string, outputMint: string, amount: number, slippageBps: number, time: number, bool: boolean) {
  let taskIntervalKey = 'taskInterval_' + symbol;
  const taskInterval = setInterval(() => {
    getPrice1(symbol);
    getPrice2(symbol);
    const price1Key = "price_" + symbol;
    const price1 = globals.getObjectProperty(price1Key);
    const lastPriceKey = "lastPrice_" + symbol;
    const price2 = globals.getObjectProperty(lastPriceKey);
    const tagPrice = calculatePriceDifference(price1, price2);
    if (tagPrice <= 1 && tagPrice >= -1) {
      killTask(symbol);
    } else {
      const amount = transactionVolume(symbol);
      if (tagPrice < -1) {
        pay(inputMint, outputMint, amount, slippageBps);
      } else {
        pay(outputMint, inputMint, amount, slippageBps);
      }
    }
  }, time * 60 * 1000);
  globals.setObjectProperty(taskIntervalKey, taskInterval);
}

function killTask(symbol: string) {
  const key = "taskInterval_" + symbol;
  const taskInterval = globals.getObjectProperty(key);
  clearInterval(taskInterval);
  globals.setObjectProperty(key, "");
}

export async function checkPriceAndTrade(slippageBps: number, symbol: string) {
  try {
    killTask(symbol);
    const lastPriceKey = "lastPrice_" + symbol;
    const price2 = globals.getObjectProperty(lastPriceKey);
    let symbolU = symbol.toUpperCase().replace("USDT", "");
    const inputMint = await mint(symbolU);
    if (!inputMint) {
      logger.error("未获取到inputMint地址");
      return
    }
    const price1 = await priceToUSDT(inputMint, symbolU);
    if (price1 && price2) {
      let priceDifference = calculatePriceDifference(price1, price2);
      priceDifference = parseFloat(priceDifference.toFixed(2));
      const amount = transactionVolume(symbol);
      if (priceDifference <= 1 && priceDifference >= -1) {
        killTask(symbol);
      } else {
        if (priceDifference > 1) {
          task(symbol, USDTMint, inputMint, amount, slippageBps, 5, false);
        } else if (priceDifference < -1) {
          task(symbol, inputMint, USDTMint, amount, slippageBps, 5, true);
        }
      }
    }
  } catch (error) {
    logger.error("checkPriceAndTrade方法 Error:", error);
  }
}

// 开启定时任务
export function startTask() {
  (function() {
    const listSymbols = JupSwapConfig.Symbol.split(",");
    listSymbols.forEach(async (symbol: string) => {
      getPrice1(symbol);
      getPrice2(symbol);
      // const total:any = setInterval(async () => {
        logger.info('定时器开始执行');
        try {
          const data = await fetchData(symbol);
          let item = data.data.buyList[0];
          const lastPriceKey = 'lastPrice_' + symbol;
          globals.setObjectProperty(lastPriceKey, item[0]);
          const amountKey = 'amount_' + symbol;
          globals.setObjectProperty(amountKey, item[1]);
          await checkPriceAndTrade(5, symbol);
        } catch (error) {
          logger.error("定时任务 Error:", error);
        }
      // }, timeExternal);
      // globals.setObjectProperty("total", total);
    });
  })();
}

// 停止定时任务
export function stopTask() {
  const listSymbols = JupSwapConfig.Symbol.split(",");
  listSymbols.forEach((symbol: string) => {
    killTask(symbol);
  });
}