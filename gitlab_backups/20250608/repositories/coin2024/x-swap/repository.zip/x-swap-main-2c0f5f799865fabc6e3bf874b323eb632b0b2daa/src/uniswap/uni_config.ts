import { Token } from '@uniswap/sdk-core'
import { ethers } from 'ethers'

export enum Environment {
  LOCAL,
  MAINNET,
  WALLET_EXTENSION,
}

interface ExampleConfig {
  env: Environment
  rpc: {
    local: string
    mainnet: string
  }
  wallet: {
    address: string
    privateKey: string
  }
  tokens: {
    in: Token
    amountIn: number
    out: Token
    poolFee: number
  },
  BL: {
    // POOL_FACTORY_CONTRACT_ADDRESS: string,
    // QUOTER_CONTRACT_ADDRESS: string,
    MAX_FEE_PER_GAS: number,
    MAX_PRIORITY_FEE_PER_GAS: number,
    TOKEN_AMOUNT_TO_APPROVE_FOR_TRANSFER: number,
    // WETH_CONTRACT_ADDRESS: string
    // SWAP_ROUTER_ADDRESS: string
  }
}

export const POOL_FACTORY_CONTRACT_ADDRESS =
  '0x1F98431c8aD98523631AE4a59f267346ea31F984' // 用途：用于创建池子的合约地址。
export const QUOTER_CONTRACT_ADDRESS =
  '0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6' // 用途：用于获取报价的合约地址。
// export const MAX_FEE_PER_GAS = 100000000000 // 最大的值GAS 单位Gwei 这是100 Gwei
// export const MAX_PRIORITY_FEE_PER_GAS = 100000000000 // 矿工小费 单位Gwei 这是100 Gwei
// export const TOKEN_AMOUNT_TO_APPROVE_FOR_TRANSFER = 2000 // 授权uniswap可以花费的代币数
export const WETH_CONTRACT_ADDRESS =
  '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2' // 用途：WETH（Wrapped Ether）合约地址。
export const SWAP_ROUTER_ADDRESS = 
  '0xE592427A0AEce92De3Edee1F18E0157C05861564' // 用途：Uniswap V3 路由器合约地址。


export const rpcUrl = "http://127.0.0.1:8545"

export const READABLE_FORM_LEN = 4

const WETH_TOKEN = new Token(
  1,
  '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
  18,
  'WETH',
  'Wrapped Ether'
)

const USDC_TOKEN = new Token(
  1,
  '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
  6,
  'USDC',
  'USD//C'
)

export const ERC20_ABI = [
  // Read-Only Functions
  'function balanceOf(address owner) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',

  // Authenticated Functions
  'function transfer(address to, uint amount) returns (bool)',
  'function approve(address _spender, uint256 _value) returns (bool)',

  // Events
  'event Transfer(address indexed from, address indexed to, uint amount)',
]

// 默认配置
export const CurrentConfig: ExampleConfig = {
  env: Environment.WALLET_EXTENSION,
  rpc: {
      local: 'http://localhost:8545', // 主网的本地分支
      mainnet: 'https://mainnet.chainnodes.org/8b38170b-9605-433f-9784-c48806d27602', // 测试搞得一个主网地址
  },
  wallet: {
    address: '0xf39fd6e51aad88f6f4ce6ab8827279cfffb92266', // 钱包地址
    privateKey:
      '0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80', // 私钥
  },
  tokens: {
      in: USDC_TOKEN,
      amountIn: 1000,
      out: WETH_TOKEN,
      poolFee: 1000,
  },
  BL: {
    MAX_FEE_PER_GAS : 100000000000, // 支付给矿工的Gas费
    MAX_PRIORITY_FEE_PER_GAS : 100000000000, // 小费最大费用
    TOKEN_AMOUNT_TO_APPROVE_FOR_TRANSFER : 2000,
  }
}

// 修改交易配置
export function updateConfigTokens(tokenIn: Token, amountIn: number, tokenOut: Token, poolFee: number) {
  CurrentConfig.tokens.in = tokenIn;
  CurrentConfig.tokens.amountIn = amountIn;
  CurrentConfig.tokens.out = tokenOut;
  CurrentConfig.tokens.poolFee = poolFee;
}

// 修改钱包配置
export function updateConfigWallet(walletAddress: string, privateKey: string) {
  CurrentConfig.wallet.address = walletAddress
  CurrentConfig.wallet.privateKey = privateKey
}

// 修改矿工小费
export function updateConfigBLGAS(gnum: string) {
  CurrentConfig.BL.MAX_FEE_PER_GAS = ethers.utils.parseUnits(gnum, 'gwei').toNumber()
}

// 修改Gas Price
export function updateConfigBLPr(gnum: string) {
  CurrentConfig.BL.MAX_PRIORITY_FEE_PER_GAS = ethers.utils.parseUnits(gnum, 'gwei').toNumber()
}

// 修改可以使用的代币数量
export function updateConfigBLAmount(num: string) {
  CurrentConfig.BL.TOKEN_AMOUNT_TO_APPROVE_FOR_TRANSFER = Number(num)
}
