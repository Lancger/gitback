import { Connection, Keypair, VersionedTransaction } from '@solana/web3.js';
import fetch from 'cross-fetch';
import { Wallet } from '@project-serum/anchor';
// import { parseErrorForTransaction } from '@mercurial-finance/optimist';
import bs58 from 'bs58';
import { logger } from '../commons/logger';
import { JupSwapConfig } from './jup_config';

// 建议您使用自己的RPC端点。
// 此RPC端点仅用于演示目的，以便运行此示例。
const connection = new Connection('https://neat-hidden-sanctuary.solana-mainnet.discover.quiknode.pro/2af5315d336f9ae920028bbb90a73b724dc1bbed/');
if (!JupSwapConfig.PRIVATE_KEY) {
  logger.error('请设置PRIVATE_KEY环境变量');
  process.exit(1);
}

console.log("process.env.PRIVATE_KEY:",JupSwapConfig.PRIVATE_KEY)

const secretKeyBuffer = bs58.decode(JupSwapConfig.PRIVATE_KEY);
const wallet = new Wallet(Keypair.fromSecretKey(secretKeyBuffer));

interface PayResponse {
  swapTransaction: string;
}

export async function pay(inputMint: string, outputMint: string, amount: number, slippageBps?: number): Promise<VersionedTransaction | undefined> {
  try {
    logger.info("支付接收的参数：", inputMint, outputMint, amount);
    
    // 滑点
    let slippageBpsTag = 50;
    if (slippageBps) {
      slippageBpsTag = slippageBps * 10;
    }

    // 获取报价
    const quoteResponse = await (await fetch(`https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amount * 100000000}&slippageBps=${slippageBpsTag}`)).json();
    logger.info("支付：", quoteResponse);

    // 获取swap交易
    const swapResponse = await (await fetch('https://quote-api.jup.ag/v6/swap', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        quoteResponse,
        userPublicKey: wallet.publicKey.toString(),
        wrapAndUnwrapSol: true,
      })
    })).json() as PayResponse;

    const swapTransaction = swapResponse.swapTransaction;

    // 反序列化交易
    let transaction: VersionedTransaction | undefined;
    if (swapTransaction) {
      const swapTransactionBuf = Buffer.from(swapTransaction, 'base64');
      transaction = VersionedTransaction.deserialize(swapTransactionBuf);
    }
    logger.info("处理后的transaction对象：", transaction);

    // 签署交易
    if (transaction) {
      transaction.sign([wallet.payer]);

      // 执行交易
      const rawTransaction = transaction.serialize();
      const txid = await connection.sendRawTransaction(rawTransaction, {
        skipPreflight: true,
        maxRetries: 2
      });
      await connection.confirmTransaction(txid);
      logger.info("发送请求", `https://solscan.io/tx/${txid}`);
      return transaction;
    }
  } catch (error) {
    logger.error("交易错误：", error);
  }
}
