import fetch from 'cross-fetch';

// 定义返回数据的类型 (根据实际返回的数据结构进行定义)
interface StrictList {
    // 根据API返回的数据结构进行调整
    [key: string]: any;
}

export async function strict(): Promise<StrictList> {
    const response = await fetch('https://token.jup.ag/strict');
    const strictList: StrictList = await response.json();
    return strictList;
}
