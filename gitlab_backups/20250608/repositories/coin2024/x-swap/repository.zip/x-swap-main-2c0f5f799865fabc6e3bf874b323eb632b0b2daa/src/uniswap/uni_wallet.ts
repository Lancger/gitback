import { BigNumber, ethers, providers } from 'ethers'
import { CurrentConfig, Environment } from './uni_config'

const mainnetProvider = new ethers.providers.JsonRpcProvider(
    CurrentConfig.rpc.local
)

const wallet = createWallet()

let walletExtensionAddress: string | null = null
export function createWallet(): ethers.Wallet {
    let provider = mainnetProvider
    if (CurrentConfig.env == Environment.LOCAL) {
        provider = new ethers.providers.JsonRpcProvider(CurrentConfig.rpc.local)
    }
    return new ethers.Wallet(CurrentConfig.wallet.privateKey, provider)
}


export function getWalletAddress(): string | null {
    return CurrentConfig.env === Environment.WALLET_EXTENSION
      ? walletExtensionAddress
      : wallet.address
}