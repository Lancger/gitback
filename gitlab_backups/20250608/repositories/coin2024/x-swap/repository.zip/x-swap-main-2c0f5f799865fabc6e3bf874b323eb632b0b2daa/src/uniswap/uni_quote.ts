import { computePoolAddress } from '@uniswap/v3-sdk'
import { CurrentConfig,POOL_FACTORY_CONTRACT_ADDRESS,QUOTER_CONTRACT_ADDRESS,READABLE_FORM_LEN } from './uni_config'
import { BigNumber,ethers,providers } from 'ethers'
import IUniswapV3PoolABI from '@uniswap/v3-core/artifacts/contracts/interfaces/IUniswapV3Pool.sol/IUniswapV3Pool.json'
import Quoter from '@uniswap/v3-periphery/artifacts/contracts/lens/Quoter.sol/Quoter.json'

// const currentPoolAddress = computePoolAddress({
//   factoryAddress: POOL_FACTORY_CONTRACT_ADDRESS,
//   tokenA: CurrentConfig.tokens.in,
//   tokenB: CurrentConfig.tokens.out,
//   fee: CurrentConfig.tokens.poolFee,
// })

// const provider = new ethers.providers.JsonRpcProvider(CurrentConfig.rpc.mainnet)
// const poolContract = new ethers.Contract(
//   currentPoolAddress,
//   IUniswapV3PoolABI.abi,
//   provider
// )

// const [token0, token1, fee, liquidity, slot0] = await Promise.all([
//   poolContract.token0(),
//   poolContract.token1(),
//   poolContract.fee(),
//   poolContract.liquidity(),
//   poolContract.slot0(),
// ])


// const quotedAmountOut = await quoterContract.callStatic.quoteExactInputSingle(
//   token0,
//   token1,
//   fee,
//   fromReadableAmount(
//     CurrentConfig.tokens.amountIn,
//     CurrentConfig.tokens.in.decimals
//   ).toString(),
//   0
// )

const quoterContract = new ethers.Contract(
  QUOTER_CONTRACT_ADDRESS,
  Quoter.abi,
  getProvider()
)

export function getProvider(): providers.Provider {
  return new ethers.providers.JsonRpcProvider(CurrentConfig.rpc.local)
}

export function fromReadableAmount(
  amount: number,
  decimals: number
): BigNumber {
  return ethers.utils.parseUnits(amount.toString(), decimals)
}

export function toReadableAmount(rawAmount: number, decimals: number): string {
  return ethers.utils
    .formatUnits(rawAmount, decimals)
    .slice(0, READABLE_FORM_LEN)
}

// 核心quote函数
export async function quote(): Promise<string> {
  const quoterContract = new ethers.Contract(
    QUOTER_CONTRACT_ADDRESS,
    Quoter.abi,
    getProvider()
  )

  // console.log('quoterContract=====',quoterContract)

  const poolConstants = await getPoolConstants()

  console.log('poolConstants=====',poolConstants)

  const quotedAmountOut = await quoterContract.callStatic.quoteExactInputSingle(
    poolConstants.token0,
    poolConstants.token1,
    poolConstants.fee,
    fromReadableAmount(
      CurrentConfig.tokens.amountIn,
      CurrentConfig.tokens.in.decimals
    ).toString(),
    0
  )

  console.log('quotedAmountOut=====',quotedAmountOut)

  return toReadableAmount(quotedAmountOut, CurrentConfig.tokens.out.decimals)
}


async function getPoolConstants(): Promise<{
  token0: string
  token1: string
  fee: number
}> {
  const currentPoolAddress = computePoolAddress({
    factoryAddress: POOL_FACTORY_CONTRACT_ADDRESS,
    tokenA: CurrentConfig.tokens.in,
    tokenB: CurrentConfig.tokens.out,
    fee: CurrentConfig.tokens.poolFee,
  })

  // console.log('currentPoolAddress=====',currentPoolAddress)

  const poolContract = new ethers.Contract(
    currentPoolAddress,
    IUniswapV3PoolABI.abi,
    getProvider()
  )

  // console.log('poolContract=====',poolContract)
  console.log('token0=====',)
  // console.log('token1=====',poolContract.token1())
  // console.log('fee=====',poolContract.fee())

  poolContract.token0().then((res: any) => {
    console.log('token0=====',res)
  })

  const [token0, token1, fee] = await Promise.all([
    poolContract.token0(),
    poolContract.token1(),
    poolContract.fee(),
  ])

  return {
    token0,
    token1,
    fee,
  }
}

interface PoolInfo {
  token0: string
  token1: string
  fee: number
  tickSpacing: number
  sqrtPriceX96: ethers.BigNumber
  liquidity: ethers.BigNumber
  tick: number
}

// 会创建一个以太坊的合约，并从池中获取元数据
export async function getPoolInfo(): Promise<PoolInfo> {
  const provider = getProvider()
  if (!provider) {
    throw new Error('No provider')
  }

  const currentPoolAddress = computePoolAddress({
    factoryAddress: POOL_FACTORY_CONTRACT_ADDRESS,
    tokenA: CurrentConfig.tokens.in,
    tokenB: CurrentConfig.tokens.out,
    fee: CurrentConfig.tokens.poolFee,
  })

  const poolContract = new ethers.Contract(
    currentPoolAddress,
    IUniswapV3PoolABI.abi,
    provider
  )

  const [token0, token1, fee, tickSpacing, liquidity, slot0] =
  await Promise.all([
    poolContract.token0(),
    poolContract.token1(),
    poolContract.fee(),
    poolContract.tickSpacing(),
    poolContract.liquidity(),
    poolContract.slot0(),
  ])

  return {
    token0,
    token1,
    fee,
    tickSpacing,
    liquidity,
    sqrtPriceX96: slot0[0],
    tick: slot0[1],
  }
}