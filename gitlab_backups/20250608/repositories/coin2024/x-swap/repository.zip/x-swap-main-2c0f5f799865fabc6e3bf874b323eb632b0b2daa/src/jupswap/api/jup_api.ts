import { startTask,stopTask } from "../jup_task";
import R from "../../commons/R";
import { Request, Response } from "express";

// 开启任务
export function jupTaskStart(req: Request,res: Response) {
    startTask();
    res.json(R.success(null))
} 

export function jupTaskStop(req: Request,res: Response) {
    stopTask()
    res.json(R.success(null))
} 