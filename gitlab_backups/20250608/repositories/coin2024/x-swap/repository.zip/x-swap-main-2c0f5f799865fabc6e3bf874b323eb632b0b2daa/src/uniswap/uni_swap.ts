import {
    Currency,
    CurrencyAmount,
    Percent,
    Token,
    TradeType,
} from '@uniswap/sdk-core'
import {
    Pool,
    Route,
    SwapOptions,
    SwapQuoter,
    SwapRouter,
    Trade,
  } from '@uniswap/v3-sdk'
import { getPoolInfo } from './uni_quote'
import { 
    CurrentConfig, Environment,
    QUOTER_CONTRACT_ADDRESS,
    ERC20_ABI,SWAP_ROUTER_ADDRESS
} from './uni_config'
import { BigNumber, ethers, providers } from 'ethers'
import { createWallet,getWalletAddress } from './uni_wallet'
import { fromReadableAmount } from './uni_quote'
import JSBI from 'jsbi'

// 这里的pool是可以存在多个的
// - PoolA: USDC/ WETH
// - PoolB: USDT/ WETH
// - PoolC: USDT/ DAI
// PoolA -> PoolB -> PoolC

// 获取
async function getOutputQuote(route: Route<Currency, Currency>) {
  const provider = getProvider()

  if (!provider) {
    throw new Error('Provider required to get pool state')
  }

  const { calldata } = await SwapQuoter.quoteCallParameters(
    route,
    CurrencyAmount.fromRawAmount(
      CurrentConfig.tokens.in,
      fromReadableAmount(
        CurrentConfig.tokens.amountIn,
        CurrentConfig.tokens.in.decimals
      ).toString()
    ),
    TradeType.EXACT_INPUT,
    {
      useQuoterV2: true,
    }
  )

  // 报价信息
  const quoteCallReturnData = await provider.call({
    to: QUOTER_CONTRACT_ADDRESS,
    data: calldata,
  })
  
  // 解码并返回
  return ethers.utils.defaultAbiCoder.decode(['uint256'], quoteCallReturnData)
}


export function getProvider(): providers.Provider | null {
    return CurrentConfig.env === Environment.WALLET_EXTENSION
        ? wallet.provider
        : wallet.provider
}
const wallet = createWallet()

// const browserExtensionProvider = createBrowserExtensionProvider()
// let walletExtensionAddress: string | null = null
// function createBrowserExtensionProvider(): ethers.providers.Web3Provider | null {
//   try {
//     return new ethers.providers.Web3Provider(window?.ethereum, 'any')
//   } catch (e) {
//     console.log('No Wallet Extension Found')
//     return null
//   }
// }
// export async function connectBrowserExtensionWallet() {
//   if (!window.ethereum) {
//     return null
//   }

//   const { ethereum } = window
//   const provider = new ethers.providers.Web3Provider(ethereum)
//   const accounts = await provider.send('eth_requestAccounts', [])

//   if (accounts.length !== 1) {
//     return
//   }

//   walletExtensionAddress = accounts[0]
//   return walletExtensionAddress
// }

export type TokenTrade = Trade<Token, Token, TradeType>
// uncheckedTrade函数来创建交易
export async function createTrade(): Promise<TokenTrade> {
    const poolInfo = await getPoolInfo()

    // 这里的pool是可以存在多个的
    // - PoolA: USDC/ WETH
    // - PoolB: USDT/ WETH
    // - PoolC: USDT/ DAI
    // PoolA -> PoolB -> PoolC
    // 这里只创建了一条线
    const pool = new Pool(
        CurrentConfig.tokens.in,
        CurrentConfig.tokens.out,
        CurrentConfig.tokens.poolFee,
        poolInfo.sqrtPriceX96.toString(),
        poolInfo.liquidity.toString(),
        poolInfo.tick
    )

    // 拟交易路线
    const swapRoute = new Route(
        [pool],
        CurrentConfig.tokens.in,
        CurrentConfig.tokens.out
    )

    // 我们现在需要获取给定示例的报价
    const amountOut = await getOutputQuote(swapRoute)

    // uncheckedTrade函数来创建交易
    const uncheckedTrade = Trade.createUncheckedTrade({
        route: swapRoute,
        inputAmount: CurrencyAmount.fromRawAmount(
        CurrentConfig.tokens.in,
        fromReadableAmount(
            CurrentConfig.tokens.amountIn,
            CurrentConfig.tokens.in.decimals
        ).toString()
        ),
        outputAmount: CurrencyAmount.fromRawAmount(
        CurrentConfig.tokens.out,
        JSBI.BigInt(amountOut)
        ),
        tradeType: TradeType.EXACT_INPUT,
    })

    return uncheckedTrade
}


export enum TransactionState {
    Failed = 'Failed',
    New = 'New',
    Rejected = 'Rejected',
    Sending = 'Sending',
    Sent = 'Sent',
}

export async function getTokenTransferApproval(
    token: Token
  ): Promise<TransactionState> {
    const provider = getProvider()
    const address = getWalletAddress()
    if (!provider || !address) {
      console.log('No Provider Found')
      return TransactionState.Failed
    }
  
    try {
      const tokenContract = new ethers.Contract(
        token.address,
        ERC20_ABI,
        provider
      )
  
      const transaction = await tokenContract.populateTransaction.approve(
        SWAP_ROUTER_ADDRESS,
        fromReadableAmount(
          CurrentConfig.BL.TOKEN_AMOUNT_TO_APPROVE_FOR_TRANSFER,
          token.decimals
        ).toString()
      )
  
      return sendTransaction({
        ...transaction,
        from: address,
      })
    } catch (e) {
      console.error(e)
      return TransactionState.Failed
    }
  }

// 核心代码块2，发送执行交易请求
export async function executeTrade(
    trade: TokenTrade
  ): Promise<TransactionState> {
    const walletAddress = getWalletAddress()
    const provider = getProvider()
  
    if (!walletAddress || !provider) {
      throw new Error('Cannot execute a trade without a connected wallet')
    }
  
    // Give approval to the router to spend the token
    const tokenApproval = await getTokenTransferApproval(CurrentConfig.tokens.in)
  
    // Fail if transfer approvals do not go through
    if (tokenApproval !== TransactionState.Sent) {
      return TransactionState.Failed
    }
  
    // 设置交易参数
    const options: SwapOptions = {
      slippageTolerance: new Percent(50, 10_000), // 50 bips, or 0.50%  滑点
      deadline: Math.floor(Date.now() / 1000) + 60 * 20, // 20 minutes from the current Unix time 时间戳
      recipient: walletAddress,
    }
  
    // 得到交易请求参数
    const methodParameters = SwapRouter.swapCallParameters([trade], options)
  
    // 构建对象
    const tx = {
      data: methodParameters.calldata,
      to: SWAP_ROUTER_ADDRESS,
      value: methodParameters.value,
      from: walletAddress,
      maxFeePerGas: CurrentConfig.BL.MAX_FEE_PER_GAS ? ethers.utils.parseUnits('100','gwei') : CurrentConfig.BL.MAX_FEE_PER_GAS,
      maxPriorityFeePerGas: CurrentConfig.BL.MAX_PRIORITY_FEE_PER_GAS ? ethers.utils.parseUnits('100','gwei') : CurrentConfig.BL.MAX_PRIORITY_FEE_PER_GAS,
    }
  
    // 请求交易
    const res = await sendTransaction(tx)
  
    return res
  }

export async function sendTransaction(
  transaction: ethers.providers.TransactionRequest
): Promise<TransactionState> {
  // if (CurrentConfig.env === Environment.WALLET_EXTENSION) {
  //   return sendTransactionViaExtension(transaction)
  // } else {
    if (transaction.value) {
      transaction.value = BigNumber.from(transaction.value)
    }
    return sendTransactionViaWallet(transaction)
  // }
}

// async function sendTransactionViaExtension(
//   transaction: ethers.providers.TransactionRequest
// ): Promise<TransactionState> {
  // try {
  //   const receipt = await browserExtensionProvider?.send(
  //     'eth_sendTransaction',
  //     [transaction]
  //   )
  //   if (receipt) {
  //     return TransactionState.Sent
  //   } else {
  //     return TransactionState.Failed
  //   }
  // } catch (e) {
  //   console.log(e)
  //   return TransactionState.Rejected
  // }
  // try {
  //   const txHash = await browserExtensionProvider?.send(
  //     'eth_sendTransaction',
  //     [transaction]
  //   )

  //   if (!txHash) {
  //     return TransactionState.Failed
  //   }

  //   const provider = new ethers.providers.Web3Provider(window.ethereum)
  //   const receipt = await provider.waitForTransaction(txHash)

  //   if (receipt.status === 1) {
  //     return TransactionState.Sent
  //   } else {
  //     return TransactionState.Failed
  //   }
  // } catch (e) {
  //   console.log(e)
  //   return TransactionState.Rejected
  // }
// }

async function sendTransactionViaWallet(
  transaction: ethers.providers.TransactionRequest
): Promise<TransactionState> {
  // if (transaction.value) {
  //   transaction.value = BigNumber.from(transaction.value)
  // }
  // const txRes = await wallet.sendTransaction(transaction)

  // let receipt = null
  // const provider = getProvider()
  // if (!provider) {
  //   return TransactionState.Failed
  // }

  // while (receipt === null) {
  //   try {
  //     receipt = await provider.getTransactionReceipt(txRes.hash)

  //     if (receipt === null) {
  //       continue
  //     }
  //   } catch (e) {
  //     console.log(`Receipt error:`, e)
  //     break
  //   }
  // }

  // // Transaction was successful if status === 1
  // if (receipt) {
  //   return TransactionState.Sent
  // } else {
  //   return TransactionState.Failed
  // }
  if (transaction.value) {
    transaction.value = BigNumber.from(transaction.value)
  }
  const txRes = await wallet.sendTransaction(transaction)

  const provider = getProvider()
  if (!provider) {
    return TransactionState.Failed
  }

  try {
    const receipt = await provider.waitForTransaction(txRes.hash)
    if (receipt.status === 1) {
      return TransactionState.Sent
    } else {
      return TransactionState.Failed
    }
  } catch (e) {
    console.log(`Receipt error:`, e)
    return TransactionState.Failed
  }
}