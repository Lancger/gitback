import fetch from 'cross-fetch';

// 定义返回数据的类型 (根据实际返回的数据结构进行定义)
interface QuoteResponse {
    // 根据API返回的数据结构进行调整
    [key: string]: any;
}

export async function quote(inputMint: string, outputMint: string, amount: number, slippageBps?: number): Promise<QuoteResponse> {
    let slippageBpsTag = 50;
    if (slippageBps) {
        slippageBpsTag = slippageBps;
    }

    const response = await fetch(`https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amount * 100000000}&slippageBps=${slippageBpsTag}`);
    const quoteResponse: QuoteResponse = await response.json();
    return quoteResponse;
}
