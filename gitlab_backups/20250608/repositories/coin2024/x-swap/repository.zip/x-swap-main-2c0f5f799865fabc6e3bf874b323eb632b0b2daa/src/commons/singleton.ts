// 定义类型
type SingletonType = {
    _value: any;
    _object: { [key: string]: any };
  
    value: any;
    object: { [key: string]: any };
  
    setObjectProperty(key: string, value: any): void;
    getObjectProperty(key: string): any;
  };
  
  // 全局对象工具
  const Globals: SingletonType = {
    _value: null,
    _object: {},
  
    get value() {
      return this._value;
    },
  
    set value(newValue: any) {
      this._value = newValue;
    },
  
    get object() {
      return this._object;
    },
  
    setObjectProperty(key: string, value: any) {
      this._object[key] = value;
    },
  
    getObjectProperty(key: string) {
      return this._object[key];
    },
  };
  
  export default Globals;
  