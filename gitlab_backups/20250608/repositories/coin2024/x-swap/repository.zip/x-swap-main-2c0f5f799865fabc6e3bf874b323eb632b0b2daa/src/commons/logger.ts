// logger.js
import { createLogger, format, transports } from 'winston';
const { combine, timestamp, printf, colorize } = format;

// 自定义日志格式
const myFormat = printf(({ level, message, timestamp }) => {
  return `${timestamp} ${level}: ${message}`;
});

// 创建Winston日志实例
export const logger = createLogger({
  level: 'info',
  format: combine(
    timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    colorize(),
    myFormat
  ),
  transports: [
    new transports.Console(),
    // 输出所有日志到app.log文件
    new transports.File({ filename: 'app.log' }),
    // 仅输出错误日志到error.log文件
    new transports.File({ filename: 'error.log', level: 'error' })
  ],
});
