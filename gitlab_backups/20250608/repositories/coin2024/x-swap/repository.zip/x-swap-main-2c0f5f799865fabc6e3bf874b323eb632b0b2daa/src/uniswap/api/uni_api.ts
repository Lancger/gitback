import R from '../../commons/R';
import { executeTrade,createTrade } from '../uni_swap';
import { quote } from '../uni_quote';
import e, { Request, Response } from 'express';
import { logger } from '../../commons/logger'

export function uniStarTask(req:Request,res:Response){
    createTrade().then(r=>{
        executeTrade(r).then(re=>{
            res.json(R.success(re))
        })
    }).catch(e=>{
        logger.error(e)
        res.json(R.fail(e))
    })
    // res.json(R.success('success'));
}

export function uniQuote(req:Request,res:Response){
    quote().then(r=>{
        res.json(R.success(r))
    }).catch(e=>{
        logger.error(e)
        res.json(R.fail(e))
    })
    // res.json(R.success('success'));
}