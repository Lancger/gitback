class R {
    code: number;

    data: any;

    msg: string;
    constructor(code: number, data: any, msg: string) {
        this.code = code;
        this.data = data;
        this.msg = msg;
    }

    static success(data: any, msg: string = 'success') {
        return new R(200, data, msg);
    }

    static fail(msg: string = 'fail') {
        return new R(500, null, msg);
    }
}

export default R;